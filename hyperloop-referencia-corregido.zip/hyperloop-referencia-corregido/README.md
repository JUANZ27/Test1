# IBK11 – Cuenta Negocios – Selenium BDD

Proyecto reconstruido con la misma base tecnológica del ZIP de referencia para evitar incompatibilidades entre versiones.

## Stack alineado al proyecto de referencia

- Java 11 como nivel de compilación.
- Serenity BDD `3.6.21`.
- Cucumber integrado mediante `serenity-cucumber`.
- JUnit 4 y `CucumberWithSerenity`.
- Maven Failsafe ejecutando `WebRunnerTest` durante `verify`.
- Reporte Serenity agregado en `post-integration-test`.
- Paquetes bajo `pe.interbank.hyperloop.automation`.
- Page Object directo para reducir inyección y dependencias innecesarias.

No se copiaron credenciales, secretos de Jira/Xray, archivos de datos ni integraciones privadas del proyecto original.

## ChromeDriver local

El ejecutable activo para Windows está dentro del proyecto:

```text
src/test/resources/webdriver/windows/chromedriver.exe
```

El runner convierte esta ruta en absoluta antes de que Serenity cree el navegador. Por ello, el proyecto no depende de Selenium Manager ni de un ChromeDriver instalado globalmente.

La copia del ChromeDriver Linux encontrada en el ZIP de referencia se conserva únicamente como evidencia en:

```text
src/test/resources/webdriver/referencia-linux/chromedriver
```

No se usa en Windows.

## Flujo automatizado

1. Abrir Cuenta Negocios en staging.
2. Seleccionar **Entendido** si aparece el modal.
3. Seleccionar **Persona Jurídica** en el componente Shadow DOM.
4. Seleccionar **Continuar**.
5. Ingresar RUC `20653561378`.
6. Ingresar DNI `47396815`.
7. Marcar la política de privacidad.
8. Marcar la validación biométrica.
9. Seleccionar **Comencemos**.
10. Finalizar sin validar ni resolver CAPTCHA.

## Ejecutar

Desde la raíz del proyecto:

```text
ejecutar-flujo.bat
```

O desde terminal:

```bat
mvn clean verify -Denvironment=staging -Dcucumber.filter.tags="@IBK11" -Dwebdriver.chrome.driver="%CD%\src\test\resources\webdriver\windows\chromedriver.exe"
```

## Comprobar el proyecto antes de ejecutar

```text
verificar-entorno.bat
compilar-proyecto.bat
```

`verificar-entorno.bat` muestra las versiones de Java, Maven, Chrome y ChromeDriver. La versión principal de Chrome y ChromeDriver debe coincidir.

## Reporte

```text
target/site/serenity/index.html
```

El archivo `ejecutar-flujo.bat` abre el reporte al finalizar. También puede usar:

```text
abrir-reporte.bat
```

## Capturas del flujo

El Word original se encuentra en:

```text
documentos/Flujo ibk11.docx
```

## Problemas corregidos respecto de la entrega anterior

- Se eliminó Serenity 5 y se volvió a Serenity `3.6.21`, usada por el proyecto de referencia.
- Se reemplazaron las anotaciones `net.serenitybdd.annotations` por `net.thucydides.core.annotations`.
- Se usa JUnit 4 con `CucumberWithSerenity`.
- El runner se llama `WebRunnerTest`, igual que el patrón del plugin Failsafe.
- La ejecución correcta es `mvn clean verify`, no solamente `mvn test`.
- ChromeDriver se obtiene desde una ruta absoluta calculada desde `%CD%`.
- Se eliminó todo paso de CAPTCHA.
- Se simplificaron las dependencias para reducir conflictos.
- Los componentes Hyperloop se manipulan mediante Shadow DOM abierto y selectores alternativos.
