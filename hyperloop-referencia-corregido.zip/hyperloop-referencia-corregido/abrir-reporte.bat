@echo off
setlocal
cd /d "%~dp0"
if exist "target\site\serenity\index.html" (
  start "" "target\site\serenity\index.html"
) else (
  echo No existe el reporte. Ejecute primero ejecutar-flujo.bat
  pause
)
