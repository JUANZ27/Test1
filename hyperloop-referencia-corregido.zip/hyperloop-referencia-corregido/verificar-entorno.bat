@echo off
setlocal
cd /d "%~dp0"

echo ===== JAVA =====
java -version

echo.
echo ===== MAVEN =====
mvn -version

echo.
echo ===== CHROMEDRIVER DEL PROYECTO =====
set "DRIVER=%CD%\src\test\resources\webdriver\windows\chromedriver.exe"
if exist "%DRIVER%" (
  "%DRIVER%" --version
) else (
  echo NO ENCONTRADO: %DRIVER%
)

echo.
echo ===== GOOGLE CHROME INSTALADO =====
powershell -NoProfile -Command "$paths=@('${env:ProgramFiles}\Google\Chrome\Application\chrome.exe','${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe','${env:LocalAppData}\Google\Chrome\Application\chrome.exe'); $chrome=$paths|Where-Object{Test-Path $_}|Select-Object -First 1; if($chrome){(Get-Item $chrome).VersionInfo.ProductVersion; Write-Host $chrome}else{Write-Host 'Chrome no encontrado en las rutas comunes'}"

echo.
echo La version principal de Chrome y ChromeDriver debe ser la misma.
pause
