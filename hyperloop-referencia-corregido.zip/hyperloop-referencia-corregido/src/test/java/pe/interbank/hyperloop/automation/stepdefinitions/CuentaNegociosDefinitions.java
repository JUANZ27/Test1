package pe.interbank.hyperloop.automation.stepdefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import pe.interbank.hyperloop.automation.ui.assi.cuentanegocio.CuentaNegociosPage;
import pe.interbank.hyperloop.automation.utils.Demo;

public class CuentaNegociosDefinitions {

    @Managed
    WebDriver driver;

    private CuentaNegociosPage cuentaNegociosPage;

    private CuentaNegociosPage pagina() {
        if (cuentaNegociosPage == null) {
            cuentaNegociosPage = new CuentaNegociosPage(driver);
        }
        return cuentaNegociosPage;
    }

    @Dado("que el usuario ingresa al portal de Cuenta Negocios")
    public void ingresarAlPortal() {
        pagina().openPortal();
        Demo.pause();
    }

    @Y("acepta las recomendaciones iniciales si aparecen")
    public void aceptarRecomendacionesIniciales() {
        pagina().acceptInitialRecommendationsIfPresent();
        Demo.pause();
    }

    @Cuando("selecciona el tipo de cuenta {string}")
    public void seleccionarTipoCuenta(String tipoCuenta) {
        pagina().selectAccountType(tipoCuenta);
        Demo.pause();
    }

    @Y("presiona el botón Continuar")
    public void presionarContinuar() {
        pagina().clickContinue();
        Demo.pause();
    }

    @Y("ingresa el RUC {string}")
    public void ingresarRuc(String ruc) {
        pagina().enterRuc(ruc);
        Demo.pause();
    }

    @Y("el DNI del representante legal {string}")
    public void ingresarDni(String dni) {
        pagina().enterDni(dni);
        Demo.pause();
    }

    @Y("acepta la política de privacidad")
    public void aceptarPrivacidad() {
        pagina().acceptPrivacy();
        Demo.pause();
    }

    @Y("acepta la validación biométrica")
    public void aceptarBiometria() {
        pagina().acceptBiometrics();
        Demo.pause();
    }

    @Y("resuelve el captcha si aparece")
    public void resolverCaptcha() {
        pagina().handleCaptchaIfPresent();
    }

    @Entonces("presiona el botón Comencemos")
    public void presionarComencemos() {
        pagina().clickStart();
        Demo.finalPause();
    }
}
