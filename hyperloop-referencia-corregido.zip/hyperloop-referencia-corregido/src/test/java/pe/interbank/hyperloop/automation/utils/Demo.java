package pe.interbank.hyperloop.automation.utils;

public final class Demo {

    private Demo() {
    }

    public static void pause() {
        if (TestConfiguration.getBoolean("demo.mode")) {
            sleep(TestConfiguration.getInt("demo.pause.ms"));
        }
    }

    public static void finalPause() {
        if (TestConfiguration.getBoolean("demo.mode")) {
            sleep(TestConfiguration.getInt("final.pause.ms"));
        }
    }

    private static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("La pausa visual fue interrumpida", exception);
        }
    }
}
