package pe.interbank.hyperloop.automation.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class TestConfiguration {

    private static final Properties VALUES = load();

    private TestConfiguration() {
    }

    private static Properties load() {
        Properties properties = new Properties();
        try (InputStream input = TestConfiguration.class.getClassLoader()
                .getResourceAsStream("test.properties")) {
            if (input == null) {
                throw new IllegalStateException("No se encontró test.properties");
            }
            properties.load(input);
            return properties;
        } catch (IOException exception) {
            throw new IllegalStateException("No se pudo leer test.properties", exception);
        }
    }

    public static String get(String name) {
        String systemValue = System.getProperty(name);
        if (systemValue != null && !systemValue.trim().isEmpty()) {
            return systemValue.trim();
        }
        String propertyValue = VALUES.getProperty(name);
        if (propertyValue == null || propertyValue.trim().isEmpty()) {
            throw new IllegalArgumentException("No existe la propiedad: " + name);
        }
        return propertyValue.trim();
    }

    public static int getInt(String name) {
        return Integer.parseInt(get(name));
    }

    public static boolean getBoolean(String name) {
        return Boolean.parseBoolean(get(name));
    }
}
