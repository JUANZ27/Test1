package pe.interbank.hyperloop.automation.utils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;

public final class LocalChromeDriver {

    private LocalChromeDriver() {
    }

    public static Path configureFromProjectDirectory() {
        String osName = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        Path projectDirectory = Paths.get(System.getProperty("user.dir"))
                .toAbsolutePath()
                .normalize();

        if (!osName.contains("win")) {
            throw new IllegalStateException(
                    "Este paquete está preparado para Windows 64 bits. "
                            + "El ChromeDriver activo es chromedriver.exe.");
        }

        Path driver = projectDirectory
                .resolve("src/test/resources/webdriver/windows/chromedriver.exe")
                .normalize();

        if (!Files.isRegularFile(driver)) {
            throw new IllegalStateException(
                    "No se encontró ChromeDriver dentro del proyecto: " + driver);
        }

        System.setProperty("webdriver.chrome.driver", driver.toString());
        System.setProperty("webdriver.autodownload", "false");

        System.out.println("[IBK11] ChromeDriver local: " + driver);
        return driver;
    }
}
