package pe.interbank.hyperloop.automation.runners;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;
import pe.interbank.hyperloop.automation.utils.LocalChromeDriver;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources/features/",
        glue = "pe.interbank.hyperloop.automation.stepdefinitions",
        plugin = {
                "pretty",
                "json:target/build/cucumber-reports/cucumber.json"
        },
        tags = "@IBK11",
        snippets = CucumberOptions.SnippetType.CAMELCASE,
        monochrome = true
)
public class WebRunnerTest {

    static {
        // Se ejecuta antes de que Serenity cree ChromeDriver.
        LocalChromeDriver.configureFromProjectDirectory();
    }

    private WebRunnerTest() {
    }
}
