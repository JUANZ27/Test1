package pe.interbank.hyperloop.automation.ui.assi.cuentanegocio;

import java.text.Normalizer;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import pe.interbank.hyperloop.automation.utils.TestConfiguration;

@DefaultUrl("page:webdriver.base.url")
public class CuentaNegociosPage extends PageObject {

    private static final Logger LOG = Logger.getLogger(CuentaNegociosPage.class.getName());

    // Timeout para resolución manual de CAPTCHA (segundos)
    private static final int CAPTCHA_WAIT_SECONDS = 180;

    private static final By BODY = By.tagName("body");

    private static final By BOTON_ENTENDIDO = By.xpath(
            "//a-hyperloop-button[@text='Entendido']//button"
                    + " | //button[normalize-space()='Entendido']"
                    + " | /html/body/hcommon-dynamic-modal-ui/"
                    + "hcommon-biometrics-express-modal-container/"
                    + "hcommon-biometrics-express-modal-component-ui/section/div/section/div[4]/"
                    + "a-hyperloop-button/button");

    private static final By BOTON_CONTINUAR = By.xpath(
            "//a-hyperloop-button[@text='Continuar']//button"
                    + " | //button[normalize-space()='Continuar']");

    private static final By BOTON_COMENCEMOS = By.xpath(
            "//a-hyperloop-button[@text='Comencemos']//button"
                    + " | //button[normalize-space()='Comencemos']");

    private static final By BOTON_COMENCEMOS_ID = By.cssSelector(
            "a-hyperloop-button#nextStepDataNaturalPerson button, #nextStepDataNaturalPerson button, button#nextStepDataNaturalPerson");

    private static final By ETAPA_NEGOCIO_RADIO = By.cssSelector(
            "li.asc-screen__option input[type='radio'], .asc-screen__option-input");

    /** Selector del contenedor visual clickeable de cada opción (visible, no el input oculto) */
    private static final By ETAPA_NEGOCIO_OPCION_VISIBLE = By.cssSelector(
            "li.asc-screen__option");

    private static final By ETAPA_NEGOCIO_CONTINUAR = By.cssSelector(
            "button.asc-screen__continue");

    private static final String[] SELECT_HOSTS = {
            "a-hyperloop-select-subtitle[formcontrolname='chooseAccountType']",
            "a-hyperloop-select-subtitle",
            "m-hyperloop-select a-hyperloop-select",
            "a-hyperloop-select"
    };

    private static final String[] RUC_HOSTS = {
            "m-hyperloop-inputgroup-text[label='RUC de la empresa'] a-hyperloop-input",
            "m-hyperloop-inputgroup-text#formCompanyRuc a-hyperloop-input",
            "#formCompanyRuc a-hyperloop-input",
            "a-hyperloop-input[formcontrolname='companyRuc']"
    };

    private static final String[] DNI_HOSTS = {
            "m-hyperloop-inputgroup-text[label='DNI del Representante Legal'] a-hyperloop-input",
            "m-hyperloop-inputgroup-text#formLegalRepresentative a-hyperloop-input",
            "#formLegalRepresentative a-hyperloop-input",
            "a-hyperloop-input[formcontrolname='legalRepresentative']",
            "a-hyperloop-input[formcontrolname='documentNumber']"
    };

    private static final String[] PRIVACY_HOSTS = {
            "m-hyperloop-checkbox#check-pdp",
            "#check-pdp",
            "m-hyperloop-checkbox[id*='pdp']"
    };

    private static final String[] BIOMETRIC_HOSTS = {
            "m-hyperloop-checkbox#check-biometrics",
            "#check-biometrics",
            "m-hyperloop-checkbox[id*='biometric']"
    };

    public CuentaNegociosPage(WebDriver driver) {
        super(driver);
    }

    public void openPortal() {
        open();
        waitForDocumentReady();
        waitForBody();
    }

    public boolean acceptInitialRecommendationsIfPresent() {
        try {
            WebElement button = shortWait(15).until(driver -> firstClickable(BOTON_ENTENDIDO));
            safeClick(button);
            return true;
        } catch (TimeoutException ignored) {
            return false;
        }
    }

    public void selectAccountType(String accountType) {
        WebElement host = waitForHost(SELECT_HOSTS, "selector de tipo de cuenta");
        String normalizedExpected = normalizeText(accountType);

        WebElement trigger = fluentWait().until(driver -> {
            Object value = execute(
                    "const host=arguments[0];"
                            + "if(!host || !host.shadowRoot) return null;"
                            + "return host.shadowRoot.querySelector('#dropdown-select .select-styled,"
                            + " .select-styled, [role=combobox], button');",
                    host);
            return displayedElement(value);
        });
        safeClick(trigger);

        WebElement option = fluentWait().until(driver -> {
            Object value = execute(
                    "const host=arguments[0], expected=arguments[1], expectedRaw=arguments[2];"
                            + "if(!host || !host.shadowRoot) return null;"
                            + "const nodes=host.shadowRoot.querySelectorAll('ul#list li, li, [role=option]');"
                            + "for(const node of Array.from(nodes)){"
                            + "  const raw=(node.textContent||'').trim().replace(/\\s+/g,' ');"
                            + "  const normalized=raw.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();"
                            + "  const byId=((node.id||'').trim().toLowerCase()===expectedRaw) || ((node.id||'').trim().toLowerCase()===expected);"
                            + "  const byText=normalized===expected || normalized.startsWith(expected + ' ') || normalized.includes(expected);"
                            + "  if(byId || byText) return node;"
                            + "}"
                            + "return null;",
                    host,
                    normalizedExpected,
                    accountType.trim().toLowerCase(Locale.ROOT));
            return displayedElement(value);
        });
        safeClick(option);
    }

    public void clickContinue() {
        safeClick(waitForClickable(BOTON_CONTINUAR, "botón Continuar"));
        completeBusinessStageIfPresent();
        fluentWait().until(driver -> findHost(RUC_HOSTS) != null);
    }

    public void enterRuc(String ruc) {
        completeBusinessStageIfPresent();
        enterValueInShadowInput(RUC_HOSTS, ruc, "campo RUC", "RUC de la empresa");
    }

    public void enterDni(String dni) {
        completeBusinessStageIfPresent();
        enterValueInShadowInput(DNI_HOSTS, dni, "campo DNI", "DNI del Representante Legal");
    }

    private void completeBusinessStageIfPresent() {
        for (int attempt = 0; attempt < 3; attempt++) {
            if (findHost(RUC_HOSTS) != null) {
                return;
            }

            if (!isBusinessStageVisible()) {
                return;
            }

            // 1. Selenium click en el primer li visible de la lista de opciones
            List<WebElement> opciones = getDriver().findElements(ETAPA_NEGOCIO_OPCION_VISIBLE);
            WebElement primeraOpcion = opciones.stream()
                    .filter(this::isDisplayedSafely)
                    .findFirst()
                    .orElse(null);

            if (primeraOpcion != null) {
                safeClick(primeraOpcion);
            } else {
                // fallback JS en el label
                execute("const lbl = document.querySelector('li.asc-screen__option label,"
                        + " li.asc-screen__option');"
                        + "if(lbl) lbl.click();");
            }

            // 2. Espera que el botón pierda el atributo disabled (hasta 8 s)
            try {
                shortWait(8).until(driver -> {
                    List<WebElement> btns = driver.findElements(ETAPA_NEGOCIO_CONTINUAR);
                    return btns.stream().anyMatch(b -> {
                        try {
                            return b.isDisplayed() && b.getAttribute("disabled") == null;
                        } catch (StaleElementReferenceException ignored) {
                            return false;
                        }
                    });
                });
            } catch (TimeoutException ignored) {
                // intenta el click de todas formas
            }

            // 3. Selenium click en el botón Continuar
            List<WebElement> btns = getDriver().findElements(ETAPA_NEGOCIO_CONTINUAR);
            WebElement continuar = btns.stream()
                    .filter(this::isDisplayedSafely)
                    .findFirst()
                    .orElse(null);

            if (continuar != null) {
                safeClick(continuar);
            }

            // 4. JS click adicional por si Angular no lo procesó
            execute("const btn = document.querySelector('button.asc-screen__continue');"
                    + "if(btn){ btn.removeAttribute('disabled'); btn.click(); }");

            // 5. Espera que la pantalla desaparezca
            try {
                shortWait(8).until(driver -> !isBusinessStageVisible());
                return;
            } catch (TimeoutException ignored) {
                // reintenta el ciclo
            }
        }
    }

    private boolean isBusinessStageVisible() {
        // Usa el li VISIBLE, NO el input[type=radio] que está oculto por CSS
        List<WebElement> opciones = getDriver().findElements(ETAPA_NEGOCIO_OPCION_VISIBLE);
        List<WebElement> btns = getDriver().findElements(ETAPA_NEGOCIO_CONTINUAR);
        boolean tieneOpciones = opciones.stream().anyMatch(this::isDisplayedSafely);
        boolean tieneContinuar = btns.stream().anyMatch(this::isDisplayedSafely);
        return tieneOpciones && tieneContinuar;
    }

    public void acceptPrivacy() {
        setShadowCheckbox(PRIVACY_HOSTS, true, "política de privacidad", "privacidad", "he leido y acepto");
    }

    public void acceptBiometrics() {
        setShadowCheckbox(BIOMETRIC_HOSTS, true, "validación biométrica", "biometria", "identidad", "otp");
    }

    public void clickStart() {
        for (int attempt = 0; attempt < 4; attempt++) {
            handleCaptchaIfPresent();

            clickComencemosOnce();

            try {
                shortWait(6).until(driver -> isCaptchaChallengeVisible() || !isComencemosVisible());
            } catch (TimeoutException ignored) {
                // Continúa con validaciones de estado.
            }

            // Si el CAPTCHA salió justo al click, espera resolución y reintenta.
            if (isCaptchaChallengeVisible()) {
                handleCaptchaIfPresent();
            }

            // Después de resolver CAPTCHA suele requerir un segundo click explícito.
            if (isComencemosVisible()) {
                clickComencemosOnce();
            }

            try {
                boolean advanced = shortWait(5).until(driver -> {
                    if (isCaptchaChallengeVisible()) {
                        return false;
                    }
                    WebElement byText = findVisibleElement(BOTON_COMENCEMOS);
                    WebElement byId = findVisibleElement(BOTON_COMENCEMOS_ID);
                    return byText == null && byId == null;
                });

                if (advanced) {
                    return;
                }
            } catch (TimeoutException ignored) {
                // Reintenta click + resolución de CAPTCHA.
            }
        }

        throw diagnosticTimeout("No fue posible avanzar al presionar el botón Comencemos.",
                new TimeoutException("Comencemos no avanzó tras reintentos"));
    }

    private void clickComencemosOnce() {
        WebElement byId = findVisibleElement(BOTON_COMENCEMOS_ID);
        WebElement byText = findVisibleElement(BOTON_COMENCEMOS);

        if (byId != null) {
            safeClick(byId);
        }
        if (byText != null) {
            safeClick(byText);
        }

        tryClickPrimaryButtonByText("Comencemos");
        execute(
                "const btn=document.querySelector('a-hyperloop-button#nextStepDataNaturalPerson button, #nextStepDataNaturalPerson button, button#nextStepDataNaturalPerson');"
                        + "if(btn){ btn.removeAttribute('disabled'); btn.click(); return true; }"
                        + "return false;");
    }

    private boolean isComencemosVisible() {
        return findVisibleElement(BOTON_COMENCEMOS_ID) != null
                || findVisibleElement(BOTON_COMENCEMOS) != null;
    }

    private WebElement findVisibleElement(By locator) {
        List<WebElement> elements = getDriver().findElements(locator);
        for (WebElement element : elements) {
            if (isDisplayedSafely(element)) {
                return element;
            }
        }
        return null;
    }

    /**
     * Detecta si el reCAPTCHA challenge está activo y espera hasta CAPTCHA_WAIT_SECONDS
     * para que el operador lo resuelva manualmente antes de continuar.
     */
    public void handleCaptchaIfPresent() {
        if (!isCaptchaChallengeVisible()) {
            return;
        }

        LOG.warning("======================================================");
        LOG.warning("  CAPTCHA DETECTADO - Por favor resuélvelo manualmente");
        LOG.warning("  El test esperará hasta " + CAPTCHA_WAIT_SECONDS + " segundos...");
        LOG.warning("======================================================");

        try {
            new FluentWait<>(getDriver())
                    .withTimeout(Duration.ofSeconds(CAPTCHA_WAIT_SECONDS))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class)
                    .until(driver -> !isCaptchaChallengeVisible());
            LOG.warning("CAPTCHA resuelto, continuando el flujo.");
        } catch (TimeoutException e) {
            LOG.warning("Timeout esperando CAPTCHA - intentando continuar de todos modos.");
        }
    }

    private boolean isCaptchaChallengeVisible() {
        // El badge de reCAPTCHA puede estar siempre visible; filtramos challenge real.
        try {
            Object result = execute(
                    "const frames = Array.from(document.querySelectorAll('iframe'));"
                            + "return frames.some(f => {"
                            + "  const src = (f.src || f.getAttribute('src') || '');"
                            + "  const title = (f.title || f.getAttribute('title') || '').toLowerCase();"
                            + "  const isRecaptcha = src.includes('recaptcha') || title.includes('recaptcha');"
                            + "  const isChallenge = isRecaptcha && (src.includes('bframe') || title.includes('challenge'));"
                            + "  if(!isChallenge) return false;"
                            + "  const rect = f.getBoundingClientRect();"
                            + "  const style = window.getComputedStyle(f);"
                            + "  return rect.width > 220 && rect.height > 140 "
                            + "    && style.display !== 'none' && style.visibility !== 'hidden';"
                            + "});");
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            return false;
        }
    }

    private void enterValueInShadowInput(String[] hostSelectors, String value, String description, String... labelHints) {
        WebElement host = waitForInputHost(hostSelectors, description, labelHints);
        WebElement input = fluentWait().until(driver -> {
            Object result = execute(
                    "const host=arguments[0];"
                            + "if(!host) return null;"
                            + "const root = host.shadowRoot || host;"
                            + "const inputs=Array.from(root.querySelectorAll('input'));"
                            + "return inputs.find(el => {"
                            + "  const type=(el.getAttribute('type')||'text').toLowerCase();"
                            + "  const name=(el.getAttribute('name')||'').toLowerCase();"
                            + "  if(type==='hidden' || name.includes('fake-field') || el.getAttribute('aria-hidden')==='true') return false;"
                            + "  const style=window.getComputedStyle(el);"
                            + "  const visible=style.display!=='none' && style.visibility!=='hidden' && el.getClientRects().length>0;"
                            + "  return visible;"
                            + "}) || null;",
                    host);
            return displayedElement(result);
        });

        scrollTo(input);
        safeClick(input);
        input.clear();
        input.sendKeys(value);

        String expected = value.replaceAll("\\D", "");
        String current = readShadowInputValue(host, input);
        if (!expected.equals(current.replaceAll("\\D", ""))) {
            setShadowInputValue(host, input, value);
        }

        fluentWait().until(driver -> {
            Object actual = readShadowInputValue(host, input);
            return actual != null && actual.toString().replaceAll("\\D", "").equals(expected);
        });
    }

    private WebElement waitForInputHost(String[] selectors, String description, String... labelHints) {
        try {
            return waitForHost(selectors, description);
        } catch (TimeoutException ignored) {
            if (labelHints == null || labelHints.length == 0) {
                throw ignored;
            }
        }

        try {
            return fluentWait().until(driver -> {
                Object result = execute(
                        "const labels=arguments[0].map(v => (v||'').trim().toLowerCase());"
                                + "const hosts=Array.from(document.querySelectorAll('m-hyperloop-inputgroup-text, a-hyperloop-input'));"
                                + "const normalize=s => (s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').replace(/\\s+/g,' ').trim().toLowerCase();"
                                + "for(const host of hosts){"
                                + "  const text=normalize(host.getAttribute('label') || host.getAttribute('aria-label') || host.textContent || '');"
                                + "  if(labels.some(label => text.includes(normalize(label)))) return host;"
                                + "}"
                                + "return null;",
                        (Object) labelHints);
                return displayedElement(result);
            });
        } catch (TimeoutException exception) {
            throw diagnosticTimeout(
                    "No se encontró el host por selector ni por label para " + description
                            + ". Selectores: " + Arrays.toString(selectors)
                            + ". Labels: " + Arrays.toString(labelHints),
                    exception);
        }
    }

    private String readShadowInputValue(WebElement host, WebElement input) {
        Object actual = execute(
                "const host=arguments[0], input=arguments[1];"
                        + "const root = host ? (host.shadowRoot || host) : null;"
                        + "const node = input && input.isConnected ? input : (root ? Array.from(root.querySelectorAll('input')).find(el => {"
                        + "  const type=(el.getAttribute('type')||'text').toLowerCase();"
                        + "  const name=(el.getAttribute('name')||'').toLowerCase();"
                        + "  if(type==='hidden' || name.includes('fake-field') || el.getAttribute('aria-hidden')==='true') return false;"
                        + "  const style=window.getComputedStyle(el);"
                        + "  return style.display!=='none' && style.visibility!=='hidden' && el.getClientRects().length>0;"
                        + "}) : null);"
                        + "return node ? (node.value || node.getAttribute('value') || '') : '';",
                host,
                input);
        return actual == null ? "" : actual.toString();
    }

    private void setShadowInputValue(WebElement host, WebElement input, String value) {
        execute(
                "const host=arguments[0], input=arguments[1], nextValue=arguments[2];"
                        + "const root = host ? (host.shadowRoot || host) : null;"
                        + "const node = input && input.isConnected ? input : (root ? Array.from(root.querySelectorAll('input')).find(el => {"
                        + "  const type=(el.getAttribute('type')||'text').toLowerCase();"
                        + "  const name=(el.getAttribute('name')||'').toLowerCase();"
                        + "  if(type==='hidden' || name.includes('fake-field') || el.getAttribute('aria-hidden')==='true') return false;"
                        + "  const style=window.getComputedStyle(el);"
                        + "  return style.display!=='none' && style.visibility!=='hidden' && el.getClientRects().length>0;"
                        + "}) : null);"
                        + "if(!node) return null;"
                        + "node.removeAttribute('readonly');"
                        + "node.removeAttribute('disabled');"
                        + "node.readOnly = false;"
                        + "node.disabled = false;"
                        + "node.focus();"
                        + "node.click();"
                        + "const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;"
                        + "nativeSetter.call(node, '');"
                        + "node.dispatchEvent(new InputEvent('input', {bubbles:true, composed:true, data:'', inputType:'deleteContentBackward'}));"
                        + "for(const ch of String(nextValue)){"
                        + "  node.dispatchEvent(new KeyboardEvent('keydown', {bubbles:true, composed:true, key:ch, code:'Digit'+ch, cancelable:true}));"
                        + "  const start = node.value.length;"
                        + "  node.setRangeText(ch, start, start, 'end');"
                        + "  node.dispatchEvent(new InputEvent('input', {bubbles:true, composed:true, data:ch, inputType:'insertText'}));"
                        + "  node.dispatchEvent(new KeyboardEvent('keyup', {bubbles:true, composed:true, key:ch, code:'Digit'+ch, cancelable:true}));"
                        + "}"
                        + "node.dispatchEvent(new Event('change', {bubbles:true, composed:true}));"
                        + "node.dispatchEvent(new Event('blur', {bubbles:true, composed:true}));"
                        + "if(host && 'value' in host){ try { host.value = nextValue; } catch(e) {} }"
                        + "return node.value || node.getAttribute('value') || '';",
                host,
                input,
                value);
    }

    private void setShadowCheckbox(String[] hostSelectors, boolean expected, String description, String... labelHints) {
        WebElement host = waitForCheckboxHost(hostSelectors, description, labelHints);

        // El input[type=checkbox] suele estar oculto por CSS; lo buscamos sin requerir visibilidad
        WebElement checkbox = fluentWait().until(driver -> {
            Object result = execute(
                    "const host=arguments[0];"
                            + "if(!host) return null;"
                            + "const root = host.shadowRoot || host;"
                            + "return root.querySelector('input[type=checkbox]');",
                    host);
            if (!(result instanceof WebElement)) return null;
            return (WebElement) result;  // no requiere isDisplayed()
        });

        Boolean current = isCheckboxChecked(host, checkbox);
        if (current == null || current != expected) {
            setCheckboxState(host, checkbox, expected);
        }

        fluentWait().until(driver -> {
            Boolean state = isCheckboxChecked(host, checkbox);
            return state != null && state == expected;
        });
    }

    private WebElement waitForCheckboxHost(String[] selectors, String description, String... labelHints) {
        try {
            return waitForHost(selectors, description);
        } catch (TimeoutException ignored) {
            if (labelHints == null || labelHints.length == 0) {
                throw ignored;
            }
        }

        try {
            return fluentWait().until(driver -> {
                Object result = execute(
                        "const labels=arguments[0].map(v => (v||'').trim().toLowerCase());"
                                + "const normalize=s => (s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').replace(/\\s+/g,' ').trim().toLowerCase();"
                                + "const hosts=Array.from(document.querySelectorAll('m-hyperloop-checkbox'));"
                                + "for(const host of hosts){"
                                + "  const text=normalize(host.getAttribute('id') || host.getAttribute('aria-label') || host.textContent || '');"
                                + "  if(labels.some(label => text.includes(normalize(label)))) return host;"
                                + "}"
                                + "return null;",
                        (Object) labelHints);
                return displayedElement(result);
            });
        } catch (TimeoutException exception) {
            throw diagnosticTimeout(
                    "No se encontró el checkbox por selector ni por label para " + description
                            + ". Selectores: " + Arrays.toString(selectors)
                            + ". Labels: " + Arrays.toString(labelHints),
                    exception);
        }
    }

    private Boolean isCheckboxChecked(WebElement host, WebElement checkbox) {
        Object value = execute(
                "const host=arguments[0], checkbox=arguments[1];"
                        + "const root = host ? (host.shadowRoot || host) : null;"
                        + "const node = checkbox && checkbox.isConnected ? checkbox : (root ? root.querySelector('input[type=checkbox]') : null);"
                        + "return node ? !!node.checked : null;",
                host,
                checkbox);
        return value instanceof Boolean ? (Boolean) value : null;
    }

    private void setCheckboxState(WebElement host, WebElement checkbox, boolean expected) {
        execute(
                "const host=arguments[0], checkbox=arguments[1], expected=arguments[2];"
                        + "const root = host ? (host.shadowRoot || host) : null;"
                        + "const node = checkbox && checkbox.isConnected ? checkbox : (root ? root.querySelector('input[type=checkbox]') : null);"
                        + "if(!node) return null;"
                        // Primero intenta click en el label visible
                        + "const label = root ? root.querySelector('label[for=\"' + node.id + '\"], label') : null;"
                        + "if(label && node.checked !== expected){"
                        + "  label.click();"
                        + "}"
                        // Si no cambió, click directo en el input
                        + "if(node.checked !== expected){"
                        + "  node.click();"
                        + "}"
                        // Último recurso: setter nativo + eventos
                        + "if(node.checked !== expected){"
                        + "  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'checked').set;"
                        + "  setter.call(node, expected);"
                        + "  node.dispatchEvent(new Event('input', {bubbles:true, composed:true}));"
                        + "  node.dispatchEvent(new Event('change', {bubbles:true, composed:true}));"
                        + "  node.dispatchEvent(new Event('click', {bubbles:true, composed:true}));"
                        + "}"
                        + "return node.checked;",
                host,
                checkbox,
                expected);
    }

    private void tryClickPrimaryButtonByText(String text) {
        execute(
                "const expected=(arguments[0]||'').trim().toLowerCase();"
                        + "const button=Array.from(document.querySelectorAll('button')).find(b =>"
                        + " (b.textContent||'').trim().toLowerCase()===expected && !b.disabled);"
                        + "if(button){ button.click(); return true; }"
                        + "return false;",
                text);
    }

    private WebElement waitForHost(String[] selectors, String description) {
        try {
            return fluentWait().until(driver -> findHost(selectors));
        } catch (TimeoutException exception) {
            throw diagnosticTimeout(
                    "No se encontró el host Shadow DOM para " + description
                            + ". Selectores: " + Arrays.toString(selectors),
                    exception);
        }
    }

    private WebElement findHost(String[] selectors) {
        for (String selector : selectors) {
            Object result = execute(DEEP_QUERY_SCRIPT, selector);
            WebElement element = displayedElement(result);
            if (element != null) {
                return element;
            }
        }
        return null;
    }

    private WebElement waitForClickable(By locator, String description) {
        try {
            return fluentWait().until(driver -> firstClickable(locator));
        } catch (TimeoutException exception) {
            throw diagnosticTimeout("No se encontró habilitado: " + description, exception);
        }
    }

    private WebElement firstClickable(By locator) {
        List<WebElement> elements = getDriver().findElements(locator);
        for (WebElement element : elements) {
            try {
                if (element.isDisplayed() && element.isEnabled()) {
                    return element;
                }
            } catch (StaleElementReferenceException ignored) {
                // El DOM se actualizó; el wait reintenta.
            }
        }
        return null;
    }

    private boolean isDisplayedSafely(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (StaleElementReferenceException ignored) {
            return false;
        }
    }

    private void safeClick(WebElement element) {
        scrollTo(element);
        try {
            element.click();
        } catch (ElementClickInterceptedException | StaleElementReferenceException exception) {
            execute("arguments[0].click();", element);
        }
    }

    private void scrollTo(WebElement element) {
        execute("arguments[0].scrollIntoView({block:'center',inline:'center'});", element);
    }

    private void waitForDocumentReady() {
        fluentWait().until(driver -> {
            Object state = execute("return document.readyState;");
            return "interactive".equals(state) || "complete".equals(state);
        });
    }

    private void waitForBody() {
        fluentWait().until(driver -> {
            List<WebElement> bodies = driver.findElements(BODY);
            return !bodies.isEmpty() && bodies.get(0).isDisplayed();
        });
    }

    public Wait<WebDriver> fluentWait() {
        return new FluentWait<>(getDriver())
                .withTimeout(Duration.ofSeconds(TestConfiguration.getInt("explicit.wait.seconds")))
                .pollingEvery(Duration.ofMillis(300))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);
    }

    private Wait<WebDriver> shortWait(long seconds) {
        return new FluentWait<>(getDriver())
                .withTimeout(Duration.ofSeconds(seconds))
                .pollingEvery(Duration.ofMillis(250))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);
    }

    private Object execute(String script, Object... arguments) {
        return ((JavascriptExecutor) getDriver()).executeScript(script, arguments);
    }

    private WebElement displayedElement(Object value) {
        if (!(value instanceof WebElement)) {
            return null;
        }
        WebElement element = (WebElement) value;
        try {
            return element.isDisplayed() ? element : null;
        } catch (StaleElementReferenceException ignored) {
            return null;
        }
    }

    private String normalizeText(String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase(Locale.ROOT);
    }

    private TimeoutException diagnosticTimeout(String message, Throwable cause) {
        String bodyText;
        try {
            bodyText = getDriver().findElement(BODY).getText().replaceAll("\\s+", " ").trim();
            if (bodyText.length() > 600) {
                bodyText = bodyText.substring(0, 600) + "...";
            }
        } catch (RuntimeException exception) {
            bodyText = "<no disponible>";
        }
        return new TimeoutException(
                message
                        + System.lineSeparator()
                        + "URL: " + getDriver().getCurrentUrl()
                        + System.lineSeparator()
                        + "Título: " + getDriver().getTitle()
                        + System.lineSeparator()
                        + "Texto visible: " + bodyText,
                cause);
    }

    private static final String DEEP_QUERY_SCRIPT =
            "const selector=arguments[0];"
                    + "function find(root){"
                    + "  const direct=root.querySelector(selector);"
                    + "  if(direct) return direct;"
                    + "  for(const node of root.querySelectorAll('*')){"
                    + "    if(node.shadowRoot){"
                    + "      const found=find(node.shadowRoot);"
                    + "      if(found) return found;"
                    + "    }"
                    + "  }"
                    + "  return null;"
                    + "}"
                    + "return find(document);";
}




