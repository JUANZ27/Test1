# language: es

@IBK11 @CuentaNegocios @PersonaJuridica
Característica: Completar los datos iniciales de una Cuenta Negocios
  Como representante legal de una empresa
  Quiero completar el formulario inicial
  Para comenzar la solicitud de una Cuenta Negocios

  @smoke @staging
  Escenario: Completar el formulario inicial para Persona Jurídica
    Dado que el usuario ingresa al portal de Cuenta Negocios
    Y acepta las recomendaciones iniciales si aparecen
    Cuando selecciona el tipo de cuenta "Persona Jurídica"
    Y presiona el botón Continuar
    E ingresa el RUC "20653561378"
    Y el DNI del representante legal "47396815"
    E acepta la política de privacidad
    Y acepta la validación biométrica
    Y resuelve el captcha si aparece
    Entonces presiona el botón Comencemos
