@echo off
setlocal
cd /d "%~dp0"

echo ==========================================================
echo IBK11 - CUENTA NEGOCIOS - SELENIUM BDD
echo Directorio: %CD%
echo ==========================================================

where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] No se encontro Java en PATH.
  echo Instale o configure JDK 11 o superior.
  pause
  exit /b 1
)

where mvn >nul 2>nul
if errorlevel 1 (
  echo [ERROR] No se encontro Maven en PATH.
  echo Ejecute verificar-entorno.bat para ver el diagnostico.
  pause
  exit /b 1
)

set "DRIVER=%CD%\src\test\resources\webdriver\windows\chromedriver.exe"
if not exist "%DRIVER%" (
  echo [ERROR] No existe ChromeDriver: %DRIVER%
  pause
  exit /b 1
)

echo [INFO] ChromeDriver local: %DRIVER%
"%DRIVER%" --version

echo.
echo [INFO] Ejecutando el flujo visible...
call mvn clean verify -Denvironment=staging -Dcucumber.filter.tags="@IBK11" -Dwebdriver.chrome.driver="%DRIVER%"
set "RESULT=%ERRORLEVEL%"

if exist "target\site\serenity\index.html" (
  echo [INFO] Abriendo reporte Serenity...
  start "" "target\site\serenity\index.html"
) else (
  echo [WARN] No se encontro target\site\serenity\index.html
)

echo.
if not "%RESULT%"=="0" (
  echo [ERROR] La ejecucion termino con codigo %RESULT%.
) else (
  echo [OK] Ejecucion finalizada correctamente.
)
pause
exit /b %RESULT%
