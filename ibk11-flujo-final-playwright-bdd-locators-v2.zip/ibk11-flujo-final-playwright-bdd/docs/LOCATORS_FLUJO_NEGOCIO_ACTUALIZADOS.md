# Locators actualizados - Flujo Datos del negocio

Se ajustó la función `completeBusinessData` en `src/test/pages/CuentaNegociosPage.ts` para continuar el flujo indicado en el Word `flujo playwright.docx`.

## Orden corregido

1. Espera la pantalla **Datos del negocio**.
2. Selecciona el radio button del rango de ingresos: **Desde 0 hasta 742,500**.
3. Presiona **Continuar**.
4. Ingresa el número de partida registral: **11045263** o el valor enviado desde el feature.
5. Selecciona el rubro: **Alquileres**.
6. Selecciona el subrubro: **Alquiler de autos**.
7. Selecciona el radio button **Sí** en la pregunta de residencia fiscal o tributaria en Perú.
8. Marca el checkbox de declaración jurada.
9. Presiona **Continuar**.
10. Espera la pantalla **Datos del accionista**.

## Mejoras técnicas

- Se agregaron selectores alternativos para `Número de Partida Registral`, `Rubro del negocio` y `Subrubro del negocio`.
- Se corrigió el orden del flujo: antes intentaba ingresar partida registral antes de presionar Continuar.
- Se agregó búsqueda profunda en Shadow DOM para radios, checkbox y opciones.
- Se agregó manejo más flexible del texto del rango de ingresos: `Desde S/ 0 hasta S/ 742,500`, `Desde S/0 hasta S/742,500` y `Desde 0 hasta 742,500`.
