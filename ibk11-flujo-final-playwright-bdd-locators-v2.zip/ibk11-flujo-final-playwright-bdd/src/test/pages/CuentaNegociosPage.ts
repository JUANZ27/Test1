import { expect, Page } from '@playwright/test';
import { ElementHandle } from 'playwright';
import { testConfig } from '../support/config';
import { clickDeepText, deepQuery, deepQueryAllText } from '../utils/deepSelectors';
import { isCaptchaChallengeVisible, waitManualCaptchaIfPresent } from '../utils/captcha';

function normalize(text: string): string {
  return (text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

export class CuentaNegociosPage {
  private readonly page: Page;

  private readonly selectHosts = [
    "a-hyperloop-select-subtitle[formcontrolname='chooseAccountType']",
    'a-hyperloop-select-subtitle',
    'm-hyperloop-select a-hyperloop-select',
    'a-hyperloop-select'
  ];

  private readonly rucHosts = [
    "m-hyperloop-inputgroup-text[label='RUC de la empresa'] a-hyperloop-input",
    'm-hyperloop-inputgroup-text#formCompanyRuc a-hyperloop-input',
    '#formCompanyRuc a-hyperloop-input',
    "a-hyperloop-input[formcontrolname='companyRuc']"
  ];

  private readonly dniHosts = [
    "m-hyperloop-inputgroup-text[label='DNI del Representante Legal'] a-hyperloop-input",
    'm-hyperloop-inputgroup-text#formLegalRepresentative a-hyperloop-input',
    '#formLegalRepresentative a-hyperloop-input',
    "a-hyperloop-input[formcontrolname='legalRepresentative']",
    "a-hyperloop-input[formcontrolname='documentNumber']"
  ];

  private readonly privacyHosts = [
    'm-hyperloop-checkbox#check-pdp',
    '#check-pdp',
    "m-hyperloop-checkbox[id*='pdp']"
  ];

  private readonly biometricHosts = [
    'm-hyperloop-checkbox#check-biometrics',
    '#check-biometrics',
    "m-hyperloop-checkbox[id*='biometric']"
  ];

  private readonly registrationNumberHosts = [
    "m-hyperloop-inputgroup-text[formcontrolname='registrationNumber'] a-hyperloop-input",
    "m-hyperloop-inputgroup-text[label*='Partida Registral'] a-hyperloop-input",
    "m-hyperloop-inputgroup-text[label*='partida registral'] a-hyperloop-input",
    '#formRegistrationNumber a-hyperloop-input',
    "a-hyperloop-input[formcontrolname='registrationNumber']",
    "a-hyperloop-input[name*='registration']",
    "a-hyperloop-input[id*='registration']"
  ];

  private readonly businessRubroHosts = [
    "m-hyperloop-autocompletegroup-text[formcontrolname='businessArea'] a-hyperloop-autocomplete",
    "m-hyperloop-autocompletegroup-text[label*='Rubro del negocio'] a-hyperloop-autocomplete",
    "m-hyperloop-autocompletegroup-text[label*='Rubro'] a-hyperloop-autocomplete",
    "m-hyperloop-autocompletegroup-text[label*='rubro'] a-hyperloop-autocomplete",
    "a-hyperloop-autocomplete[formcontrolname='businessArea']",
    "m-hyperloop-inputgroup-text[formcontrolname='businessArea'] a-hyperloop-input",
    "m-hyperloop-inputgroup-text[label*='Rubro del negocio'] a-hyperloop-input",
    "a-hyperloop-input[formcontrolname='businessArea']"
  ];

  private readonly businessSubrubroSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='subBusinessArea'] a-hyperloop-select",
    "m-hyperloop-inputgroup-select[label*='Subrubro del negocio'] a-hyperloop-select",
    "m-hyperloop-inputgroup-select[label*='Subrubro'] a-hyperloop-select",
    '#formSubBusinessArea a-hyperloop-select',
    "a-hyperloop-select[formcontrolname='subBusinessArea']",
    "a-hyperloop-select[id*='subBusiness']"
  ];

  private readonly shareholderDocTypeSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='documentType'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='documentType']"
  ];

  private readonly operatorSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='operator'] a-hyperloop-select",
    "m-hyperloop-inputgroup-select[label*='Operador'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='operator']"
  ];

  private readonly civilStatusSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='civilStatus'] a-hyperloop-select",
    "m-hyperloop-inputgroup-select[label*='Estado civil'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='civilStatus']"
  ];

  private readonly departmentSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='department'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='department']"
  ];

  private readonly provinceSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='province'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='province']"
  ];

  private readonly districtSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='district'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='district']"
  ];

  private readonly streetTypeSelectHosts = [
    "m-hyperloop-inputgroup-select[formcontrolname='streetType'] a-hyperloop-select",
    "a-hyperloop-select[formcontrolname='streetType']"
  ];

  constructor(page: Page) {
    this.page = page;
  }

  async openPortal(): Promise<void> {
    await this.page.goto(testConfig.baseUrl, { waitUntil: 'domcontentloaded' });
    await this.page.waitForLoadState('networkidle').catch(() => undefined);
    await expect(this.page.locator('body')).toBeVisible({ timeout: testConfig.timeout });
  }

  async acceptInitialRecommendationsIfPresent(): Promise<boolean> {
    const clicked = await this.clickFirstVisible([
      "//a-hyperloop-button[@text='Entendido']//button",
      "//button[normalize-space()='Entendido']"
    ], 15000);

    if (clicked) return true;

    return this.evaluateClickByText('Entendido');
  }

  async selectAccountType(accountType: string): Promise<void> {
    const host = await this.waitForHost(this.selectHosts, 'tipo de cuenta');
    const isDropdownOpen = await host.evaluate((node) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const list = root.querySelector('ul#list, ul.select-options') as HTMLElement | null;
      return !!list && list.classList.contains('show');
    });

    if (!isDropdownOpen) {
      await this.clickTriggerInsideHost(host, 'tipo de cuenta');
      await this.page.waitForTimeout(300);
    }

    const optionHandle = await host.evaluateHandle((node, wanted) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const options = Array.from(root.querySelectorAll('li.li-select, ul#list li, [role="option"]')) as HTMLElement[];
      return options.find((candidate) => candidate.id === wanted) || null;
    }, accountType);
    const option = optionHandle.asElement() as ElementHandle<HTMLElement> | null;

    if (!option) {
      await optionHandle.dispose();
      throw new Error(`No apareció la opción del tipo de cuenta: ${accountType}`);
    }

    await option.scrollIntoViewIfNeeded();
    await option.click({ timeout: 5000 });

    // No se da el paso por exitoso hasta que el dropdown procese la selección
    // y se cierre. Esto evita continuar después de hacer clic en un contenedor.
    await expect.poll(() => host.evaluate((node) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const list = root.querySelector('ul#list, ul.select-options') as HTMLElement | null;
      return !list || !list.classList.contains('show');
    }), {
      timeout: 5000,
      message: `El selector no confirmó la opción ${accountType}`
    }).toBe(true);
  }

  async clickContinue(): Promise<void> {
    await this.clickButtonByText('Continuar');
    await this.completeBusinessStageIfPresent();
    await this.waitForAnyHost(this.rucHosts, 30000).catch(() => undefined);
  }

  async enterRuc(ruc: string): Promise<void> {
    await this.completeBusinessStageIfPresent();
    await this.enterValueInShadowInput(this.rucHosts, ruc, 'RUC de la empresa', ['RUC de la empresa']);
  }

  async enterDni(dni: string): Promise<void> {
    await this.completeBusinessStageIfPresent();
    await this.enterValueInShadowInput(this.dniHosts, dni, 'DNI del representante legal', ['DNI del Representante Legal']);
  }

  async acceptPrivacy(): Promise<void> {
    await this.setShadowCheckbox(this.privacyHosts, true, 'política de privacidad', ['privacidad', 'he leido y acepto']);
  }

  async acceptBiometrics(): Promise<void> {
    await this.setShadowCheckbox(this.biometricHosts, true, 'validación biométrica', ['biometria', 'identidad', 'otp']);
  }

  async clickStart(): Promise<void> {
    for (let attempt = 0; attempt < 4; attempt++) {
      await waitManualCaptchaIfPresent(this.page);
      await this.clickComencemosOnce();

      await this.page.waitForTimeout(1500);

      if (await isCaptchaChallengeVisible(this.page)) {
        await waitManualCaptchaIfPresent(this.page);
      }

      if (await this.isComencemosVisible()) {
        await this.clickComencemosOnce();
      }

      await this.page.waitForTimeout(2000);
      if (!(await this.isComencemosVisible()) && !(await isCaptchaChallengeVisible(this.page))) {
        return;
      }
    }

    throw new Error('No fue posible avanzar al presionar Comencemos. Revisa el CAPTCHA o validaciones bloqueantes.');
  }

  async handleCaptchaIfPresent(): Promise<void> {
    await waitManualCaptchaIfPresent(this.page);
  }

  async completeBusinessData(registrationNumber: string, businessArea: string, subBusinessArea: string): Promise<void> {
    await this.waitForText('Datos del negocio');

    // Según el flujo documentado, primero se selecciona el rango de ingresos
    // y recién después se presiona Continuar para habilitar Partida Registral,
    // Rubro y Subrubro del negocio.
    await this.selectAnnualIncomeRange();
    await this.clickBusinessStepContinueAndWaitRegistration();

    await this.enterValueInShadowInput(this.registrationNumberHosts, registrationNumber, 'Número de Partida Registral', ['partida registral']);
    await this.selectAutocompleteOption(this.businessRubroHosts, businessArea, 'Rubro del negocio');
    await this.selectShadowOption(this.businessSubrubroSelectHosts, subBusinessArea, 'Subrubro del negocio');

    await this.selectRadioNearText('¿Tu empresa tiene residencia fiscal o tributaria en Perú?', 'Si');
    await this.setCheckboxByText('Declaro bajo juramento que la información proporcionada', true);
    await this.clickButtonByText('Continuar');
    await this.waitForText('Datos del accionista');
  }

  async completeShareholdersData(): Promise<void> {
    await this.waitForText('Datos del accionista');
    await this.completeShareholderCard(1, 'DNI', '47396815', '50', 'No');
    await this.completeShareholderCard(2, 'DNI', '47396816', '50', 'No');
    await this.setCheckboxByText('Declaro haber ingresado todos los accionistas', true);
    await this.clickButtonByText('Comencemos');
    await this.waitForText('Datos del representante legal');
  }

  async completeLegalRepresentativeData(): Promise<void> {
    await this.waitForText('Datos del representante legal');

    await this.enterInputByLabel('Correo electrónico', 'zcarlos927@gmail.com');
    await this.selectShadowOption(this.operatorSelectHosts, 'Claro', 'Operador');
    await this.enterInputByLabel('Celular', '954841305');

    await this.enterInputByLabel('Primer nombre', 'Juan');
    await this.enterInputByLabel('Apellido Paterno', 'Salazar');
    await this.enterInputByLabel('Apellido materno', 'Quispe');
    await this.enterInputByLabel('Fecha de nacimiento', '27/09/1992');
    await this.clickByTextDeep('Hombre');
    await this.selectShadowOption(this.civilStatusSelectHosts, 'Soltero', 'Estado civil');

    await this.selectShadowOption(this.departmentSelectHosts, 'Amazonas', 'Departamento');
    await this.selectShadowOption(this.provinceSelectHosts, 'Bagua', 'Provincia');
    await this.selectShadowOption(this.districtSelectHosts, 'Aramango', 'Distrito');
    await this.selectShadowOption(this.streetTypeSelectHosts, 'Avenida', 'Tipo de vía');
    await this.enterInputByLabel('Nombre de vía', 'alameda');
    await this.enterInputByLabel('Número', '1');
    await this.selectRadioNearText('Representante Legal es una persona Expuesta', 'No');
    await this.clickButtonByText('Siguiente');
  }

  async continueIdentityValidationIfPresent(): Promise<void> {
    const body = normalize(await deepQueryAllText(this.page));
    if (!body.includes('valida tu identidad')) return;

    console.warn('Pantalla de validación de identidad detectada. Si solicita código, completarlo manualmente.');
    await this.clickButtonByText('Continuar').catch(() => undefined);
  }

  async selectAccountCurrency(currency: string): Promise<void> {
    await this.waitForText('Configura tu cuenta');
    await this.selectRadioOptionByText(currency);
  }

  async clickOpenAccount(): Promise<void> {
    await this.clickButtonByText('Abrir cuenta');
  }

  private async completeBusinessStageIfPresent(): Promise<void> {
    for (let attempt = 0; attempt < 3; attempt++) {
      if (await this.findHost(this.rucHosts)) return;
      if (!(await this.isBusinessStageVisible())) return;

      await this.page.evaluate(() => {
        const option = Array.from(document.querySelectorAll('li.asc-screen__option'))
          .find((el) => {
            const html = el as HTMLElement;
            const style = window.getComputedStyle(html);
            return style.display !== 'none' && style.visibility !== 'hidden' && html.getClientRects().length > 0;
          }) as HTMLElement | undefined;
        option?.click();
      });

      await this.page.waitForTimeout(1000);
      await this.page.evaluate(() => {
        const button = document.querySelector('button.asc-screen__continue') as HTMLButtonElement | null;
        if (button) {
          button.removeAttribute('disabled');
          button.click();
        }
      });

      await this.page.waitForTimeout(2000);
      if (!(await this.isBusinessStageVisible())) return;
    }
  }

  private async isBusinessStageVisible(): Promise<boolean> {
    return this.page.evaluate(() => {
      const visible = (el: Element) => {
        const html = el as HTMLElement;
        const style = window.getComputedStyle(html);
        return style.display !== 'none' && style.visibility !== 'hidden' && html.getClientRects().length > 0;
      };
      const options = Array.from(document.querySelectorAll('li.asc-screen__option')).some(visible);
      const buttons = Array.from(document.querySelectorAll('button.asc-screen__continue')).some(visible);
      return options && buttons;
    });
  }

  private async clickComencemosOnce(): Promise<void> {
    await this.clickFirstVisible([
      "a-hyperloop-button#nextStepDataNaturalPerson button",
      '#nextStepDataNaturalPerson button',
      'button#nextStepDataNaturalPerson',
      "//a-hyperloop-button[@text='Comencemos']//button",
      "//button[normalize-space()='Comencemos']"
    ], 5000).catch(() => false);

    await this.evaluateClickByText('Comencemos').catch(() => false);

    await this.page.evaluate(() => {
      const btn = document.querySelector('a-hyperloop-button#nextStepDataNaturalPerson button, #nextStepDataNaturalPerson button, button#nextStepDataNaturalPerson') as HTMLButtonElement | null;
      if (btn) {
        btn.removeAttribute('disabled');
        btn.click();
      }
    });
  }

  private async isComencemosVisible(): Promise<boolean> {
    const byCss = await this.page.locator('a-hyperloop-button#nextStepDataNaturalPerson button, #nextStepDataNaturalPerson button, button#nextStepDataNaturalPerson').first().isVisible().catch(() => false);
    if (byCss) return true;
    const byText = await this.page.locator('button', { hasText: 'Comencemos' }).first().isVisible().catch(() => false);
    return byText;
  }


  private async selectAnnualIncomeRange(): Promise<void> {
    const options = [
      'Desde S/ 0 hasta S/ 742,500',
      'Desde S/0 hasta S/742,500',
      'Desde 0 hasta 742,500'
    ];

    for (const option of options) {
      const selected = await this.selectRadioOptionByTextIfPresent(option);
      if (selected) return;
    }

    const selectedByNumbers = await this.page.evaluate(() => {
      const normalizeText = (s: string) => (s || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
      function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      for (const root of allRoots(document, [])) {
        const candidates = Array.from(root.querySelectorAll('label, li, div, span')) as HTMLElement[];
        const target = candidates.find((candidate) => {
          const style = getComputedStyle(candidate);
          const visible = style.display !== 'none' && style.visibility !== 'hidden' && candidate.getClientRects().length > 0;
          const raw = normalizeText(candidate.innerText || candidate.textContent || '');
          return visible && raw.includes('desde') && raw.includes('742,500');
        });
        if (target) {
          target.scrollIntoView({ block: 'center', inline: 'center' });
          target.click();
          return true;
        }
      }
      return false;
    });

    if (!selectedByNumbers) throw new Error('No se pudo seleccionar el rango de ingresos Desde 0 hasta 742,500');
  }

  private async clickBusinessStepContinueAndWaitRegistration(): Promise<void> {
    await this.clickButtonByText('Continuar');
    await this.page.waitForLoadState('networkidle').catch(() => undefined);
    await this.waitForInputHost(this.registrationNumberHosts, 'Número de Partida Registral', ['partida registral']);
  }

  private async selectAutocompleteOption(hostSelectors: string[], optionText: string, description: string): Promise<void> {
    const host = await this.waitForInputHost(hostSelectors, description, [description]);
    const typed = await host.evaluate((node, nextValue) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const input = (Array.from(root.querySelectorAll('input')) as HTMLInputElement[]).find((i) => {
        const type = (i.type || 'text').toLowerCase();
        const style = getComputedStyle(i);
        return type !== 'hidden' && i.getAttribute('aria-hidden') !== 'true' && style.display !== 'none' && style.visibility !== 'hidden';
      });
      if (!input) return false;
      input.removeAttribute('readonly');
      input.removeAttribute('disabled');
      input.readOnly = false;
      input.disabled = false;
      input.focus();
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, '');
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'deleteContentBackward' }));
      setter?.call(input, nextValue);
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: nextValue, inputType: 'insertText' }));
      input.dispatchEvent(new Event('keyup', { bubbles: true, composed: true }));
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      return true;
    }, optionText);
    if (!typed) throw new Error(`No se pudo escribir ${description}`);

    await this.page.waitForTimeout(500);
    await this.clickOptionByText(optionText);
  }

  private async selectRadioOptionByTextIfPresent(text: string): Promise<boolean> {
    return this.page.evaluate((expectedRaw) => {
      const normalizeText = (value: string) => (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const expected = normalizeText(expectedRaw);
      function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      for (const root of allRoots(document, [])) {
        const labels = Array.from(root.querySelectorAll('label, li, div, span')) as HTMLElement[];
        const label = labels.find((candidate) => {
          const style = getComputedStyle(candidate);
          const visible = style.display !== 'none' && style.visibility !== 'hidden' && candidate.getClientRects().length > 0;
          const raw = normalizeText(candidate.innerText || candidate.textContent || '');
          return visible && (raw === expected || raw.includes(expected));
        });
        if (label) {
          label.scrollIntoView({ block: 'center', inline: 'center' });
          label.click();
          return true;
        }
      }
      return false;
    }, text);
  }

  private async completeShareholderCard(index: number, documentType: string, documentNumber: string, participation: string, pepOption: string): Promise<void> {
    const card = await this.waitForShareholderCard(index);
    await card.scrollIntoViewIfNeeded();
    await this.selectOptionInside(card, documentType, `tipo de documento del accionista ${index}`);
    await this.enterInputInside(card, documentNumber, `número de documento del accionista ${index}`, 1);
    await this.enterInputInside(card, participation, `participación del accionista ${index}`, 2);
    await this.selectRadioInside(card, pepOption, `PEP accionista ${index}`);
  }

  private async waitForShareholderCard(index: number): Promise<ElementHandle<HTMLElement>> {
    const deadline = Date.now() + testConfig.timeout;
    while (Date.now() < deadline) {
      const handle = await this.page.evaluateHandle((position) => {
        const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
        const cards = Array.from(document.querySelectorAll('a-hyperloop-accordion-v2, .accordion, [class*=accordion]'))
          .filter((e) => normalizeText(e.textContent || '').includes('accionista'));
        return cards.length >= position ? cards[position - 1] : null;
      }, index);
      const element = handle.asElement() as ElementHandle<HTMLElement> | null;
      if (element) return element;
      await this.page.waitForTimeout(300);
    }
    throw new Error(`No se encontró tarjeta de accionista ${index}`);
  }

  private async selectOptionInside(container: ElementHandle<HTMLElement>, optionText: string, description: string): Promise<void> {
    const selected = await container.evaluate((node, expectedRaw) => {
      const expected = (expectedRaw || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      function allRoots(root: Element | ShadowRoot, acc: Array<Element | ShadowRoot>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      const roots = allRoots(node, []);
      for (const root of roots) {
        const triggers = Array.from(root.querySelectorAll('.select-styled, [role=combobox], button')) as HTMLElement[];
        for (const trigger of triggers) {
          const style = window.getComputedStyle(trigger);
          if (style.display === 'none' || style.visibility === 'hidden' || trigger.getClientRects().length === 0) continue;
          trigger.click();
          const options = Array.from(document.querySelectorAll('li, [role=option]')) as HTMLElement[];
          const option = options.find((o) => normalizeText(o.innerText || o.textContent || '') === expected || normalizeText(o.innerText || o.textContent || '').includes(expected));
          if (option) { option.click(); return true; }
        }
      }
      return false;
    }, optionText);
    if (!selected) throw new Error(`No se pudo seleccionar ${optionText} en ${description}`);
  }

  private async enterInputInside(container: ElementHandle<HTMLElement>, value: string, description: string, visibleInputPosition: number): Promise<void> {
    const updated = await container.evaluate((node, args) => {
      function allRoots(root: Element | ShadowRoot, acc: Array<Element | ShadowRoot>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      const inputs: HTMLInputElement[] = [];
      for (const root of allRoots(node, [])) {
        inputs.push(...Array.from(root.querySelectorAll('input')).filter((i) => {
          const type = (i.type || 'text').toLowerCase();
          const style = getComputedStyle(i);
          return type !== 'hidden' && i.getAttribute('aria-hidden') !== 'true' && style.display !== 'none' && style.visibility !== 'hidden';
        }));
      }
      const input = inputs[args.position - 1] || inputs[0];
      if (!input) return false;
      input.removeAttribute('readonly');
      input.removeAttribute('disabled');
      input.readOnly = false;
      input.disabled = false;
      input.focus();
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, args.nextValue);
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: args.nextValue, inputType: 'insertText' }));
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true, composed: true }));
      return true;
    }, { nextValue: value, position: visibleInputPosition });
    if (!updated) throw new Error(`No se pudo ingresar ${description}`);
  }

  private async selectRadioInside(container: ElementHandle<HTMLElement>, optionText: string, description: string): Promise<void> {
    const selected = await container.evaluate((node, expectedRaw) => {
      const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const expected = normalizeText(expectedRaw);
      function allRoots(root: Element | ShadowRoot, acc: Array<Element | ShadowRoot>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      for (const root of allRoots(node, [])) {
        const labels = Array.from(root.querySelectorAll('label')) as HTMLElement[];
        const label = labels.find((l) => normalizeText(l.innerText || l.textContent || '') === expected || normalizeText(l.innerText || l.textContent || '').includes(expected));
        if (label) { label.click(); return true; }
        const inputs = Array.from(root.querySelectorAll('input[type=radio]')) as HTMLInputElement[];
        const input = inputs.find((i) => normalizeText(i.value) === expected || normalizeText(i.id).includes(expected));
        if (input) { input.click(); input.dispatchEvent(new Event('change', { bubbles: true, composed: true })); return true; }
      }
      return false;
    }, optionText);
    if (!selected) throw new Error(`No se pudo seleccionar radio ${optionText} en ${description}`);
  }

  private async enterValueInShadowInput(hostSelectors: string[], value: string, description: string, labelHints: string[] = []): Promise<void> {
    const host = await this.waitForInputHost(hostSelectors, description, labelHints);
    const ok = await host.evaluate((node, nextValue) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const inputs = Array.from(root.querySelectorAll('input')) as HTMLInputElement[];
      const input = inputs.find((el) => {
        const type = (el.getAttribute('type') || 'text').toLowerCase();
        const name = (el.getAttribute('name') || '').toLowerCase();
        const style = window.getComputedStyle(el);
        return type !== 'hidden' && !name.includes('fake-field') && el.getAttribute('aria-hidden') !== 'true' && style.display !== 'none' && style.visibility !== 'hidden';
      });
      if (!input) return false;
      input.removeAttribute('readonly');
      input.removeAttribute('disabled');
      input.readOnly = false;
      input.disabled = false;
      input.focus();
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, '');
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'deleteContentBackward' }));
      setter?.call(input, nextValue);
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: nextValue, inputType: 'insertText' }));
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true, composed: true }));
      return true;
    }, value);
    if (!ok) throw new Error(`No se pudo ingresar ${description}`);
  }

  private async enterInputByLabel(label: string, value: string): Promise<void> {
    const host = await this.waitForInputHost([
      `m-hyperloop-inputgroup-text[label*='${label}'] a-hyperloop-input`,
      `a-hyperloop-input[formcontrolname*='${label}']`
    ], label, [label]);
    const ok = await host.evaluate((node, nextValue) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const input = (Array.from(root.querySelectorAll('input')) as HTMLInputElement[]).find((i) => {
        const type = (i.type || 'text').toLowerCase();
        const style = getComputedStyle(i);
        return type !== 'hidden' && style.display !== 'none' && style.visibility !== 'hidden';
      }) as HTMLInputElement | undefined;
      if (!input) return false;
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, nextValue);
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: nextValue, inputType: 'insertText' }));
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true, composed: true }));
      return true;
    }, value);
    if (!ok) throw new Error(`No se pudo ingresar ${label}`);
  }

  private async setShadowCheckbox(hostSelectors: string[], expected: boolean, description: string, labelHints: string[] = []): Promise<void> {
    const host = await this.waitForCheckboxHost(hostSelectors, description, labelHints);
    const ok = await host.evaluate((node, target) => {
      const root = (node as HTMLElement).shadowRoot || node;
      const checkbox = root.querySelector('input[type=checkbox]') as HTMLInputElement | null;
      if (!checkbox) return false;
      if (checkbox.checked !== target) {
        const label = root.querySelector(`label[for="${checkbox.id}"], label`) as HTMLElement | null;
        label?.click();
      }
      if (checkbox.checked !== target) checkbox.click();
      if (checkbox.checked !== target) {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'checked')?.set;
        setter?.call(checkbox, target);
        checkbox.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
        checkbox.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      }
      return checkbox.checked === target;
    }, expected);
    if (!ok) throw new Error(`No se pudo marcar ${description}`);
  }

  private async waitForInputHost(selectors: string[], description: string, labelHints: string[] = []): Promise<ElementHandle<HTMLElement>> {
    const host = await this.findHost(selectors);
    if (host) return host;
    if (labelHints.length === 0) throw new Error(`No se encontró host de input para ${description}`);

    const deadline = Date.now() + testConfig.timeout;
    while (Date.now() < deadline) {
      const result = await this.page.evaluateHandle((labels) => {
        const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
        const expected = labels.map(normalizeText);
        function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
          acc.push(root);
          root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
          return acc;
        }
        for (const root of allRoots(document, [])) {
          const groups = Array.from(root.querySelectorAll('m-hyperloop-inputgroup-text, m-hyperloop-autocompletegroup-text, m-hyperloop-inputgroup-autocomplete'));
          for (const group of groups) {
            const text = normalizeText(group.getAttribute('label') || group.textContent || group.getAttribute('formcontrolname') || '');
            if (expected.some((label) => text.includes(label))) {
              return group.querySelector('a-hyperloop-input, a-hyperloop-autocomplete') || group;
            }
          }
        }
        return null;
      }, labelHints);
      const element = result.asElement() as ElementHandle<HTMLElement> | null;
      if (element) return element;
      await this.page.waitForTimeout(300);
    }
    throw new Error(`No se encontró input ${description}. Selectores: ${selectors.join(', ')}`);
  }

  private async waitForCheckboxHost(selectors: string[], description: string, labelHints: string[] = []): Promise<ElementHandle<HTMLElement>> {
    const host = await this.findHost(selectors);
    if (host) return host;

    const deadline = Date.now() + testConfig.timeout;
    while (Date.now() < deadline) {
      const result = await this.page.evaluateHandle((labels) => {
        const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
        const expected = labels.map(normalizeText);
        const hosts = Array.from(document.querySelectorAll('m-hyperloop-checkbox'));
        for (const checkboxHost of hosts) {
          const text = normalizeText(checkboxHost.getAttribute('id') || checkboxHost.getAttribute('aria-label') || checkboxHost.textContent || '');
          if (expected.some((label) => text.includes(label))) return checkboxHost;
        }
        return null;
      }, labelHints);
      const element = result.asElement() as ElementHandle<HTMLElement> | null;
      if (element) return element;
      await this.page.waitForTimeout(300);
    }
    throw new Error(`No se encontró checkbox ${description}`);
  }

  private async selectShadowOption(hostSelectors: string[], optionText: string, description: string): Promise<void> {
    const host = await this.waitForHost(hostSelectors, description);
    await this.clickTriggerInsideHost(host, description);
    await this.clickOptionByText(optionText);
  }

  private async clickTriggerInsideHost(host: ElementHandle<HTMLElement>, description: string): Promise<void> {
    const triggerHandle = await host.evaluateHandle((node) => {
      const root = (node as HTMLElement).shadowRoot || node;
      return root.querySelector('#dropdown-select .select-styled, .select-styled, [role=combobox], button');
    });
    const trigger = triggerHandle.asElement() as ElementHandle<HTMLElement> | null;
    if (!trigger) {
      await triggerHandle.dispose();
      throw new Error(`No se encontró trigger del selector ${description}`);
    }
    await trigger.scrollIntoViewIfNeeded();
    await trigger.click({ timeout: 5000 });
  }

  private async clickOptionByText(optionText: string): Promise<void> {
    const expected = normalize(optionText);
    const deadline = Date.now() + testConfig.timeout;
    while (Date.now() < deadline) {
      const clicked = await this.page.evaluate((wanted) => {
        const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
        function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
          acc.push(root);
          root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
          return acc;
        }
        for (const root of allRoots(document, [])) {
          const nodes = Array.from(root.querySelectorAll('ul#list li, li, [role=option], button')) as HTMLElement[];
          const option = nodes.find((node) => {
            const style = window.getComputedStyle(node);
            const visible = style.display !== 'none' && style.visibility !== 'hidden' && node.getClientRects().length > 0;
            const raw = normalizeText(node.innerText || node.textContent || '');
            return visible && (raw === wanted || raw.startsWith(`${wanted} `) || raw.includes(wanted));
          });
          if (option) {
            option.scrollIntoView({ block: 'center', inline: 'center' });
            option.click();
            return true;
          }
        }
        return false;
      }, expected);
      if (clicked) return;
      await this.page.waitForTimeout(300);
    }
    throw new Error(`No se pudo seleccionar opción ${optionText}`);
  }

  private async selectRadioOptionByText(text: string): Promise<void> {
    const clicked = await this.selectRadioOptionByTextIfPresent(text);
    if (!clicked) throw new Error(`No se pudo seleccionar radio por texto: ${text}`);
  }

  private async setCheckboxByText(text: string, expected: boolean): Promise<void> {
    const ok = await this.page.evaluate(({ expectedRaw, target }) => {
      const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const expectedText = normalizeText(expectedRaw);
      function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      for (const root of allRoots(document, [])) {
        const labels = Array.from(root.querySelectorAll('label, m-hyperloop-checkbox, div, span')) as HTMLElement[];
        const label = labels.find((l) => {
          const style = getComputedStyle(l);
          const visible = style.display !== 'none' && style.visibility !== 'hidden' && l.getClientRects().length > 0;
          return visible && normalizeText(l.innerText || l.textContent || '').includes(expectedText);
        });
        if (!label) continue;
        label.scrollIntoView({ block: 'center', inline: 'center' });
        const directInput = label.querySelector('input[type=checkbox]') as HTMLInputElement | null;
        const hostInput = (label.shadowRoot?.querySelector('input[type=checkbox]') || directInput) as HTMLInputElement | null;
        if (hostInput) {
          if (hostInput.checked !== target) hostInput.click();
          if (hostInput.checked !== target) {
            const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'checked')?.set;
            setter?.call(hostInput, target);
            hostInput.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
            hostInput.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
          }
          return hostInput.checked === target;
        }
        label.click();
        return true;
      }
      return false;
    }, { expectedRaw: text, target: expected });
    if (!ok) throw new Error(`No se pudo marcar checkbox por texto: ${text}`);
  }

  private async selectRadioNearText(questionText: string, optionText: string): Promise<void> {
    const clicked = await this.page.evaluate(({ question, option }) => {
      const normalizeText = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
      const q = normalizeText(question);
      const qShort = q.replace(/^¿?/, '').replace(/\?$/, '');
      const o = normalizeText(option);
      function allRoots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
        acc.push(root);
        root.querySelectorAll('*').forEach((n) => { if ((n as HTMLElement).shadowRoot) allRoots((n as HTMLElement).shadowRoot!, acc); });
        return acc;
      }
      for (const root of allRoots(document, [])) {
        const containers = Array.from(root.querySelectorAll('section, div, form, fieldset, m-hyperloop-radio, a-hyperloop-radio')) as HTMLElement[];
        const container = containers.find((el) => {
          const raw = normalizeText(el.innerText || el.textContent || el.getAttribute('label') || '');
          return raw.includes(q) || raw.includes(qShort) || (qShort.includes('residencia fiscal') && raw.includes('residencia fiscal'));
        });
        if (!container) continue;
        const labels = Array.from(container.querySelectorAll('label, button, div, span')) as HTMLElement[];
        const target = labels.find((el) => {
          const raw = normalizeText(el.innerText || el.textContent || '');
          const style = getComputedStyle(el);
          const visible = style.display !== 'none' && style.visibility !== 'hidden' && el.getClientRects().length > 0;
          return visible && (raw === o || raw.includes(o));
        });
        if (target) {
          target.scrollIntoView({ block: 'center', inline: 'center' });
          target.click();
          return true;
        }
      }
      return false;
    }, { question: questionText, option: optionText });
    if (!clicked) throw new Error(`No se pudo seleccionar ${optionText} cerca de ${questionText}`);
  }

  private async clickButtonByText(text: string): Promise<void> {
    const byRole = this.page.getByRole('button', { name: new RegExp(text, 'i') }).first();
    if (await byRole.isVisible().catch(() => false)) {
      await byRole.scrollIntoViewIfNeeded();
      await byRole.click();
      return;
    }
    if (await this.evaluateClickByText(text)) return;
    throw new Error(`No se pudo hacer click en botón: ${text}`);
  }

  private async clickByTextDeep(text: string): Promise<void> {
    if (await clickDeepText(this.page, text)) return;
    throw new Error(`No se pudo hacer click en texto: ${text}`);
  }

  private async waitForText(text: string): Promise<void> {
    const expected = normalize(text);
    const deadline = Date.now() + testConfig.timeout;
    while (Date.now() < deadline) {
      const body = normalize(await deepQueryAllText(this.page));
      if (body.includes(expected)) return;
      await this.page.waitForTimeout(300);
    }
    throw new Error(`No apareció el texto esperado: ${text}`);
  }

  private async evaluateClickByText(text: string): Promise<boolean> {
    return this.page.evaluate((expectedRaw) => {
      const expected = (expectedRaw || '').trim().toLowerCase();
      const buttons = Array.from(document.querySelectorAll('button, a-hyperloop-button, a, label')) as HTMLElement[];
      const button = buttons.find((b) => (b.innerText || b.textContent || '').trim().toLowerCase() === expected);
      if (button) {
        button.scrollIntoView({ block: 'center', inline: 'center' });
        button.click();
        return true;
      }
      return false;
    }, text);
  }

  private async clickFirstVisible(selectors: string[], timeout: number): Promise<boolean> {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      for (const selector of selectors) {
        const locator = selector.startsWith('//') ? this.page.locator(`xpath=${selector}`) : this.page.locator(selector);
        const first = locator.first();
        if (await first.isVisible().catch(() => false)) {
          await first.scrollIntoViewIfNeeded();
          await first.click({ timeout: 5000 }).catch(async () => {
            await first.evaluate((el) => (el as HTMLElement).click());
          });
          return true;
        }
      }
      await this.page.waitForTimeout(300);
    }
    return false;
  }

  private async waitForHost(selectors: string[], description: string): Promise<ElementHandle<HTMLElement>> {
    const host = await this.waitForAnyHost(selectors, testConfig.timeout);
    if (host) return host;
    throw new Error(`No se encontró host Shadow DOM para ${description}. Selectores: ${selectors.join(', ')}`);
  }

  private async waitForAnyHost(selectors: string[], timeout: number): Promise<ElementHandle<HTMLElement> | null> {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const host = await this.findHost(selectors);
      if (host) return host;
      await this.page.waitForTimeout(300);
    }
    return null;
  }

  private async findHost(selectors: string[]): Promise<ElementHandle<HTMLElement> | null> {
    for (const selector of selectors) {
      const element = await deepQuery(this.page, selector);
      if (element) return element;
    }
    return null;
  }
}
