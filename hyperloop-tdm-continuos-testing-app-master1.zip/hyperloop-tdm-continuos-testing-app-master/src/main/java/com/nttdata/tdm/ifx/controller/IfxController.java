package com.nttdata.tdm.ifx.controller;

import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;
import com.nttdata.tdm.ifx.service.IfxCustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tdm/ifx")
public class IfxController {

    private final IfxCustomerService ifxCustomerService;

    public IfxController(IfxCustomerService ifxCustomerService) {
        this.ifxCustomerService = ifxCustomerService;
    }

    @PostMapping("/customer/create")
    @ResponseStatus(HttpStatus.OK)
    public IfxCreateCustomerResponse createCustomer(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument) {
        return ifxCustomerService.createNaturalPerson(typeDocument);
    }
}
