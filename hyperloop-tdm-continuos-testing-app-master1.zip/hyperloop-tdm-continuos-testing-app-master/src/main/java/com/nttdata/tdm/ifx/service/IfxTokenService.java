package com.nttdata.tdm.ifx.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.tdm.ifx.dto.IfxTokenResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class IfxTokenService {

    private final ObjectMapper objectMapper;
    private final IfxHttpClientFactory httpClientFactory;

    @Value("${ifx.base-url}")
    private String baseUrl;

    @Value("${ifx.token-path:/oauthproviderh1/oauth2/token}")
    private String tokenPath;

    @Value("${ifx.grant-type:password}")
    private String grantType;

    @Value("${ifx.username:}")
    private String username;

    @Value("${ifx.password:}")
    private String password;

    @Value("${ifx.client-id:}")
    private String clientId;

    @Value("${ifx.client-secret:}")
    private String clientSecret;

    @Value("${ifx.scope-transaccion:}")
    private String scopeTransaccion;

    public IfxTokenService(ObjectMapper objectMapper, IfxHttpClientFactory httpClientFactory) {
        this.objectMapper = objectMapper;
        this.httpClientFactory = httpClientFactory;
    }

    public IfxTokenResponse generateTransactionToken() {
        try {
            Map<String, String> form = new LinkedHashMap<>();
            form.put("grant_type", grantType);
            form.put("username", username);
            form.put("password", password);
            form.put("client_id", clientId);
            form.put("client_secret", clientSecret);
            form.put("scope", scopeTransaccion);

            String body = form.entrySet().stream()
                    .map(e -> encode(e.getKey()) + "=" + encode(e.getValue()))
                    .collect(Collectors.joining("&"));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(normalizeBaseUrl(baseUrl) + normalizePath(tokenPath)))
                    .timeout(Duration.ofSeconds(60))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpClient httpClient = httpClientFactory.create();
            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            IfxTokenResponse response = new IfxTokenResponse();
            response.setStatusCode(httpResponse.statusCode());
            response.setResponseBody(httpResponse.body());

            if (httpResponse.body() != null && !httpResponse.body().isBlank()) {
                JsonNode json = objectMapper.readTree(httpResponse.body());
                if (json.hasNonNull("access_token")) {
                    response.setAccessToken(json.get("access_token").asText());
                }
            }

            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error generando token IFX transaccional: " + e.getMessage(), e);
        }
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private String normalizeBaseUrl(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalStateException("Configure ifx.base-url o IFX_BASE_URL");
        }
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private String normalizePath(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        return value.startsWith("/") ? value : "/" + value;
    }
}
