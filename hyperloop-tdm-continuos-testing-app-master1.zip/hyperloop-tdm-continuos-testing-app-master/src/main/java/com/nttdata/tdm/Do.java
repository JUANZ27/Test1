package com.nttdata.tdm;

import com.nttdata.tdm.ifx.client.IfxStandaloneClient;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;

public class Do {

    private Do() {
    }

    /**
     * Crea cliente persona natural en IFX usando el ambiente definido con -Denvironment.
     * Ejemplo: Do.crearPersonaNaturalIFX("DNI");
     */
    public static IfxCreateCustomerResponse crearPersonaNaturalIFX(String tipoDocumento) {
        String environment = System.getProperty("environment", "uat");
        return crearPersonaNaturalIFX(tipoDocumento, environment);
    }

    /**
     * Crea cliente persona natural en IFX usando el application-{environment}.properties
     * ubicado en C:\\Users\\<usuario>.
     */
    public static IfxCreateCustomerResponse crearPersonaNaturalIFX(String tipoDocumento, String environment) {
        return new IfxStandaloneClient(environment).createNaturalPerson(tipoDocumento);
    }
}
