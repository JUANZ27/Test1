package com.nttdata.tdm.ifx.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Collectors;

public class IfxStandaloneClient {

    private final String environment;
    private final Properties props;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public IfxStandaloneClient(String environment) {
        this.environment = isBlank(environment) ? "uat" : environment.trim().toLowerCase();
        this.props = loadProperties(this.environment);
    }

    public IfxCreateCustomerResponse createNaturalPerson(String typeDocument) {
        try {
            String requestedDocumentType = normalizeTypeDocument(typeDocument);
            String documentTypeId = toIfxDocumentTypeId(requestedDocumentType);
            String configuredDocumentNumber = value("ifx.document-number", "");
            String documentNumber = isBlank(configuredDocumentNumber) ? nextDni() : configuredDocumentNumber;
            String firstName = value("ifx.first-name", "ISABEL");
            String secondName = value("ifx.second-name", "MARIA");
            String firstLastName = value("ifx.first-last-name", "MONTENEGRO");
            String secondLastName = value("ifx.second-last-name", "RIVAS");
            String phoneNumber = value("ifx.phone-number", "958595853");
            String email = value("ifx.email", "70562659g@gmail.com");

            String accessToken = generateToken();

            IfxCreateCustomerResponse output = new IfxCreateCustomerResponse();
            output.setDocumentType(requestedDocumentType);
            output.setDocumentTypeId(documentTypeId);
            output.setDocumentNumber(documentNumber);
            output.setFirstName(firstName);
            output.setSecondName(secondName);
            output.setFirstLastName(firstLastName);
            output.setSecondLastName(secondLastName);
            output.setPhoneNumber(phoneNumber);
            output.setEmail(email);
            output.setTokenGenerated(!isBlank(accessToken));

            if (isBlank(accessToken)) {
                output.setStatusCode(0);
                output.setResponseBody("No se genero access_token. Revisar application-" + environment + ".properties en user.home");
                System.out.println(output.getResponseBody());
                return output;
            }

            Map<String, Object> requestMap = buildCreateCustomerRequest(
                    documentTypeId, documentNumber, firstLastName, secondLastName, firstName, secondName, phoneNumber, email);
            String requestBody = objectMapper.writeValueAsString(requestMap);
            System.out.println("[IFX] Request body:\n" + objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMap));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(normalizeBaseUrl(value("ifx.base-url", "")) + normalizePath(value("ifx.create-customer-path", "/party-reference-data-directory-customer/v1/customer/create"))))
                    .timeout(Duration.ofSeconds(60))
                    .header("accept", "application/json")
                    .header("authorization", normalizeBearer(accessToken))
                    .header("branchid", value("ifx.branch-id", "100"))
                    .header("chanelid", value("ifx.chanel-id", "16"))
                    .header("consumerid", value("ifx.consumer-id", "BPE"))
                    .header("content-type", "application/json")
                    .header("deviceid", value("ifx.device-id", "192.135.183.250"))
                    .header("funcionalidadid", value("ifx.funcionalidad-id", "Funcionalidad IFX"))
                    .header("iporigen", value("ifx.ip-origen", "192.135.183.200"))
                    .header("ocp-apim-subscription-key", value("ifx.subscription-key", ""))
                    .header("ocp-apim-subscription-secret", value("ifx.subscription-secret", ""))
                    .header("parentid", valueOrRandom(value("ifx.parent-id", "11a7f97345"), 10))
                    .header("timestamp", valueOrCurrentTimestamp(value("ifx.timestamp", "2016-05-24T11:57:48.000Z")))
                    .header("traceid", valueOrRandom(value("ifx.trace-id", "34338b0e6d2271c2345"), 20))
                    .header("userid", value("ifx.user-id", "S7301"))
                    .header("x-global-transaction-id", valueOrCurrentGlobalTransactionId(value("ifx.global-transaction-id", "20160623152105")))
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response = createHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            output.setStatusCode(response.statusCode());
            output.setBusResponseMessage(response.headers().firstValue("busresponsemessage").orElse(""));
            output.setSrvResponseCode(response.headers().firstValue("srvresponsecode").orElse(""));
            output.setSrvResponseMessage(response.headers().firstValue("srvresponsemessage").orElse(""));
            output.setResponseBody(response.body());

            System.out.println("[IFX] Documento generado: " + documentNumber);
            System.out.println("[IFX] Status: " + response.statusCode());
            System.out.println("[IFX] busresponsemessage: " + output.getBusResponseMessage());
            System.out.println("[IFX] srvresponsecode: " + output.getSrvResponseCode());
            System.out.println("[IFX] srvresponsemessage: " + output.getSrvResponseMessage());
            System.out.println("[IFX] Response: " + response.body());
            return output;
        } catch (Exception e) {
            throw new IllegalStateException("Error creando persona natural IFX: " + e.getMessage(), e);
        }
    }

    private String generateToken() throws Exception {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("grant_type", value("ifx.grant-type", "password"));
        form.put("username", value("ifx.username", ""));
        form.put("password", value("ifx.password", ""));
        form.put("client_id", value("ifx.client-id", ""));
        form.put("client_secret", value("ifx.client-secret", ""));
        form.put("scope", value("ifx.scope-transaccion", ""));

        String body = form.entrySet().stream()
                .map(e -> encode(e.getKey()) + "=" + encode(e.getValue()))
                .collect(Collectors.joining("&"));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(normalizeBaseUrl(value("ifx.base-url", "")) + normalizePath(value("ifx.token-path", "/oauthproviderh1/oauth2/token"))))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HttpResponse<String> response = createHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            System.out.println("[IFX TOKEN] Status: " + response.statusCode());
            System.out.println("[IFX TOKEN] Body: " + response.body());
            return null;
        }
        JsonNode json = objectMapper.readTree(response.body());
        JsonNode tokenNode = json.get("access_token");
        return tokenNode == null ? null : tokenNode.asText();
    }

    private Map<String, Object> buildCreateCustomerRequest(String documentTypeId,
                                                           String documentNumber,
                                                           String firstLastName,
                                                           String secondLastName,
                                                           String firstName,
                                                           String secondName,
                                                           String phoneNumber,
                                                           String email) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("documentTypeId", documentTypeId);
        body.put("documentNumber", documentNumber);
        body.put("passportNumber", value("ifx.passport-number", ""));
        body.put("birthDate", value("ifx.birth-date", "1980-12-12"));
        body.put("firstLastName", firstLastName);
        body.put("secondLastName", secondLastName);
        body.put("firstName", firstName);
        body.put("secondName", secondName);
        body.put("genderType", "M");
        body.put("maritalStatus", "S");
        body.put("nationalityCode", "0");
        body.put("birthCountryCode", "4028");
        body.put("residentCountryCode", "4028");
        body.put("nationalityCountryCode", "4028");
        body.put("streetType", "AV");
        body.put("streetName", "MARINA");
        body.put("streetNumber", "17");
        body.put("blockIdentification", "8");
        body.put("lotId", "G");
        body.put("insideId", "3");
        body.put("urbanizationName", "");
        body.put("locationReference", "");
        body.put("department", "CAJAMARCA");
        body.put("province", "CAJAMARCA");
        body.put("district", "CAJAMARCA");

        Map<String, String> phone = new LinkedHashMap<>();
        phone.put("phoneType", "CELULAR");
        phone.put("phonePrefix", "051");
        phone.put("phoneNumber", phoneNumber);
        phone.put("extension", "123");
        body.put("phoneAddress", List.of(phone));

        body.put("emailType", "P");
        body.put("email", email);
        body.put("ciiuCode", "");
        body.put("employmentDate", "");
        body.put("companyName", "SYNOPSIS");
        body.put("ocupationCode", "PRF");
        return body;
    }

    private String nextDni() throws IOException {
        long base = Long.parseLong(value("ifx.dni-base", "54072013"));
        Path path = Path.of(value("ifx.dni-sequence-file", "target/dni-sequence.txt"));
        Path parent = path.getParent();
        if (parent != null) Files.createDirectories(parent);
        long last = base - 1;
        if (Files.exists(path)) {
            String content = Files.readString(path).trim();
            if (!content.isEmpty()) last = Long.parseLong(content);
        }
        long next = last + 1;
        Files.writeString(path, String.valueOf(next));
        return String.format("%08d", next);
    }

    private Properties loadProperties(String env) {
        Properties properties = new Properties();
        String fileName = "application-" + env + ".properties";
        File localFile = new File(System.getProperty("user.home"), fileName);
        if (localFile.exists()) {
            try (FileInputStream fis = new FileInputStream(localFile)) {
                properties.load(fis);
                System.out.println("[TDM] Configuracion local cargada: " + localFile.getAbsolutePath());
            } catch (IOException e) {
                throw new IllegalStateException("No se pudo leer " + localFile.getAbsolutePath(), e);
            }
        } else {
            try (var stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties")) {
                if (stream != null) properties.load(stream);
                System.out.println("[TDM] No existe " + localFile.getAbsolutePath() + ". Se usara application.properties/variables de entorno.");
            } catch (IOException e) {
                throw new IllegalStateException("No se pudo leer application.properties", e);
            }
        }
        return properties;
    }

    private String value(String propertyKey, String defaultValue) {
        String sys = System.getProperty(propertyKey);
        if (!isBlank(sys)) return sys.trim();
        String envKey = propertyKey.toUpperCase().replace('.', '_').replace('-', '_');
        String env = System.getenv(envKey);
        if (!isBlank(env)) return env.trim();
        String prop = props.getProperty(propertyKey);
        if (!isBlank(prop)) return prop.trim();
        return defaultValue;
    }

    private HttpClient createHttpClient() throws Exception {
        String relaxedSslValue = value("ifx.relaxed-ssl", "true");
        boolean useRelaxedSsl = Boolean.parseBoolean(relaxedSslValue);
        System.out.println("[IFX] Propiedad ifx.relaxed-ssl=" + relaxedSslValue + " -> useRelaxedSsl=" + useRelaxedSsl);

        if (!useRelaxedSsl) {
            System.out.println("[IFX] Usando cliente HTTP con validacion de certificado estricta");
            return HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();
        }

        System.out.println("[IFX] Usando cliente HTTP con validacion de certificado relajada (SSL deshabilitado)");
        // Deshabilitar hostname verification a nivel de sistema
        System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");

        // Crear un X509ExtendedTrustManager que acepte todos los certificados
        X509ExtendedTrustManager trustAllCerts = new X509ExtendedTrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] certs, String authType) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType) { }
            public void checkClientTrusted(X509Certificate[] certs, String authType, java.net.Socket socket) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType, java.net.Socket socket) { }
            public void checkClientTrusted(X509Certificate[] certs, String authType, javax.net.ssl.SSLEngine engine) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType, javax.net.ssl.SSLEngine engine) { }
        };

        // Crear SSLContext con el TrustManager permisivo
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustAllCerts}, new SecureRandom());

        return HttpClient.newBuilder()
                .sslContext(sslContext)
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    private String normalizeTypeDocument(String typeDocument) {
        if (isBlank(typeDocument)) return "DNI";
        return typeDocument.trim().toUpperCase();
    }

    private String toIfxDocumentTypeId(String typeDocument) {
        switch (typeDocument) {
            case "DNI": return "1";
            case "RUC": return "2";
            case "CE": return "3";
            case "PASAPORTE": return "5";
            default: return typeDocument;
        }
    }

    private String normalizeBearer(String token) {
        if (isBlank(token)) return "";
        String value = token.trim();
        return value.toLowerCase().startsWith("bearer ") ? value : "Bearer " + value;
    }

    private String valueOrRandom(String configured, int length) {
        if (!isBlank(configured)) return configured.trim();
        String raw = UUID.randomUUID().toString().replace("-", "");
        return raw.substring(0, Math.min(length, raw.length()));
    }

    private String valueOrCurrentTimestamp(String configured) {
        if (!isBlank(configured)) return configured.trim();
        return DateTimeFormatter.ISO_INSTANT.format(Instant.now());
    }

    private String valueOrCurrentGlobalTransactionId(String configured) {
        if (!isBlank(configured)) return configured.trim();
        return DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneOffset.UTC).format(Instant.now());
    }

    private String normalizeBaseUrl(String value) {
        if (isBlank(value)) throw new IllegalStateException("Configure ifx.base-url en C:\\Users\\<usuario>\\application-" + environment + ".properties");
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private String normalizePath(String value) {
        if (isBlank(value)) return "";
        return value.startsWith("/") ? value : "/" + value;
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
