package com.nttdata.tdm;

import org.junit.jupiter.api.Test;

public class CD {
    /* ************ Ingresos automatizados ************ */
    // Cambiar a "stg" si necesitas ejecutar con application-stg.properties.
    String environment = System.getProperty("environment", "uat");

    /**
     * Crea una persona natural IFX con DNI incremental/dinamico.
     * Lee credenciales desde:
     * C:\Users\<tu_usuario>\application-uat.properties
     */
    @Test
    public void CrearPersonaNaturalIFX() {
        Do.crearPersonaNaturalIFX("DNI", environment);
    }

    /**
     * Ejemplo alternativo si luego necesitas CE.
     */
    @Test
    public void CrearPersonaNaturalIFX_CE() {
        Do.crearPersonaNaturalIFX("CE", environment);
    }
}
