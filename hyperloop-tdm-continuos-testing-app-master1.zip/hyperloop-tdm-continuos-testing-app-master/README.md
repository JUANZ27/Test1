## Requisitos
- Tener instalado **JDK 18**
- Tener instalado **Maven**

## Proyecto TDM
Proyecto para mantener datos disponibles y seguros que serán consumidos por automatizaciones.

## Configuración local requerida
Por seguridad, las URLs y credenciales no deben quedar quemadas en `src/main/resources/application.properties`.

Copiar los archivos:

- [`application-uat.properties`](src/Documents/application-uat.properties)
- [`application-stg.properties`](src/Documents/application-stg.properties)

a la carpeta del usuario local de Windows:

```text
C:\Users\<tu_usuario>\application-uat.properties
C:\Users\<tu_usuario>\application-stg.properties
```

Ejemplo:

```text
C:\Users\user\application-uat.properties
```

El proyecto lee ese archivo automáticamente usando:

```text
file:${user.home}/application-${environment}.properties
```

## Endpoint IFX implementado

```http
POST /tdm/ifx/customer/create?typeDocument=DNI
```

Consume internamente:

```text
/oauthproviderh1/oauth2/token
/party-reference-data-directory-customer/v1/customer/create
```

El DNI es incremental/dinámico desde `ifx.dni-base` y se guarda en:

```text
target/dni-sequence.txt
```

## Ejecución como API Spring Boot

```powershell
mvn spring-boot:run -Denvironment=uat
```

Luego consumir:

```powershell
curl --request POST "http://localhost:8080/tdm/ifx/customer/create?typeDocument=DNI"
```

## Ejecución desde clase CD.java

La clase está en:

```text
src/test/java/com/nttdata/tdm/CD.java
```

Método disponible:

```java
@Test
public void CrearPersonaNaturalIFX() {
    Do.crearPersonaNaturalIFX("DNI", environment);
}
```

Ejecutar:

```powershell
mvn -Dtest=CD#CrearPersonaNaturalIFX -Denvironment=uat test
```

## Uso desde otro proyecto Java

También se puede invocar directamente:

```java
Do.crearPersonaNaturalIFX("DNI", "uat");
```

## Nota importante del token
El `grant_type` correcto es:

```text
password
```

No usar `passwrod`.
