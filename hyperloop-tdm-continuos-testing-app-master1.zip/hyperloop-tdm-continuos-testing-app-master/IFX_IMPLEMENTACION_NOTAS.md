# Implementacion IFX - v3

Se corrigió la implementación para respetar el patrón del TDM:

1. Las credenciales se leen desde el usuario local:
   - `C:\Users\<usuario>\application-uat.properties`
   - `C:\Users\<usuario>\application-stg.properties`

2. `src/main/resources/application.properties` ya no contiene credenciales quemadas.

3. Se agregó clase de ejemplo:
   - `src/test/java/com/nttdata/tdm/CD.java`

4. Se agregó clase de uso directo:
   - `src/main/java/com/nttdata/tdm/Do.java`

5. Se agregó cliente standalone:
   - `src/main/java/com/nttdata/tdm/ifx/client/IfxStandaloneClient.java`

## Ejecutar desde CD.java

```powershell
mvn -Dtest=CD#CrearPersonaNaturalIFX -Denvironment=uat test
```

## Ejecutar como endpoint Spring

```powershell
mvn spring-boot:run -Denvironment=uat
curl --request POST "http://localhost:8080/tdm/ifx/customer/create?typeDocument=DNI"
```

## Endpoint IFX consumido

```text
POST /party-reference-data-directory-customer/v1/customer/create
```

## Token IFX

```text
POST /oauthproviderh1/oauth2/token
Content-Type: application/x-www-form-urlencoded
grant_type=password
```
