# IBK Performance Automation - Playwright + TypeScript + Cucumber BDD

Proyecto generado a partir de los 3 JMX entregados:

- `PN_all_profiles_2_endpoints_token_reportes.jmx`
- `PJ_all_profiles.jmx`
- `NoConstituida_all_profiles.jmx`

El objetivo es ejecutar pruebas de performance desde un stack moderno con:

- **Playwright APIRequestContext** para ejecutar requests HTTP.
- **TypeScript** para orquestación, métricas y reportes.
- **Cucumber + Gherkin + BDD** para escenarios legibles por negocio/QA.
- **Reporte HTML tipo JMeter Dashboard** similar al de JMeter.
- **JTL compatible con JMeter** para generar dashboard oficial si lo deseas.

## Flujos incluidos

### PN

1. Token inicial compartido
2. PN Compliance / Initial Validation
3. PN Business Account / Apertura

### PJ

1. Token inicial compartido
2. PJ Compliance
3. PJ Apertura
4. PJ Tracking

### No Constituida

1. Token inicial compartido
2. NC Creación de Expediente
3. NC Apertura de Cuenta

## Tipos de pruebas

Cada flujo tiene perfiles para:

- **Carga**: valida comportamiento con concurrencia esperada.
- **Pico**: valida reacción ante incremento rápido de usuarios.
- **Estrés**: busca degradación y límite del servicio.
- **Resiliencia**: valida estabilidad durante tiempo prolongado.

## Instalación

```bash
npm install
copy .env.example .env
```

En Git Bash o Linux/Mac:

```bash
cp .env.example .env
```

Completa el archivo `.env` con tus credenciales reales:

```env
TOKEN_BASIC_AUTH=Basic_REEMPLAZAR
TOKEN_SUBSCRIPTION_KEY=REEMPLAZAR_TOKEN_SUBSCRIPTION_KEY
API_SUBSCRIPTION_KEY=REEMPLAZAR_API_SUBSCRIPTION_KEY
CONSUMER_ID=REEMPLAZAR_CONSUMER_ID
```

## Ejecución por BDD

### PN

```bash
npm run test:pn:load
npm run test:pn:spike
npm run test:pn:stress
npm run test:pn:resilience
```

### PJ

```bash
npm run test:pj:load
npm run test:pj:spike
npm run test:pj:stress
npm run test:pj:resilience
```

### No Constituida

```bash
npm run test:nc:load
npm run test:nc:spike
npm run test:nc:stress
npm run test:nc:resilience
```

## Ejecución directa sin Cucumber

```bash
npm run perf:pn:load
npm run perf:pj:load
npm run perf:nc:load
```

## Cambiar duración, VUs y ramp-up

Se configura desde `.env`. Ejemplo:

```env
PN_LOAD_VUS=10
PN_LOAD_RAMP_UP=10s
PN_LOAD_DURATION=2m
PN_LOAD_RAMP_DOWN=10s

PJ_STRESS_MAX_VUS=100
PJ_STRESS_DURATION=15m

NC_RESILIENCE_DURATION=1h
```

Formato permitido:

```text
500ms
30s
10m
1h
```

## Reportes generados

Después de ejecutar se generan archivos en:

```text
reports/html/jmeter-dashboard-<flow>-<perfil>-<runId>.html
reports/html/informe-<flow>-<perfil>-<runId>.md
reports/jtl/<flow>-<perfil>-<runId>.jtl
reports/csv/samples-<flow>-<perfil>-<runId>.csv
reports/json/summary-<flow>-<perfil>-<runId>.json
```

El HTML incluye secciones similares al dashboard de JMeter:

- Test and Report information
- APDEX
- Requests Summary
- Statistics
- Errors
- Top 5 Errors by sampler
- HTTP Performance overview
- Response Time Scatter / dispersión
- Acceptance Criteria

## Generar dashboard oficial de JMeter desde el JTL

El proyecto genera un `.jtl` compatible con JMeter. Puedes crear el dashboard oficial así:

```bash
jmeter -g "reports/jtl/pn-carga-<runId>.jtl" -o "reports/jmeter-html/pn-carga"
```

En Windows con ruta completa:

```cmd
"C:\apache-jmeter-5.6.3\bin\jmeter.bat" -g "C:\ruta\reports\jtl\archivo.jtl" -o "C:\ruta\reports\jmeter-html\salida"
```

La carpeta de salida debe estar vacía o no existir.

## Decisión automática

El framework calcula decisión:

- **PASS**: cumple error rate, p95 y TPS mínimo.
- **FAIL**: supera error rate o p95 máximo.
- **REVIEW**: no falla gravemente, pero requiere revisión por TPS u otra señal.

Criterios por defecto:

```env
MAX_ERROR_RATE=0.01
P95_MAX_MS=3000
MIN_TPS=1
```

También se pueden definir desde los escenarios Gherkin.

## Buenas prácticas aplicadas

- No se graban videos ni screenshots, porque no aplican para performance API.
- Token inicial compartido, similar a setUp Thread Group de JMeter.
- Variables sensibles fuera del código, en `.env`.
- Generación dinámica de DNI/RUC por VU e iteración.
- Separación por capas: features, steps, runner, flows, fixtures, reportes y métricas.
- JTL compatible con JMeter para análisis externo.
