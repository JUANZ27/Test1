@echo off
npm run test:pn:load
pause
