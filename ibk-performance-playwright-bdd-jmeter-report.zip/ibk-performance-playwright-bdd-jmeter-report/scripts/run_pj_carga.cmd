@echo off
npm run test:pj:load
pause
