@echo off
npm run test:nc:load
pause
