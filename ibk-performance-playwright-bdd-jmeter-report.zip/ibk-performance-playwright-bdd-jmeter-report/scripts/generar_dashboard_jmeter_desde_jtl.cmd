@echo off
REM Uso: generar_dashboard_jmeter_desde_jtl.cmd reports\jtl\archivo.jtl reports\jmeter-html\salida
IF "%1"=="" (
  echo Debes indicar el archivo JTL.
  exit /b 1
)
IF "%2"=="" (
  echo Debes indicar la carpeta de salida.
  exit /b 1
)
jmeter -g "%1" -o "%2"
pause
