module.exports = {
  default: {
    requireModule: ['ts-node/register'],
    require: ['src/support/world.ts', 'src/steps/**/*.ts'],
    paths: ['features/**/*.feature'],
    format: [
      'progress-bar',
      'html:reports/html/cucumber-report.html',
      'json:reports/json/cucumber-report.json'
    ],
    publishQuiet: true,
    parallel: 0
  }
};
