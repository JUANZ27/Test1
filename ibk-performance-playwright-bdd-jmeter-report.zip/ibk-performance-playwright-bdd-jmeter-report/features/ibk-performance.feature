Feature: Pruebas de performance BDD para flujos IBK migrados desde JMeter
  Como QA Automation Senior
  Quiero ejecutar pruebas de carga, pico, estrés y resiliencia para PN, PJ y No Constituida
  Para obtener métricas y reportes tipo JMeter que permitan tomar decisiones técnicas

  Background:
    Given la URL base del ambiente está configurada

  @performance @PN @Carga
  Scenario: PN - Prueba de carga
    Given el flujo de performance es "PN"
    And el perfil de performance es "Carga"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.01  |
      | p95MaxMs     | <=       | 3000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PN @Pico
  Scenario: PN - Prueba de pico
    Given el flujo de performance es "PN"
    And el perfil de performance es "Pico"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.03  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PN @Estres
  Scenario: PN - Prueba de estrés
    Given el flujo de performance es "PN"
    And el perfil de performance es "Estres"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.05  |
      | p95MaxMs     | <=       | 8000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PN @Resiliencia
  Scenario: PN - Prueba de resiliencia
    Given el flujo de performance es "PN"
    And el perfil de performance es "Resiliencia"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.02  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PJ @Carga
  Scenario: PJ - Prueba de carga
    Given el flujo de performance es "PJ"
    And el perfil de performance es "Carga"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.01  |
      | p95MaxMs     | <=       | 3000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PJ @Pico
  Scenario: PJ - Prueba de pico
    Given el flujo de performance es "PJ"
    And el perfil de performance es "Pico"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.03  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PJ @Estres
  Scenario: PJ - Prueba de estrés
    Given el flujo de performance es "PJ"
    And el perfil de performance es "Estres"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.05  |
      | p95MaxMs     | <=       | 8000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @PJ @Resiliencia
  Scenario: PJ - Prueba de resiliencia
    Given el flujo de performance es "PJ"
    And el perfil de performance es "Resiliencia"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.02  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @NC @Carga
  Scenario: No Constituida - Prueba de carga
    Given el flujo de performance es "NC"
    And el perfil de performance es "Carga"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.01  |
      | p95MaxMs     | <=       | 3000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @NC @Pico
  Scenario: No Constituida - Prueba de pico
    Given el flujo de performance es "NC"
    And el perfil de performance es "Pico"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.03  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @NC @Estres
  Scenario: No Constituida - Prueba de estrés
    Given el flujo de performance es "NC"
    And el perfil de performance es "Estres"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.05  |
      | p95MaxMs     | <=       | 8000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada

  @performance @NC @Resiliencia
  Scenario: No Constituida - Prueba de resiliencia
    Given el flujo de performance es "NC"
    And el perfil de performance es "Resiliencia"
    And los criterios de aceptación son
      | metric       | operator | value |
      | maxErrorRate | <=       | 0.02  |
      | p95MaxMs     | <=       | 5000  |
      | minTps       | >=       | 1     |
    When ejecuto la prueba de performance
    Then se debe generar el reporte tipo JMeter
    And la decisión de performance debe ser calculada
