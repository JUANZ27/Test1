import path from 'path';
import { FlowDefinition, FlowName } from '../types/performance';
import { config } from '../support/config';

const payload = (file: string): string => path.resolve(process.cwd(), 'src', 'fixtures', 'payloads', file);

const jsonHeaders = (xTraceId: string): Record<string, string> => ({
  authorization: 'Bearer ${access_token}',
  'content-type': 'application/json',
  'ocp-apim-subscription-key': config.api.subscriptionKey,
  'x-trace-id': xTraceId
});

const aperturaHeaders = (): Record<string, string> => ({
  authorization: 'Bearer ${access_token}',
  'content-type': 'application/json',
  'ocp-apim-subscription-key': config.api.subscriptionKey,
  Channel: config.api.channel,
  'Consumer-Id': config.api.consumerId
});

export const flowDefinitions: Record<FlowName, FlowDefinition> = {
  PN: {
    name: 'PN',
    displayName: 'Persona Natural',
    jmxSource: 'PN_all_profiles_2_endpoints_token_reportes.jmx',
    dataFactory: 'pn',
    tokenRequired: true,
    steps: [
      {
        id: '01',
        label: '01 - PN Compliance / Initial Validation',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation',
        payloadFile: payload('pn-compliance.json'),
        headers: jsonHeaders(config.api.xTraceIdCompliance),
        expectedStatus: [200, 201],
        extractors: [
          { variable: 'expedientNumber', jsonPath: '$.expedientNumber', defaultValue: config.data.expedientNumberDefault }
        ]
      },
      {
        id: '02',
        label: '02 - PN Business Account / Apertura',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account',
        payloadFile: payload('pn-apertura.json'),
        headers: aperturaHeaders(),
        expectedStatus: [200, 201]
      }
    ]
  },
  PJ: {
    name: 'PJ',
    displayName: 'Persona Jurídica',
    jmxSource: 'PJ_all_profiles.jmx',
    dataFactory: 'pj',
    tokenRequired: true,
    steps: [
      {
        id: '01',
        label: '01 - PJ Compliance',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation',
        payloadFile: payload('pj-compliance.json'),
        headers: jsonHeaders(config.api.xTraceIdCompliance),
        expectedStatus: [200, 201],
        extractors: [
          { variable: 'expNumber', jsonPath: '$.expedientNumber', defaultValue: config.data.expedientNumberDefault },
          { variable: 'expedientNumber', jsonPath: '$.expedientNumber', defaultValue: config.data.expedientNumberDefault }
        ]
      },
      {
        id: '02',
        label: '02 - PJ Apertura',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account',
        payloadFile: payload('pj-apertura.json'),
        headers: aperturaHeaders(),
        expectedStatus: [200, 201]
      },
      {
        id: '03',
        label: '03 - PJ Tracking',
        method: 'GET',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account/status-expedient',
        query: { dni: '${dni}' },
        headers: jsonHeaders(config.api.xTraceIdTracking),
        expectedStatus: [200]
      }
    ]
  },
  NC: {
    name: 'NC',
    displayName: 'No Constituida',
    jmxSource: 'NoConstituida_all_profiles.jmx',
    dataFactory: 'nc',
    tokenRequired: true,
    steps: [
      {
        id: '01',
        label: '01 - NC Creación de Expediente',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation',
        payloadFile: payload('nc-compliance.json'),
        headers: jsonHeaders(config.api.xTraceIdCompliance),
        expectedStatus: [200, 201],
        extractors: [
          { variable: 'expedientNumber', jsonPath: '$.expedientNumber', defaultValue: config.data.expedientNumberDefault }
        ],
        postProcess: 'ncDocumentNumberFromExpedient'
      },
      {
        id: '02',
        label: '02 - NC Apertura de Cuenta',
        method: 'POST',
        path: '/bcv-bacc-party-lifecycle-management/v1/business-account',
        payloadFile: payload('nc-apertura.json'),
        headers: aperturaHeaders(),
        expectedStatus: [200, 201]
      }
    ]
  }
};

export function getFlow(flow: FlowName): FlowDefinition {
  const definition = flowDefinitions[flow];
  if (!definition) throw new Error(`Flujo no soportado: ${flow}`);
  return definition;
}
