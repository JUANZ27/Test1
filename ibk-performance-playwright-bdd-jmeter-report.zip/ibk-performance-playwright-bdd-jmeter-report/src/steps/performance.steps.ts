import assert from 'assert';
import { DataTable, Given, Then, When } from '@cucumber/cucumber';
import { config } from '../support/config';
import { CustomWorld } from '../support/world';
import { FlowName, ProfileName } from '../types/performance';
import { runPerformance } from '../runner/performance-runner';

Given('la URL base del ambiente está configurada', function () {
  assert.ok(config.baseUrl.startsWith('http'), 'BASE_URL debe iniciar con http o https');
});

Given('el flujo de performance es {string}', function (this: CustomWorld, flow: string) {
  const normalized = flow.toUpperCase();
  assert.ok(['PN', 'PJ', 'NC'].includes(normalized), `Flujo inválido: ${flow}`);
  this.flow = normalized as FlowName;
});

Given('el perfil de performance es {string}', function (this: CustomWorld, profile: string) {
  const normalized = normalizeProfile(profile);
  this.profile = normalized;
});

Given('los criterios de aceptación son', function (this: CustomWorld, table: DataTable) {
  for (const row of table.hashes()) {
    const metric = row.metric;
    const value = Number(row.value);
    if (!Number.isFinite(value)) throw new Error(`Valor inválido para ${metric}: ${row.value}`);
    if (metric === 'maxErrorRate') this.criteria.maxErrorRate = value;
    if (metric === 'p95MaxMs') this.criteria.p95MaxMs = value;
    if (metric === 'minTps') this.criteria.minTps = value;
  }
});

When('ejecuto la prueba de performance', async function (this: CustomWorld) {
  const flow = this.flow;
  const profile = this.profile;
  assert.ok(flow, 'Debe definirse el flujo de performance');
  assert.ok(profile, 'Debe definirse el perfil de performance');
  this.result = await runPerformance({ flow, profile, criteria: this.criteria });
});

Then('se debe generar el reporte tipo JMeter', function (this: CustomWorld) {
  const result = this.result;
  assert.ok(result?.output.htmlReport, 'No se generó HTML report');
  assert.ok(result.output.jtlFile, 'No se generó JTL compatible JMeter');
  this.attach(`Reporte HTML: ${result.output.htmlReport}`, 'text/plain');
  this.attach(`JTL: ${result.output.jtlFile}`, 'text/plain');
});

Then('la decisión de performance debe ser calculada', function (this: CustomWorld) {
  const result = this.result;
  assert.ok(result?.summary.decision, 'No se calculó decisión');
  this.attach(JSON.stringify(result.summary, null, 2), 'application/json');
});

function normalizeProfile(profile: string): ProfileName {
  const normalized = profile.toLowerCase();
  if (normalized === 'carga' || normalized === 'load') return 'Carga';
  if (normalized === 'pico' || normalized === 'spike') return 'Pico';
  if (normalized === 'estres' || normalized === 'estrés' || normalized === 'stress') return 'Estres';
  if (normalized === 'resiliencia' || normalized === 'resilience' || normalized === 'endurance') return 'Resiliencia';
  throw new Error(`Perfil inválido: ${profile}`);
}
