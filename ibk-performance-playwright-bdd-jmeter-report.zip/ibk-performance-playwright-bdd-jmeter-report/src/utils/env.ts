import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

export function env(name: string, defaultValue = ''): string {
  const value = process.env[name];
  return value === undefined || value === null || value === '' ? defaultValue : value;
}

export function intEnv(name: string, defaultValue: number): number {
  const raw = env(name, String(defaultValue));
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) ? value : defaultValue;
}

export function numberEnv(name: string, defaultValue: number): number {
  const raw = env(name, String(defaultValue));
  const value = Number.parseFloat(raw);
  return Number.isFinite(value) ? value : defaultValue;
}
