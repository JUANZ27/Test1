export function readJsonPath(source: unknown, path: string): string | undefined {
  if (!path.startsWith('$.')) return undefined;
  const parts = path.slice(2).split('.');
  let current: unknown = source;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    const arrayMatch = /^(\w+)\[(\d+)]$/.exec(part);
    if (arrayMatch) {
      const [, key, index] = arrayMatch;
      current = (current as Record<string, unknown>)[key];
      if (!Array.isArray(current)) return undefined;
      current = current[Number(index)];
      continue;
    }
    current = (current as Record<string, unknown>)[part];
  }
  return current === undefined || current === null ? undefined : String(current);
}
