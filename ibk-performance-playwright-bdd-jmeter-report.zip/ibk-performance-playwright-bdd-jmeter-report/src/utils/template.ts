import { RuntimeVariables } from '../types/performance';

export function applyTemplate(value: string, variables: RuntimeVariables): string {
  return value.replace(/\$\{([^}]+)\}/g, (_, expression: string) => {
    const cleanExpression = expression.replace(/^__P\((.*)\)$/, '$1');
    const replacement = variables[cleanExpression];
    return replacement === undefined || replacement === null ? '' : String(replacement);
  });
}

export function applyTemplateToObject<T>(value: T, variables: RuntimeVariables): T {
  if (typeof value === 'string') return applyTemplate(value, variables) as unknown as T;
  if (Array.isArray(value)) return value.map(item => applyTemplateToObject(item, variables)) as unknown as T;
  if (value && typeof value === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      result[key] = applyTemplateToObject(item, variables);
    }
    return result as T;
  }
  return value;
}
