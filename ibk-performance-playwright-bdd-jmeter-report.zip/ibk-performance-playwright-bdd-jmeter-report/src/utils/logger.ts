import path from 'path';
import { writeText, ensureDir } from './fs';
import fs from 'fs';

const logDir = path.resolve(process.cwd(), 'reports/logs');
ensureDir(logDir);
const logFile = path.join(logDir, `execution-${new Date().toISOString().replace(/[:.]/g, '-')}.log`);

export function log(message: string, data?: unknown): void {
  const line = `[${new Date().toISOString()}] ${message}${data !== undefined ? ` ${JSON.stringify(data)}` : ''}`;
  console.log(line);
  fs.appendFileSync(logFile, `${line}\n`, 'utf-8');
}

export function getLogFile(): string {
  return logFile;
}
