import path from 'path';
import { writeText } from './fs';
import { AcceptanceCriteria, PerformanceRunResult, PerformanceSummary, SampleResult } from '../types/performance';
import { formatDateTime } from './time';

export function writeReports(result: PerformanceRunResult): PerformanceRunResult {
  const baseName = `${result.flow.toLowerCase()}-${result.profile.toLowerCase()}-${result.runId}`;
  const jtlFile = path.resolve(process.cwd(), 'reports', 'jtl', `${baseName}.jtl`);
  const csvFile = path.resolve(process.cwd(), 'reports', 'csv', `samples-${baseName}.csv`);
  const jsonSummary = path.resolve(process.cwd(), 'reports', 'json', `summary-${baseName}.json`);
  const htmlReport = path.resolve(process.cwd(), 'reports', 'html', `jmeter-dashboard-${baseName}.html`);
  const markdownReport = path.resolve(process.cwd(), 'reports', 'html', `informe-${baseName}.md`);

  writeText(jtlFile, toJMeterCsv(result.samples));
  writeText(csvFile, toJMeterCsv(result.samples));
  writeText(jsonSummary, JSON.stringify(result.summary, null, 2));
  writeText(markdownReport, toMarkdown(result));
  writeText(htmlReport, toHtml(result));

  result.output = { jtlFile, csvFile, jsonSummary, htmlReport, markdownReport };
  return result;
}

export function toJMeterCsv(samples: SampleResult[]): string {
  const header = ['timeStamp', 'elapsed', 'label', 'responseCode', 'responseMessage', 'threadName', 'dataType', 'success', 'failureMessage', 'bytes', 'sentBytes', 'grpThreads', 'allThreads', 'URL', 'Latency', 'IdleTime', 'Connect'];
  const rows = samples.map(sample => header.map(key => csvEscape(String((sample as unknown as Record<string, unknown>)[key] ?? ''))).join(','));
  return [header.join(','), ...rows].join('\n');
}

function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

function toMarkdown(result: PerformanceRunResult): string {
  const s = result.summary;
  const reasons = s.decisionReasons.length ? s.decisionReasons.map(reason => `- ${reason}`).join('\n') : '- Cumple los criterios definidos.';
  return `# Informe de performance - ${result.flow} ${result.profile}\n\n` +
    `## Información de la prueba\n\n` +
    `- Flujo: ${result.flow}\n` +
    `- Perfil: ${result.profile}\n` +
    `- Inicio: ${formatDateTime(result.startTime)}\n` +
    `- Fin: ${formatDateTime(result.endTime)}\n` +
    `- VUs: ${result.profileConfig.vus}\n` +
    `- Ramp up: ${result.profileConfig.rampUp}\n` +
    `- Duración: ${result.profileConfig.duration}\n` +
    `- Ramp down: ${result.profileConfig.rampDown}\n\n` +
    `## Resultado ejecutivo\n\n` +
    `- Decisión: **${s.decision}**\n` +
    `- Total muestras: ${s.totalSamples}\n` +
    `- Error rate: ${(s.errorRate * 100).toFixed(2)}%\n` +
    `- TPS promedio: ${s.tps.toFixed(2)}\n` +
    `- TPS pico: ${s.peakTps.toFixed(2)}\n` +
    `- Promedio: ${s.average} ms\n` +
    `- p90: ${s.p90} ms\n` +
    `- p95: ${s.p95} ms\n` +
    `- p99: ${s.p99} ms\n` +
    `- Apdex: ${s.apdex}\n\n` +
    `## Criterios de aceptación\n\n` +
    `- Max error rate: ${(result.criteria.maxErrorRate * 100).toFixed(2)}%\n` +
    `- p95 máximo: ${result.criteria.p95MaxMs} ms\n` +
    `- TPS mínimo: ${result.criteria.minTps}\n\n` +
    `## Decisión\n\n${reasons}\n`;
}

function toHtml(result: PerformanceRunResult): string {
  const s = result.summary;
  const pie = pieChart(s.failures, s.totalSamples - s.failures);
  const throughputChart = lineChart(buildTimeSeries(result.samples, 'throughput'), 'Throughput / sec');
  const responseScatter = scatterChart(result.samples);
  const durationChart = lineChart(buildPercentileSeries(result.samples), 'Duration p95');

  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>JMeter-like Dashboard - ${escapeHtml(result.flow)} ${escapeHtml(result.profile)}</title>
  <style>
    :root { --blue:#7fb3df; --blue2:#dcecf9; --green:#91d13d; --red:#ff5c45; --gray:#f3f5f7; --dark:#28323c; --border:#d9e1e8; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:Arial, Helvetica, sans-serif; color:#1f2933; background:#ffffff; }
    .app { display:flex; min-height:100vh; }
    .sidebar { width:170px; background:#f5f7fa; border-right:1px solid #d7dde4; padding:18px 12px; }
    .logo { font-size:18px; color:#555; font-weight:700; margin-bottom:20px; }
    .menu { font-size:13px; color:#2b5d91; line-height:32px; }
    .content { flex:1; padding:24px 28px; }
    h1 { margin:0 0 18px; font-size:22px; color:#374151; }
    h2 { font-size:16px; text-align:center; margin:8px 0 12px; color:#34495e; }
    .panel { border:1px solid var(--border); margin-bottom:20px; background:#fff; }
    .panel-header { background:#f1f3f5; padding:10px 14px; font-weight:700; text-align:center; color:#2c3e50; border-bottom:1px solid var(--border); }
    table { width:100%; border-collapse:collapse; font-size:12px; }
    th { background:#9fc5e8; color:#1f2933; border:1px solid #cbd7e2; padding:7px; text-align:center; }
    td { border:1px solid #dce3ea; padding:7px; }
    tr:nth-child(even) td { background:#eef5fb; }
    .grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
    .kpis { display:grid; grid-template-columns:repeat(6, minmax(120px,1fr)); gap:12px; margin-bottom:20px; }
    .kpi { border:1px solid var(--border); border-radius:6px; padding:12px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,.04); }
    .kpi-title { color:#687788; font-size:12px; font-weight:700; margin-bottom:5px; }
    .kpi-value { font-size:24px; color:#1f2933; }
    .decision { font-weight:700; padding:10px 14px; border-radius:4px; display:inline-block; }
    .PASS { color:#14532d; background:#dcfce7; }
    .REVIEW { color:#7c2d12; background:#ffedd5; }
    .FAIL { color:#7f1d1d; background:#fee2e2; }
    .chart { min-height:240px; padding:10px; }
    .small { font-size:12px; color:#5f6b7a; }
    .right { text-align:right; }
    .center { text-align:center; }
    .summary { display:flex; gap:20px; align-items:center; justify-content:center; padding:14px; }
    .legend span { display:inline-block; margin-right:14px; }
    .legend i { display:inline-block; width:10px; height:10px; margin-right:5px; vertical-align:middle; }
    @media (max-width: 1000px) { .app {display:block;} .sidebar{width:auto;} .kpis{grid-template-columns:repeat(2,1fr);} .grid-2{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<div class="app">
  <aside class="sidebar">
    <div class="logo">Apache JMeter Dashboard</div>
    <div class="menu">▸ Dashboard<br/>▸ Charts<br/>▸ Customs Graphs</div>
  </aside>
  <main class="content">
    <h1>Reporte tipo JMeter - ${escapeHtml(result.flow)} / ${escapeHtml(result.profile)}</h1>
    <div class="kpis">
      <div class="kpi"><div class="kpi-title">Samples</div><div class="kpi-value">${s.totalSamples}</div></div>
      <div class="kpi"><div class="kpi-title">Throughput</div><div class="kpi-value">${s.tps.toFixed(2)}/s</div></div>
      <div class="kpi"><div class="kpi-title">Avg Response</div><div class="kpi-value">${s.average}ms</div></div>
      <div class="kpi"><div class="kpi-title">p95</div><div class="kpi-value">${s.p95}ms</div></div>
      <div class="kpi"><div class="kpi-title">Error %</div><div class="kpi-value">${(s.errorRate * 100).toFixed(2)}%</div></div>
      <div class="kpi"><div class="kpi-title">Apdex</div><div class="kpi-value">${s.apdex}</div></div>
    </div>

    <section class="panel">
      <div class="panel-header">Test and Report information</div>
      <table>
        <tbody>
          <tr><td>Source file</td><td>${escapeHtml(result.flow)} desde ${escapeHtml(result.profileConfig.description)}</td></tr>
          <tr><td>Start time</td><td>${escapeHtml(formatDateTime(result.startTime))}</td></tr>
          <tr><td>End time</td><td>${escapeHtml(formatDateTime(result.endTime))}</td></tr>
          <tr><td>VUs / Ramp / Duration</td><td>${result.profileConfig.vus} VUs / ${escapeHtml(result.profileConfig.rampUp)} / ${escapeHtml(result.profileConfig.duration)}</td></tr>
          <tr><td>Decision</td><td><span class="decision ${s.decision}">${s.decision}</span> ${escapeHtml(s.decisionReasons.join(' | ') || 'Cumple criterios')}</td></tr>
        </tbody>
      </table>
    </section>

    <div class="grid-2">
      <section class="panel">
        <div class="panel-header">APDEX (Application Performance Index)</div>
        <table>
          <thead><tr><th>Apdex</th><th>T (Toleration threshold)</th><th>F (Frustration threshold)</th><th>Label</th></tr></thead>
          <tbody>
            <tr><td class="center">${s.apdex}</td><td class="center">500 ms</td><td class="center">1 sec 500 ms</td><td>Total</td></tr>
            ${s.labels.map(row => `<tr><td class="center">${calculateApdexForLabel(result.samples, row.label)}</td><td class="center">500 ms</td><td class="center">1 sec 500 ms</td><td>${escapeHtml(row.label)}</td></tr>`).join('')}
          </tbody>
        </table>
      </section>
      <section class="panel">
        <div class="panel-header">Requests Summary</div>
        <div class="summary">${pie}<div class="legend"><span><i style="background:var(--red)"></i>FAIL ${s.failures}</span><br/><span><i style="background:var(--green)"></i>PASS ${s.totalSamples - s.failures}</span></div></div>
      </section>
    </div>

    <section class="panel">
      <div class="panel-header">Statistics</div>
      ${statisticsTable(s)}
    </section>

    <section class="panel">
      <div class="panel-header">Errors</div>
      ${errorsTable(s)}
    </section>

    <section class="panel">
      <div class="panel-header">Top 5 Errors by sampler</div>
      ${topErrorsTable(s)}
    </section>

    <div class="grid-2">
      <section class="panel"><div class="panel-header">HTTP Performance overview</div><div class="chart">${throughputChart}</div></section>
      <section class="panel"><div class="panel-header">Response Time Scatter / Dispersión</div><div class="chart">${responseScatter}</div></section>
      <section class="panel"><div class="panel-header">HTTP Request Duration</div><div class="chart">${durationChart}</div></section>
      <section class="panel"><div class="panel-header">Acceptance Criteria</div>${criteriaTable(result.criteria, s)}</section>
    </div>
  </main>
</div>
</body>
</html>`;
}

function statisticsTable(summary: PerformanceSummary): string {
  const rows = [
    { label: 'Total', samples: summary.totalSamples, failures: summary.failures, errorRate: summary.errorRate, average: summary.average, min: summary.min, max: summary.max, median: summary.median, p90: summary.p90, p95: summary.p95, p99: summary.p99, throughput: summary.tps, receivedKbSec: summary.receivedKbSec, sentKbSec: summary.sentKbSec },
    ...summary.labels
  ];
  return `<table><thead><tr><th>Label</th><th># Samples</th><th>FAIL</th><th>Error %</th><th>Average</th><th>Min</th><th>Max</th><th>Median</th><th>90th pct</th><th>95th pct</th><th>99th pct</th><th>Throughput</th><th>Received KB/sec</th><th>Sent KB/sec</th></tr></thead><tbody>${rows.map(row => `<tr><td>${escapeHtml(row.label)}</td><td class="right">${row.samples}</td><td class="right">${row.failures}</td><td class="right">${(row.errorRate * 100).toFixed(2)}%</td><td class="right">${row.average}</td><td class="right">${row.min}</td><td class="right">${row.max}</td><td class="right">${row.median}</td><td class="right">${row.p90}</td><td class="right">${row.p95}</td><td class="right">${row.p99}</td><td class="right">${row.throughput.toFixed(2)}</td><td class="right">${row.receivedKbSec.toFixed(2)}</td><td class="right">${row.sentKbSec.toFixed(2)}</td></tr>`).join('')}</tbody></table>`;
}

function errorsTable(summary: PerformanceSummary): string {
  if (!summary.errors.length) return '<div class="small" style="padding:14px;">No se registraron errores.</div>';
  return `<table><thead><tr><th>Type of error</th><th>Number of errors</th><th>% in errors</th><th>% in all samples</th></tr></thead><tbody>${summary.errors.map(row => `<tr><td>${escapeHtml(row.responseCode)} / ${escapeHtml(row.responseMessage)}</td><td class="right">${row.count}</td><td class="right">${(row.percentage * 100).toFixed(2)}%</td><td class="right">${((row.count / Math.max(summary.totalSamples, 1)) * 100).toFixed(2)}%</td></tr>`).join('')}</tbody></table>`;
}

function topErrorsTable(summary: PerformanceSummary): string {
  if (!summary.topErrorsBySampler.length) return '<div class="small" style="padding:14px;">No se registraron errores por sampler.</div>';
  return `<table><thead><tr><th>Sample</th><th># Errors</th><th>Error</th></tr></thead><tbody>${summary.topErrorsBySampler.map(row => `<tr><td>${escapeHtml(row.label)}</td><td class="right">${row.count}</td><td>${escapeHtml(row.responseCode)} / ${escapeHtml(row.responseMessage)}</td></tr>`).join('')}</tbody></table>`;
}

function criteriaTable(criteria: AcceptanceCriteria, summary: PerformanceSummary): string {
  const rows = [
    ['maxErrorRate', '<=', `${(criteria.maxErrorRate * 100).toFixed(2)}%`, `${(summary.errorRate * 100).toFixed(2)}%`, summary.errorRate <= criteria.maxErrorRate],
    ['p95MaxMs', '<=', `${criteria.p95MaxMs} ms`, `${summary.p95} ms`, summary.p95 <= criteria.p95MaxMs],
    ['minTps', '>=', String(criteria.minTps), summary.tps.toFixed(2), summary.tps >= criteria.minTps]
  ];
  return `<table><thead><tr><th>Metric</th><th>Operator</th><th>Expected</th><th>Actual</th><th>Status</th></tr></thead><tbody>${rows.map(([m, o, e, a, ok]) => `<tr><td>${m}</td><td class="center">${o}</td><td class="right">${e}</td><td class="right">${a}</td><td class="center">${ok ? 'PASS' : 'FAIL'}</td></tr>`).join('')}</tbody></table>`;
}

function pieChart(fail: number, pass: number): string {
  const total = fail + pass || 1;
  const failPct = fail / total;
  const angle = failPct * 360;
  return `<svg width="220" height="150" viewBox="0 0 220 150" role="img"><circle r="55" cx="110" cy="75" fill="var(--green)"></circle><path d="${describeArc(110, 75, 55, 0, angle)}" fill="var(--red)"></path><text x="110" y="80" text-anchor="middle" font-size="13" font-weight="bold">FAIL ${(failPct * 100).toFixed(1)}%</text></svg>`;
}

function describeArc(cx: number, cy: number, r: number, startAngle: number, endAngle: number): string {
  if (endAngle <= 0) return '';
  if (endAngle >= 359.99) endAngle = 359.99;
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
  return ['M', cx, cy, 'L', start.x, start.y, 'A', r, r, 0, largeArcFlag, 0, end.x, end.y, 'Z'].join(' ');
}

function polarToCartesian(cx: number, cy: number, r: number, angleInDegrees: number): { x: number; y: number } {
  const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return { x: cx + (r * Math.cos(angleInRadians)), y: cy + (r * Math.sin(angleInRadians)) };
}

function lineChart(points: Array<{ x: number; y: number }>, title: string): string {
  const width = 560;
  const height = 220;
  if (!points.length) return '<div class="small">Sin data suficiente para graficar.</div>';
  const maxX = Math.max(...points.map(p => p.x));
  const minX = Math.min(...points.map(p => p.x));
  const maxY = Math.max(...points.map(p => p.y), 1);
  const minY = 0;
  const d = points.map((p, index) => {
    const x = 40 + ((p.x - minX) / Math.max(maxX - minX, 1)) * (width - 70);
    const y = height - 30 - ((p.y - minY) / Math.max(maxY - minY, 1)) * (height - 60);
    return `${index === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return `<svg width="100%" viewBox="0 0 ${width} ${height}"><text x="40" y="16" font-size="12">${escapeHtml(title)}</text><line x1="40" y1="190" x2="540" y2="190" stroke="#ccd"/><line x1="40" y1="30" x2="40" y2="190" stroke="#ccd"/><path d="${d}" fill="none" stroke="#5fa8d3" stroke-width="2"/><path d="${d} L540,190 L40,190 Z" fill="#dcecf9" opacity="0.6"/></svg>`;
}

function scatterChart(samples: SampleResult[]): string {
  const width = 560;
  const height = 220;
  if (!samples.length) return '<div class="small">Sin muestras.</div>';
  const minTs = Math.min(...samples.map(s => s.timeStamp));
  const maxTs = Math.max(...samples.map(s => s.timeStamp));
  const maxElapsed = Math.max(...samples.map(s => s.elapsed), 1);
  const dots = samples.slice(0, 2000).map(sample => {
    const x = 40 + ((sample.timeStamp - minTs) / Math.max(maxTs - minTs, 1)) * (width - 70);
    const y = height - 30 - (sample.elapsed / maxElapsed) * (height - 60);
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2" fill="${sample.success ? '#5fa8d3' : '#ff5c45'}" opacity="0.75"/>`;
  }).join('');
  return `<svg width="100%" viewBox="0 0 ${width} ${height}"><text x="40" y="16" font-size="12">Response Time Scatter</text><line x1="40" y1="190" x2="540" y2="190" stroke="#ccd"/><line x1="40" y1="30" x2="40" y2="190" stroke="#ccd"/>${dots}</svg>`;
}

function buildTimeSeries(samples: SampleResult[], mode: 'throughput'): Array<{ x: number; y: number }> {
  const map = new Map<number, number>();
  for (const sample of samples) {
    const second = Math.floor(sample.timeStamp / 1000);
    map.set(second, (map.get(second) ?? 0) + 1);
  }
  return [...map.entries()].sort(([a], [b]) => a - b).map(([x, y]) => ({ x, y }));
}

function buildPercentileSeries(samples: SampleResult[]): Array<{ x: number; y: number }> {
  const bucket = new Map<number, number[]>();
  for (const sample of samples) {
    const second = Math.floor(sample.timeStamp / 1000);
    const values = bucket.get(second) ?? [];
    values.push(sample.elapsed);
    bucket.set(second, values);
  }
  return [...bucket.entries()].sort(([a], [b]) => a - b).map(([x, values]) => ({ x, y: percentile(values.sort((a, b) => a - b), 95) }));
}

function percentile(values: number[], pct: number): number {
  if (!values.length) return 0;
  const index = Math.ceil((pct / 100) * values.length) - 1;
  return values[Math.max(0, Math.min(index, values.length - 1))];
}

function calculateApdexForLabel(samples: SampleResult[], label: string): string {
  const values = samples.filter(s => s.label === label);
  if (!values.length) return '0.000';
  const satisfied = values.filter(sample => sample.success && sample.elapsed <= 500).length;
  const tolerated = values.filter(sample => sample.success && sample.elapsed > 500 && sample.elapsed <= 1500).length;
  return ((satisfied + tolerated / 2) / values.length).toFixed(3);
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char] ?? char));
}
