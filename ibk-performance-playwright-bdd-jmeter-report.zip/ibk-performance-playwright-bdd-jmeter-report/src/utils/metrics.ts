import { AcceptanceCriteria, LabelSummary, PerformanceSummary, SampleResult } from '../types/performance';
import { config } from '../support/config';
import { msToSeconds } from './time';

export function buildSummary(samples: SampleResult[], startedAt: number, endedAt: number, criteria: AcceptanceCriteria): PerformanceSummary {
  const elapsedValues = samples.map(sample => sample.elapsed).sort((a, b) => a - b);
  const durationSec = msToSeconds(endedAt - startedAt);
  const failures = samples.filter(sample => !sample.success).length;
  const labels = [...new Set(samples.map(sample => sample.label))].map(label => summarizeLabel(label, samples.filter(sample => sample.label === label), durationSec));
  const tpsBySecond = groupTpsBySecond(samples);
  const errors = summarizeErrors(samples);
  const topErrorsBySampler = summarizeTopErrorsBySampler(samples);

  const summary: PerformanceSummary = {
    totalSamples: samples.length,
    failures,
    errorRate: samples.length ? failures / samples.length : 0,
    average: average(elapsedValues),
    min: elapsedValues[0] ?? 0,
    max: elapsedValues[elapsedValues.length - 1] ?? 0,
    median: percentile(elapsedValues, 50),
    p90: percentile(elapsedValues, 90),
    p95: percentile(elapsedValues, 95),
    p99: percentile(elapsedValues, 99),
    tps: samples.length / durationSec,
    peakTps: Math.max(0, ...Object.values(tpsBySecond)),
    apdex: calculateApdex(samples),
    receivedKbSec: samples.reduce((sum, sample) => sum + sample.bytes, 0) / 1024 / durationSec,
    sentKbSec: samples.reduce((sum, sample) => sum + sample.sentBytes, 0) / 1024 / durationSec,
    labels,
    errors,
    topErrorsBySampler,
    decision: 'REVIEW',
    decisionReasons: []
  };

  summary.decisionReasons = buildDecisionReasons(summary, criteria);
  summary.decision = summary.decisionReasons.length === 0 ? 'PASS' : summary.errorRate > criteria.maxErrorRate || summary.p95 > criteria.p95MaxMs ? 'FAIL' : 'REVIEW';
  return summary;
}

export function percentile(sortedValues: number[], pct: number): number {
  if (!sortedValues.length) return 0;
  const index = Math.ceil((pct / 100) * sortedValues.length) - 1;
  return sortedValues[Math.max(0, Math.min(index, sortedValues.length - 1))];
}

function average(values: number[]): number {
  return values.length ? Math.round(values.reduce((sum, value) => sum + value, 0) / values.length) : 0;
}

function summarizeLabel(label: string, samples: SampleResult[], durationSec: number): LabelSummary {
  const values = samples.map(sample => sample.elapsed).sort((a, b) => a - b);
  const failures = samples.filter(sample => !sample.success).length;
  return {
    label,
    samples: samples.length,
    failures,
    errorRate: samples.length ? failures / samples.length : 0,
    average: average(values),
    min: values[0] ?? 0,
    max: values[values.length - 1] ?? 0,
    median: percentile(values, 50),
    p90: percentile(values, 90),
    p95: percentile(values, 95),
    p99: percentile(values, 99),
    throughput: samples.length / durationSec,
    receivedKbSec: samples.reduce((sum, sample) => sum + sample.bytes, 0) / 1024 / durationSec,
    sentKbSec: samples.reduce((sum, sample) => sum + sample.sentBytes, 0) / 1024 / durationSec
  };
}

function calculateApdex(samples: SampleResult[]): number {
  if (!samples.length) return 0;
  const satisfied = samples.filter(sample => sample.success && sample.elapsed <= config.apdex.tMs).length;
  const tolerated = samples.filter(sample => sample.success && sample.elapsed > config.apdex.tMs && sample.elapsed <= config.apdex.fMs).length;
  return Number(((satisfied + tolerated / 2) / samples.length).toFixed(3));
}

function summarizeErrors(samples: SampleResult[]): Array<{ responseCode: string; responseMessage: string; count: number; percentage: number }> {
  const errors = samples.filter(sample => !sample.success);
  const map = new Map<string, { responseCode: string; responseMessage: string; count: number }>();
  for (const sample of errors) {
    const key = `${sample.responseCode}|${sample.responseMessage}`;
    const current = map.get(key) ?? { responseCode: sample.responseCode, responseMessage: sample.responseMessage, count: 0 };
    current.count += 1;
    map.set(key, current);
  }
  return [...map.values()]
    .sort((a, b) => b.count - a.count)
    .map(item => ({ ...item, percentage: errors.length ? item.count / errors.length : 0 }));
}

function summarizeTopErrorsBySampler(samples: SampleResult[]): Array<{ label: string; responseCode: string; responseMessage: string; count: number }> {
  const map = new Map<string, { label: string; responseCode: string; responseMessage: string; count: number }>();
  for (const sample of samples.filter(item => !item.success)) {
    const key = `${sample.label}|${sample.responseCode}|${sample.responseMessage}`;
    const current = map.get(key) ?? { label: sample.label, responseCode: sample.responseCode, responseMessage: sample.responseMessage, count: 0 };
    current.count += 1;
    map.set(key, current);
  }
  return [...map.values()].sort((a, b) => b.count - a.count).slice(0, 5);
}

function groupTpsBySecond(samples: SampleResult[]): Record<string, number> {
  const map: Record<string, number> = {};
  for (const sample of samples) {
    const second = Math.floor(sample.timeStamp / 1000).toString();
    map[second] = (map[second] ?? 0) + 1;
  }
  return map;
}

function buildDecisionReasons(summary: PerformanceSummary, criteria: AcceptanceCriteria): string[] {
  const reasons: string[] = [];
  if (summary.errorRate > criteria.maxErrorRate) reasons.push(`Error rate ${(summary.errorRate * 100).toFixed(2)}% supera ${(criteria.maxErrorRate * 100).toFixed(2)}%.`);
  if (summary.p95 > criteria.p95MaxMs) reasons.push(`p95 ${summary.p95} ms supera ${criteria.p95MaxMs} ms.`);
  if (summary.tps < criteria.minTps) reasons.push(`TPS promedio ${summary.tps.toFixed(2)} es menor a ${criteria.minTps}.`);
  return reasons;
}
