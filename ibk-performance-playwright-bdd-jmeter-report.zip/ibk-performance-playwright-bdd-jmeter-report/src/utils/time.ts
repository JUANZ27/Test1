export function parseDurationToMs(value: string): number {
  const match = /^\s*(\d+(?:\.\d+)?)\s*(ms|s|m|h)\s*$/i.exec(value);
  if (!match) throw new Error(`Duración inválida: ${value}. Usa formato 500ms, 30s, 10m o 1h.`);
  const amount = Number(match[1]);
  const unit = match[2].toLowerCase();
  const multiplier = unit === 'ms' ? 1 : unit === 's' ? 1000 : unit === 'm' ? 60000 : 3600000;
  return Math.round(amount * multiplier);
}

export function msToSeconds(ms: number): number {
  return Math.max(ms / 1000, 0.001);
}

export function formatDateTime(value: string | number | Date): string {
  return new Date(value).toLocaleString('es-PE', { hour12: true });
}
