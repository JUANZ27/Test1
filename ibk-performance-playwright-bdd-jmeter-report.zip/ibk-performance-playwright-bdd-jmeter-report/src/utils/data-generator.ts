import { FlowDefinition, RuntimeVariables } from '../types/performance';
import { config } from '../support/config';

export function createBaseVariables(flow: FlowDefinition, vu: number, iteration: number): RuntimeVariables {
  const uniqueSeed = Date.now() + vu * 100000 + iteration;
  const dni = generateDni(uniqueSeed);
  const ruc = generateRuc(uniqueSeed);
  const variables: RuntimeVariables = {
    dni,
    ruc,
    email: `qa.${flow.name.toLowerCase()}.${dni}@yopmail.com`,
    access_token: config.token.accessTokenOverride || '',
    expNumber: config.data.expedientNumberDefault,
    expedientNumber: config.data.expedientNumberDefault,
    documentNumber: buildDocumentNumber(config.data.expedientNumberDefault)
  };

  if (flow.dataFactory === 'pn') {
    variables.ruc = '';
  }

  if (flow.dataFactory === 'nc') {
    variables.ruc = '';
    variables.legalDocumentNumber = '';
  }

  return variables;
}

function generateDni(seed: number): string {
  const base = config.data.dniBase;
  const value = Math.abs((base + seed) % 99999999);
  return value.toString().padStart(8, '0');
}

function generateRuc(seed: number): string {
  const prefix = config.data.rucPrefix.padStart(2, '2').slice(0, 2);
  const base = `${prefix}${Math.abs(seed % 100000000).toString().padStart(8, '0')}`;
  const weights = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  const sum = base.split('').reduce((acc, digit, index) => acc + Number(digit) * weights[index], 0);
  const remainder = sum % 11;
  const check = remainder < 2 ? 0 : 11 - remainder;
  return `${base}${check}`;
}

export function buildDocumentNumber(expedientNumber: string): string {
  const last4 = expedientNumber.slice(-4).padStart(4, '0');
  return `B000${last4}`;
}
