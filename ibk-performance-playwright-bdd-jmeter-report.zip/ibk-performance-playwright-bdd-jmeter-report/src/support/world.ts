import { IWorldOptions, setDefaultTimeout, setWorldConstructor, World } from '@cucumber/cucumber';
import { AcceptanceCriteria, FlowName, PerformanceRunResult, ProfileName } from '../types/performance';
import { config } from './config';

setDefaultTimeout(8 * 60 * 60 * 1000);

export class CustomWorld extends World {
  flow?: FlowName;
  profile?: ProfileName;
  criteria: AcceptanceCriteria = { ...config.criteria };
  result?: PerformanceRunResult;

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(CustomWorld);
