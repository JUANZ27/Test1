import { AcceptanceCriteria, FlowName, PerformanceProfile, ProfileName } from '../types/performance';
import { env, intEnv, numberEnv } from '../utils/env';

const defaultThinkTime = intEnv('THINK_TIME_MS', 1000);

export const config = {
  environment: env('ENVIRONMENT', 'stg'),
  baseUrl: env('BASE_URL', 'https://eu2-ibk-apm-stg-ext-001.azure-api.net'),
  httpTimeoutMs: intEnv('HTTP_TIMEOUT_MS', 60000),
  token: {
    basicAuth: env('TOKEN_BASIC_AUTH', 'Basic_REEMPLAZAR'),
    subscriptionKey: env('TOKEN_SUBSCRIPTION_KEY', 'REEMPLAZAR'),
    accessTokenOverride: env('ACCESS_TOKEN_OVERRIDE', '')
  },
  api: {
    subscriptionKey: env('API_SUBSCRIPTION_KEY', 'REEMPLAZAR'),
    channel: env('CHANNEL', 'DIGITAL'),
    consumerId: env('CONSUMER_ID', 'REEMPLAZAR_CONSUMER_ID'),
    xTraceIdCompliance: env('X_TRACE_ID_COMPLIANCE', 'b6735999dc71f5c23a66a3fc6079ca9b'),
    xTraceIdTracking: env('X_TRACE_ID_TRACKING', '123123-21312312-6654654')
  },
  data: {
    dniBase: intEnv('DNI_BASE', 45342123),
    rucPrefix: env('RUC_PREFIX', '20'),
    expedientNumberDefault: env('EXPEDIENT_NUMBER_DEFAULT', 'B000000000002076')
  },
  apdex: {
    tMs: intEnv('JMETER_APDEX_T_MS', 500),
    fMs: intEnv('JMETER_APDEX_F_MS', 1500)
  },
  criteria: {
    maxErrorRate: numberEnv('MAX_ERROR_RATE', 0.01),
    p95MaxMs: intEnv('P95_MAX_MS', 3000),
    minTps: numberEnv('MIN_TPS', 1)
  } as AcceptanceCriteria
};

export const profiles: Record<FlowName, Record<ProfileName, PerformanceProfile>> = {
  PN: {
    Carga: {
      vus: intEnv('PN_LOAD_VUS', 50),
      rampUp: env('PN_LOAD_RAMP_UP', '60s'),
      duration: env('PN_LOAD_DURATION', '1h'),
      rampDown: env('PN_LOAD_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('PN_LOAD_THINK_TIME_MS', defaultThinkTime),
      description: 'Carga nominal PN basada en JMX PN.'
    },
    Pico: {
      vus: intEnv('PN_SPIKE_VUS', 150),
      rampUp: env('PN_SPIKE_RAMP_UP', '30s'),
      duration: env('PN_SPIKE_DURATION', '10m'),
      rampDown: env('PN_SPIKE_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('PN_SPIKE_THINK_TIME_MS', defaultThinkTime),
      description: 'Pico súbito PN para validar tolerancia ante incremento rápido.'
    },
    Estres: {
      vus: intEnv('PN_STRESS_MAX_VUS', 250),
      rampUp: env('PN_STRESS_RAMP_UP', '300s'),
      duration: env('PN_STRESS_DURATION', '30m'),
      rampDown: env('PN_STRESS_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('PN_STRESS_THINK_TIME_MS', defaultThinkTime),
      description: 'Estrés PN para buscar degradación y punto de quiebre.'
    },
    Resiliencia: {
      vus: intEnv('PN_RESILIENCE_VUS', 50),
      rampUp: env('PN_RESILIENCE_RAMP_UP', '300s'),
      duration: env('PN_RESILIENCE_DURATION', '4h'),
      rampDown: env('PN_RESILIENCE_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('PN_RESILIENCE_THINK_TIME_MS', defaultThinkTime),
      description: 'Resiliencia PN para validar estabilidad sostenida.'
    }
  },
  PJ: {
    Carga: {
      vus: intEnv('PJ_LOAD_VUS', 50),
      rampUp: env('PJ_LOAD_RAMP_UP', '1s'),
      duration: env('PJ_LOAD_DURATION', '1h'),
      rampDown: env('PJ_LOAD_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('PJ_LOAD_THINK_TIME_MS', defaultThinkTime),
      description: 'Carga nominal PJ basada en JMX PJ.'
    },
    Pico: {
      vus: intEnv('PJ_SPIKE_VUS', 150),
      rampUp: env('PJ_SPIKE_RAMP_UP', '5s'),
      duration: env('PJ_SPIKE_DURATION', '10m'),
      rampDown: env('PJ_SPIKE_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('PJ_SPIKE_THINK_TIME_MS', defaultThinkTime),
      description: 'Pico PJ con incremento rápido de concurrencia.'
    },
    Estres: {
      vus: intEnv('PJ_STRESS_MAX_VUS', 250),
      rampUp: env('PJ_STRESS_RAMP_UP', '300s'),
      duration: env('PJ_STRESS_DURATION', '30m'),
      rampDown: env('PJ_STRESS_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('PJ_STRESS_THINK_TIME_MS', defaultThinkTime),
      description: 'Estrés PJ para evaluar límites.'
    },
    Resiliencia: {
      vus: intEnv('PJ_RESILIENCE_VUS', 50),
      rampUp: env('PJ_RESILIENCE_RAMP_UP', '60s'),
      duration: env('PJ_RESILIENCE_DURATION', '4h'),
      rampDown: env('PJ_RESILIENCE_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('PJ_RESILIENCE_THINK_TIME_MS', defaultThinkTime),
      description: 'Resiliencia PJ para detectar degradación prolongada.'
    }
  },
  NC: {
    Carga: {
      vus: intEnv('NC_LOAD_VUS', 4),
      rampUp: env('NC_LOAD_RAMP_UP', '1s'),
      duration: env('NC_LOAD_DURATION', '1h'),
      rampDown: env('NC_LOAD_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('NC_LOAD_THINK_TIME_MS', defaultThinkTime),
      description: 'Carga nominal No Constituida basada en JMX.'
    },
    Pico: {
      vus: intEnv('NC_SPIKE_VUS', 20),
      rampUp: env('NC_SPIKE_RAMP_UP', '5s'),
      duration: env('NC_SPIKE_DURATION', '10m'),
      rampDown: env('NC_SPIKE_RAMP_DOWN', '30s'),
      thinkTimeMs: intEnv('NC_SPIKE_THINK_TIME_MS', defaultThinkTime),
      description: 'Pico No Constituida.'
    },
    Estres: {
      vus: intEnv('NC_STRESS_MAX_VUS', 50),
      rampUp: env('NC_STRESS_RAMP_UP', '180s'),
      duration: env('NC_STRESS_DURATION', '30m'),
      rampDown: env('NC_STRESS_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('NC_STRESS_THINK_TIME_MS', defaultThinkTime),
      description: 'Estrés No Constituida.'
    },
    Resiliencia: {
      vus: intEnv('NC_RESILIENCE_VUS', 4),
      rampUp: env('NC_RESILIENCE_RAMP_UP', '60s'),
      duration: env('NC_RESILIENCE_DURATION', '4h'),
      rampDown: env('NC_RESILIENCE_RAMP_DOWN', '60s'),
      thinkTimeMs: intEnv('NC_RESILIENCE_THINK_TIME_MS', defaultThinkTime),
      description: 'Resiliencia No Constituida.'
    }
  }
};
