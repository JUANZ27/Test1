import { runPerformance } from '../runner/performance-runner';
import { FlowName, ProfileName } from '../types/performance';
import { config } from '../support/config';

function asFlow(value: string): FlowName {
  const normalized = value.toUpperCase();
  if (normalized === 'PN' || normalized === 'PJ' || normalized === 'NC') return normalized;
  throw new Error(`FLOW inválido: ${value}. Usa PN, PJ o NC.`);
}

function asProfile(value: string): ProfileName {
  const normalized = value.toLowerCase();
  if (normalized === 'carga' || normalized === 'load') return 'Carga';
  if (normalized === 'pico' || normalized === 'spike') return 'Pico';
  if (normalized === 'estres' || normalized === 'estrés' || normalized === 'stress') return 'Estres';
  if (normalized === 'resiliencia' || normalized === 'resilience' || normalized === 'endurance') return 'Resiliencia';
  throw new Error(`PROFILE inválido: ${value}. Usa Carga, Pico, Estres o Resiliencia.`);
}

(async () => {
  const flow = asFlow(process.env.FLOW ?? 'PN');
  const profile = asProfile(process.env.PROFILE ?? 'Carga');
  const result = await runPerformance({ flow, profile, criteria: config.criteria });
  console.log('\nReporte HTML:', result.output.htmlReport);
  console.log('JTL compatible JMeter:', result.output.jtlFile);
  console.log('Decisión:', result.summary.decision);
})().catch(error => {
  console.error(error);
  process.exit(1);
});
