import fs from 'fs';
import { request, APIRequestContext } from '@playwright/test';
import { AcceptanceCriteria, FlowDefinition, FlowName, PerformanceProfile, PerformanceRunResult, ProfileName, RuntimeVariables, SampleResult, FlowStep } from '../types/performance';
import { config, profiles } from '../support/config';
import { getFlow } from '../flows/flow-definitions';
import { applyTemplate, applyTemplateToObject } from '../utils/template';
import { parseDurationToMs } from '../utils/time';
import { createBaseVariables, buildDocumentNumber } from '../utils/data-generator';
import { readJsonPath } from '../utils/json-path';
import { buildSummary } from '../utils/metrics';
import { writeReports } from '../utils/report-generator';
import { log } from '../utils/logger';

interface RunInput {
  flow: FlowName;
  profile: ProfileName;
  criteria: AcceptanceCriteria;
}

export async function runPerformance(input: RunInput): Promise<PerformanceRunResult> {
  const flow = getFlow(input.flow);
  const profile = profiles[input.flow][input.profile];
  const runId = new Date().toISOString().replace(/[:.]/g, '-');
  const start = Date.now();
  const startTime = new Date(start).toISOString();
  const samples: SampleResult[] = [];

  log(`Iniciando performance ${flow.name}/${input.profile}`, profile);
  const token = await getSharedToken(flow, samples, profile.vus);

  const rampMs = parseDurationToMs(profile.rampUp);
  const durationMs = parseDurationToMs(profile.duration);
  const rampDownMs = parseDurationToMs(profile.rampDown);
  const testClockStart = Date.now();
  const holdEndAt = testClockStart + rampMs + durationMs;

  await Promise.all(
    Array.from({ length: profile.vus }, (_, index) => runVirtualUser({
      vu: index + 1,
      flow,
      profile,
      endAt: holdEndAt + Math.floor((rampDownMs / Math.max(profile.vus, 1)) * (profile.vus - index)),
      startDelayMs: profile.vus <= 1 ? 0 : Math.floor((rampMs / profile.vus) * index),
      sharedToken: token,
      samples
    }))
  );

  const end = Date.now();
  const endTime = new Date(end).toISOString();
  const summary = buildSummary(samples, start, end, input.criteria);
  const result: PerformanceRunResult = {
    runId,
    flow: input.flow,
    profile: input.profile,
    startTime,
    endTime,
    durationMs: end - start,
    profileConfig: profile,
    criteria: input.criteria,
    samples,
    summary,
    output: {
      htmlReport: '',
      jtlFile: '',
      csvFile: '',
      jsonSummary: '',
      markdownReport: ''
    }
  };

  writeReports(result);
  log(`Finalizó performance ${flow.name}/${input.profile}`, { decision: result.summary.decision, htmlReport: result.output.htmlReport });
  return result;
}

async function getSharedToken(flow: FlowDefinition, samples: SampleResult[], vus: number): Promise<string> {
  if (config.token.accessTokenOverride) {
    log('ACCESS_TOKEN_OVERRIDE configurado. Se omite llamada al endpoint de token.');
    return config.token.accessTokenOverride;
  }

  if (!flow.tokenRequired) return '';

  const api = await request.newContext({ baseURL: config.baseUrl, ignoreHTTPSErrors: true });
  try {
    const startedAt = Date.now();
    const response = await api.post('/bcv-security/v1/oauth/token', {
      headers: {
        authorization: config.token.basicAuth,
        'content-type': 'application/x-www-form-urlencoded',
        'ocp-apim-subscription-key': config.token.subscriptionKey
      },
      form: { grant_type: 'client_credentials' },
      timeout: config.httpTimeoutMs
    });
    const endedAt = Date.now();
    const bodyText = await response.text();
    let bodyJson: unknown = undefined;
    try { bodyJson = JSON.parse(bodyText); } catch { bodyJson = undefined; }
    const token = bodyJson && typeof bodyJson === 'object' ? String((bodyJson as Record<string, unknown>).access_token ?? '') : '';
    samples.push(buildSample({
      startedAt,
      endedAt,
      label: '00 - Token inicial compartido',
      status: response.status(),
      statusText: response.statusText(),
      success: response.ok() && Boolean(token),
      failureMessage: response.ok() && token ? '' : 'No se obtuvo access_token',
      url: `${config.baseUrl}/bcv-security/v1/oauth/token`,
      threadName: 'setUp Thread Group 1-1',
      sentBytes: 'grant_type=client_credentials'.length,
      receivedBytes: bodyText.length,
      allThreads: vus,
      bodyText
    }));

    if (!token) throw new Error('No se obtuvo access_token. Revisa TOKEN_BASIC_AUTH y TOKEN_SUBSCRIPTION_KEY en .env.');
    return token;
  } finally {
    await api.dispose();
  }
}

interface VuParams {
  vu: number;
  flow: FlowDefinition;
  profile: PerformanceProfile;
  endAt: number;
  startDelayMs: number;
  sharedToken: string;
  samples: SampleResult[];
}

async function runVirtualUser(params: VuParams): Promise<void> {
  if (params.startDelayMs > 0) await sleep(params.startDelayMs);
  const api = await request.newContext({ baseURL: config.baseUrl, ignoreHTTPSErrors: true });
  let iteration = 1;
  try {
    while (Date.now() < params.endAt) {
      const variables = createBaseVariables(params.flow, params.vu, iteration);
      variables.access_token = params.sharedToken;
      for (const step of params.flow.steps) {
        if (Date.now() >= params.endAt) break;
        await executeStep(api, step, variables, params.vu, iteration, params.profile.vus, params.samples);
      }
      iteration += 1;
      if (params.profile.thinkTimeMs > 0) await sleep(params.profile.thinkTimeMs);
    }
  } finally {
    await api.dispose();
  }
}

async function executeStep(api: APIRequestContext, step: FlowStep, variables: RuntimeVariables, vu: number, iteration: number, allThreads: number, samples: SampleResult[]): Promise<void> {
  const startedAt = Date.now();
  const path = applyTemplate(step.path, variables);
  const headers = step.headers ? applyTemplateToObject(step.headers, variables) : {};
  const query = step.query ? applyTemplateToObject(step.query, variables) : undefined;
  const payloadText = step.payloadFile ? applyTemplate(fs.readFileSync(step.payloadFile, 'utf-8'), variables) : undefined;
  let data: unknown = undefined;
  if (payloadText) {
    try { data = JSON.parse(payloadText); } catch { data = payloadText; }
  }

  let status = 0;
  let statusText = 'ERROR';
  let bodyText = '';
  let failureMessage = '';
  try {
    const response = await api.fetch(path, {
      method: step.method,
      headers,
      params: query,
      data,
      timeout: config.httpTimeoutMs
    });
    status = response.status();
    statusText = response.statusText();
    bodyText = await response.text();
    let bodyJson: unknown = undefined;
    try { bodyJson = JSON.parse(bodyText); } catch { bodyJson = undefined; }

    if (bodyJson && step.extractors) {
      for (const extractor of step.extractors) {
        const value = readJsonPath(bodyJson, extractor.jsonPath) ?? extractor.defaultValue;
        if (value) variables[extractor.variable] = value;
      }
    }

    if (step.postProcess === 'ncDocumentNumberFromExpedient') {
      variables.documentNumber = buildDocumentNumber(String(variables.expedientNumber ?? ''));
    }
  } catch (error) {
    failureMessage = (error as Error).message;
  }

  const endedAt = Date.now();
  const expectedStatus = step.expectedStatus ?? [200, 201];
  const success = expectedStatus.includes(status);
  if (!success && !failureMessage) failureMessage = `HTTP status ${status} no esperado. Esperado: ${expectedStatus.join(',')}`;

  samples.push(buildSample({
    startedAt,
    endedAt,
    label: step.label,
    status,
    statusText,
    success,
    failureMessage,
    url: buildUrl(path, query),
    threadName: `${step.label} VU-${vu}-${iteration}`,
    sentBytes: payloadText?.length ?? 0,
    receivedBytes: bodyText.length,
    allThreads,
    bodyText
  }));
}

function buildUrl(path: string, query?: Record<string, string>): string {
  const url = new URL(path, config.baseUrl);
  if (query) {
    Object.entries(query).forEach(([key, value]) => url.searchParams.set(key, value));
  }
  return url.toString();
}

function buildSample(input: {
  startedAt: number;
  endedAt: number;
  label: string;
  status: number;
  statusText: string;
  success: boolean;
  failureMessage: string;
  url: string;
  threadName: string;
  sentBytes: number;
  receivedBytes: number;
  allThreads: number;
  bodyText: string;
}): SampleResult {
  return {
    timeStamp: input.startedAt,
    elapsed: input.endedAt - input.startedAt,
    label: input.label,
    responseCode: input.status ? String(input.status) : '000',
    responseMessage: input.statusText || 'ERROR',
    threadName: input.threadName,
    dataType: 'text',
    success: input.success,
    failureMessage: input.failureMessage,
    bytes: input.receivedBytes,
    sentBytes: input.sentBytes,
    grpThreads: input.allThreads,
    allThreads: input.allThreads,
    URL: input.url,
    Latency: input.endedAt - input.startedAt,
    IdleTime: 0,
    Connect: 0,
    bodyPreview: input.bodyText.slice(0, 500)
  };
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
