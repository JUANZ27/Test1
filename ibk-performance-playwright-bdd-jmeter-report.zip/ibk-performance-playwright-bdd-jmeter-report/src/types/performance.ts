export type FlowName = 'PN' | 'PJ' | 'NC';
export type ProfileName = 'Carga' | 'Pico' | 'Estres' | 'Resiliencia';
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface PerformanceProfile {
  vus: number;
  rampUp: string;
  duration: string;
  rampDown: string;
  thinkTimeMs: number;
  description: string;
}

export interface AcceptanceCriteria {
  maxErrorRate: number;
  p95MaxMs: number;
  minTps: number;
}

export interface FlowStep {
  id: string;
  label: string;
  method: HttpMethod;
  path: string;
  payloadFile?: string;
  query?: Record<string, string>;
  headers?: Record<string, string>;
  expectedStatus?: number[];
  extractors?: Array<{
    variable: string;
    jsonPath: string;
    defaultValue?: string;
  }>;
  postProcess?: 'ncDocumentNumberFromExpedient';
}

export interface FlowDefinition {
  name: FlowName;
  displayName: string;
  jmxSource: string;
  dataFactory: 'pn' | 'pj' | 'nc';
  tokenRequired: boolean;
  steps: FlowStep[];
}

export interface RuntimeVariables {
  [key: string]: string | number | boolean | undefined;
}

export interface SampleResult {
  timeStamp: number;
  elapsed: number;
  label: string;
  responseCode: string;
  responseMessage: string;
  threadName: string;
  dataType: string;
  success: boolean;
  failureMessage: string;
  bytes: number;
  sentBytes: number;
  grpThreads: number;
  allThreads: number;
  URL: string;
  Latency: number;
  IdleTime: number;
  Connect: number;
  bodyPreview?: string;
}

export interface PerformanceRunResult {
  runId: string;
  flow: FlowName;
  profile: ProfileName;
  startTime: string;
  endTime: string;
  durationMs: number;
  profileConfig: PerformanceProfile;
  criteria: AcceptanceCriteria;
  samples: SampleResult[];
  summary: PerformanceSummary;
  output: {
    htmlReport: string;
    jtlFile: string;
    csvFile: string;
    jsonSummary: string;
    markdownReport: string;
  };
}

export interface LabelSummary {
  label: string;
  samples: number;
  failures: number;
  errorRate: number;
  average: number;
  min: number;
  max: number;
  median: number;
  p90: number;
  p95: number;
  p99: number;
  throughput: number;
  receivedKbSec: number;
  sentKbSec: number;
}

export interface PerformanceSummary {
  totalSamples: number;
  failures: number;
  errorRate: number;
  average: number;
  min: number;
  max: number;
  median: number;
  p90: number;
  p95: number;
  p99: number;
  tps: number;
  peakTps: number;
  apdex: number;
  receivedKbSec: number;
  sentKbSec: number;
  labels: LabelSummary[];
  errors: Array<{ responseCode: string; responseMessage: string; count: number; percentage: number }>;
  topErrorsBySampler: Array<{ label: string; responseCode: string; responseMessage: string; count: number }>;
  decision: 'PASS' | 'REVIEW' | 'FAIL';
  decisionReasons: string[];
}
