# Generar reporte HTML JMeter desde CMD

El framework genera un archivo `.jtl` compatible con JMeter.

Ejemplo:

```cmd
"C:\apache-jmeter-5.6.3\bin\jmeter.bat" -g "C:\ruta\reports\jtl\pn-carga-run.jtl" -o "C:\ruta\reports\jmeter-html\pn-carga"
```

Si la carpeta de salida ya existe, debe estar vacía. Puedes borrarla con:

```cmd
rmdir /s /q "C:\ruta\reports\jmeter-html\pn-carga"
```

Luego abre:

```text
C:\ruta\reports\jmeter-html\pn-carga\index.html
```
