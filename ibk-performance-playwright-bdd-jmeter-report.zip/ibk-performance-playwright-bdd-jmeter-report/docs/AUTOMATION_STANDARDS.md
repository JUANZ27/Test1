# Estándares QA Automation aplicados

## Performance API

- No usar video ni screenshots.
- Medir tiempos, errores, TPS, p90/p95/p99, throughput y APDEX.
- Separar carga, pico, estrés y resiliencia.
- Mantener credenciales en `.env` o secrets del pipeline.
- Generar JTL/CSV para trazabilidad.
- No usar View Results Tree en ejecución de carga real.

## Estructura

- `features`: escenarios BDD.
- `steps`: glue code Cucumber.
- `flows`: definición funcional de cada flujo migrado desde JMX.
- `fixtures/payloads`: bodies JSON.
- `runner`: ejecución concurrente.
- `utils`: métricas, datos, reportes y utilidades.

## Comentarios

Los comentarios se agregan solo donde ayudan a entender decisiones técnicas, no para repetir lo que el código ya expresa.
