# Mapeo desde JMeter hacia Playwright BDD

| JMeter | Proyecto Playwright BDD |
|---|---|
| Test Plan | `features/ibk-performance.feature` + `src/runner/performance-runner.ts` |
| setUp Thread Group / Token | `getSharedToken()` en `performance-runner.ts` |
| Thread Group Carga/Pico/Estrés/Resiliencia | `profiles` en `src/support/config.ts` |
| HTTP Request Sampler | `FlowStep` en `src/flows/flow-definitions.ts` |
| Header Manager | Headers por endpoint en `flow-definitions.ts` + `.env` |
| JSON Extractor | `extractors` con JSONPath simple |
| JSR223 PreProcessor | `src/utils/data-generator.ts` |
| Summary Report | `reports/html/jmeter-dashboard-*.html` |
| Simple Data Writer | `reports/jtl/*.jtl` y `reports/csv/*.csv` |
| JMeter HTML Dashboard | `jmeter -g reports/jtl/*.jtl -o reports/jmeter-html/<salida>` |

## Consideraciones

Este framework usa Playwright APIRequestContext para ejecutar HTTP requests. Para cargas muy altas se recomienda ejecutar desde una máquina dedicada o conservar k6/JMeter como motor de carga y usar este proyecto para orquestación, validación y reportes.
