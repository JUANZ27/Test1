#!/usr/bin/env node
const { spawnSync } = require('child_process');
const path = require('path');

const [, , environment = 'uat', ...args] = process.argv;
process.env.ENVIRONMENT = environment;
process.env.environment = environment;

const cucumberBin = path.resolve(__dirname, '..', 'node_modules', '@cucumber', 'cucumber', 'bin', 'cucumber-js');
const result = spawnSync(process.execPath, [cucumberBin, ...args], {
  stdio: 'inherit',
  env: process.env
});
process.exit(result.status ?? 1);
