# Hyperloop TDM IFX - Playwright + TypeScript + BDD

Proyecto para ejecutar TDM IFX solo en **UAT**.

Escenarios activos:

- `@CrearPersonaNaturalIFX`
- `@CrearClientePJIFX`
- `@ConsultaClienteIFX`
- `@GenerateDataFromExcel`

El proyecto usa **Playwright API**, **TypeScript**, **Cucumber/Gherkin**, reporte HTML, logs técnicos, retry por errores técnicos, retry funcional por `209 DOCUMENTO EXISTE` y CSV único de trazabilidad.

## Alcance

- **Solo UAT:** STG se retiró del feature y scripts porque es inestable.
- **Credenciales fuera del repositorio:** tokens, password, client secret y keys deben ir en `C:\Users\TU_USUARIO\application-uat.properties`.
- **Cantidad desde feature:** puedes crear 1, 10, 100 o más documentos cambiando `cantidad` en Examples.
- **Documento base desde feature:** puedes controlar `documentoBase` o `rucBase` por ejecución.
- **Retry 209:** si el documento ya existe, se genera el siguiente incremental y se reintenta hasta obtener 200.
- **CSV único:** solo se guarda el documento exitoso en `reports/generated/documentos-generados.csv`.
- **Excel maestro:** permite `CREAR_PN`, `CREAR_PJ` y `CONSULTA_FULL` desde un mismo archivo.

## Configuración por máquina

Copia:

```text
config/maquinas/application-uat.properties
```

a:

```text
C:\Users\TU_USUARIO\application-uat.properties
```

No subas ese archivo con credenciales reales al repositorio.

## Instalación

```bash
npm install
```

## Ejecución recomendada

```bash
npm run test:uat:crear-pn
npm run test:uat:crear-pj
npm run test:uat:consulta-full
npm run test:uat:generate-excel
npm run test:uat
npm run report
npm run clean:reports
```

Por tag:

```bash
npx cucumber-js --tags "@CrearPersonaNaturalIFX and @UAT"
npx cucumber-js --tags "@CrearClientePJIFX and @UAT"
npx cucumber-js --tags "@ConsultaClienteIFX and @UAT"
npx cucumber-js --tags "@GenerateDataFromExcel and @UAT"
```

## Feature parametrizado

### Crear Persona Natural

```gherkin
Cuando ejecuto Crear <cantidad> Personas Naturales IFX con tipo documento "<tipoDocumento>" desde documento base "<documentoBase>"
```

Ejemplo:

```gherkin
| cantidad | tipoDocumento | documentoBase |
| 100      | DNI           | 40903470      |
```

### Crear Cliente PJ

```gherkin
Cuando ejecuto Crear <cantidad> Clientes PJ IFX con RUC base "<rucBase>" societyType "<societyType>" countryCode "<countryCode>" economicActivityCode "<economicActivityCode>"
```

Ejemplo:

```gherkin
| cantidad | rucBase     | societyType | countryCode | economicActivityCode |
| 100      | 20276135814 | EIRL        | 4028        | 2023                 |
```

### Consulta Full

```gherkin
Cuando ejecuto Consulta Cliente IFX con tipo documento "<tipoDocumento>" y numero documento "<numeroDocumento>"
```

Ejemplo:

```gherkin
| tipoDocumento | numeroDocumento |
| DNI           | 40903470        |
```

## Excel maestro

Ruta:

```text
src/main/resources/Data/CargaClientePNPJ.xlsx
```

Columnas recomendadas:

| Columna | Uso |
|---|---|
| `OPERACION` | `CREAR_PN`, `CREAR_PJ` o `CONSULTA_FULL` |
| `AMBIENTE` | `uat` |
| `TIPO_DOCUMENTO` | `DNI` o `RUC` |
| `NUMERO_DOCUMENTO` | Número fijo o `AUTO` |
| `DOCUMENTO_BASE` | Base incremental para esta fila |
| `CANTIDAD` | Cantidad de registros a generar |
| `SOCIETYTYPE` | Solo PJ |
| `COUNTRYCODE` | Solo PJ |
| `ECONOMICACTIVITYCODE` | Solo PJ |

Ejemplo:

```text
OPERACION     | AMBIENTE | TIPO_DOCUMENTO | NUMERO_DOCUMENTO | DOCUMENTO_BASE | CANTIDAD | SOCIETYTYPE | COUNTRYCODE | ECONOMICACTIVITYCODE
CREAR_PN      | uat      | DNI            | AUTO             | 40903470       | 2        |             |             |
CREAR_PJ      | uat      | RUC            | AUTO             | 20276135814    | 2        | EIRL        | 4028        | 2023
CONSULTA_FULL | uat      | DNI            | 40903470         |                | 1        |             |             |
```

## Reportes y trazabilidad

```text
reports/html/index.html
reports/html/scenarios/*.html
reports/generated/documentos-generados.csv
reports/generated/duplicados-detectados.csv
reports/logs/ifx-technical-execution.csv
reports/logs/ifx-technical-execution.jsonl
```
