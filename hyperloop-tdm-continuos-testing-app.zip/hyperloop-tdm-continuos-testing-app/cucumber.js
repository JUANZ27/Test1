module.exports = {
  default: {
    paths: ['src/test/features/**/*.feature'],
    requireModule: ['ts-node/register'],
    require: [
      'src/support/world.ts',
      'src/support/hooks.ts',
      'src/test/steps/**/*.ts'
    ],
    format: [
      'progress',
      'json:reports/cucumber/cucumber-report.json',
      'html:reports/cucumber/cucumber-report.html'
    ],
    parallel: 0
  }
};
