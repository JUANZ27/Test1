# Refactor QA Automation Senior

## Cambios aplicados

- Se retiró la generación de videos de evidencia porque el proyecto es API testing y el video no aporta valor funcional.
- Se mantiene evidencia HTML/JSON con request, response, headers y status por escenario.
- Se eliminó la generación de evidencias HTML porque el proyecto es API/TDM y la evidencia principal es request/response/headers/logs.
- Se agregaron comentarios en:
  - `src/test/features/ifx-tdm-operaciones.feature`
  - `src/test/steps/ifx.steps.ts`
  - `src/services/ifx-client.ts`
  - `src/support/hooks.ts`
  - `src/support/report-generator.ts`
  - `src/support/world.ts`
- Se eliminan del ZIP carpetas generadas o locales: `.idea`, `target`, `reports`.
- Se deja la ejecución principal por `npm` y `npx cucumber-js --tags`.

## Evidencias vigentes

- `reports/evidence/*.json`
- `reports/html/index.html`
- `reports/html/evidencias.html`
- `reports/html/scenarios/*.html`
- No se generan evidencias HTML ni videos; el reporte HTML contiene la evidencia técnica necesaria.
- `reports/generated/documentos-generados.csv`

## Ejecución recomendada

```bash
npm install
npm run install:browsers
npx cucumber-js --tags @CrearPersonaNaturalIFX
npm run report
```

## Mejoras v6 agregadas

- Reporte HTML ejecutivo con métricas de escenarios, operaciones, status HTTP, retries y documentos generados.
- Trazabilidad CSV centralizada únicamente en `reports/generated/documentos-generados.csv`.
- Tags QA por módulo: `@IFX`, `@Consulta`, `@Transaccion`, `@Smoke`, `@Regression`, `@DataDriven`.
- Retry controlado solo para errores técnicos configurables: `408`, `429`, `500`, `502`, `503`, `504`.
- Pipeline CI/CD de referencia para GitHub Actions, Azure DevOps y Jenkins.
