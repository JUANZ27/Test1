# Cargas masivas TDM desde Feature

## Objetivo

Permitir que los QA puedan crear N documentos desde Cucumber sin editar código TypeScript ni properties.

## Escenarios actualizados

### CrearPersonaNaturalIFX

```gherkin
Cuando ejecuto Crear <cantidad> Personas Naturales IFX con tipo documento "<tipoDocumento>"
```

Ejemplo:

```gherkin
| ambiente | cantidad | tipoDocumento |
| uat      | 100      | DNI           |
```

### CrearClientePJIFX

```gherkin
Cuando ejecuto Crear <cantidad> Clientes PJ IFX con RUC dinamico societyType "<societyType>" countryCode "<countryCode>" economicActivityCode "<economicActivityCode>"
```

Ejemplo:

```gherkin
| ambiente | cantidad | societyType | countryCode | economicActivityCode |
| uat      | 100      | EIRL        | 4028        | 2023                 |
```

## Buenas prácticas QA Automation Senior

- Para cargas masivas usar un solo CSV de salida: `reports/generated/documentos-generados.csv`.
- Ejecutar primero con una cantidad pequeña, por ejemplo 2 o 5.
- Luego subir a 100 si el endpoint responde estable.
- Mantener `ifx.retry.duplicate-document.enabled=true` para manejar código 209 por documento existente.
- Mantener `ifx.bulk.max-quantity` como control de seguridad.

## Propiedad de seguridad

```properties
ifx.bulk.max-quantity=500
```

Si la cantidad del feature supera ese valor, el escenario falla antes de consumir el API.
