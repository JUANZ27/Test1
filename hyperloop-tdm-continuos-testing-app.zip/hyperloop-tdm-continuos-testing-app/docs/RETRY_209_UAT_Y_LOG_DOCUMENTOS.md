# Retry funcional 209 en UAT/STG y logs de documentos

## Problema corregido

En UAT algunos endpoints de creación PN/PJ responden HTTP `209` con mensaje funcional como `DOCUMENTO EXISTE`. En versiones previas el framework no reintentaba porque priorizaba el header `srvresponsecode=001` sobre el HTTP status `209`.

## Criterio aplicado

Para un TDM, una creación PN/PJ debe considerarse exitosa solo cuando el código efectivo es `200`. Si el API devuelve `209`, se genera un nuevo DNI/RUC incremental y se reintenta hasta obtener `200` o hasta agotar el máximo de intentos configurado.

## Prioridad del código efectivo

El código efectivo ahora se calcula así:

1. `x-original-http-status-code=209`
2. HTTP status `209`
3. Código funcional `209` en body
4. `srvresponsecode` cuando no es un caso de documento existente
5. HTTP status final

## Logs de documentos generados

En consola se imprime el documento generado por ambiente:

```text
[IFX][CrearClientePJIFX] RUC generado para UAT: 20276135815 | source=createLegalPerson intento 2
[IFX][CrearPersonaNaturalIFX] RUC generado para STG: 10294411492 | source=buildStgNaturalPersonBody intento 2
```

En los logs técnicos se agregan las columnas:

```text
documentTypes;documentNumbers
```

Archivo:

```text
reports/logs/ifx-technical-execution.csv
```

Además, el JSONL conserva el bloque `generatedDocuments` con el DNI/RUC enviado en el request:

```text
reports/logs/ifx-technical-execution.jsonl
```

## CSV funcional

Se mantiene un único CSV funcional para documentos creados correctamente:

```text
reports/generated/documentos-generados.csv
```

Los intentos con `209` no se guardan como data creada, solo se registran como duplicados/reintentos en:

```text
reports/generated/duplicados-detectados.csv
reports/logs/ifx-technical-execution.csv
```
