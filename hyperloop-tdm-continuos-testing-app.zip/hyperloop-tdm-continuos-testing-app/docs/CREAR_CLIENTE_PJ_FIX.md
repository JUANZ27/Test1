# Ajuste CrearClientePJIFX UAT/STG

## Motivo

Se alineó `CrearClientePJIFX` al curl UAT actualizado y a los endpoints STG APM.

## Cambios clave UAT

- Header `application=ASSI`.
- Header `branchid=898`.
- Header `channelid=15`.
- Header `consumerid=01`.
- Header `serviceid=BPI`.
- Header `timestamp=2016-05-24T11:57:48.000Z`.
- Se eliminó `codFuente` del body UAT porque no existe en el curl compartido.
- Dirección del body PJ alineada: `streetType=AV` y `district=Lima`.

## Cambios clave STG

- Crear PN: `/bcw-business-account/v1/business-accounts/internal-channel`.
- Crear PJ: `/business/v1/business-accounts/internal-channel`.
- Consulta full: GET `/vision-cliente/uat/customers/full`.
- `processtraceid` incremental por ejecución para PN/PJ.
- Por defecto los 3 endpoints STG se ejecutan sin `authorization`. Si STG exige token, activar `ifx.stg.authorization.enabled=true` y configurar token estático en properties.

## Ejecución recomendada

```bash
npm install
npm run test:uat:crear-pj
npm run test:stg:crear-pj
npm run report
```
