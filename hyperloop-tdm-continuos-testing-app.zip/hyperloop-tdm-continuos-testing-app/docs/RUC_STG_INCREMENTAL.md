# RUC incremental para STG - Crear PN y Crear PJ

## Objetivo

En STG, los endpoints de creación pueden responder código funcional `209` cuando el documento ya existe. Para un TDM, el objetivo es generar data utilizable; por eso el framework debe cambiar el RUC y reintentar hasta obtener código efectivo `200`.

## Regla implementada

### CrearPersonaNaturalIFX STG

El campo del body:

```json
{
  "business": {
    "identityDocument": {
      "type": "RUC",
      "number": "10294411491"
    }
  }
}
```

ahora se genera de forma incremental como **RUC 10 válido** usando:

```properties
ifx.stg.pn.ruc10-base=10294411491
ifx.stg.pn.ruc10-sequence-file=reports/sequences/stg-pn-ruc10-sequence.txt
```

### CrearClientePJIFX STG

El campo del body:

```json
{
  "business": {
    "identityDocument": {
      "type": "RUC",
      "number": "20101298851"
    }
  }
}
```

ahora se genera con la misma lógica que UAT, como **RUC 20 válido incremental**, usando:

```properties
ifx.stg.pj.ruc-base=20101298851
ifx.stg.pj.ruc-sequence-file=reports/sequences/stg-pj-ruc-sequence.txt
```

## Comportamiento con Excel

- Si el Excel no envía `NUMERO_DOCUMENTO`, o envía `AUTO`, se genera RUC incremental.
- Si el Excel envía un RUC fijo, se respeta solo en el primer intento.
- Si el endpoint devuelve `209 - DOCUMENTO EXISTE`, el framework genera el siguiente RUC y reintenta.
- En STG, cada retry también genera un nuevo `processtraceid`.

## Trazabilidad

Solo se guarda el documento final creado exitosamente en:

```text
reports/generated/documentos-generados.csv
```

Los intentos con 209 quedan en los logs técnicos:

```text
reports/logs/ifx-technical-execution.csv
reports/logs/ifx-technical-execution.jsonl
```
