# Retry funcional por documento existente - código 209

## Objetivo

Como el proyecto funciona como TDM, algunas ejecuciones de `CrearPersonaNaturalIFX` y `CrearClientePJIFX` pueden fallar porque el documento generado o configurado ya existe en el ambiente. En ese caso el servicio puede devolver código efectivo `209`.

La mejora implementada permite que, cuando la creación PN/PJ devuelve `209`, el framework genere un nuevo documento y reintente hasta obtener código efectivo `200`.

## Alcance

Aplica a:

- `@CrearPersonaNaturalIFX`
- `@CrearClientePJIFX`
- `@GenerateDataFromExcel`, cuando la fila ejecuta `CREAR_PN` o `CREAR_PJ`

No aplica a consultas.

## Código efectivo

El framework detecta el código `209` desde cualquiera de estas fuentes:

- HTTP status `209`
- header `srvresponsecode=209`
- body con campos como `code`, `responseCode`, `statusCode`, `codigo` o `codigoRespuesta`

Se considera creación exitosa cuando el código efectivo es `200`.

## Comportamiento

1. Ejecuta la creación PN/PJ.
2. Si responde `200`, termina correctamente.
3. Si responde `209`, genera un nuevo DNI/RUC.
4. En STG también genera un nuevo `processtraceid`.
5. Reintenta hasta el máximo configurado.
6. Guarda la trazabilidad de documentos generados en CSV.

## Configuración

Agregar en `C:\Users\<usuario>\application-uat.properties` y `application-stg.properties`:

```properties
ifx.retry.duplicate-document.enabled=true
ifx.retry.duplicate-document-code=209
ifx.retry.duplicate-document.max-attempts=10
ifx.retry.duplicate-document.max-attempts-pn=10
ifx.retry.duplicate-document.max-attempts-pj=10
ifx.retry.duplicate-document.delay-ms=500
ifx.retry.duplicate-document.exponential=false
```

## Evidencia y trazabilidad

Se sigue guardando la data generada en:

```text
reports/generated/documentos-generados.csv
reports/generated/duplicados-detectados.csv
reports/logs/ifx-technical-execution.csv
reports/logs/ifx-technical-execution.jsonl
```

Si un intento devuelve `209`, también queda trazado con su response status/código funcional. El intento final exitoso debe quedar con `200`.

## Ejecución

```bash
npm run test:uat:crear-pn
npm run test:uat:crear-pj
npm run test:stg:crear-pn
npm run test:stg:crear-pj
npm run report
```
