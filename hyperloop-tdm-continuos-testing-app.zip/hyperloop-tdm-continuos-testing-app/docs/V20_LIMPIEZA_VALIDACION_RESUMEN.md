# V20 - Limpieza de evidencias, validación de properties y resumen ejecutivo

## Cambios aplicados

### 1. CSV único de documentos generados

Se elimina la generación de archivos separados por tipo de documento:

- `reports/generated/dni-generados.csv`
- `reports/generated/ruc-generados.csv`

A partir de esta versión, la trazabilidad funcional queda centralizada en:

```text
reports/generated/documentos-generados.csv
```

Este archivo contiene DNI y RUC generados, ambiente, operación, status HTTP, códigos funcionales, intento y mensajes relevantes.

### 2. Limpieza de reportes

Se agrega el script:

```bash
npm run clean:reports
```

Este comando elimina la carpeta `reports/` antes de una nueva corrida, evitando acumulación de HTML, logs y evidencias antiguas.

### 3. `.gitignore` reforzado

Se excluyen del repositorio:

```text
reports/
node_modules/
.env
*.log
playwright-report/
test-results/
config/application-*.properties
config/maquinas/application-*.properties
```

Los properties reales deben vivir en cada máquina, no en el repositorio.

### 4. Validación temprana de properties

Al iniciar un escenario, el framework valida el archivo:

```text
C:\Users\TU_USUARIO\application-uat.properties
C:\Users\TU_USUARIO\application-stg.properties
```

Si falta una propiedad obligatoria, la ejecución falla rápido con un mensaje claro indicando qué campo falta.

### 5. Resumen ejecutivo en consola

Al ejecutar:

```bash
npm run report
```

Se imprime un resumen con:

- escenarios totales
- escenarios exitosos/fallidos
- operaciones API
- status 2xx/4xx/5xx
- retries ejecutados
- PN/PJ generadas
- documentos generados
- ruta del CSV y reporte HTML
