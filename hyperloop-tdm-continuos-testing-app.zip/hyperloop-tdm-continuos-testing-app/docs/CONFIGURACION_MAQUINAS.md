# Configuración por máquina - IFX TDM

## Objetivo

Cada QA debe tener sus propios archivos locales de configuración. Así los tokens, secretos, subscription keys, consumer-id y documentos de prueba no quedan expuestos en el repositorio ni en el feature.

## Archivos incluidos

```text
config/maquinas/application-uat.properties
config/maquinas/application-stg.properties
```

## Dónde copiarlos en Windows

```text
C:\Users\TU_USUARIO\application-uat.properties
C:\Users\TU_USUARIO\application-stg.properties
```

Ejemplo:

```text
C:\Users\user\application-uat.properties
C:\Users\user\application-stg.properties
```

## Dónde copiarlos en Linux/Mac

```text
$HOME/application-uat.properties
$HOME/application-stg.properties
```

## Qué completar

### UAT

Completar principalmente:

```properties
ifx.password=
ifx.client-id=
ifx.client-secret=
ifx.subscription-key=
ifx.subscription-secret=
ifx.scope-transaccion=
ifx.scope-consulta=
```

### STG

Para los 3 endpoints STG del alcance actual no se envía `authorization`. Completar:

```properties
ifx.subscription-key=
ifx.stg.consumer-id=
```

## Cambio de ambiente

El ambiente se elige desde el feature:

```gherkin
Dado que selecciono el ambiente "uat"
Dado que selecciono el ambiente "stg"
```

También puedes ejecutar por tags:

```bash
npx cucumber-js --tags "@Smoke and @UAT"
npx cucumber-js --tags "@Smoke and @STG"
```

## Control de duplicados y logs técnicos

El framework ahora evita reciclar documentos generados automáticamente.

### Archivos generados

```text
reports/generated/documentos-generados.csv
reports/generated/duplicados-detectados.csv
reports/logs/ifx-technical-execution.jsonl
reports/logs/ifx-technical-execution.csv
```

### Políticas de duplicidad

```properties
ifx.duplicate.enabled=true
ifx.duplicate.provided-policy=warn
ifx.duplicate.max-generation-attempts=50
```

- `warn`: si el documento viene de Excel/properties y ya existe, solo advierte y continúa.
- `fail`: si el documento viene de Excel/properties y ya existe, bloquea la ejecución.
- `ignore`: no valida documentos manuales.

Los documentos generados automáticamente siempre se controlan. Si se detecta que el DNI/RUC ya está en el histórico, se genera el siguiente valor y se registra en `duplicados-detectados.csv`.

### STG con RUC automático

Para evitar RUC repetidos en creaciones STG, el framework ya genera RUC automático por defecto:

```properties
# PN STG genera RUC 10 incremental desde este valor base
ifx.stg.pn.ruc10-base=10294411491
ifx.stg.pn.ruc10-sequence-file=reports/sequences/stg-pn-ruc10-sequence.txt

# PJ STG genera RUC 20 incremental desde este valor base
ifx.stg.pj.ruc-base=20101298851
ifx.stg.pj.ruc-sequence-file=reports/sequences/stg-pj-ruc-sequence.txt
```

- Crear PN STG cambia `business.identityDocument.number` en cada ejecución.
- Crear PJ STG aplica la misma lógica incremental que UAT, pero con secuencia independiente.
- Si el Excel envía un RUC explícito, se usa solo en el primer intento; si devuelve 209, pasa a RUC incremental.
