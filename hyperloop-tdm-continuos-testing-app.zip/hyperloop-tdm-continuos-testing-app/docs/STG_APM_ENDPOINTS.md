# STG APM - endpoints agregados

Se agregó soporte para ejecutar los tres curls STG compartidos desde los tags actuales de Cucumber.

## Endpoints

| Operación | Tag | Método | Path | Authorization |
|---|---|---|---|---|
| Crear Persona Natural IFX | `@CrearPersonaNaturalIFX` | POST | `/bcw-business-account/v1/business-accounts/internal-channel` | No envía token |
| Crear Cliente PJ IFX | `@CrearClientePJIFX` | POST | `/business/v1/business-accounts/internal-channel` | No envía token |
| Consulta Cliente Full IFX | `@ConsultaClienteIFX` | GET | `/vision-cliente/uat/customers/full` | No envía token |

## Configuración

Copiar `config/application-stg.properties.example` a:

```text
C:\Users\TU_USUARIO\application-stg.properties
```

Completar:

```properties
ifx.transaccion.static-token=
ifx.consulta.static-token=
ifx.subscription-key=...
ifx.stg.consumer-id=...
```

## Ejecución

```bash
npm run test:stg:crear-pn
npm run test:stg:crear-pj
npm run test:stg:consulta-full
npm run report
```

## Notas QA

- `processtraceid` se genera incremental por request usando archivos de secuencia.
- Para estos 3 endpoints STG no se envía header `authorization`.
- La consulta STG usa GET y query params: `identityDocumentType` e `identityDocumentNumber`.
