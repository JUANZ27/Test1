# Curls UAT/STG alineados

Se actualizaron headers, body y properties con base en los archivos compartidos por QA:

- `curls uat(1).txt`
- `application-uat(1).properties`
- `curls stg (1)(1).txt`

## UAT

- CrearPersonaNaturalIFX usa `channelid=16`, `consumerid=BPE`, `branchid=100` y body con `MONTENEGRO/RIVAS/ISABEL/MARIA`.
- CrearClientePJIFX usa `application=ASSI`, `branchid=898`, `channelid=15`, `consumerid=01`, `serviceid=BIP` y body con `countryCode=4028`, `economicActivityCode=2023`, `societyType=EIRL`, dirección `JR/Catalino Miranda/Barranco`.
- ConsultaClienteIFX usa token de consulta y body POST con `identificationDocumentNumber=40903470`.

## STG

- CrearPersonaNaturalIFX usa `/bcw-business-account/v1/business-accounts/internal-channel`.
- CrearClientePJIFX usa `/business/v1/business-accounts/internal-channel`.
- ConsultaClienteIFX usa GET `/vision-cliente/uat/customers/full`.
- `processtraceid` se mantiene incremental por operación para evitar duplicidad.
- Los tokens STG quedan en properties y el envío de authorization se controla con `ifx.stg.authorization.enabled`.
