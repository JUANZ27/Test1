# CI/CD - GitHub Actions IFX

El proyecto incluye el workflow:

```text
.github/workflows/ifx-api-tests.yml
```

## Criterio de seguridad

Los tokens, credenciales, scopes, subscription keys y consumer-id no se guardan en features ni código. En GitHub Actions se toman desde **GitHub Secrets** y se escriben en archivos locales temporales:

```text
$HOME/application-uat.properties
$HOME/application-stg.properties
```

El framework siempre lee la configuración desde esos archivos, igual que en la máquina de cada QA.

## Ejecución manual

Desde GitHub Actions selecciona **IFX API Tests - UAT/STG** y define:

- `environment`: `uat` o `stg`
- `tags`: por ejemplo `@Smoke and @UAT`, `@Smoke and @STG`, `@CrearPersonaNaturalIFX and @STG`
- `retry_max_attempts`: cantidad máxima de intentos para errores técnicos
- `retry_delay_ms`: espera base entre reintentos

## Ejemplos de tags

```text
@Smoke and @UAT
@Smoke and @STG
@Regression and @UAT
@Regression and @STG
@CrearPersonaNaturalIFX and @UAT
@CrearPersonaNaturalIFX and @STG
@CrearClientePJIFX and @UAT
@CrearClientePJIFX and @STG
@ConsultaClienteIFX and @UAT
@ConsultaClienteIFX and @STG
```

## Retry técnico

El retry se aplica solamente a errores técnicos/transitorios:

```text
408, 429, 500, 502, 503, 504
```

No se reintentan errores funcionales como `400`, `401`, `403` o `404`.

Los valores de retry se inyectan al archivo properties temporal:

```properties
ifx.retry.enabled=true
ifx.retry.max-attempts=3
ifx.retry.delay-ms=1000
ifx.retry.exponential=true
ifx.retry.technical-statuses=408,429,500,502,503,504
```

## Secrets requeridos

### UAT

```text
IFX_PASSWORD
IFX_CLIENT_ID
IFX_CLIENT_SECRET
IFX_SCOPE_TRANSACCION
IFX_SCOPE_CONSULTA
IFX_SUBSCRIPTION_KEY
IFX_SUBSCRIPTION_SECRET
```

### STG

Para los 3 endpoints STG del alcance no se envía `authorization`. Solo se requieren:

```text
IFX_STG_SUBSCRIPTION_KEY
IFX_STG_CONSUMER_ID
```

## Artefactos publicados

El workflow publica:

```text
reports/html
reports/cucumber
reports/evidence
reports/generated
reports/sequences
```

## Workflow con una sola variable de ambiente

El workflow `.github/workflows/ifx-api-tests.yml` usa una sola entrada principal:

```text
environment = uat | stg
```

Si el campo `tags` queda vacío, el pipeline ejecuta automáticamente:

```text
@Smoke and @UAT
```

o

```text
@Smoke and @STG
```

según el ambiente seleccionado. Si se envía un tag sin `@UAT` o `@STG`, el workflow agrega el tag del ambiente elegido. Ejemplo:

```text
environment=stg
tags=@GenerateDataFromExcel
```

se ejecuta como:

```text
@GenerateDataFromExcel and @STG
```

## Ejecución de GenerateDataFromExcel en CI

El scenario lee el archivo desde:

```text
src/main/resources/Data/CargaClientePNPJ.xlsx
```

con columnas mínimas:

```text
TIPO_DOCUMENTO
NUMERO_DOCUMENTO
```

El valor `AUTO` permite generar el DNI/RUC incremental y seguir guardándolo en los CSV de trazabilidad.
