# Excel maestro PN/PJ - GenerateDataFromExcel

Este proyecto permite ejecutar `@GenerateDataFromExcel` con un solo archivo Excel para crear Persona Natural o Persona Jurídica.

## Decisión QA Automation Senior

No se debe inferir el endpoint solo por `TIPO_DOCUMENTO`, porque en algunos ambientes una Persona Natural con negocio también puede manejar RUC. Por eso se usa la columna `OPERACION`.

| OPERACION | Endpoint llamado |
|---|---|
| `CREAR_PN` | `CrearPersonaNaturalIFX` |
| `CREAR_PJ` | `CrearClientePJIFX` |

## Filtro por ambiente

La columna `AMBIENTE` permite tener data de `uat` y `stg` en el mismo archivo. Cuando el feature selecciona `uat`, solo se ejecutan filas con `AMBIENTE=uat`. Cuando selecciona `stg`, solo se ejecutan filas con `AMBIENTE=stg`.

## Columnas recomendadas

| Columna | Uso |
|---|---|
| `OPERACION` | `CREAR_PN` o `CREAR_PJ` |
| `AMBIENTE` | `uat` o `stg` |
| `TIPO_DOCUMENTO` | `DNI` o `RUC` |
| `NUMERO_DOCUMENTO` | Número fijo o `AUTO` |
| `CANTIDAD` | Cantidad a crear por fila |
| `SOCIETYTYPE` | Requerido para PJ |
| `COUNTRYCODE` | Requerido para PJ |
| `ECONOMICACTIVITYCODE` | Requerido para PJ |
| `EMAIL` | Opcional |

## Reglas importantes

- Si `CANTIDAD` es mayor a 1, usar `NUMERO_DOCUMENTO=AUTO` o dejarlo vacío.
- Si se coloca un documento fijo, debe usarse con `CANTIDAD=1`.
- La data generada se mantiene en los CSV de trazabilidad del proyecto.
- STG sigue ejecutando los 3 endpoints sin `authorization`, y PN/PJ usan `processtraceid` incremental.
