# Processtraceid único para STG

Para los endpoints STG de creación PN/PJ, el header `processtraceid` no debe repetirse.  
El framework ahora lo genera automáticamente con la estructura:

```text
fecha + cimapjc1local + hora + sufijo
```

Formato por defecto:

```text
ddMMyy + cimapjc1local + HHmmss + 000001
```

Ejemplo:

```text
050826cimapjc1local011530000001
```

## Configuración

En `application-stg.properties`:

```properties
ifx.stg.processtraceid-timezone=America/Lima
ifx.stg.processtraceid-date-pattern=ddMMyy
ifx.stg.processtraceid-time-pattern=HHmmss
ifx.stg.processtraceid-literal=cimapjc1local
ifx.stg.processtraceid-suffix-base=1
ifx.stg.processtraceid-suffix-width=6
ifx.stg.pn.processtraceid-suffix-file=reports/sequences/stg-pn-processtraceid-suffix.txt
ifx.stg.pj.processtraceid-suffix-file=reports/sequences/stg-pj-processtraceid-suffix.txt
```

## Comportamiento QA/TDM

- Se genera un nuevo `processtraceid` por cada request de creación PN/PJ en STG.
- Si el API responde código funcional `209` por documento existente, el retry genera otro documento y otro `processtraceid`.
- El sufijo se persiste en `reports/sequences` para evitar colisiones cuando se ejecutan varios requests dentro del mismo segundo.

## Ejemplo de salida

```text
[IFX][CrearClientePJIFX] processtraceid único generado: 050826cimapjc1local011530000001
```
