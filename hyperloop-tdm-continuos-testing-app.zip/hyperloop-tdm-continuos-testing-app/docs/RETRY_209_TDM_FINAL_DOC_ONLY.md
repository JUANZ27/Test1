# Retry funcional 209 para TDM

## Objetivo

Cuando los endpoints de creación de data (`CrearPersonaNaturalIFX` y `CrearClientePJIFX`) responden código efectivo `209` con mensaje equivalente a **DOCUMENTO EXISTE**, el framework no debe fallar de inmediato.

Como se trata de un TDM, el objetivo es **generar data válida**, por eso el flujo debe:

1. Generar documento incremental.
2. Ejecutar el endpoint de creación.
3. Si el API responde código efectivo `209`, generar el siguiente documento.
4. Reintentar hasta obtener código efectivo `200`.
5. Guardar en `documentos-generados.csv` únicamente el documento creado exitosamente.

## Código efectivo

El framework evalúa el código efectivo en este orden:

- `srvResponseCode` de headers.
- Campos del body como `responseCode`, `code`, `statusCode`, `codigo` o `codigoRespuesta`.
- HTTP status si no existe código funcional.

## Archivos generados

### Data creada correctamente

Solo se guarda en:

```text
reports/generated/documentos-generados.csv
```

Este CSV almacena la data realmente creada, es decir, el intento que terminó con código efectivo `200`.

### Intentos descartados por 209

Los documentos que respondieron `209 DOCUMENTO EXISTE` no se mezclan con la data creada. Se registran en:

```text
reports/generated/duplicados-detectados.csv
reports/logs/ifx-technical-execution.csv
reports/logs/ifx-technical-execution.jsonl
```

## Configuración

```properties
ifx.retry.duplicate-document.enabled=true
ifx.retry.duplicate-document-code=209
ifx.retry.duplicate-document.max-attempts=10
ifx.retry.duplicate-document.max-attempts-pn=10
ifx.retry.duplicate-document.max-attempts-pj=10
ifx.retry.duplicate-document.delay-ms=500
ifx.retry.duplicate-document.exponential=false
```

## Criterio de aprobación

El escenario pasa solo si logra obtener código efectivo `200` dentro del máximo de intentos configurado.

El escenario falla si:

- Todos los intentos responden `209`.
- Retorna un error funcional distinto de `209`.
- Retorna un error técnico no recuperable.
