# Mejora: Response Body en formato JSON

Se agregó una normalización del `responseBody` para que, cuando el API responda JSON, se muestre con indentación en:

- Consola durante la ejecución.
- Evidencia HTML por escenario.
- Logs técnicos `reports/logs/ifx-technical-execution.jsonl`.

Esto mejora especialmente la lectura de `ConsultaClienteIFX`, que antes se imprimía como una sola línea extensa.

## Comando de prueba

```bash
npm run test:stg:consulta-full
npm run report
```

Luego revisar:

```text
reports/html/evidencias.html
reports/html/scenarios/*.html
reports/logs/ifx-technical-execution.jsonl
```

Si el response no es JSON válido, se conserva el texto original del servicio.
