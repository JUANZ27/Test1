# Refactor UAT - Feature, Excel y TDM masivo

## Alcance

Esta versión deja el framework enfocado en **UAT** debido a la inestabilidad de STG.

Escenarios activos:

- `@CrearPersonaNaturalIFX`
- `@CrearClientePJIFX`
- `@ConsultaClienteIFX`
- `@GenerateDataFromExcel`

## Cantidad y documento base desde feature

Para cargas masivas se parametriza desde Examples:

```gherkin
Cuando ejecuto Crear <cantidad> Personas Naturales IFX con tipo documento "<tipoDocumento>" desde documento base "<documentoBase>"
```

```gherkin
Cuando ejecuto Crear <cantidad> Clientes PJ IFX con RUC base "<rucBase>" societyType "<societyType>" countryCode "<countryCode>" economicActivityCode "<economicActivityCode>"
```

## Consulta desde feature

```gherkin
Cuando ejecuto Consulta Cliente IFX con tipo documento "<tipoDocumento>" y numero documento "<numeroDocumento>"
```

## Excel maestro

El Excel soporta:

- `CREAR_PN`
- `CREAR_PJ`
- `CONSULTA_FULL`

Columnas clave:

```text
OPERACION
AMBIENTE
TIPO_DOCUMENTO
NUMERO_DOCUMENTO
DOCUMENTO_BASE
CANTIDAD
SOCIETYTYPE
COUNTRYCODE
ECONOMICACTIVITYCODE
```

## Retry 209

Si UAT responde `209 DOCUMENTO EXISTE`, el framework:

1. Incrementa DNI/RUC.
2. Reintenta la creación.
3. Continúa hasta código efectivo 200 o hasta agotar intentos.
4. Guarda solo el documento final exitoso en `documentos-generados.csv`.
