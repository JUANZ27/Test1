import { request, APIResponse } from '@playwright/test';
import { Properties, prop } from '../utils/properties';
import { nextSequence, nextValidRuc10, nextValidRuc20 } from '../utils/sequence';
import { appendGeneratedDocument, GeneratedDocumentRecord } from '../utils/generated-store';
import { appendDuplicateEvent, checkDuplicateDocument } from '../utils/duplicate-control';
import { appendTechnicalLog } from '../utils/technical-log';
import { readExcelRows, rowValue, ExcelRow } from '../utils/excel';

export interface ExecutionEvidence {
  operation: string;
  tokenType: 'consulta' | 'transaccion';
  method: string;
  url: string;
  requestHeaders: Record<string, string>;
  requestBody?: unknown;
  responseStatus: number;
  responseHeaders: Record<string, string>;
  responseBody: string;
  parsedResponse?: unknown;
  busResponseMessage: string;
  srvResponseCode: string;
  srvResponseMessage: string;
  generatedDocuments?: GeneratedDocumentRecord[];
  attempts?: number;
  durationMs?: number;
  retryHistory?: Array<{ attempt: number; status?: number; error?: string }>;
  technicalLogFile?: string;
  timestamp: string;
}

function cleanBaseUrl(value: string): string {
  return value.endsWith('/') ? value.slice(0, -1) : value;
}

function pathJoin(pathValue: string): string {
  return pathValue.startsWith('/') ? pathValue : `/${pathValue}`;
}

function firstNonBlank(...values: Array<string | undefined>): string {
  for (const value of values) {
    if (value && value.trim()) return value.trim();
  }
  return '';
}

function normalizeOptionalValue(value: string | undefined): string {
  const normalized = (value || '').trim();
  if (!normalized) return '';
  const lower = normalized.toLowerCase();
  if (lower === 'string' || lower === 'null' || lower === 'undefined' || lower === 'n/a' || lower === 'na' || lower === '-') return '';
  return normalized;
}

function valueOrDefault(value: string | undefined, defaultValue: string): string {
  return normalizeOptionalValue(value) || defaultValue;
}

function toLimaIsoTimestamp(date: Date): string {
  const limaDate = new Date(date.getTime() - 5 * 60 * 60 * 1000);
  return `${limaDate.toISOString().slice(0, 23)}-05:00`;
}

function normalizeDocumentType(type: string): string {
  return (type || 'DNI').trim().toUpperCase();
}

function documentTypeId(type: string): string {
  const t = normalizeDocumentType(type);
  if (t === 'DNI') return '1';
  if (t === 'RUC') return '2';
  if (t === 'CE') return '3';
  if (t === 'PASAPORTE') return '5';
  return t;
}

export class IfxClient {
  constructor(private props: Properties) {}

  /**
   * Crea una persona natural IFX.
   * Si el Excel/Gherkin no envía documento, genera un DNI incremental y lo persiste en CSV.
   */
  async createNaturalPerson(typeDocument = 'DNI', row: ExcelRow = {}): Promise<ExecutionEvidence> {
    return this.executeCreateWithDuplicate209Retry('CrearPersonaNaturalIFX', async (attempt, generatedDocuments) => {
      // STG APM usa el endpoint internal-channel y un body distinto al IFX UAT clásico.
      // El processtraceid se genera único en cada request para evitar rechazos por duplicidad.
      if (this.isStgApm()) {
        const body = this.buildStgNaturalPersonBody(row, generatedDocuments, attempt);
        return this.postJson(
          'CrearPersonaNaturalIFX',
          'transaccion',
          prop(this.props, 'ifx.create-customer-path'),
          this.stgInternalChannelHeaders('CrearPersonaNaturalIFX'),
          body
        );
      }

      const docType = normalizeDocumentType(typeDocument);
      const providedDocNumberRaw = firstNonBlank(rowValue(row, 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'DOCUMENT_NUMBER', 'DOCUMENT NUMBER', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO'));
      const providedDocNumber = providedDocNumberRaw.toUpperCase() === 'AUTO' ? '' : providedDocNumberRaw;

      // Primer intento respeta el documento enviado por Excel/Gherkin si existe.
      // Si el API responde 209 por documento existente, los siguientes intentos cambian a documento AUTO incremental.
      const shouldUseProvidedDocument = attempt === 1 && !!providedDocNumber;
      if (shouldUseProvidedDocument) {
        this.validateProvidedDocumentNotDuplicated('DNI', providedDocNumber, 'CrearPersonaNaturalIFX', 'createNaturalPerson');
      }
      const documentoBase = rowValue(row, 'DOCUMENTO_BASE', 'DOCUMENT_BASE', 'DOC_BASE', 'BASE_DOCUMENTO');
      const docNumber = shouldUseProvidedDocument
        ? providedDocNumber
        : (docType === 'RUC'
          ? this.generateAndPersistRuc('CrearPersonaNaturalIFX', `createNaturalPerson intento ${attempt}`, generatedDocuments, documentoBase)
          : this.generateAndPersistDni('CrearPersonaNaturalIFX', `createNaturalPerson intento ${attempt}`, generatedDocuments, documentoBase));

      const body = this.buildNaturalPersonBody(documentTypeId(docType), docNumber, row);
      return this.postJson('CrearPersonaNaturalIFX', 'transaccion', prop(this.props, 'ifx.create-customer-path'), this.naturalPersonHeaders(), body);
    });
  }

  /**
   * Crea N personas naturales en una sola ejecución BDD.
   * Se usa para el step: Cuando ejecuto Crear 2 Personas Naturales IFX...
   */
  async createNaturalPersons(quantity: number, typeDocument = 'DNI', row: ExcelRow = {}): Promise<ExecutionEvidence[]> {
    const safeQuantity = this.validateQuantity(quantity);
    const evidences: ExecutionEvidence[] = [];
    for (let index = 1; index <= safeQuantity; index++) {
      const evidence = await this.createNaturalPerson(typeDocument, { ...row, __BULK_ITEM: `${index}/${safeQuantity}` });
      evidence.operation = `CrearPersonaNaturalIFX ${index}/${safeQuantity}`;
      evidences.push(evidence);
    }
    return evidences;
  }

  /**
   * Consulta Full Information usando token de consulta.
   * No debe usar token transaccional.
   */
  async retrieveCustomer(typeDocument = 'DNI', documentNumber = ''): Promise<ExecutionEvidence> {
    let docType = normalizeDocumentType(typeDocument);
    let docNumber = firstNonBlank(documentNumber, docType === 'RUC' ? prop(this.props, 'ifx.query-ruc') : prop(this.props, 'ifx.query-dni', '40903462'));

    // En STG se prioriza la data del curl/config para que el tag existente ejecute el caso real de ConsultaFULL.
    if (this.isStgApm() && prop(this.props, 'ifx.stg.consulta.use-properties', 'true').toLowerCase() !== 'false') {
      docType = normalizeDocumentType(prop(this.props, 'ifx.query-document-type', 'RUC'));
      docNumber = docType === 'RUC' ? prop(this.props, 'ifx.query-ruc', '20188121676') : prop(this.props, 'ifx.query-dni', '40903462');
    }

    // STG APM expone Consulta FULL como GET con query params identityDocumentType/identityDocumentNumber.
    if (this.isStgApm() || prop(this.props, 'ifx.retrieve-customer-method', 'POST').toUpperCase() === 'GET') {
      const query = new URLSearchParams({ identityDocumentType: docType, identityDocumentNumber: docNumber }).toString();
      return this.getJson('ConsultaClienteIFX', 'consulta', `${prop(this.props, 'ifx.retrieve-customer-path')}?${query}`, this.consultationHeaders());
    }

    const body = {
      searchCriteria: prop(this.props, 'ifx.consulta.search-criteria', '5'),
      identificationDocumentType: documentTypeId(docType),
      identificationDocumentNumber: docNumber,
      cardId: '',
      customerAccount: {
        organisationId: '',
        currencyCode: '',
        categoryCode: '',
        account: { branchCode: '', accountNumber: '' }
      }
    };
    return this.postJson('ConsultaClienteIFX', 'consulta', prop(this.props, 'ifx.retrieve-customer-path'), this.consultationHeaders(), body);
  }

  /**
   * Consulta Full Information usando token de consulta.
   * No debe usar token transaccional.
   */
  /**
   * Consulta CCE Customer Special Status con query params documentTypeId y documentNumber.
   * Usa token de consulta.
   */
  async retrieveCustomerSpecialStatus(documentTypeIdValue = '1', documentNumber = '40975592'): Promise<ExecutionEvidence> {
    const query = new URLSearchParams({ documentTypeId: documentTypeIdValue, documentNumber }).toString();
    const path = `${prop(this.props, 'ifx.customer-special-status-path') || '/customer-profile/v1/customer-special-status'}?${query}`;
    return this.getJson('ConsultaCustomerSpecialStatusCCE', 'consulta', path, this.specialStatusHeaders());
  }

  /**
   * Crea cliente persona jurídica IFX.
   * Si no recibe RUC desde Excel, genera un RUC 20 válido incremental.
   */
  async createLegalPerson(row: ExcelRow = {}): Promise<ExecutionEvidence> {
    return this.executeCreateWithDuplicate209Retry('CrearClientePJIFX', async (attempt, generatedDocuments) => {
      // STG APM usa el endpoint business-accounts/internal-channel para Crear PJ.
      // En cada reintento cambia el RUC y el processtraceid para evitar duplicidad funcional.
      if (this.isStgApm()) {
        const body = this.buildStgLegalPersonBody(row, generatedDocuments, attempt);
        return this.postJson(
          'CrearClientePJIFX',
          'transaccion',
          prop(this.props, 'ifx.create-merchant-path'),
          this.stgInternalChannelHeaders('CrearClientePJIFX'),
          body
        );
      }

      const providedRucRaw = rowValue(row, 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'DOCUMENT_NUMBER', 'DOCUMENT NUMBER', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO');
      const providedRuc = providedRucRaw.toUpperCase() === 'AUTO' ? '' : providedRucRaw;

      // Primer intento respeta el RUC enviado. Si el API responde 209, los siguientes intentos usan RUC AUTO incremental.
      const shouldUseProvidedRuc = attempt === 1 && !!providedRuc;
      if (shouldUseProvidedRuc) {
        this.validateProvidedDocumentNotDuplicated('RUC', providedRuc, 'CrearClientePJIFX', 'createLegalPerson');
      }
      const rucBase = rowValue(row, 'DOCUMENTO_BASE', 'DOCUMENT_BASE', 'RUC_BASE', 'BASE_DOCUMENTO');
      const ruc = shouldUseProvidedRuc
        ? providedRuc
        : this.generateAndPersistRuc('CrearClientePJIFX', `createLegalPerson intento ${attempt}`, generatedDocuments, rucBase);

      const body = this.buildLegalPersonBody('2', ruc, row);
      return this.postJson('CrearClientePJIFX', 'transaccion', prop(this.props, 'ifx.create-merchant-path'), this.merchantHeaders(row), body);
    });
  }

  /**
   * Crea N clientes PJ en una sola ejecución BDD.
   * Permite parametrizar societyType, countryCode y economicActivityCode.
   */
  async createLegalPersons(quantity: number, row: ExcelRow = {}): Promise<ExecutionEvidence[]> {
    const safeQuantity = this.validateQuantity(quantity);
    const evidences: ExecutionEvidence[] = [];
    for (let index = 1; index <= safeQuantity; index++) {
      const evidence = await this.createLegalPerson(row);
      evidence.operation = `CrearClientePJIFX ${index}/${safeQuantity}`;
      evidences.push(evidence);
    }
    return evidences;
  }

  /**
   * Crea cuenta para PN o PJ usando token transaccional.
   * Puede tomar documentNumber/customerId desde Gherkin o desde Excel.
   */
  async createAccount(typeDocument = 'DNI', documentNumber = '', customerId = '', row: ExcelRow = {}): Promise<ExecutionEvidence> {
    const docType = normalizeDocumentType(typeDocument);
    const docNumber = firstNonBlank(documentNumber, rowValue(row, 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'DOCUMENT NUMBER', 'DOCUMENT_NUMBER', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO'), docType === 'RUC' ? prop(this.props, 'ifx.ruc-base') : prop(this.props, 'ifx.dni-base'));
    const resolvedCustomerId = firstNonBlank(customerId, rowValue(row, 'CUSTOMER ID', 'CUSTOMER_ID'), prop(this.props, 'ifx.account.customer-id'), docNumber);
    const body = this.buildCreateAccountBody(documentTypeId(docType), docNumber, resolvedCustomerId, row);
    return this.postJson('CrearCuentaIFX', 'transaccion', prop(this.props, 'ifx.create-account-path'), this.accountHeaders(row), body);
  }

  /**
   * Lee el Excel de src/main/resources/<dataDir>/<fileName> y ejecuta operaciones por fila.
   *
   * Enfoque QA Automation Senior:
   * - La columna OPERACION define explícitamente qué endpoint se ejecuta, evitando adivinar por tipo de documento.
   * - La columna AMBIENTE permite que un mismo Excel tenga data para UAT y STG; se ejecutan solo las filas del ambiente elegido.
   * - La columna CANTIDAD permite crear varios clientes por fila usando documentos AUTO/incrementales.
   *
   * Operaciones soportadas:
   * - CREAR_PN / PN / PERSONA_NATURAL / CREAR_PERSONA_NATURAL -> CrearPersonaNaturalIFX
   * - CREAR_PJ / PJ / PERSONA_JURIDICA / CREAR_PERSONA_JURIDICA -> CrearClientePJIFX
   * - CREAR_CUENTA -> CrearCuentaIFX (compatibilidad)
   * - CREAR_PN_Y_CUENTA / CREAR_PJ_Y_CUENTA -> cliente + cuenta (compatibilidad)
   */
  async generateDataFromExcel(dataDir: string, fileName: string): Promise<ExecutionEvidence> {
    const rows = readExcelRows(dataDir, fileName);
    const executions: ExecutionEvidence[] = [];
    const skippedRows: Array<{ row: number; ambiente: string; reason: string }> = [];
    const environment = this.environmentName().toLowerCase();

    for (const [index, row] of rows.entries()) {
      const rowNumber = index + 2; // +2 porque la fila 1 es cabecera en Excel.
      const rowEnvironment = rowValue(row, 'AMBIENTE', 'ENVIRONMENT', 'ENV');
      if (rowEnvironment && rowEnvironment.toLowerCase() !== environment) {
        skippedRows.push({ row: rowNumber, ambiente: rowEnvironment, reason: `Fila no corresponde al ambiente ${environment}` });
        continue;
      }

      const operation = this.normalizeExcelOperation(row);
      const quantity = this.validateQuantity(Number(rowValue(row, 'CANTIDAD', 'QUANTITY', 'NUMBER_RECORD') || '1'));
      const typeDocument = rowValue(row, 'TIPO DOCUMENTO', 'TIPO_DOCUMENTO', 'TYPE DOCUMENT', 'DOCUMENT_TYPE', 'TIPO DOCUEMNTO', 'TIPO_DOCUEMNTO', 'TIPO DOCUEMENTO', 'TIPO_DOCUEMENTO') || (operation.includes('PJ') ? 'RUC' : 'DNI');
      const docNumberRaw = rowValue(row, 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'DOCUMENT NUMBER', 'DOCUMENT_NUMBER', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO');
      const docNumber = docNumberRaw.toUpperCase() === 'AUTO' ? '' : docNumberRaw;
      const customerId = rowValue(row, 'CUSTOMER ID', 'CUSTOMER_ID');

      if (quantity > 1 && docNumber && operation !== 'CONSULTA_FULL') {
        throw new Error(`[GenerateDataFromExcel] Fila ${rowNumber}: CANTIDAD=${quantity} requiere NUMERO_DOCUMENTO=AUTO o vacío para evitar duplicar el documento ${docNumber}.`);
      }

      console.log(`[IFX][EXCEL] Fila ${rowNumber} | ambiente=${environment} | operacion=${operation} | cantidad=${quantity} | tipoDocumento=${typeDocument} | numeroDocumento=${docNumber || 'AUTO'}`);

      for (let item = 1; item <= quantity; item++) {
        const sourceRow: ExcelRow = { ...row, __EXCEL_ROW: String(rowNumber), __EXCEL_ITEM: `${item}/${quantity}` };

        if (operation === 'CREAR_PN') {
          const evidence = await this.withRetriesDisabledForExcel(() => this.createNaturalPerson(typeDocument, sourceRow));
          evidence.operation = `GenerateDataFromExcel CrearPersonaNaturalIFX fila ${rowNumber} ${item}/${quantity}`;
          executions.push(evidence);
          continue;
        }

        if (operation === 'CREAR_PJ') {
          const evidence = await this.withRetriesDisabledForExcel(() => this.createLegalPerson(sourceRow));
          evidence.operation = `GenerateDataFromExcel CrearClientePJIFX fila ${rowNumber} ${item}/${quantity}`;
          executions.push(evidence);
          continue;
        }

        if (operation === 'CONSULTA_FULL') {
          const evidence = await this.withRetriesDisabledForExcel(() => this.retrieveCustomer(typeDocument, docNumber));
          evidence.operation = `GenerateDataFromExcel ConsultaClienteIFX fila ${rowNumber} ${item}/${quantity}`;
          executions.push(evidence);
          continue;
        }

        if (operation === 'CREAR_CUENTA') {
          const evidence = await this.withRetriesDisabledForExcel(() => this.createAccount(typeDocument, docNumber, customerId, sourceRow));
          evidence.operation = `GenerateDataFromExcel CrearCuentaIFX fila ${rowNumber} ${item}/${quantity}`;
          executions.push(evidence);
          continue;
        }

        if (operation === 'CREAR_PN_Y_CUENTA' || operation === 'CREAR_PJ_Y_CUENTA') {
          const clientExecution = operation === 'CREAR_PJ_Y_CUENTA'
            ? await this.withRetriesDisabledForExcel(() => this.createLegalPerson(sourceRow))
            : await this.withRetriesDisabledForExcel(() => this.createNaturalPerson(typeDocument, sourceRow));
          clientExecution.operation = `GenerateDataFromExcel ${operation === 'CREAR_PJ_Y_CUENTA' ? 'CrearClientePJIFX' : 'CrearPersonaNaturalIFX'} fila ${rowNumber} ${item}/${quantity}`;
          executions.push(clientExecution);

          const clientGeneratedDoc = clientExecution.generatedDocuments?.[0]?.documentNumber || '';
          const resolvedDocNumber = docNumber || clientGeneratedDoc;
          const accountExecution = await this.withRetriesDisabledForExcel(() => this.createAccount(typeDocument, resolvedDocNumber, customerId || resolvedDocNumber || '', sourceRow));
          accountExecution.operation = `GenerateDataFromExcel CrearCuentaIFX fila ${rowNumber} ${item}/${quantity}`;
          executions.push(accountExecution);
          continue;
        }

        throw new Error(`[GenerateDataFromExcel] Fila ${rowNumber}: operación no soportada: ${operation}`);
      }
    }

    if (executions.length === 0) {
      throw new Error(`[GenerateDataFromExcel] No se ejecutó ninguna fila para el ambiente ${environment}. Filas omitidas: ${JSON.stringify(skippedRows)}`);
    }

    return {
      operation: 'GenerateDataFromExcel',
      tokenType: 'transaccion',
      method: 'BATCH',
      url: `${dataDir}/${fileName}`,
      requestHeaders: {},
      requestBody: { totalRows: rows.length, executedOperations: executions.length, skippedRows },
      responseStatus: executions.every(e => e.responseStatus >= 200 && e.responseStatus < 500) ? 200 : 500,
      responseHeaders: {},
      responseBody: JSON.stringify({ executed: executions, skippedRows }, null, 2),
      parsedResponse: { executed: executions, skippedRows },
      busResponseMessage: '',
      srvResponseCode: '',
      srvResponseMessage: '',
      generatedDocuments: executions.flatMap(e => e.generatedDocuments || []),
      attempts: executions.reduce((sum, e) => sum + (e.attempts || 1), 0),
      durationMs: executions.reduce((sum, e) => sum + (e.durationMs || 0), 0),
      retryHistory: executions.flatMap(e => e.retryHistory || []),
      timestamp: new Date().toISOString()
    };
  }

  /** En cargas Excel se desactivan retries para fallar rápido y mantener el resultado 1:1 por fila. */
  private async withRetriesDisabledForExcel<T>(action: () => Promise<T>): Promise<T> {
    const retryKey = 'ifx.retry.enabled';
    const duplicateRetryKey = 'ifx.retry.duplicate-document.enabled';
    const hadRetryKey = Object.prototype.hasOwnProperty.call(this.props, retryKey);
    const hadDuplicateRetryKey = Object.prototype.hasOwnProperty.call(this.props, duplicateRetryKey);
    const previousRetryValue = this.props[retryKey];
    const previousDuplicateRetryValue = this.props[duplicateRetryKey];

    this.props[retryKey] = 'false';
    this.props[duplicateRetryKey] = 'false';

    try {
      return await action();
    } finally {
      if (hadRetryKey) this.props[retryKey] = previousRetryValue;
      else delete this.props[retryKey];

      if (hadDuplicateRetryKey) this.props[duplicateRetryKey] = previousDuplicateRetryValue;
      else delete this.props[duplicateRetryKey];
    }
  }

  /**
   * Normaliza la operación configurada en Excel.
   * Se deja explícito para que PN y PJ llamen a endpoints distintos aunque ambos puedan usar RUC en algunos ambientes.
   */
  private normalizeExcelOperation(row: ExcelRow): 'CREAR_PN' | 'CREAR_PJ' | 'CONSULTA_FULL' | 'CREAR_CUENTA' | 'CREAR_PN_Y_CUENTA' | 'CREAR_PJ_Y_CUENTA' {
    const rawOperation = (rowValue(row, 'OPERACION', 'OPERATION', 'TIPO_CLIENTE', 'TIPO CLIENTE', 'ACCION', 'ACTION') || prop(this.props, 'ifx.excel.default-operation', 'CREAR_PN')).trim().toUpperCase();
    const compactOperation = rawOperation.replace(/\s+/g, '_').replace(/-/g, '_');

    if (['CREAR_PN', 'PN', 'PERSONA_NATURAL', 'CREAR_PERSONA_NATURAL', 'NATURAL'].includes(compactOperation)) return 'CREAR_PN';
    if (['CREAR_PJ', 'PJ', 'PERSONA_JURIDICA', 'PERSONA_JURÍDICA', 'CREAR_PERSONA_JURIDICA', 'CREAR_PERSONA_JURÍDICA', 'JURIDICA', 'JURÍDICA'].includes(compactOperation)) return 'CREAR_PJ';
    if (['CONSULTA_FULL', 'CONSULTAR_FULL', 'CONSULTA_CLIENTE', 'CONSULTAR_CLIENTE', 'CONSULTA'].includes(compactOperation)) return 'CONSULTA_FULL';
    if (['CREAR_CUENTA', 'CUENTA'].includes(compactOperation)) return 'CREAR_CUENTA';
    if (['CREAR_PN_Y_CUENTA', 'CREAR_PERSONA_NATURAL_Y_CUENTA', 'PN_Y_CUENTA'].includes(compactOperation)) return 'CREAR_PN_Y_CUENTA';
    if (['CREAR_PJ_Y_CUENTA', 'CREAR_PERSONA_JURIDICA_Y_CUENTA', 'CREAR_PERSONA_JURÍDICA_Y_CUENTA', 'PJ_Y_CUENTA'].includes(compactOperation)) return 'CREAR_PJ_Y_CUENTA';

    // Compatibilidad con versiones previas: CREAR_CLIENTE decidía por tipo documento.
    if (['CREAR_CLIENTE', 'CLIENTE'].includes(compactOperation)) {
      const typeDocument = normalizeDocumentType(rowValue(row, 'TIPO DOCUMENTO', 'TIPO_DOCUMENTO', 'TYPE DOCUMENT', 'DOCUMENT_TYPE'));
      return typeDocument === 'RUC' ? 'CREAR_PJ' : 'CREAR_PN';
    }

    throw new Error(`[GenerateDataFromExcel] Operación no soportada en Excel: ${rawOperation}. Usar CREAR_PN o CREAR_PJ.`);
  }

  /**
   * Retry funcional para TDM cuando el API indica documento existente.
   *
   * Contexto QA:
   * - En creación PN/PJ el servicio puede responder código 209 cuando el documento ya existe.
   * - Para TDM, la expectativa es obtener una creación válida con código 200.
   * - En cada reintento se vuelve a construir el body para generar un nuevo DNI/RUC y, en STG, un nuevo processtraceid.
   * - Se mantiene la trazabilidad CSV de cada documento generado, incluyendo intentos fallidos con 209 y el intento final 200.
   */
  private async executeCreateWithDuplicate209Retry(
    operation: 'CrearPersonaNaturalIFX' | 'CrearClientePJIFX',
    executeAttempt: (attempt: number, generatedDocuments: GeneratedDocumentRecord[]) => Promise<ExecutionEvidence>
  ): Promise<ExecutionEvidence> {
    const maxAttempts = this.duplicate209RetryEnabled()
      ? this.duplicate209MaxAttempts(operation)
      : 1;
    const allGeneratedDocuments: GeneratedDocumentRecord[] = [];
    const functionalRetryHistory: Array<{ attempt: number; status?: number; error?: string }> = [];
    let lastEvidence: ExecutionEvidence | undefined;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const generatedDocuments: GeneratedDocumentRecord[] = [];
      const evidence = await executeAttempt(attempt, generatedDocuments);
      lastEvidence = evidence;

      allGeneratedDocuments.push(...generatedDocuments);
      functionalRetryHistory.push({ attempt, status: this.effectiveResponseCode(evidence) });

      if (this.isBusinessSuccess(evidence)) {
        // Para TDM solo se persiste en documentos-generados.csv la data realmente creada.
        // Los intentos previos con 209 quedan registrados en logs técnicos y en duplicados-detectados.csv.
        this.persistGeneratedDocuments(generatedDocuments, evidence, attempt, attempt > 1);
        evidence.generatedDocuments = allGeneratedDocuments;
        evidence.attempts = attempt;
        evidence.retryHistory = [...(evidence.retryHistory || []), ...functionalRetryHistory];
        console.log(`[IFX][${operation}] Creación exitosa con código 200 en intento funcional ${attempt}/${maxAttempts}. Documento final guardado en CSV.`);
        return evidence;
      }

      if (this.isDuplicate209Response(evidence) && attempt < maxAttempts) {
        this.registerDuplicate209Attempt(generatedDocuments, operation, evidence, attempt);
        console.warn(`[IFX][${operation}] Documento existente detectado con código 209. Se reintentará con nuevo documento. Intento ${attempt}/${maxAttempts}.`);
        await this.delay(this.duplicate209RetryDelayMs(attempt));
        continue;
      }

      // Si no es 200 ni 209 reintentable, no se considera data creada. Se devuelve evidencia para que falle el escenario.
      evidence.generatedDocuments = allGeneratedDocuments;
      evidence.attempts = attempt;
      evidence.retryHistory = [...(evidence.retryHistory || []), ...functionalRetryHistory];
      return evidence;
    }

    if (!lastEvidence) throw new Error(`[IFX][${operation}] No se ejecutó ningún intento de creación.`);
    lastEvidence.generatedDocuments = allGeneratedDocuments;
    lastEvidence.retryHistory = [...(lastEvidence.retryHistory || []), ...functionalRetryHistory];
    return lastEvidence;
  }

  /**
   * Código efectivo de negocio para decidir si el TDM debe reintentar.
   *
   * Importante QA/TDM:
   * - En UAT el API puede responder HTTP 209 y además headers como srvresponsecode=001.
   * - Antes se priorizaba srvresponsecode y por eso el retry 209 no se activaba.
   * - Ahora se prioriza HTTP 209 o x-original-http-status-code=209 para detectar DOCUMENTO EXISTE.
   */
  private effectiveResponseCode(evidence: ExecutionEvidence): number {
    const duplicateCode = Number(prop(this.props, 'ifx.retry.duplicate-document-code', '209'));
    const originalStatus = Number(this.headerValue(evidence.responseHeaders, 'x-original-http-status-code'));

    if (Number.isFinite(originalStatus) && originalStatus === duplicateCode) return originalStatus;
    if (evidence.responseStatus === duplicateCode) return evidence.responseStatus;

    const parsedBusinessCode = Number(this.valueFromParsedResponse(evidence.parsedResponse, [
      'srvResponseCode',
      'responseCode',
      'code',
      'statusCode',
      'codigo',
      'codigoRespuesta'
    ]));
    if (Number.isFinite(parsedBusinessCode) && parsedBusinessCode === duplicateCode) return parsedBusinessCode;

    const srvResponseCode = Number(String(evidence.srvResponseCode || '').trim());
    if (Number.isFinite(srvResponseCode) && srvResponseCode > 0) return srvResponseCode;

    if (Number.isFinite(originalStatus) && originalStatus > 0) return originalStatus;
    return evidence.responseStatus;
  }

  /** Extrae campos simples del response parseado sin acoplarse a un contrato específico. */
  private valueFromParsedResponse(parsed: unknown, keys: string[]): string {
    if (!parsed || typeof parsed !== 'object') return '';
    const stack: unknown[] = [parsed];
    while (stack.length > 0) {
      const current = stack.pop();
      if (!current || typeof current !== 'object') continue;
      const record = current as Record<string, unknown>;
      for (const key of keys) {
        const foundKey = Object.keys(record).find(k => k.toLowerCase() === key.toLowerCase());
        if (foundKey && record[foundKey] !== undefined && record[foundKey] !== null) return String(record[foundKey]);
      }
      for (const value of Object.values(record)) {
        if (value && typeof value === 'object') stack.push(value);
      }
    }
    return '';
  }

  /** Considera éxito funcional solo cuando el código efectivo es 200. */
  private isBusinessSuccess(evidence: ExecutionEvidence): boolean {
    return this.effectiveResponseCode(evidence) === 200;
  }

  /** Detecta documento ya existente, ya sea por HTTP 209, header srvresponsecode=209 o body con code/responseCode=209. */
  private isDuplicate209Response(evidence: ExecutionEvidence): boolean {
    return this.effectiveResponseCode(evidence) === Number(prop(this.props, 'ifx.retry.duplicate-document-code', '209'));
  }

  private duplicate209RetryEnabled(): boolean {
    return prop(this.props, 'ifx.retry.duplicate-document.enabled', 'true').toLowerCase() !== 'false';
  }

  private duplicate209MaxAttempts(operation: string): number {
    const specificKey = operation === 'CrearClientePJIFX' ? 'ifx.retry.duplicate-document.max-attempts-pj' : 'ifx.retry.duplicate-document.max-attempts-pn';
    const value = Number(prop(this.props, specificKey, prop(this.props, 'ifx.retry.duplicate-document.max-attempts', '10')));
    return Number.isFinite(value) && value > 0 ? Math.floor(value) : 10;
  }

  private duplicate209RetryDelayMs(attempt: number): number {
    const base = Number(prop(this.props, 'ifx.retry.duplicate-document.delay-ms', '500'));
    const safeBase = Number.isFinite(base) && base >= 0 ? base : 500;
    const exponential = prop(this.props, 'ifx.retry.duplicate-document.exponential', 'false').toLowerCase() === 'true';
    return exponential ? safeBase * Math.pow(2, Math.max(0, attempt - 1)) : safeBase;
  }

  /**
   * Genera token IFX separado por tipo: consulta o transaccion.
   * También aplica retry técnico al token para evitar falsos fallos por APIC/OAuth intermitente.
   */
  private async token(type: 'consulta' | 'transaccion'): Promise<string> {
    // Para STG APM se puede usar token fijo desde properties locales, sin subirlo al repo.
    // Acepta token con o sin prefijo Bearer.
    const staticToken = firstNonBlank(
      prop(this.props, `ifx.${type}.static-token`),
      prop(this.props, `ifx.${type}.access-token`)
    );
    if (staticToken) return staticToken;

    const scope = type === 'consulta'
      ? prop(this.props, 'ifx.consulta.scope', prop(this.props, 'ifx.scope-consulta'))
      : prop(this.props, 'ifx.transaccion.scope', prop(this.props, 'ifx.scope-transaccion'));

    const result = await this.executeTokenWithRetry(type, scope);
    const json = result.json as { access_token?: string; raw?: string };
    if (!json.access_token) {
      throw new Error(`No se pudo generar token ${type}. La respuesta no contiene access_token: ${JSON.stringify(json)}`);
    }
    return json.access_token;
  }

  /** Ejecuta el token OAuth con retry solo para errores técnicos/transitorios. */
  private async executeTokenWithRetry(
    type: 'consulta' | 'transaccion',
    scope: string
  ): Promise<{ status: number; json: unknown }> {
    const maxAttempts = this.retryEnabled() ? this.retryMaxAttempts() : 1;
    const url = `${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(prop(this.props, 'ifx.token-path'))}`;
    let lastError: unknown;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const context = await request.newContext({ ignoreHTTPSErrors: true });
      try {
        const response = await context.post(url, {
          headers: { 'content-type': 'application/x-www-form-urlencoded' },
          form: {
            grant_type: prop(this.props, 'ifx.grant-type', 'password'),
            username: prop(this.props, 'ifx.username'),
            password: prop(this.props, 'ifx.password'),
            client_id: prop(this.props, 'ifx.client-id'),
            client_secret: prop(this.props, 'ifx.client-secret'),
            scope
          }
        });
        const json = await response.json().catch(async () => ({ raw: await response.text() }));
        const status = response.status();
        await context.dispose();

        if (response.ok()) return { status, json };

        if (attempt < maxAttempts && this.isRetryableTechnicalStatus(status)) {
          console.warn(`[IFX][TOKEN ${type}] Retry ${attempt}/${maxAttempts} por status técnico ${status}`);
          await this.delay(this.retryDelayMs(attempt));
          continue;
        }

        const noRetryError = new Error(`No se pudo generar token ${type}. Status ${status}: ${JSON.stringify(json)}`);
        (noRetryError as Error & { noRetry?: boolean }).noRetry = true;
        throw noRetryError;
      } catch (error) {
        lastError = error;
        await context.dispose();

        if ((error as Error & { noRetry?: boolean }).noRetry) {
          throw error;
        }

        if (attempt < maxAttempts) {
          console.warn(`[IFX][TOKEN ${type}] Retry ${attempt}/${maxAttempts} por error técnico: ${error instanceof Error ? error.message : String(error)}`);
          await this.delay(this.retryDelayMs(attempt));
          continue;
        }
      }
    }

    throw new Error(`No se pudo generar token ${type} luego de ${maxAttempts} intento(s). Último error: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
  }

  private authorization(token: string, type: 'consulta' | 'transaccion'): string {
    if (/^Bearer\s+/i.test(token)) return token;
    const prefix = prop(this.props, `ifx.${type}.authorization-prefix`, prop(this.props, 'ifx.authorization-prefix', 'Bearer'));
    return prefix ? `${prefix} ${token}` : token;
  }

  /** Ejecuta POST JSON con retry controlado y transforma request/response en evidencia QA. */
  private async postJson(operation: string, tokenType: 'consulta' | 'transaccion', pathValue: string, headers: Record<string, string>, body: unknown): Promise<ExecutionEvidence> {
    const url = `${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(pathValue)}`;
    const requestHeaders = await this.buildRequestHeaders(operation, tokenType, headers);
    const result = await this.executeWithRetry(operation, 'POST', url, requestHeaders, body);
    return this.toEvidence(operation, tokenType, 'POST', url, requestHeaders, body, result.response, result.responseBody, result.attempts, result.durationMs, result.retryHistory);
  }

  /** Ejecuta GET JSON con retry controlado y transforma request/response en evidencia QA. */
  private async getJson(operation: string, tokenType: 'consulta' | 'transaccion', pathValue: string, headers: Record<string, string>): Promise<ExecutionEvidence> {
    const url = `${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(pathValue)}`;
    const requestHeaders = await this.buildRequestHeaders(operation, tokenType, headers);
    const result = await this.executeWithRetry(operation, 'GET', url, requestHeaders);
    return this.toEvidence(operation, tokenType, 'GET', url, requestHeaders, undefined, result.response, result.responseBody, result.attempts, result.durationMs, result.retryHistory);
  }

  /**
   * Construye headers finales por operación.
   * Para los 3 endpoints STG APM compartidos por QA no se envía authorization/token:
   * - CrearPersonaNaturalIFX
   * - CrearClientePJIFX
   * - ConsultaClienteIFX
   */
  private async buildRequestHeaders(operation: string, tokenType: 'consulta' | 'transaccion', headers: Record<string, string>): Promise<Record<string, string>> {
    const requestHeaders = { ...headers };
    if (!this.requiresAuthorization(operation)) {
      console.log(`[IFX][${operation}] STG APM: request sin header authorization según contrato del curl.`);
      return requestHeaders;
    }

    const accessToken = await this.token(tokenType);
    requestHeaders.authorization = this.authorization(accessToken, tokenType);
    return requestHeaders;
  }

  /** Indica si la operación debe agregar header authorization. */
  private requiresAuthorization(operation: string): boolean {
    if (!this.isStgApm()) return true;

    // En STG APM los 3 endpoints compartidos pueden ejecutarse sin token según el criterio QA actual.
    // Si el equipo activa seguridad en STG, se habilita sin tocar código:
    // ifx.stg.authorization.enabled=true
    if (['CrearPersonaNaturalIFX', 'CrearClientePJIFX', 'ConsultaClienteIFX'].includes(operation)) {
      return prop(this.props, 'ifx.stg.authorization.enabled', 'false').toLowerCase() === 'true';
    }

    return true;
  }

  /**
   * Retry controlado para errores técnicos.
   * No reintenta errores funcionales 4xx salvo 408/429 porque esos suelen ser transitorios.
   */
  private async executeWithRetry(
    operation: string,
    method: 'GET' | 'POST',
    url: string,
    headers: Record<string, string>,
    body?: unknown
  ): Promise<{ response: APIResponse; responseBody: string; attempts: number; durationMs: number; retryHistory: Array<{ attempt: number; status?: number; error?: string }> }> {
    const start = Date.now();
    const maxAttempts = this.retryEnabled() ? this.retryMaxAttempts() : 1;
    const retryHistory: Array<{ attempt: number; status?: number; error?: string }> = [];
    let lastError: unknown;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const context = await request.newContext({ ignoreHTTPSErrors: true });
      try {
        const response = method === 'POST'
          ? await context.post(url, { headers, data: body })
          : await context.get(url, { headers });
        const responseBody = await response.text();
        const status = response.status();
        retryHistory.push({ attempt, status });
        await context.dispose();

        if (attempt < maxAttempts && this.isRetryableTechnicalStatus(status)) {
          console.warn(`[IFX][${operation}] Retry ${attempt}/${maxAttempts} por status técnico ${status}`);
          await this.delay(this.retryDelayMs(attempt));
          continue;
        }

        return { response, responseBody, attempts: attempt, durationMs: Date.now() - start, retryHistory };
      } catch (error) {
        lastError = error;
        retryHistory.push({ attempt, error: error instanceof Error ? error.message : String(error) });
        await context.dispose();

        if (attempt < maxAttempts) {
          console.warn(`[IFX][${operation}] Retry ${attempt}/${maxAttempts} por error técnico: ${error instanceof Error ? error.message : String(error)}`);
          await this.delay(this.retryDelayMs(attempt));
          continue;
        }
      }
    }

    throw new Error(`Falló la operación ${operation} luego de ${maxAttempts} intento(s). Último error: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
  }

  private retryEnabled(): boolean {
    return prop(this.props, 'ifx.retry.enabled', 'true').toLowerCase() !== 'false';
  }

  private retryMaxAttempts(): number {
    const value = Number(prop(this.props, 'ifx.retry.max-attempts', '3'));
    return Number.isFinite(value) && value > 0 ? Math.floor(value) : 3;
  }

  private retryDelayMs(attempt: number): number {
    const base = Number(prop(this.props, 'ifx.retry.delay-ms', '1000'));
    const safeBase = Number.isFinite(base) && base >= 0 ? base : 1000;
    const exponential = prop(this.props, 'ifx.retry.exponential', 'true').toLowerCase() !== 'false';
    return exponential ? safeBase * Math.pow(2, Math.max(0, attempt - 1)) : safeBase;
  }

  private isRetryableTechnicalStatus(status: number): boolean {
    const retryStatuses = prop(this.props, 'ifx.retry.technical-statuses', '408,429,500,502,503,504')
      .split(',')
      .map(value => Number(value.trim()))
      .filter(value => Number.isFinite(value));
    return retryStatuses.includes(status);
  }

  private async delay(ms: number): Promise<void> {
    if (ms <= 0) return;
    await new Promise(resolve => setTimeout(resolve, ms));
  }

  /** Normaliza la respuesta HTTP y extrae headers clave para los reportes. */
  private toEvidence(
    operation: string,
    tokenType: 'consulta' | 'transaccion',
    method: string,
    url: string,
    requestHeaders: Record<string, string>,
    requestBody: unknown,
    response: APIResponse,
    responseBody: string,
    attempts = 1,
    durationMs = 0,
    retryHistory: Array<{ attempt: number; status?: number; error?: string }> = []
  ): ExecutionEvidence {
    let parsedResponse: unknown;
    try { parsedResponse = JSON.parse(responseBody); } catch { parsedResponse = responseBody; }

    // Para mejorar lectura en consola, evidencia HTML y logs técnicos,
    // el body JSON se normaliza con indentación. El valor raw se mantiene parseado en parsedResponse.
    const formattedResponseBody = this.formatJsonBody(responseBody);

    const responseHeaders = response.headers();
    const busResponseMessage = this.headerValue(responseHeaders, 'busresponsemessage');
    const srvResponseCode = this.headerValue(responseHeaders, 'srvresponsecode');
    const srvResponseMessage = this.headerValue(responseHeaders, 'srvresponsemessage');

    this.printExecutionResponse(operation, response.status(), responseHeaders, formattedResponseBody);
    const timestamp = new Date().toISOString();
    const maskedRequestHeaders = this.maskSensitiveHeaders(requestHeaders);
    const technicalLogFile = appendTechnicalLog({
      timestamp,
      environment: this.environmentName(),
      operation,
      tokenType,
      method,
      url,
      status: response.status(),
      attempts,
      durationMs,
      retryHistory,
      requestHeaders: maskedRequestHeaders,
      requestBody,
      responseHeaders,
      responseBody: formattedResponseBody,
      generatedDocuments: this.extractDocumentsFromRequestBody(operation, requestBody)
    }, prop(this.props, 'ifx.technical-log-dir', 'reports/logs'));

    return {
      operation,
      tokenType,
      method,
      url,
      requestHeaders: maskedRequestHeaders,
      requestBody,
      responseStatus: response.status(),
      responseHeaders,
      responseBody: formattedResponseBody,
      parsedResponse,
      busResponseMessage,
      srvResponseCode,
      srvResponseMessage,
      attempts,
      durationMs,
      retryHistory,
      technicalLogFile,
      timestamp
    };
  }

  /**
   * Devuelve el response body en formato JSON legible cuando el contenido es JSON.
   * Si la respuesta no es JSON, devuelve el texto original para no alterar mensajes del API.
   */
  private formatJsonBody(body: string): string {
    if (!body) return '';
    try {
      return JSON.stringify(JSON.parse(body), null, 2);
    } catch {
      return body;
    }
  }

  private headerValue(headers: Record<string, string>, headerName: string): string {
    const foundKey = Object.keys(headers).find(key => key.toLowerCase() === headerName.toLowerCase());
    return foundKey ? String(headers[foundKey] || '') : '';
  }


  /**
   * Extrae DNI/RUC del request enviado para que los logs técnicos muestren claramente qué documento se usó.
   * Cubre UAT PN/PJ y STG PN/PJ.
   */
  private extractDocumentsFromRequestBody(operation: string, requestBody: unknown): GeneratedDocumentRecord[] {
    if (!requestBody || typeof requestBody !== 'object') return [];
    const body = requestBody as Record<string, unknown>;
    const documents: GeneratedDocumentRecord[] = [];

    const addDocument = (documentType: string, documentNumber: string, source: string): void => {
      if (!documentNumber) return;
      documents.push({
        timestamp: toLimaIsoTimestamp(new Date()),
        environment: this.environmentName(),
        documentType: normalizeDocumentType(documentType),
        documentNumber,
        operation,
        source,
        sequenceFile: '',
        csvFile: prop(this.props, 'ifx.generated-documents-csv', 'reports/generated/documentos-generados.csv'),
        duplicateStatus: 'PROVIDED_NOT_CHECKED',
        duplicatePolicy: 'technical-log'
      });
    };

    // UAT Crear PN/PJ: documentTypeId/documentNumber en raíz.
    const rootDocumentNumber = String(body.documentNumber || '');
    const rootDocumentTypeId = String(body.documentTypeId || '');
    if (rootDocumentNumber) addDocument(rootDocumentTypeId === '1' ? 'DNI' : 'RUC', rootDocumentNumber, 'request.body.documentNumber');

    // STG Crear PN/PJ: business.identityDocument.type/number.
    const business = body.business as Record<string, unknown> | undefined;
    const identityDocument = business?.identityDocument as Record<string, unknown> | undefined;
    const stgDocumentNumber = String(identityDocument?.number || '');
    const stgDocumentType = String(identityDocument?.type || 'RUC');
    if (stgDocumentNumber) addDocument(stgDocumentType, stgDocumentNumber, 'request.body.business.identityDocument.number');

    return documents;
  }

  private printExecutionResponse(operation: string, status: number, responseHeaders: Record<string, string>, responseBody: string): void {
    console.log('\n============================================================');
    console.log(`[IFX][${operation}] RESPONSE STATUS: ${status}`);
    console.log(`[IFX][${operation}] response.header.busresponsemessage: ${this.headerValue(responseHeaders, 'busresponsemessage')}`);
    console.log(`[IFX][${operation}] response.header.srvresponsecode: ${this.headerValue(responseHeaders, 'srvresponsecode')}`);
    console.log(`[IFX][${operation}] response.header.srvresponsemessage: ${this.headerValue(responseHeaders, 'srvresponsemessage')}`);
    console.log(`[IFX][${operation}] RESPONSE HEADERS:`);
    console.log(JSON.stringify(responseHeaders, null, 2));
    console.log(`[IFX][${operation}] RESPONSE BODY:`);
    console.log(responseBody || '<empty body>');
    console.log('============================================================\n');
  }

  /** Devuelve el ambiente actual para logs, CSV y reportes. */
  private environmentName(): string {
    return prop(this.props, '__environment', prop(this.props, 'environment', 'uat'));
  }

  /** CSV histórico único usado para evitar reciclar documentos generados. */
  private duplicateRegistryFiles(csvFile?: string): string[] {
    return Array.from(new Set([
      csvFile || '',
      prop(this.props, 'ifx.generated-documents-csv', 'reports/generated/documentos-generados.csv')
    ].filter(Boolean)));
  }

  /** Política para documentos enviados manualmente desde Excel/properties: warn, fail o ignore. */
  private duplicateProvidedPolicy(): string {
    return prop(this.props, 'ifx.duplicate.provided-policy', 'warn').toLowerCase();
  }

  /**
   * Valida documentos enviados por Excel/properties contra el histórico.
   * Por defecto solo advierte para no bloquear pruebas con data controlada por QA.
   */
  private validateProvidedDocumentNotDuplicated(documentType: string, documentNumber: string, operation: string, source: string): void {
    if (prop(this.props, 'ifx.duplicate.enabled', 'true').toLowerCase() === 'false') return;
    const policy = this.duplicateProvidedPolicy();
    if (policy === 'ignore') return;

    const duplicate = checkDuplicateDocument(documentType, documentNumber, this.duplicateRegistryFiles());
    if (!duplicate.duplicated) return;

    appendDuplicateEvent({
      timestamp: toLimaIsoTimestamp(new Date()),
      environment: this.environmentName(),
      operation,
      documentType: duplicate.documentType,
      documentNumber: duplicate.documentNumber,
      policy,
      result: policy === 'fail' ? 'BLOCKED' : 'WARNED',
      foundInFiles: duplicate.foundInFiles,
      source
    }, prop(this.props, 'ifx.duplicate-events-csv', 'reports/generated/duplicados-detectados.csv'));

    const message = `[IFX][${operation}] Documento ${duplicate.documentType} ${duplicate.documentNumber} ya existe en histórico: ${duplicate.foundInFiles.join(', ')}`;
    if (policy === 'fail') throw new Error(message);
    console.warn(`${message}. Se continúa porque ifx.duplicate.provided-policy=${policy}`);
  }

  /**
   * Persiste solo documentos creados exitosamente.
   * Para TDM, un intento con response code 209 no es data generada: es un documento descartado.
   * Por eso no se escribe en documentos-generados.csv hasta obtener código efectivo 200.
   */
  private persistGeneratedDocuments(generatedDocuments: GeneratedDocumentRecord[], evidence: ExecutionEvidence, attempts = 1, retriedBy209 = false): void {
    if (generatedDocuments.length === 0) return;
    for (const generated of generatedDocuments) {
      generated.responseStatus = evidence.responseStatus;
      generated.effectiveResponseCode = this.effectiveResponseCode(evidence);
      generated.attempts = attempts;
      generated.retriedBy209 = retriedBy209;
      generated.busResponseMessage = evidence.busResponseMessage;
      generated.srvResponseCode = evidence.srvResponseCode;
      generated.srvResponseMessage = evidence.srvResponseMessage;
      appendGeneratedDocument(generated);
      console.log(`[IFX][${generated.operation}] ${generated.documentType} creado y guardado en CSV consolidado: ${generated.documentNumber} -> reports/generated/documentos-generados.csv`);
    }
    evidence.generatedDocuments = generatedDocuments;
  }

  /** Registra documentos descartados por 209 sin mezclarlos con la data creada en documentos-generados.csv. */
  private registerDuplicate209Attempt(generatedDocuments: GeneratedDocumentRecord[], operation: string, evidence: ExecutionEvidence, attempt: number): void {
    for (const generated of generatedDocuments) {
      appendDuplicateEvent({
        timestamp: toLimaIsoTimestamp(new Date()),
        environment: this.environmentName(),
        operation,
        documentType: generated.documentType,
        documentNumber: generated.documentNumber,
        policy: 'retry-209',
        result: 'API_209_DOCUMENTO_EXISTE_RETRY',
        foundInFiles: [`httpStatus=${evidence.responseStatus}`, `effectiveCode=${this.effectiveResponseCode(evidence)}`],
        source: `${generated.source} | intento=${attempt}`
      }, prop(this.props, 'ifx.duplicate-events-csv', 'reports/generated/duplicados-detectados.csv'));
    }
  }

  /** Genera un documento y reintenta si por error la secuencia regresó a un valor ya usado. */
  private nextUniqueGeneratedDocument(
    documentType: 'DNI' | 'RUC',
    operation: string,
    source: string,
    csvFile: string,
    sequenceFile: string,
    generator: () => string
  ): GeneratedDocumentRecord {
    const maxAttempts = Number(prop(this.props, 'ifx.duplicate.max-generation-attempts', '50')) || 50;
    const registryFiles = this.duplicateRegistryFiles(csvFile);

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const documentNumber = generator();
      const duplicate = checkDuplicateDocument(documentType, documentNumber, registryFiles);
      if (!duplicate.duplicated) {
        return {
          timestamp: toLimaIsoTimestamp(new Date()),
          environment: this.environmentName(),
          documentType,
          documentNumber,
          operation,
          source,
          sequenceFile,
          csvFile,
          duplicateStatus: 'UNIQUE',
          duplicatePolicy: 'regenerate'
        };
      }

      appendDuplicateEvent({
        timestamp: toLimaIsoTimestamp(new Date()),
        environment: this.environmentName(),
        operation,
        documentType,
        documentNumber,
        policy: 'regenerate',
        result: 'REGENERATED',
        foundInFiles: duplicate.foundInFiles,
        source
      }, prop(this.props, 'ifx.duplicate-events-csv', 'reports/generated/duplicados-detectados.csv'));
      console.warn(`[IFX][${operation}] ${documentType} duplicado detectado (${documentNumber}). Se genera el siguiente valor. Intento ${attempt}/${maxAttempts}`);
    }

    throw new Error(`[IFX][${operation}] No se pudo generar ${documentType} único luego de ${maxAttempts} intentos. Revisar secuencia y CSV histórico.`);
  }

  /**
   * Protege ejecuciones masivas inválidas.
   * Como TDM puede crear grandes volúmenes, se permite parametrizar cantidad desde feature/Excel,
   * pero se limita por ifx.bulk.max-quantity para evitar ejecuciones accidentales demasiado grandes.
   */
  private validateQuantity(quantity: number): number {
    if (!Number.isInteger(quantity) || quantity <= 0) {
      throw new Error(`La cantidad de clientes a crear debe ser un entero mayor a 0. Valor recibido: ${quantity}`);
    }

    const maxQuantity = Number(prop(this.props, 'ifx.bulk.max-quantity', '500'));
    const safeMaxQuantity = Number.isFinite(maxQuantity) && maxQuantity > 0 ? Math.floor(maxQuantity) : 500;
    if (quantity > safeMaxQuantity) {
      throw new Error(`La cantidad ${quantity} supera el máximo permitido ifx.bulk.max-quantity=${safeMaxQuantity}. Ajusta el properties si necesitas una carga mayor.`);
    }

    return quantity;
  }

  /** Genera DNI incremental único y prepara el registro para CSV de trazabilidad. */
  private generateAndPersistDni(operation: string, source: string, generatedDocuments: GeneratedDocumentRecord[], baseOverride = ''): string {
    const sequenceFile = prop(this.props, 'ifx.dni-sequence-file', 'reports/sequences/dni-sequence.txt');
    const csvFile = prop(this.props, 'ifx.generated-documents-csv', 'reports/generated/documentos-generados.csv');
    const base = firstNonBlank(baseOverride, prop(this.props, 'ifx.dni-base', '54072013'));
    const record = this.nextUniqueGeneratedDocument('DNI', operation, source, csvFile, sequenceFile, () =>
      nextSequence(base, sequenceFile, 8)
    );
    generatedDocuments.push(record);
    console.log(`[IFX][${operation}] DNI generado para ${this.environmentName().toUpperCase()}: ${record.documentNumber} | source=${source}`);
    return record.documentNumber;
  }

  /** Genera RUC 20 válido, incremental y único; prepara el registro para CSV de trazabilidad. */
  private generateAndPersistRuc(operation: string, source: string, generatedDocuments: GeneratedDocumentRecord[], baseOverride = ''): string {
    return this.generateAndPersistRuc20WithConfig(
      operation,
      source,
      generatedDocuments,
      'ifx.ruc-base',
      'ifx.ruc-sequence-file',
      '20276135769',
      'reports/sequences/ruc-sequence.txt',
      baseOverride
    );
  }

  /**
   * Genera RUC 20 válido, incremental y único usando una base/secuencia configurable.
   * Se usa para separar las secuencias UAT y STG, evitando que ambas consuman el mismo archivo.
   */
  private generateAndPersistRuc20WithConfig(
    operation: string,
    source: string,
    generatedDocuments: GeneratedDocumentRecord[],
    baseProperty: string,
    sequenceProperty: string,
    defaultBase: string,
    defaultSequenceFile: string,
    baseOverride = ''
  ): string {
    const sequenceFile = prop(this.props, sequenceProperty, defaultSequenceFile);
    const csvFile = prop(this.props, 'ifx.generated-documents-csv', 'reports/generated/documentos-generados.csv');
    const base = firstNonBlank(baseOverride, prop(this.props, baseProperty, defaultBase));
    const record = this.nextUniqueGeneratedDocument('RUC', operation, source, csvFile, sequenceFile, () =>
      nextValidRuc20(base, sequenceFile)
    );
    generatedDocuments.push(record);
    console.log(`[IFX][${operation}] RUC generado para ${this.environmentName().toUpperCase()}: ${record.documentNumber} | source=${source}`);
    return record.documentNumber;
  }

  /** Genera RUC 10 válido, incremental y único para Persona Natural con negocio. */
  private generateAndPersistRuc10(operation: string, source: string, generatedDocuments: GeneratedDocumentRecord[]): string {
    return this.generateAndPersistRuc10WithConfig(
      operation,
      source,
      generatedDocuments,
      'ifx.ruc10-base',
      'ifx.ruc10-sequence-file',
      '10294411491',
      'reports/sequences/ruc10-sequence.txt'
    );
  }

  /**
   * Genera RUC 10 válido, incremental y único usando una base/secuencia configurable.
   * STG Crear PN usa RUC 10, por eso mantiene su propia secuencia desde 10294411491.
   */
  private generateAndPersistRuc10WithConfig(
    operation: string,
    source: string,
    generatedDocuments: GeneratedDocumentRecord[],
    baseProperty: string,
    sequenceProperty: string,
    defaultBase: string,
    defaultSequenceFile: string
  ): string {
    const sequenceFile = prop(this.props, sequenceProperty, defaultSequenceFile);
    const csvFile = prop(this.props, 'ifx.generated-documents-csv', 'reports/generated/documentos-generados.csv');
    const record = this.nextUniqueGeneratedDocument('RUC', operation, source, csvFile, sequenceFile, () =>
      nextValidRuc10(prop(this.props, baseProperty, defaultBase), sequenceFile)
    );
    generatedDocuments.push(record);
    console.log(`[IFX][${operation}] RUC generado para ${this.environmentName().toUpperCase()}: ${record.documentNumber} | source=${source}`);
    return record.documentNumber;
  }

  /** Enmascara tokens y secretos antes de persistir evidencias. */
  private maskSensitiveHeaders(headers: Record<string, string>): Record<string, string> {
    const masked = { ...headers };
    for (const key of Object.keys(masked)) {
      if (['authorization', 'ocp-apim-subscription-key', 'ocp-apim-subscription-secret'].includes(key.toLowerCase())) {
        masked[key] = masked[key] ? `${masked[key].slice(0, 12)}***` : '';
      }
    }
    return masked;
  }

  /** Headers para crear persona natural según contrato IFX. */
  private naturalPersonHeaders(): Record<string, string> {
    return {
      accept: 'application/json',
      branchid: prop(this.props, 'ifx.branch-id', '100'),
      channelid: firstNonBlank(prop(this.props, 'ifx.channel-id'), prop(this.props, 'ifx.chanel-id', '16')),
      consumerid: prop(this.props, 'ifx.consumer-id', 'BPE'),
      'content-type': 'application/json',
      deviceid: prop(this.props, 'ifx.device-id', '192.135.183.250'),
      funcionalidadid: prop(this.props, 'ifx.funcionalidad-id', 'Funcionalidad IFX'),
      iporigen: prop(this.props, 'ifx.ip-origen', '192.135.183.200'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.parent-id', '11a7f97345'),
      timestamp: prop(this.props, 'ifx.timestamp', '2016-05-24T11:57:48.000Z'),
      traceid: prop(this.props, 'ifx.trace-id', '34338b0e6d2271c2345'),
      userid: prop(this.props, 'ifx.user-id', 'S7301'),
      'x-global-transaction-id': prop(this.props, 'ifx.global-transaction-id', '20160623152105')
    };
  }

  /** Headers para consulta full information. */
  private consultationHeaders(): Record<string, string> {
    if (this.isStgApm()) {
      return {
        application: prop(this.props, 'ifx.consulta.application', 'ASSI'),
        company: prop(this.props, 'ifx.consulta.company', 'INTERBANK'),
        'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
        storecode: prop(this.props, 'ifx.consulta.storecode', '100'),
        user: prop(this.props, 'ifx.consulta.user', 'XT10023')
      };
    }

    return {
      accept: 'application/json',
      consumerid: prop(this.props, 'ifx.consulta.consumer-id', 'BCV'),
      'content-type': 'application/json',
      funcionalidadid: prop(this.props, 'ifx.consulta.funcionalidad-id', 'funcionalidad01'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.consulta.parent-id', '53ce929d0e0e4736'),
      traceid: prop(this.props, 'ifx.consulta.trace-id', '53ce929d0e0e4736'),
      usertype: prop(this.props, 'ifx.consulta.user-type', 'F')
    };
  }

  /** Headers para CCE Customer Special Status. */
  private specialStatusHeaders(): Record<string, string> {
    return {
      accept: 'application/json',
      consumerid: prop(this.props, 'ifx.special-status.consumer-id', '7824164593336320'),
      'content-type': 'application/json',
      funcionalidadid: prop(this.props, 'ifx.special-status.funcionalidad-id', '2516899420176384'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.special-status.parent-id', '3686228603961344'),
      traceid: prop(this.props, 'ifx.special-status.trace-id', '2359211902107648')
    };
  }

  /** Headers para crear cliente PJ. Se priorizan properties para evitar hardcode innecesario. */
  private merchantHeaders(row: ExcelRow): Record<string, string> {
    return {
      accept: 'application/json',
      application: prop(this.props, 'ifx.merchant.application', 'ASSI'),
      branchid: prop(this.props, 'ifx.merchant.branch-id', '898'),
      cardidtype: prop(this.props, 'ifx.merchant.card-id-type', '1'),
      channelid: prop(this.props, 'ifx.merchant.channel-id', '15'),
      consumerid: prop(this.props, 'ifx.merchant.consumer-id', '01'),
      'content-type': 'application/json',
      countrycode: prop(this.props, 'ifx.merchant.country-code', 'PE'),
      deviceid: prop(this.props, 'ifx.merchant.device-id', '130.30.20.80'),
      funcionalidadid: prop(this.props, 'ifx.merchant.funcionalidad-id', 'funcionalidad01'),
      groupmember: prop(this.props, 'ifx.merchant.group-member', 'G0001'),
      iporigen: prop(this.props, 'ifx.merchant.ip-origen', '130.30.20.80'),
      messageid: prop(this.props, 'ifx.merchant.message-id', '20160623152105'),
      moduloid: prop(this.props, 'ifx.merchant.modulo-id', 'modcontacto'),
      netid: prop(this.props, 'ifx.merchant.net-id', 'BI'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.merchant.parent-id', '53ce929d0e0e4736'),
      referencenumber: prop(this.props, 'ifx.merchant.reference-number', 'REF01092'),
      serverid: prop(this.props, 'ifx.merchant.server-id', 'server12'),
      serviceid: prop(this.props, 'ifx.merchant.service-id', 'BPI'),
      supervisorid: prop(this.props, 'ifx.merchant.supervisor-id', 'S2058'),
      timestamp: prop(this.props, 'ifx.merchant.timestamp', '2016-05-24T11:57:48.000Z'),
      traceid: prop(this.props, 'ifx.merchant.trace-id', '53ce929d0e0e4736'),
      userid: prop(this.props, 'ifx.merchant.user-id', 'S23052'),
      usertype: prop(this.props, 'ifx.merchant.user-type', 'F')
    };
  }

  /** Headers para crear cuenta; algunas columnas pueden venir desde Excel. */
  private accountHeaders(row: ExcelRow): Record<string, string> {
    return {
      accept: 'application/json',
      branchid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'BRANCHID')), valueOrDefault(prop(this.props, 'ifx.account.branch-id'), '100')),
      cardidtype: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CARDIDTYPE')), valueOrDefault(prop(this.props, 'ifx.account.card-id-type'), '1')),
      channelid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CHANNELID')), valueOrDefault(prop(this.props, 'ifx.account.channel-id'), '16')),
      consumerid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CONSUMERID')), valueOrDefault(prop(this.props, 'ifx.account.consumer-id'), 'BPE')),
      'content-type': 'application/json',
      countrycode: firstNonBlank(normalizeOptionalValue(rowValue(row, 'COUNTRYCODE')), valueOrDefault(prop(this.props, 'ifx.account.country-code'), 'PE')),
      deviceid: valueOrDefault(prop(this.props, 'ifx.account.device-id'), '192.135.183.250'),
      funcionalidadid: valueOrDefault(prop(this.props, 'ifx.account.funcionalidad-id'), 'Funcionalidad IFX'),
      iporigen: valueOrDefault(prop(this.props, 'ifx.account.ip-origen'), '192.135.183.200'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: valueOrDefault(prop(this.props, 'ifx.account.parent-id'), '11a7f97345'),
      traceid: valueOrDefault(prop(this.props, 'ifx.account.trace-id'), '34338b0e6d2271c2345'),
      userid: valueOrDefault(prop(this.props, 'ifx.account.user-id'), 'S7301')
    };
  }

  /** Detecta el contrato STG APM, que usa endpoints y headers distintos al IFX UAT clásico. */
  private isStgApm(): boolean {
    return prop(this.props, 'ifx.api-flavor', '').toLowerCase() === 'stg-apm'
      || prop(this.props, '__environment', '').toLowerCase() === 'stg';
  }

  /**
   * Genera un processtraceid único para STG usando fecha + literal + hora + sufijo.
   *
   * Formato por defecto:
   *   ddMMyy + cimapjc1local + HHmmss + sufijo
   * Ejemplo:
   *   050826cimapjc1local011530000001
   *
   * Motivo QA/TDM:
   * - STG rechaza creaciones PN/PJ cuando el processtraceid se repite.
   * - En cada intento/retry funcional 209 se genera otro processtraceid.
   * - El sufijo se mantiene incremental y persistido para evitar colisiones si se ejecuta más de una vez en el mismo segundo.
   */
  private processTraceId(operation: string): string {
    const isPj = operation === 'CrearClientePJIFX';
    const literalKey = isPj ? 'ifx.stg.pj.processtraceid-literal' : 'ifx.stg.pn.processtraceid-literal';
    const fileKey = isPj ? 'ifx.stg.pj.processtraceid-suffix-file' : 'ifx.stg.pn.processtraceid-suffix-file';
    const baseKey = isPj ? 'ifx.stg.pj.processtraceid-suffix-base' : 'ifx.stg.pn.processtraceid-suffix-base';
    const widthKey = isPj ? 'ifx.stg.pj.processtraceid-suffix-width' : 'ifx.stg.pn.processtraceid-suffix-width';

    const timezone = prop(this.props, 'ifx.stg.processtraceid-timezone', 'America/Lima');
    const datePattern = prop(this.props, 'ifx.stg.processtraceid-date-pattern', 'ddMMyy');
    const timePattern = prop(this.props, 'ifx.stg.processtraceid-time-pattern', 'HHmmss');
    const literal = prop(this.props, literalKey, prop(this.props, 'ifx.stg.processtraceid-literal', 'cimapjc1local'));

    const sequenceFile = prop(this.props, fileKey, isPj ? 'reports/sequences/stg-pj-processtraceid-suffix.txt' : 'reports/sequences/stg-pn-processtraceid-suffix.txt');
    const suffixBase = prop(this.props, baseKey, prop(this.props, 'ifx.stg.processtraceid-suffix-base', '1'));
    const suffixWidth = Number(prop(this.props, widthKey, prop(this.props, 'ifx.stg.processtraceid-suffix-width', '6')));
    const safeSuffixWidth = Number.isFinite(suffixWidth) && suffixWidth > 0 ? Math.floor(suffixWidth) : 6;

    const now = new Date();
    const datePart = this.formatDatePart(now, timezone, datePattern);
    const timePart = this.formatDatePart(now, timezone, timePattern);
    const suffix = nextSequence(suffixBase, sequenceFile, safeSuffixWidth);
    const traceId = `${datePart}${literal}${timePart}${suffix}`;

    console.log(`[IFX][${operation}] processtraceid único generado: ${traceId}`);
    return traceId;
  }

  /**
   * Formatea partes de fecha/hora en la zona horaria configurada para STG.
   * Soporta los patrones usados por el processtraceid: ddMMyy, yyyyMMdd, HHmmss y HHmmssSSS.
   */
  private formatDatePart(date: Date, timezone: string, pattern: string): string {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).formatToParts(date);

    const get = (type: string) => parts.find((part) => part.type === type)?.value || '';
    const year = get('year');
    const values: Record<string, string> = {
      yyyy: year,
      yy: year.slice(-2),
      MM: get('month'),
      dd: get('day'),
      HH: get('hour'),
      mm: get('minute'),
      ss: get('second'),
      SSS: String(date.getMilliseconds()).padStart(3, '0')
    };

    return pattern.replace(/yyyy|yy|MM|dd|HH|mm|ss|SSS/g, (token) => values[token] || token);
  }

  /** Headers STG para Crear PN/PJ internal-channel. */
  private stgInternalChannelHeaders(operation: 'CrearPersonaNaturalIFX' | 'CrearClientePJIFX'): Record<string, string> {
    return {
      channel: prop(this.props, 'ifx.stg.channel', 'DIGITAL'),
      'consumer-id': prop(this.props, 'ifx.stg.consumer-id', 'REEMPLAZAR_CONSUMER_ID'),
      'content-type': 'application/json',
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      processtraceid: this.processTraceId(operation)
    };
  }

  /** Body STG para Crear Persona Natural, basado en el curl internal-channel PN. */
  private buildStgNaturalPersonBody(row: ExcelRow, generatedDocuments: GeneratedDocumentRecord[], attempt = 1): unknown {
    const providedBusinessRucRaw = rowValue(row, 'RUC', 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO');
    const providedBusinessRuc = providedBusinessRucRaw.toUpperCase() === 'AUTO' ? '' : providedBusinessRucRaw;

    // STG PN siempre debe generar un RUC 10 incremental si no viene un RUC explícito desde Excel.
    // No se toma el valor fijo de properties como documento final, solo como base de la secuencia.
    const shouldUseProvidedRuc = attempt === 1 && !!providedBusinessRuc;
    const businessRuc = shouldUseProvidedRuc
      ? providedBusinessRuc
      : this.generateAndPersistRuc10WithConfig(
        'CrearPersonaNaturalIFX',
        `buildStgNaturalPersonBody intento ${attempt}`,
        generatedDocuments,
        'ifx.stg.pn.ruc10-base',
        'ifx.stg.pn.ruc10-sequence-file',
        '10294411491',
        'reports/sequences/stg-pn-ruc10-sequence.txt'
      );
    if (shouldUseProvidedRuc) {
      this.validateProvidedDocumentNotDuplicated('RUC', businessRuc, 'CrearPersonaNaturalIFX', 'buildStgNaturalPersonBody');
    }
    const representativeDni = firstNonBlank(rowValue(row, 'DNI_REPRESENTANTE', 'REPRESENTATIVE_DNI'), prop(this.props, 'ifx.stg.pn.representative-dni', '29441149'));
    const email = rowValue(row, 'EMAIL') || `${businessRuc}@YOPMAIL.COM`;

    return {
      business: {
        identityDocument: { type: 'RUC', number: businessRuc },
        businessName: rowValue(row, 'RAZON SOCIAL', 'BUSINESS_NAME') || prop(this.props, 'ifx.stg.pn.business-name', 'CARHUALLANQUI HUARCAYA JESUS'),
        sectorCode: rowValue(row, 'SECTOR_CODE') || prop(this.props, 'ifx.stg.pn.sector-code', '06'),
        subSectorCode: rowValue(row, 'SUB_SECTOR_CODE') || prop(this.props, 'ifx.stg.pn.sub-sector-code', '0603'),
        taxPeru: rowValue(row, 'TAX_PERU') || prop(this.props, 'ifx.stg.pn.tax-peru', 'NO'),
        fiscalResidence: {
          countryName: rowValue(row, 'FISCAL_COUNTRY') || prop(this.props, 'ifx.stg.pn.fiscal-country-name', 'COLOMBIA'),
          cityName: rowValue(row, 'FISCAL_CITY') || prop(this.props, 'ifx.stg.pn.fiscal-city-name', 'Cali'),
          legalAddress: rowValue(row, 'FISCAL_ADDRESS') || prop(this.props, 'ifx.stg.pn.fiscal-legal-address', 'Las Begonias'),
          tributaryNumber: rowValue(row, 'TRIBUTARY_NUMBER') || prop(this.props, 'ifx.stg.pn.fiscal-tributary-number', '14545454545454')
        },
        legalRepresentatives: [
          {
            customerID: rowValue(row, 'CUSTOMER_ID') || prop(this.props, 'ifx.stg.pn.customer-id', '0062022433'),
            identityDocument: { type: 'DNI', number: representativeDni },
            firstName: rowValue(row, 'FIRST_NAME', 'NOMBRE') || prop(this.props, 'ifx.stg.pn.representative-first-name', 'JESUS'),
            middleName: rowValue(row, 'MIDDLE_NAME') || prop(this.props, 'ifx.stg.pn.representative-middle-name', ''),
            lastName: rowValue(row, 'LAST_NAME', 'APELLIDO_PATERNO') || prop(this.props, 'ifx.stg.pn.representative-last-name', 'CARHUALLANQUI'),
            motherLastName: rowValue(row, 'MOTHER_LAST_NAME', 'APELLIDO_MATERNO') || prop(this.props, 'ifx.stg.pn.representative-mother-last-name', 'HUARCAYA'),
            birthDate: rowValue(row, 'BIRTH_DATE') || prop(this.props, 'ifx.stg.pn.representative-birth-date', '1986-04-10'),
            gender: rowValue(row, 'GENDER') || prop(this.props, 'ifx.stg.pn.representative-gender', 'MASCULINO'),
            maritalStatus: rowValue(row, 'MARITAL_STATUS') || prop(this.props, 'ifx.stg.pn.representative-marital-status', 'SOLTERO'),
            isPep: true,
            pepEntity: prop(this.props, 'ifx.stg.pn.pep-entity', 'PRUEBAS QA'),
            pepPosition: prop(this.props, 'ifx.stg.pn.pep-position', 'PRuebas qa'),
            pepStartDate: prop(this.props, 'ifx.stg.pn.pep-start-date', '15/12/2021'),
            pepEndDate: prop(this.props, 'ifx.stg.pn.pep-end-date', '15/12/2024'),
            email: { type: prop(this.props, 'ifx.stg.pn.email-type', 'PERSONAL'), value: email },
            phone: { type: prop(this.props, 'ifx.stg.pn.phone-type', 'CELULAR'), carrier: prop(this.props, 'ifx.stg.pn.phone-carrier', 'CLARO'), number: rowValue(row, 'PHONE') || prop(this.props, 'ifx.stg.pn.phone-number', '943123213') },
            address: {
              department: prop(this.props, 'ifx.stg.pn.address-department', 'LIMA'), district: prop(this.props, 'ifx.stg.pn.address-district', 'ATE'), province: prop(this.props, 'ifx.stg.pn.address-province', 'LIMA'), streetType: prop(this.props, 'ifx.stg.pn.address-street-type', 'AVENIDA'), streetName: prop(this.props, 'ifx.stg.pn.address-street-name', '123'), streetNumber: prop(this.props, 'ifx.stg.pn.address-street-number', '123'), block: prop(this.props, 'ifx.stg.pn.address-block', ''), lot: prop(this.props, 'ifx.stg.pn.address-lot', ''), apartment: prop(this.props, 'ifx.stg.pn.address-apartment', '')
            },
            configuration: {
              ldpd: { accept: true },
              customerPEP: { accept: true },
              bpie: { accept: false },
              authentications: ['OTP_SMS', 'BIOMETRIA']
            }
          }
        ]
      },
      account: { tariff: 'DIGITAL', currencyCode: ['PEN', 'USD'] },
      configuration: {
        store: { storeCode: prop(this.props, 'ifx.stg.store-code', '898') },
        agency: { code: prop(this.props, 'ifx.stg.pn.agency-code', '300'), name: prop(this.props, 'ifx.stg.pn.agency-name', 'Arequipa, Arequipa') },
        device: { type: 'PC', deviceID: prop(this.props, 'ifx.stg.pn.device-id', '10.244.50.17') }
      }
    };
  }

  /** Body STG para Crear Persona Jurídica, basado en el curl internal-channel PJ. */
  private buildStgLegalPersonBody(row: ExcelRow, generatedDocuments: GeneratedDocumentRecord[], attempt = 1): unknown {
    const providedBusinessRucRaw = rowValue(row, 'RUC', 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'NUMERO DOCUEMNTO', 'NUMERO_DOCUEMNTO', 'NUMERO DOCUEMENTO', 'NUMERO_DOCUEMENTO');
    const providedBusinessRuc = providedBusinessRucRaw.toUpperCase() === 'AUTO' ? '' : providedBusinessRucRaw;

    // STG PJ usa la misma lógica que UAT: RUC 20 incremental si no viene RUC explícito desde Excel.
    // La base 20101298851 se configura como ifx.stg.pj.ruc-base y no queda quemada como valor fijo.
    const shouldUseProvidedRuc = attempt === 1 && !!providedBusinessRuc;
    const businessRuc = shouldUseProvidedRuc
      ? providedBusinessRuc
      : this.generateAndPersistRuc20WithConfig(
        'CrearClientePJIFX',
        `buildStgLegalPersonBody intento ${attempt}`,
        generatedDocuments,
        'ifx.stg.pj.ruc-base',
        'ifx.stg.pj.ruc-sequence-file',
        '20101298851',
        'reports/sequences/stg-pj-ruc-sequence.txt'
      );
    if (shouldUseProvidedRuc) {
      this.validateProvidedDocumentNotDuplicated('RUC', businessRuc, 'CrearClientePJIFX', 'buildStgLegalPersonBody');
    }
    const representativeDni = firstNonBlank(rowValue(row, 'DNI_REPRESENTANTE', 'REPRESENTATIVE_DNI'), prop(this.props, 'ifx.stg.pj.representative-dni', '57286094'));

    return {
      business: {
        identityDocument: { type: 'RUC', number: businessRuc },
        businessName: rowValue(row, 'RAZON SOCIAL', 'BUSINESS_NAME') || prop(this.props, 'ifx.stg.pj.business-name', 'MANUFACTURAS SAN ISIDRO SAC'),
        economicActivityCode: rowValue(row, 'ECONOMICACTIVITYCODE', 'ECONOMIC_ACTIVITY_CODE') || prop(this.props, 'ifx.stg.pj.economic-activity-code', '2023'),
        remainsCompany: prop(this.props, 'ifx.stg.pj.remains-company', 'SI'),
        societyType: rowValue(row, 'SOCIETYTYPE', 'SOCIETY_TYPE') || prop(this.props, 'ifx.stg.pj.society-type', 'SA'),
        registrationNumber: rowValue(row, 'REGISTRATION_NUMBER') || prop(this.props, 'ifx.stg.pj.registration-number', '77777777'),
        constitutionDate: rowValue(row, 'CONSTITUTION_DATE') || prop(this.props, 'ifx.stg.pj.constitution-date', '2023-03-08'),
        majorCustomers: prop(this.props, 'ifx.stg.pj.major-customers', 'PERSONAS'),
        sectorCode: rowValue(row, 'SECTOR_CODE') || prop(this.props, 'ifx.stg.pj.sector-code', '01'),
        subSectorCode: rowValue(row, 'SUB_SECTOR_CODE') || prop(this.props, 'ifx.stg.pj.sub-sector-code', '0101'),
        affidavit: prop(this.props, 'ifx.stg.pj.affidavit', 'true').toLowerCase() === 'true',
        businessMagnitude: rowValue(row, 'BUSINESS_MAGNITUDE') || prop(this.props, 'ifx.stg.pj.business-magnitude', '6'),
        phone: { number: rowValue(row, 'BUSINESS_PHONE') || prop(this.props, 'ifx.stg.pj.business-phone-number', '994328764') },
        email: { type: prop(this.props, 'ifx.stg.pj.email-type', 'TRABAJO'), value: rowValue(row, 'EMAIL') || prop(this.props, 'ifx.stg.pj.email-value', 'dpoloavi@gmail.com') },
        address: {
          streetType: prop(this.props, 'ifx.stg.pj.address-street-type', 'ASENTAMIENTO_HUMANO'), streetName: prop(this.props, 'ifx.stg.pj.address-street-name', 'LAS LOMAS'), streetNumber: prop(this.props, 'ifx.stg.pj.address-street-number', '789'), department: prop(this.props, 'ifx.stg.pj.address-department', 'LIMA'), district: prop(this.props, 'ifx.stg.pj.address-district', 'LIMA'), province: prop(this.props, 'ifx.stg.pj.address-province', 'LIMA'), apartment: prop(this.props, 'ifx.stg.pj.address-apartment', ''), block: prop(this.props, 'ifx.stg.pj.address-block', ''), landmark: prop(this.props, 'ifx.stg.pj.address-landmark', ''), lot: prop(this.props, 'ifx.stg.pj.address-lot', ''), neighborhood: prop(this.props, 'ifx.stg.pj.address-neighborhood', '')
        },
        legalRepresentatives: [
          {
            identityDocument: { type: 'DNI', number: representativeDni },
            firstName: prop(this.props, 'ifx.stg.pj.representative-first-name', 'JULIAN'), middleName: prop(this.props, 'ifx.stg.pj.representative-middle-name', 'ALEJANRA'), lastName: prop(this.props, 'ifx.stg.pj.representative-last-name', 'ALAVRO'), motherLastName: prop(this.props, 'ifx.stg.pj.representative-mother-last-name', 'PEREDA'), birthDate: prop(this.props, 'ifx.stg.pj.representative-birth-date', '1970-08-08'), gender: prop(this.props, 'ifx.stg.pj.representative-gender', 'MASCULINO'), maritalStatus: prop(this.props, 'ifx.stg.pj.representative-marital-status', 'CASADO'),
            email: { type: prop(this.props, 'ifx.stg.pj.representative-email-type', 'PERSONAL'), value: rowValue(row, 'EMAIL') || prop(this.props, 'ifx.stg.pj.representative-email-value', 'dpoloavi@gmail.com') },
            phone: { type: prop(this.props, 'ifx.stg.pj.representative-phone-type', 'CELULAR'), number: prop(this.props, 'ifx.stg.pj.representative-phone-number', '976241681'), carrier: prop(this.props, 'ifx.stg.pj.representative-phone-carrier', 'CLARO') },
            address: {
              department: prop(this.props, 'ifx.stg.pj.representative-address-department', 'AMAZONAS'), district: prop(this.props, 'ifx.stg.pj.representative-address-district', 'CHACHAPOYAS'), province: prop(this.props, 'ifx.stg.pj.representative-address-province', 'CHACHAPOYAS'), apartment: prop(this.props, 'ifx.stg.pj.representative-address-apartment', 'A2'), block: prop(this.props, 'ifx.stg.pj.representative-address-block', ''), landmark: prop(this.props, 'ifx.stg.pj.representative-address-landmark', ''), lot: prop(this.props, 'ifx.stg.pj.representative-address-lot', ''), streetName: prop(this.props, 'ifx.stg.pj.representative-address-street-name', 'LOS ALAMOS'), streetType: prop(this.props, 'ifx.stg.pj.representative-address-street-type', 'CALLE'), neighborhood: prop(this.props, 'ifx.stg.pj.representative-address-neighborhood', ''), streetNumber: prop(this.props, 'ifx.stg.pj.representative-address-street-number', '895')
            },
            configuration: {
              ldpd: { accept: true },
              authentications: ['OTP_SMS', 'BIOMETRIA'],
              customerPEP: { isPep: true, pepEntity: 'Ministerio', pepPosition: 'Ministro', pepStartDate: '2020-01-01', pepEndDate: '2025-01-01' }
            }
          }
        ],
        partners: [
          { identityDocument: { type: 'DNI', number: '45980242' }, isPep: true, pepEntity: 'Ministerio de justicia', pepPosition: 'Ministro', pepStartDate: '2020-01-01', pepEndDate: '' },
          { identityDocument: { type: 'DNI', number: '88882083' }, isPep: true, pepEntity: 'Ministerio de agricultura', pepPosition: 'Ministro', pepStartDate: '2020-01-01', pepEndDate: '2022-01-01' }
        ]
      },
      account: { currencyCode: ['PEN', 'USD'], tariff: 'DIGITAL' },
      configuration: {
        store: { storeCode: prop(this.props, 'ifx.stg.store-code', '898') },
        agency: { code: prop(this.props, 'ifx.stg.pj.agency-code', '731'), name: prop(this.props, 'ifx.stg.pj.agency-name', 'Tumbes, Tumbes') },
        device: { type: 'PC', deviceID: prop(this.props, 'ifx.stg.pj.device-id', '52.167.75.123') }
      }
    };
  }

  /** Body base UAT para Persona Natural. Defaults alineados al curl UAT compartido por QA. */
  private buildNaturalPersonBody(docTypeId: string, docNumber: string, row: ExcelRow): unknown {
    return {
      documentTypeId: docTypeId,
      documentNumber: docNumber,
      passportNumber: rowValue(row, 'PASSPORT_NUMBER') || prop(this.props, 'ifx.pn.passport-number', ''),
      birthDate: rowValue(row, 'BIRTH_DATE') || prop(this.props, 'ifx.pn.birth-date', '1980-12-12'),
      firstLastName: rowValue(row, 'FIRST LAST NAME', 'APELLIDO PATERNO') || prop(this.props, 'ifx.pn.first-last-name', 'MONTENEGRO'),
      secondLastName: rowValue(row, 'SECOND LAST NAME', 'APELLIDO MATERNO') || prop(this.props, 'ifx.pn.second-last-name', 'RIVAS'),
      firstName: rowValue(row, 'FIRST NAME', 'NOMBRE') || prop(this.props, 'ifx.pn.first-name', 'ISABEL'),
      secondName: rowValue(row, 'SECOND NAME', 'SEGUNDO NOMBRE') || prop(this.props, 'ifx.pn.second-name', 'MARIA'),
      genderType: rowValue(row, 'GENDER_TYPE') || prop(this.props, 'ifx.pn.gender-type', 'M'),
      maritalStatus: rowValue(row, 'MARITAL_STATUS') || prop(this.props, 'ifx.pn.marital-status', 'S'),
      nationalityCode: prop(this.props, 'ifx.pn.nationality-code', '0'),
      birthCountryCode: prop(this.props, 'ifx.pn.birth-country-code', '4028'),
      residentCountryCode: prop(this.props, 'ifx.pn.resident-country-code', '4028'),
      nationalityCountryCode: prop(this.props, 'ifx.pn.nationality-country-code', '4028'),
      streetType: prop(this.props, 'ifx.pn.street-type', 'AV'),
      streetName: prop(this.props, 'ifx.pn.street-name', 'MARINA'),
      streetNumber: prop(this.props, 'ifx.pn.street-number', '17'),
      blockIdentification: prop(this.props, 'ifx.pn.block-identification', '8'),
      lotId: prop(this.props, 'ifx.pn.lot-id', 'G'),
      insideId: prop(this.props, 'ifx.pn.inside-id', '3'),
      urbanizationName: prop(this.props, 'ifx.pn.urbanization-name', ''),
      locationReference: prop(this.props, 'ifx.pn.location-reference', ''),
      department: prop(this.props, 'ifx.pn.department', 'CAJAMARCA'),
      province: prop(this.props, 'ifx.pn.province', 'CAJAMARCA'),
      district: prop(this.props, 'ifx.pn.district', 'CAJAMARCA'),
      phoneAddress: [
        {
          phoneType: prop(this.props, 'ifx.pn.phone-type', 'CELULAR'),
          phonePrefix: prop(this.props, 'ifx.pn.phone-prefix', '051'),
          phoneNumber: rowValue(row, 'PHONE') || prop(this.props, 'ifx.pn.phone-number', '958595853'),
          extension: prop(this.props, 'ifx.pn.phone-extension', '123')
        }
      ],
      emailType: prop(this.props, 'ifx.pn.email-type', 'P'),
      email: rowValue(row, 'EMAIL') || prop(this.props, 'ifx.pn.email', '70562659g@gmail.com'),
      ciiuCode: prop(this.props, 'ifx.pn.ciiu-code', ''),
      employmentDate: prop(this.props, 'ifx.pn.employment-date', ''),
      companyName: prop(this.props, 'ifx.pn.company-name', 'SYNOPSIS'),
      ocupationCode: prop(this.props, 'ifx.pn.ocupation-code', 'PRF')
    };
  }

  /** Body base para PJ con parámetros societyType, countryCode y economicActivityCode desde Excel/Gherkin. */
  private buildLegalPersonBody(docTypeId: string, docNumber: string, row: ExcelRow): unknown {
    return {
      documentTypeId: docTypeId,
      documentNumber: docNumber,
      accountsExecutiveId: prop(this.props, 'ifx.merchant.accounts-executive-id', '11126'),
      countryCode: rowValue(row, 'COUNTRYCODE', 'COUNTRY CODE') || prop(this.props, 'ifx.merchant.body-country-code', '4028'),
      company: {
        companyName: rowValue(row, 'COMPANY NAME', 'RAZON SOCIAL') || prop(this.props, 'ifx.merchant.company-name', 'ARICA'),
        constitutionDate: prop(this.props, 'ifx.merchant.constitution-date', '20101204'),
        economicActivityCode: rowValue(row, 'ECONOMICACTIVITYCODE', 'ECONOMIC ACTIVITY CODE') || prop(this.props, 'ifx.merchant.economic-activity-code', '2023'),
        economicGroupCode: prop(this.props, 'ifx.merchant.economic-group-code', '0001'),
        mainActivity: prop(this.props, 'ifx.merchant.main-activity', 'Prestampos'),
        tradeName: prop(this.props, 'ifx.merchant.trade-name', 'Caja Arequipa'),
        companyNameAcronym: prop(this.props, 'ifx.merchant.company-name-acronym', 'Arequipa'),
        societyType: rowValue(row, 'SOCIETYTYPE', 'SOCIETY TYPE') || prop(this.props, 'ifx.merchant.society-type', 'EIRL'),
        profitFlag: prop(this.props, 'ifx.merchant.profit-flag', 'Y'),
        businessMagnitude: prop(this.props, 'ifx.merchant.business-magnitude', '1')
      },
      standardizedAddress: {
        streetType: prop(this.props, 'ifx.merchant.address.street-type', 'JR'),
        streetName: prop(this.props, 'ifx.merchant.address.street-name', 'Catalino Miranda'),
        streetNumber: prop(this.props, 'ifx.merchant.address.street-number', '154'),
        blockIdentification: prop(this.props, 'ifx.merchant.address.block-identification', '1'),
        lotNumber: prop(this.props, 'ifx.merchant.address.lot-number', '154'),
        insideNumber: prop(this.props, 'ifx.merchant.address.inside-number', '1'),
        urbanization: prop(this.props, 'ifx.merchant.address.urbanization', 'Barranco'),
        landmark: prop(this.props, 'ifx.merchant.address.landmark', 'Altura Javier Prado'),
        department: prop(this.props, 'ifx.merchant.address.department', 'Lima'),
        province: prop(this.props, 'ifx.merchant.address.province', 'Lima'),
        district: prop(this.props, 'ifx.merchant.address.district', 'Barranco')
      },
      contact: {
        phoneAddress: { useCode: prop(this.props, 'ifx.merchant.phone.use-code', 'C'), prefix: prop(this.props, 'ifx.merchant.phone.prefix', '051'), phoneNumber: prop(this.props, 'ifx.merchant.phone.number', '909298641'), extension: prop(this.props, 'ifx.merchant.phone.extension', '12345') },
        electronicAddress: { useCode: prop(this.props, 'ifx.merchant.email.use-code', 'T'), emailAddress: rowValue(row, 'EMAIL') || prop(this.props, 'ifx.merchant.email.address', 'JDEVELOPER@NET.COM.PE') }
      }
    };
  }

  /** Body base para crear cuenta PN/PJ. */
  private buildCreateAccountBody(docTypeId: string, docNumber: string, customerId: string, row: ExcelRow): unknown {
    return {
      accountOpeningType: rowValue(row, 'ACCOUNT OPENING TYPE') || '01',
      appCode: rowValue(row, 'APP CODE') || 'ST', bankId: '03', productCode: rowValue(row, 'PRODUCT CODE') || '002', subProductCode: rowValue(row, 'SUB PRODUCT CODE') || '223',
      currencyCode: rowValue(row, 'CURRENCY CODE') || '002', termType: 'M', termTime: 2, blockedAccountFlag: 'S', investmentFoundType: 20, netCode: 'BI', annualRate: 2.01,
      functionaryId: '', sellerId: '', agency: '200', conector: 'IND', debitCard: { locateCard: 'S', validateFlag: 'N' }, accountNumber: '',
      customer: [{ order: 2, customerId, newCardFlag: 'S', cardId: '411074******3333' }],
      person: { documentTypeId: docTypeId, documentNumber: docNumber, personType: '', emailAddress: rowValue(row, 'EMAIL') || 'davde@hotmail.com' }
    };
  }
}
