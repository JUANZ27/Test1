import fs from 'fs';
import path from 'path';

/** Escapa texto para mostrar request/response de forma segura en HTML. */
function escapeHtml(value: unknown): string {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Convierte rutas del proyecto a rutas relativas para enlazar desde reports/html. */
function rel(p: string): string {
  return path.relative('reports/html', p).replace(/\\/g, '/');
}

function statusBucket(status: number): '2xx' | '3xx' | '4xx' | '5xx' | 'other' {
  if (status >= 200 && status < 300) return '2xx';
  if (status >= 300 && status < 400) return '3xx';
  if (status >= 400 && status < 500) return '4xx';
  if (status >= 500) return '5xx';
  return 'other';
}

function metricCard(label: string, value: unknown, hint = ''): string {
  return `<div class="metric"><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span>${hint ? `<small>${escapeHtml(hint)}</small>` : ''}</div>`;
}

const indexPath = 'reports/evidence/evidence-index.json';
fs.mkdirSync('reports/html', { recursive: true });

const items = fs.existsSync(indexPath) ? JSON.parse(fs.readFileSync(indexPath, 'utf-8')) : [];
const evidences = items.flatMap((item: any) => (item.evidences || []).map((e: any) => ({ ...e, scenario: item.scenario, scenarioStatus: item.status, tags: item.tags || [] })));
const generatedDocs = evidences.flatMap((e: any) => e.generatedDocuments || []);
const retryCount = evidences.reduce((sum: number, e: any) => sum + Math.max(0, (e.attempts || 1) - 1), 0);
const totalDuration = evidences.reduce((sum: number, e: any) => sum + (e.durationMs || 0), 0);
const buckets = evidences.reduce((acc: Record<string, number>, e: any) => {
  const bucket = statusBucket(Number(e.status || 0));
  acc[bucket] = (acc[bucket] || 0) + 1;
  return acc;
}, {});
const tokenSummary = evidences.reduce((acc: Record<string, number>, e: any) => {
  acc[e.tokenType || 'N/A'] = (acc[e.tokenType || 'N/A'] || 0) + 1;
  return acc;
}, {});

const rows = items.map((item: any) => `
  <tr>
    <td><span class="pill ${item.status === 'PASSED' ? 'ok' : 'fail'}">${escapeHtml(item.status)}</span></td>
    <td>${escapeHtml(item.scenario)}<br><small>${escapeHtml((item.tags || []).join(' '))}</small></td>
    <td>${(item.evidences || []).map((e: any) => `
      <div class="op">
        <strong>${escapeHtml(e.operation)}</strong> ${escapeHtml(e.method)} status ${escapeHtml(e.status)}<br>
        <small>${escapeHtml(e.url)}</small><br>
        <small><b>Token:</b> ${escapeHtml(e.tokenType)} | <b>Intentos:</b> ${escapeHtml(e.attempts || 1)} | <b>Duración:</b> ${escapeHtml(e.durationMs || 0)} ms</small><br>
        <small><b>busresponsemessage:</b> ${escapeHtml(e.busResponseMessage || '')}</small><br>
        <small><b>srvresponsecode:</b> ${escapeHtml(e.srvResponseCode || '')}</small><br>
        <small><b>srvresponsemessage:</b> ${escapeHtml(e.srvResponseMessage || '')}</small>
        ${e.generatedDocuments?.length ? `<br><small><b>Generados:</b> ${escapeHtml(e.generatedDocuments.map((d: any) => `${d.documentType} ${d.documentNumber}`).join(', '))}</small>` : ''}
        ${e.technicalLogFile ? `<br><small><b>Log técnico:</b> ${escapeHtml(e.technicalLogFile)}</small>` : ''}
      </div>`).join('')}</td>
    <td><a href="${rel(item.htmlFile)}">Ver request/response/headers</a></td>
  </tr>`).join('\n');

const generatedRows = generatedDocs.map((doc: any) => `
  <tr>
    <td>${escapeHtml(doc.timestamp)}</td>
    <td>${escapeHtml(doc.environment)}</td>
    <td>${escapeHtml(doc.documentType)}</td>
    <td><strong>${escapeHtml(doc.documentNumber)}</strong></td>
    <td>${escapeHtml(doc.operation)}</td>
    <td>${escapeHtml(doc.responseStatus || '')}</td>
    <td>${escapeHtml(doc.srvResponseCode || '')}</td>
  </tr>`).join('\n');

const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Reporte IFX Playwright BDD</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f8fafc; padding: 24px; color: #0f172a; }
    h1 { margin-bottom: 4px; }
    h2 { margin-top: 28px; }
    table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 1px 8px #0001; margin-top: 12px; }
    th { background: #123c69; color: white; text-align: left; padding: 10px; }
    td { border-bottom: 1px solid #e2e8f0; padding: 10px; vertical-align: top; }
    a { color: #005bbb; font-weight: 600; }
    small { color: #475569; }
    .op { margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px dashed #cbd5e1; }
    .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; margin: 18px 0; }
    .metric { background: white; border-radius: 12px; padding: 16px; box-shadow: 0 1px 8px #0001; border-left: 5px solid #123c69; }
    .metric strong { display: block; font-size: 28px; color: #123c69; }
    .metric span { display: block; margin-top: 4px; font-weight: 600; }
    .metric small { display: block; margin-top: 4px; }
    .pill { display: inline-block; border-radius: 999px; padding: 5px 9px; font-weight: 700; }
    .pill.ok { background: #dcfce7; color: #166534; }
    .pill.fail { background: #fee2e2; color: #991b1b; }
    .note { background: #eef6ff; border-left: 5px solid #2563eb; padding: 12px 16px; border-radius: 10px; }
  </style>
</head>
<body>
  <h1>Reporte IFX Playwright + Cucumber BDD</h1>
  <p class="note">Resumen ejecutivo para seguimiento QA: escenarios, operaciones, estados HTTP, retries técnicos, tokens usados y documentos generados.</p>

  <section class="metrics">
    ${metricCard('Escenarios', items.length)}
    ${metricCard('Escenarios OK', items.filter((i: any) => i.status === 'PASSED').length)}
    ${metricCard('Escenarios fallidos', items.filter((i: any) => i.status !== 'PASSED').length)}
    ${metricCard('Operaciones API', evidences.length)}
    ${metricCard('Status 2xx', buckets['2xx'] || 0)}
    ${metricCard('Status 4xx', buckets['4xx'] || 0)}
    ${metricCard('Status 5xx', buckets['5xx'] || 0)}
    ${metricCard('Retries técnicos', retryCount)}
    ${metricCard('Documentos generados', generatedDocs.length, 'DNI/RUC')}
    ${metricCard('Logs técnicos', evidences.filter((e: any) => e.technicalLogFile).length, 'JSONL/CSV')}
    ${metricCard('Duración API acumulada', `${totalDuration} ms`)}
  </section>

  <h2>Uso de tokens</h2>
  <table>
    <thead><tr><th>Token</th><th>Operaciones</th></tr></thead>
    <tbody>${Object.entries(tokenSummary).map(([token, count]) => `<tr><td>${escapeHtml(token)}</td><td>${escapeHtml(count)}</td></tr>`).join('') || '<tr><td colspan="2">Sin data</td></tr>'}</tbody>
  </table>

  <h2>Ejecuciones por escenario</h2>
  <p>Incluye request, request headers, request body, response headers, response body, busresponsemessage, srvresponsecode y srvresponsemessage.</p>
  <table>
    <thead>
      <tr><th>Estado</th><th>Escenario / Tags</th><th>Operaciones</th><th>Detalle</th></tr>
    </thead>
    <tbody>${rows || '<tr><td colspan="4">No hay evidencias. Ejecuta npm test primero.</td></tr>'}</tbody>
  </table>

  <h2>Trazabilidad de documentos generados</h2>
  <p>La trazabilidad funcional se centraliza en un único archivo: <code>reports/generated/documentos-generados.csv</code>. Si hay duplicados/reintentos 209, se registran en <code>reports/generated/duplicados-detectados.csv</code>.</p>
  <table>
    <thead><tr><th>Fecha</th><th>Ambiente</th><th>Tipo</th><th>Documento</th><th>Operación</th><th>Status</th><th>srvResponseCode</th></tr></thead>
    <tbody>${generatedRows || '<tr><td colspan="7">No se generaron documentos.</td></tr>'}</tbody>
  </table>
</body>
</html>`;

fs.writeFileSync('reports/html/index.html', html, 'utf-8');
fs.writeFileSync('reports/html/evidencias.html', html, 'utf-8');

const pnCreated = generatedDocs.filter((doc: any) => String(doc.operation || '').includes('CrearPersonaNatural')).length;
const pjCreated = generatedDocs.filter((doc: any) => String(doc.operation || '').includes('CrearClientePJ')).length;
const failedScenarios = items.filter((i: any) => i.status !== 'PASSED').length;

console.log('\n============================================================');
console.log('Resumen ejecutivo IFX');
console.log('============================================================');
console.log(`Escenarios totales      : ${items.length}`);
console.log(`Escenarios exitosos     : ${items.filter((i: any) => i.status === 'PASSED').length}`);
console.log(`Escenarios fallidos     : ${failedScenarios}`);
console.log(`Operaciones API         : ${evidences.length}`);
console.log(`Status 2xx              : ${buckets['2xx'] || 0}`);
console.log(`Status 4xx              : ${buckets['4xx'] || 0}`);
console.log(`Status 5xx              : ${buckets['5xx'] || 0}`);
console.log(`Retries ejecutados      : ${retryCount}`);
console.log(`PN generadas            : ${pnCreated}`);
console.log(`PJ generadas            : ${pjCreated}`);
console.log(`Documentos generados    : ${generatedDocs.length}`);
console.log('CSV documentos          : reports/generated/documentos-generados.csv');
console.log('Reporte HTML            : reports/html/index.html');
console.log('Evidencias HTML         : reports/html/evidencias.html');
console.log('============================================================\n');
