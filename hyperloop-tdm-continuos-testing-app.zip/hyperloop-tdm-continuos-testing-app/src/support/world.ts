import { IWorldOptions, setWorldConstructor, World } from '@cucumber/cucumber';
import { Properties } from '../utils/properties';
import { ExecutionEvidence } from '../services/ifx-client';

/**
 * CustomWorld mantiene el estado compartido por escenario Cucumber.
 * Aquí se guardan el ambiente, properties y evidencias generadas por cada step.
 */
export class CustomWorld extends World {
  environment = 'uat';
  props?: Properties;
  evidences: ExecutionEvidence[] = [];

  constructor(options: IWorldOptions) {
    super(options);
  }

  /** Agrega una evidencia API al escenario actual para reportarla en JSON/HTML. */
  addEvidence(evidence: ExecutionEvidence): void {
    this.evidences.push(evidence);
  }
}

setWorldConstructor(CustomWorld);
