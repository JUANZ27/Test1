import { After, Before, Status } from '@cucumber/cucumber';
import fs from 'fs';
import path from 'path';
import { CustomWorld } from './world';
import { loadProperties } from '../utils/properties';

/**
 * Normaliza el nombre del escenario para usarlo como nombre de archivo.
 * Evita caracteres especiales que pueden fallar en Windows o Linux.
 */
function safeName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 120);
}

/** Escapa contenido dinámico antes de insertarlo en HTML. */
function escapeHtml(value: string): string {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Construye el HTML individual por escenario.
 * Este detalle es la evidencia principal para QA: request, response, headers, status y datos generados.
 */
function evidenceHtml(scenarioName: string, status: string, evidences: any[]): string {
  const cards = evidences.map((evidence, index) => `
    <section class="card">
      <h2>${index + 1}. ${escapeHtml(evidence.operation)} <span>${escapeHtml(evidence.method)}</span></h2>
      <p><strong>Token:</strong> ${escapeHtml(evidence.tokenType)} | <strong>Status:</strong> ${evidence.responseStatus} | <strong>Intentos:</strong> ${evidence.attempts || 1} | <strong>Duración:</strong> ${evidence.durationMs || 0} ms</p>
      <p><strong>URL:</strong> ${escapeHtml(evidence.url)}</p>
      ${evidence.technicalLogFile ? `<p><strong>Log técnico:</strong> ${escapeHtml(evidence.technicalLogFile)}</p>` : ''}
      <div class="headers-resumen">
        <p><strong>response.header.busresponsemessage:</strong> ${escapeHtml(evidence.busResponseMessage || '')}</p>
        <p><strong>response.header.srvresponsecode:</strong> ${escapeHtml(evidence.srvResponseCode || '')}</p>
        <p><strong>response.header.srvresponsemessage:</strong> ${escapeHtml(evidence.srvResponseMessage || '')}</p>
      </div>
      ${evidence.retryHistory?.length ? `<h3>Retry history</h3><pre>${escapeHtml(JSON.stringify(evidence.retryHistory, null, 2))}</pre>` : ''}
      ${evidence.generatedDocuments?.length ? `<h3>Documentos generados</h3><pre>${escapeHtml(JSON.stringify(evidence.generatedDocuments, null, 2))}</pre>` : ''}
      <h3>Request headers</h3><pre>${escapeHtml(JSON.stringify(evidence.requestHeaders, null, 2))}</pre>
      <h3>Request body</h3><pre>${escapeHtml(JSON.stringify(evidence.requestBody ?? {}, null, 2))}</pre>
      <h3>Response headers</h3><pre>${escapeHtml(JSON.stringify(evidence.responseHeaders, null, 2))}</pre>
      <h3>Response body</h3><pre>${escapeHtml(evidence.responseBody || '')}</pre>
    </section>`).join('\n');

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>${escapeHtml(scenarioName)}</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; color: #1f2937; padding: 24px; }
    h1 { color: #0f172a; }
    .card { background: white; border-radius: 12px; padding: 18px; margin: 18px 0; box-shadow: 0 2px 10px #0001; }
    h2 { color: #123c69; margin-top: 0; }
    h2 span { font-size: 12px; background: #e0f2fe; padding: 4px 8px; border-radius: 999px; }
    pre { white-space: pre-wrap; overflow-wrap: anywhere; background: #0b1220; color: #d7e3f4; padding: 14px; border-radius: 8px; font-size: 12px; }
    .headers-resumen { background: #ecfeff; border-left: 4px solid #0891b2; padding: 8px 12px; border-radius: 8px; margin: 10px 0; }
    .headers-resumen p { margin: 4px 0; }
    .status { display: inline-block; padding: 6px 10px; border-radius: 999px; background: ${status === 'PASSED' ? '#dcfce7' : '#fee2e2'}; }
  </style>
</head>
<body>
  <h1>${escapeHtml(scenarioName)}</h1>
  <p class="status">${escapeHtml(status)}</p>
  ${cards || '<p>No se registraron evidencias.</p>'}
</body>
</html>`;
}

/**
 * Before: carga el ambiente antes de cada escenario.
 * Ejemplo: ENVIRONMENT=uat npx cucumber-js --tags @CrearPersonaNaturalIFX
 */
Before(function (this: CustomWorld) {
  this.environment = process.env.ENVIRONMENT || process.env.env || 'uat';
  this.props = loadProperties(this.environment);
});

/**
 * After: persiste evidencias livianas por escenario.
 * Para un proyecto API/TDM no se generan screenshots ni videos.
 * La evidencia útil queda en JSON/HTML con request, response, headers, status y datos generados.
 */
After(async function (this: CustomWorld, scenario) {
  fs.mkdirSync('reports/evidence', { recursive: true });
  fs.mkdirSync('reports/html/scenarios', { recursive: true });

  const name = safeName(scenario.pickle.name);
  const status = scenario.result?.status === Status.PASSED ? 'PASSED' : 'FAILED';
  const evidenceFile = path.resolve('reports/evidence', `${name}.json`);
  const htmlFile = path.resolve('reports/html/scenarios', `${name}.html`);

  fs.writeFileSync(evidenceFile, JSON.stringify({ scenario: scenario.pickle.name, status, evidences: this.evidences }, null, 2), 'utf-8');
  fs.writeFileSync(htmlFile, evidenceHtml(scenario.pickle.name, status, this.evidences), 'utf-8');

  this.attach(JSON.stringify(this.evidences, null, 2), 'application/json');


  const indexFile = 'reports/evidence/evidence-index.json';
  const index = fs.existsSync(indexFile) ? JSON.parse(fs.readFileSync(indexFile, 'utf-8')) : [];
  index.push({
    scenario: scenario.pickle.name,
    tags: scenario.pickle.tags.map(tag => tag.name),
    status,
    durationMs: this.evidences.reduce((sum, e) => sum + (e.durationMs || 0), 0),
    evidenceFile: path.relative(process.cwd(), evidenceFile),
    htmlFile: path.relative(process.cwd(), htmlFile),
    evidences: this.evidences.map(e => ({
      operation: e.operation,
      method: e.method,
      url: e.url,
      status: e.responseStatus,
      tokenType: e.tokenType,
      attempts: e.attempts || 1,
      durationMs: e.durationMs || 0,
      retryHistory: e.retryHistory || [],
      busResponseMessage: e.busResponseMessage,
      srvResponseCode: e.srvResponseCode,
      srvResponseMessage: e.srvResponseMessage,
      generatedDocuments: e.generatedDocuments || [],
      technicalLogFile: e.technicalLogFile || ''
    }))
  });
  fs.writeFileSync(indexFile, JSON.stringify(index, null, 2), 'utf-8');
});
