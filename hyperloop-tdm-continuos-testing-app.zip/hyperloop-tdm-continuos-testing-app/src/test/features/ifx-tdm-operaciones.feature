# language: es
# Proyecto Playwright + TypeScript + Cucumber para APIs IFX/TDM.
#
# Refactor - alcance UAT:
#   - CrearPersonaNaturalIFX
#   - CrearClientePJIFX
#   - ConsultaClienteIFX
#   - GenerateDataFromExcel
#
# Seguridad:
#   - El feature NO contiene tokens, password, client_secret ni subscription keys.
#   - Los valores sensibles se leen desde C:\Users\TU_USUARIO\application-uat.properties.
#
# Para TDM masivo:
#   - La cantidad y el documento base pueden parametrizarse en Examples.
#   - Si el API responde 209 DOCUMENTO EXISTE, el framework incrementa el documento y reintenta hasta 200.
#   - Solo el documento exitoso se guarda en reports/generated/documentos-generados.csv.
#
# Ejecución:
#   npm install
#   npm run clean:reports
#   npm run test:uat
#   npm run report
#
# Ejecución por tag:
#   npx cucumber-js --tags "@CrearPersonaNaturalIFX and @UAT"
#   npx cucumber-js --tags "@CrearClientePJIFX and @UAT"
#   npx cucumber-js --tags "@ConsultaClienteIFX and @UAT"
#   npx cucumber-js --tags "@GenerateDataFromExcel and @UAT"

Característica: Operaciones IFX TDM críticas para ambiente UAT
  Como QA Automation Senior
  Quiero crear y consultar data IFX desde UAT usando parámetros controlados
  Para generar datos TDM de forma masiva, trazable y sin exponer credenciales

  @IFX @UAT @Transaccion @Smoke @Regression @CrearPersonaNaturalIFX @pn
  Esquema del escenario: Crear <cantidad> personas naturales IFX en UAT desde documento base <documentoBase>
    # Cambia cantidad para cargas masivas. Ejemplo: 100.
    # documentoBase inicializa la secuencia de esta ejecución. Si ya existe, reintenta con el siguiente.
    Dado que selecciono el ambiente "uat"
    Cuando ejecuto Crear <cantidad> Personas Naturales IFX con tipo documento "<tipoDocumento>" desde documento base "<documentoBase>"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

    Ejemplos: UAT
      | cantidad | tipoDocumento | documentoBase |
      | 5        | DNI           | 10003500      |

  @IFX @UAT @Transaccion @Smoke @Regression @CrearClientePJIFX @pj
  Esquema del escenario: Crear <cantidad> clientes PJ IFX en UAT desde RUC base <rucBase>
    # societyType, countryCode y economicActivityCode se pueden cambiar desde Examples.
    # rucBase inicializa la secuencia incremental para PJ.
    Dado que selecciono el ambiente "uat"
    Cuando ejecuto Crear <cantidad> Clientes PJ IFX con RUC base "<rucBase>" societyType "<societyType>" countryCode "<countryCode>" economicActivityCode "<economicActivityCode>"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

    Ejemplos: UAT
      | cantidad | rucBase     | societyType | countryCode | economicActivityCode |
      | 10       | 20276135971 | EIRL        | 4028        | 2023                 |

  @IFX @UAT @Consulta @Smoke @Regression @ConsultaClienteIFX @full
  Esquema del escenario: Consultar cliente full IFX en UAT
    # Para consultas puntuales cambia tipoDocumento y numeroDocumento desde Examples.
    Dado que selecciono el ambiente "uat"
    Cuando ejecuto Consulta Cliente IFX con tipo documento "<tipoDocumento>" y numero documento "<numeroDocumento>"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

    Ejemplos: UAT
      | tipoDocumento | numeroDocumento |
      | RUC           | 20276136004        |

  @IFX @UAT @DataDriven @Smoke @Regression @GenerateDataFromExcel @excel
  Esquema del escenario: Generar data desde Excel para UAT
    # El Excel debe estar en src/main/resources/<directorio>/<archivo>.
    # Columnas recomendadas:
    #   OPERACION: CREAR_PN, CREAR_PJ o CONSULTA_FULL
    #   AMBIENTE: uat
    #   TIPO_DOCUMENTO, NUMERO_DOCUMENTO, DOCUMENTO_BASE, CANTIDAD
    #   Para PJ: SOCIETYTYPE, COUNTRYCODE, ECONOMICACTIVITYCODE
    Dado que selecciono el ambiente "uat"
    Cuando ejecuto GenerateDataFromExcel desde directorio "<directorio>" archivo "<archivo>" ambiente "uat"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

    Ejemplos: UAT
      | directorio | archivo              |
      | Data       | CargaClientePNPJ.xlsx |
