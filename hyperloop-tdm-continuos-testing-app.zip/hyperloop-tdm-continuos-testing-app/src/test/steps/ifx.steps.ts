import { Given, When, Then } from '@cucumber/cucumber';
import assert from 'assert';
import { CustomWorld } from '../../support/world';
import { loadProperties, prop } from '../../utils/properties';
import { IfxClient } from '../../services/ifx-client';

/** Instancia el cliente IFX reutilizando las properties del ambiente actual. */
function client(world: CustomWorld): IfxClient {
  if (!world.props) world.props = loadProperties(world.environment);
  return new IfxClient(world.props);
}


/** Usa el ambiente definido por ENVIRONMENT, environment o env. Por defecto queda en uat. */
Given('que uso el ambiente configurado', function (this: CustomWorld) {
  this.environment = process.env.ENVIRONMENT || process.env.environment || process.env.env || 'uat';
  this.props = loadProperties(this.environment);
});

/** Define el ambiente del escenario. Por defecto se usa uat si no se indica otro. */
Given('que uso el ambiente {string}', function (this: CustomWorld, environment: string) {
  this.environment = environment;
  this.props = loadProperties(environment);
});

/** Selecciona el ambiente desde el Scenario Outline del feature y carga properties locales seguras. */
Given('que selecciono el ambiente {string}', function (this: CustomWorld, environment: string) {
  this.environment = environment;
  this.props = loadProperties(environment);
  console.log(`[IFX][CONFIG] Ambiente seleccionado desde feature: ${environment}`);
  console.log(`[IFX][CONFIG] Archivo de configuración: ${this.props.__configFile}`);
});


/**
 * Crea personas naturales tomando cantidad y tipo de documento desde properties.
 * Útil para no exponer data editable o sensible en el feature.
 */
When('ejecuto Crear Personas Naturales IFX con la configuración del ambiente', async function (this: CustomWorld) {
  if (!this.props) this.props = loadProperties(this.environment);
  const quantity = Number(prop(this.props, 'ifx.crear-pn.quantity', '2'));
  const typeDocument = prop(this.props, 'ifx.crear-pn.type-document', 'DNI');
  const evidences = await client(this).createNaturalPersons(quantity, typeDocument);
  for (const evidence of evidences) this.addEvidence(evidence);
});

/**
 * Crea clientes PJ tomando cantidad, societyType, countryCode y economicActivityCode desde properties.
 * Mantiene el feature limpio y evita hardcodear valores por ambiente.
 */
When('ejecuto Crear Clientes PJ IFX con la configuración del ambiente', async function (this: CustomWorld) {
  if (!this.props) this.props = loadProperties(this.environment);
  const quantity = Number(prop(this.props, 'ifx.crear-pj.quantity', '2'));
  const societyType = prop(this.props, 'ifx.crear-pj.society-type', prop(this.props, 'ifx.merchant.society-type', prop(this.props, 'ifx.stg.pj.society-type', 'EIRL')));
  const countryCode = prop(this.props, 'ifx.crear-pj.country-code', prop(this.props, 'ifx.merchant.body-country-code', '2023'));
  const economicActivityCode = prop(this.props, 'ifx.crear-pj.economic-activity-code', prop(this.props, 'ifx.merchant.economic-activity-code', prop(this.props, 'ifx.stg.pj.economic-activity-code', '1520')));

  const evidences = await client(this).createLegalPersons(quantity, {
    SOCIETYTYPE: societyType,
    COUNTRYCODE: countryCode,
    ECONOMICACTIVITYCODE: economicActivityCode
  });
  for (const evidence of evidences) this.addEvidence(evidence);
});

/**
 * Consulta cliente full tomando tipo y número de documento desde properties locales.
 */
When('ejecuto Consulta Cliente IFX con la configuración del ambiente', async function (this: CustomWorld) {
  if (!this.props) this.props = loadProperties(this.environment);
  const typeDocument = prop(this.props, 'ifx.consulta.document-type', prop(this.props, 'ifx.query-document-type', 'DNI'));
  const documentNumber = prop(
    this.props,
    'ifx.consulta.document-number',
    typeDocument.toUpperCase() === 'RUC' ? prop(this.props, 'ifx.query-ruc') : prop(this.props, 'ifx.query-dni')
  );
  this.addEvidence(await client(this).retrieveCustomer(typeDocument, documentNumber));
});

When('ejecuto Crear Persona Natural IFX con tipo documento {string}', async function (this: CustomWorld, typeDocument: string) {
  this.addEvidence(await client(this).createNaturalPerson(typeDocument));
});

/** Crea N personas naturales usando DNI incremental y registra una evidencia por cada creación. */
When('ejecuto Crear {int} Personas Naturales IFX con tipo documento {string}', async function (this: CustomWorld, quantity: number, typeDocument: string) {
  const evidences = await client(this).createNaturalPersons(quantity, typeDocument);
  for (const evidence of evidences) this.addEvidence(evidence);
});
/** Crea N personas naturales usando documento base indicado en Gherkin. */
When('ejecuto Crear {int} Personas Naturales IFX con tipo documento {string} desde documento base {string}', async function (this: CustomWorld, quantity: number, typeDocument: string, documentoBase: string) {
  const evidences = await client(this).createNaturalPersons(quantity, typeDocument, { DOCUMENTO_BASE: documentoBase, NUMERO_DOCUMENTO: 'AUTO' });
  for (const evidence of evidences) this.addEvidence(evidence);
});

/** Crea N clientes PJ usando RUC base indicado en Gherkin. */
When('ejecuto Crear {int} Clientes PJ IFX con RUC base {string} societyType {string} countryCode {string} economicActivityCode {string}', async function (this: CustomWorld, quantity: number, rucBase: string, societyType: string, countryCode: string, economicActivityCode: string) {
  const evidences = await client(this).createLegalPersons(quantity, {
    NUMERO_DOCUMENTO: 'AUTO',
    DOCUMENTO_BASE: rucBase,
    SOCIETYTYPE: societyType,
    COUNTRYCODE: countryCode,
    ECONOMICACTIVITYCODE: economicActivityCode
  });
  for (const evidence of evidences) this.addEvidence(evidence);
});


When('ejecuto Consulta Cliente IFX con tipo documento {string} y numero documento {string}', async function (this: CustomWorld, typeDocument: string, documentNumber: string) {
  this.addEvidence(await client(this).retrieveCustomer(typeDocument, documentNumber));
});


When('ejecuto Crear Cliente PJ IFX con RUC dinamico societyType {string} countryCode {string} economicActivityCode {string}', async function (this: CustomWorld, societyType: string, countryCode: string, economicActivityCode: string) {
  this.addEvidence(await client(this).createLegalPerson({
    SOCIETYTYPE: societyType,
    COUNTRYCODE: countryCode,
    ECONOMICACTIVITYCODE: economicActivityCode
  }));
});

/** Crea N clientes PJ usando RUC dinámico válido y parámetros de negocio desde Gherkin. */
When('ejecuto Crear {int} Clientes PJ IFX con RUC dinamico societyType {string} countryCode {string} economicActivityCode {string}', async function (this: CustomWorld, quantity: number, societyType: string, countryCode: string, economicActivityCode: string) {
  const evidences = await client(this).createLegalPersons(quantity, {
    SOCIETYTYPE: societyType,
    COUNTRYCODE: countryCode,
    ECONOMICACTIVITYCODE: economicActivityCode
  });
  for (const evidence of evidences) this.addEvidence(evidence);
});


/**
 * Ejecuta la carga data-driven desde Excel usando los parámetros solicitados:
 * directorio, nombre de archivo y ambiente.
 * El archivo se busca en src/main/resources/<directorio>/<archivo>.
 */
When('ejecuto GenerateDataFromExcel desde directorio {string} archivo {string} ambiente {string}', async function (this: CustomWorld, dataDir: string, fileName: string, environment: string) {
  this.environment = environment;
  this.props = loadProperties(environment);
  console.log(`[IFX][EXCEL] Ambiente: ${environment} | Directorio: ${dataDir} | Archivo: ${fileName}`);
  this.addEvidence(await client(this).generateDataFromExcel(dataDir, fileName));
});


/** Valida que las respuestas no rompan el build, permitiendo 5xx solo si la operación está whitelist en properties. */
Then('la respuesta HTTP debe ser exitosa o aceptada por el ambiente', function (this: CustomWorld) {
  assert.ok(this.evidences.length > 0, 'No existen evidencias de ejecución');

  const allowed5xxByOperation = prop(this.props || {}, 'ifx.allowed-5xx-operations', '')
    .split(',')
    .map(v => v.trim())
    .filter(Boolean);

  const invalid = this.evidences.filter(e => {
    if (e.responseStatus < 200) return true;
    if (e.responseStatus < 500) return false;
    const isAllowed = allowed5xxByOperation.some(operation =>
      e.operation === operation || e.operation.startsWith(`${operation} `)
    );
    return !isAllowed;
  });

  assert.deepStrictEqual(invalid.map(e => ({ operation: e.operation, status: e.responseStatus, body: e.responseBody })), []);
});

Then('se adjunta el request, response y headers al reporte', function (this: CustomWorld) {
  assert.ok(this.evidences.length > 0, 'No existen evidencias para adjuntar');
  for (const evidence of this.evidences) {
    assert.ok(evidence.responseHeaders, `No hay response headers para ${evidence.operation}`);
    assert.ok(typeof evidence.responseBody === 'string', `No hay response body para ${evidence.operation}`);
  }
});
