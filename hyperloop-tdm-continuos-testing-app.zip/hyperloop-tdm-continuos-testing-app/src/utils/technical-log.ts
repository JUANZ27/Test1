import fs from 'fs';
import path from 'path';

export interface TechnicalLogEntry {
  timestamp: string;
  environment: string;
  operation: string;
  tokenType: string;
  method: string;
  url: string;
  status: number;
  attempts: number;
  durationMs: number;
  retryHistory: unknown[];
  requestHeaders: Record<string, string>;
  requestBody?: unknown;
  responseHeaders: Record<string, string>;
  responseBody: string;
  /** DNI/RUC usado en el request, extraído para auditoría TDM. */
  generatedDocuments?: Array<{ documentType?: string; documentNumber?: string; operation?: string; source?: string; environment?: string }>;
}

const SENSITIVE_KEYS = ['authorization', 'ocp-apim-subscription-key', 'ocp-apim-subscription-secret', 'client_secret', 'password', 'token'];

function maskValue(value: unknown): unknown {
  const text = String(value ?? '');
  if (!text) return '';
  if (text.length <= 8) return '***';
  return `${text.slice(0, 6)}***${text.slice(-4)}`;
}

function maskObject(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(item => maskObject(item));
  if (value && typeof value === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      const lower = key.toLowerCase();
      result[key] = SENSITIVE_KEYS.some(sensitive => lower.includes(sensitive)) ? maskValue(val) : maskObject(val);
    }
    return result;
  }
  return value;
}

function csvEscape(value: unknown): string {
  const raw = String(value ?? '');
  if (/[",\n\r;]/.test(raw)) return `"${raw.replace(/"/g, '""')}"`;
  return raw;
}

/**
 * Guarda logs técnicos por cada request ejecutado.
 * Estos logs complementan el HTML: sirven para depuración, CI/CD y auditoría técnica.
 */
export function appendTechnicalLog(entry: TechnicalLogEntry, baseDir = 'reports/logs'): string {
  const resolvedDir = path.resolve(process.cwd(), baseDir);
  fs.mkdirSync(resolvedDir, { recursive: true });

  const safeEntry = maskObject(entry) as TechnicalLogEntry;
  const jsonlFile = path.join(resolvedDir, 'ifx-technical-execution.jsonl');
  const csvFile = path.join(resolvedDir, 'ifx-technical-execution.csv');

  fs.appendFileSync(jsonlFile, `${JSON.stringify(safeEntry)}\n`, 'utf-8');

  const header = ['timestamp', 'environment', 'operation', 'method', 'url', 'status', 'attempts', 'durationMs', 'tokenType', 'documentTypes', 'documentNumbers'];
  if (!fs.existsSync(csvFile) || fs.readFileSync(csvFile, 'utf-8').trim().length === 0) {
    fs.writeFileSync(csvFile, `${header.join(';')}\n`, 'utf-8');
  }

  const generatedDocuments = Array.isArray(safeEntry.generatedDocuments) ? safeEntry.generatedDocuments : [];
  const row = [
    safeEntry.timestamp,
    safeEntry.environment,
    safeEntry.operation,
    safeEntry.method,
    safeEntry.url,
    safeEntry.status,
    safeEntry.attempts,
    safeEntry.durationMs,
    safeEntry.tokenType,
    generatedDocuments.map((doc) => doc.documentType || '').filter(Boolean).join(','),
    generatedDocuments.map((doc) => doc.documentNumber || '').filter(Boolean).join(',')
  ];
  fs.appendFileSync(csvFile, `${row.map(csvEscape).join(';')}\n`, 'utf-8');

  return path.relative(process.cwd(), jsonlFile);
}
