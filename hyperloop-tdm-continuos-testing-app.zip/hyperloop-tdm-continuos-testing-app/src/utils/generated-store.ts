import fs from 'fs';
import path from 'path';

export interface GeneratedDocumentRecord {
  timestamp: string;
  environment: string;
  documentType: 'RUC' | 'DNI' | string;
  documentNumber: string;
  operation: string;
  source: string;
  sequenceFile: string;
  csvFile: string;
  responseStatus?: number;
  effectiveResponseCode?: number;
  attempts?: number;
  retriedBy209?: boolean;
  duplicateStatus?: 'UNIQUE' | 'DUPLICATE_DETECTED' | 'PROVIDED_NOT_CHECKED' | string;
  duplicatePolicy?: 'regenerate' | 'fail' | 'warn' | string;
  busResponseMessage?: string;
  srvResponseCode?: string;
  srvResponseMessage?: string;
}

function csvEscape(value: unknown): string {
  const raw = String(value ?? '');
  if (/[",\n\r;]/.test(raw)) return `"${raw.replace(/"/g, '""')}"`;
  return raw;
}

function writeCsvRow(filePath: string, header: string[], row: unknown[]): void {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });

  if (!fs.existsSync(filePath) || fs.readFileSync(filePath, 'utf-8').trim().length === 0) {
    fs.writeFileSync(filePath, `${header.join(';')}\n`, 'utf-8');
  } else {
    const content = fs.readFileSync(filePath, 'utf-8');
    const existingHeader = (content.split(/\r?\n/)[0] || '').trim();
    const expectedHeader = header.join(';');
    if (existingHeader && existingHeader !== expectedHeader) {
      // Si el CSV existe con una versión anterior de columnas, se migra sin perder data.
      const existingColumns = existingHeader.split(';');
      const migratedRows = content
        .split(/\r?\n/)
        .slice(1)
        .filter(line => line.trim().length > 0)
        .map(line => {
          const values = line.split(';');
          const mapped: Record<string, string> = {};
          for (let i = 0; i < existingColumns.length; i++) mapped[existingColumns[i]] = values[i] || '';
          return header.map(column => mapped[column] || '').join(';');
        });
      fs.writeFileSync(filePath, `${expectedHeader}\n${migratedRows.join('\n')}${migratedRows.length ? '\n' : ''}`, 'utf-8');
    }
  }

  fs.appendFileSync(filePath, `${row.map(csvEscape).join(';')}\n`, 'utf-8');
}

function resultByStatus(status?: number): string {
  if (!status) return 'PENDING';
  if (status >= 200 && status < 300) return 'SUCCESS';
  if (status >= 400 && status < 500) return 'FUNCTIONAL_ERROR';
  if (status >= 500) return 'TECHNICAL_ERROR';
  return 'OBSERVED';
}

/**
 * Registra cualquier documento generado únicamente en el CSV consolidado.
 *
 * Decisión QA Senior:
 * - Evitar archivos separados por tipo (dni-generados.csv / ruc-generados.csv).
 * - Centralizar la trazabilidad funcional en reports/generated/documentos-generados.csv.
 * - Guardar solo documentos creados exitosamente; los 209 quedan en logs/duplicados.
 * - Reducir ruido y crecimiento innecesario de archivos en cada ejecución.
 */
export function appendGeneratedDocument(record: GeneratedDocumentRecord): void {
  const header = [
    'timestamp',
    'environment',
    'documentType',
    'documentNumber',
    'operation',
    'source',
    'sequenceFile',
    'responseStatus',
    'effectiveResponseCode',
    'attempts',
    'retriedBy209',
    'result',
    'duplicateStatus',
    'duplicatePolicy',
    'busResponseMessage',
    'srvResponseCode',
    'srvResponseMessage'
  ];
  const row = [
    record.timestamp,
    record.environment,
    record.documentType,
    record.documentNumber,
    record.operation,
    record.source,
    record.sequenceFile,
    record.responseStatus ?? '',
    record.effectiveResponseCode ?? record.responseStatus ?? '',
    record.attempts ?? '',
    record.retriedBy209 ? 'true' : 'false',
    resultByStatus(record.effectiveResponseCode ?? record.responseStatus),
    record.duplicateStatus ?? 'UNIQUE',
    record.duplicatePolicy ?? '',
    record.busResponseMessage ?? '',
    record.srvResponseCode ?? '',
    record.srvResponseMessage ?? ''
  ];

  const consolidatedCsv = path.resolve(process.cwd(), record.csvFile || 'reports/generated/documentos-generados.csv');
  writeCsvRow(consolidatedCsv, header, row);
}
