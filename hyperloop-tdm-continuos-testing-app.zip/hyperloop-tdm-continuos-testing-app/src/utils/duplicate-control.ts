import fs from 'fs';
import path from 'path';

export interface DuplicateCheckResult {
  duplicated: boolean;
  documentType: string;
  documentNumber: string;
  foundInFiles: string[];
}

export interface DuplicateEvent {
  timestamp: string;
  environment: string;
  operation: string;
  documentType: string;
  documentNumber: string;
  policy: string;
  result: string;
  foundInFiles: string[];
  source: string;
}

function normalize(value: string): string {
  return String(value || '').replace(/\D/g, '');
}

function splitCsvLine(line: string): string[] {
  // Suficiente para los CSV generados por el framework; evita dependencias extra.
  const result: string[] = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        quoted = !quoted;
      }
    } else if (char === ';' && !quoted) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

function csvEscape(value: unknown): string {
  const raw = String(value ?? '');
  if (/[",\n\r;]/.test(raw)) return `"${raw.replace(/"/g, '""')}"`;
  return raw;
}

function readDocumentsFromCsv(filePath: string): Set<string> {
  const documents = new Set<string>();
  const resolved = path.resolve(process.cwd(), filePath);
  if (!fs.existsSync(resolved)) return documents;

  const lines = fs.readFileSync(resolved, 'utf-8').split(/\r?\n/).filter(line => line.trim());
  if (lines.length <= 1) return documents;

  const header = splitCsvLine(lines[0]).map(value => value.trim());
  const typeIndex = header.findIndex(column => column.toLowerCase() === 'documenttype');
  const numberIndex = header.findIndex(column => column.toLowerCase() === 'documentnumber');
  if (typeIndex < 0 || numberIndex < 0) return documents;

  for (const line of lines.slice(1)) {
    const values = splitCsvLine(line);
    const type = String(values[typeIndex] || '').trim().toUpperCase();
    const number = normalize(values[numberIndex] || '');
    if (type && number) documents.add(`${type}:${number}`);
  }
  return documents;
}

/**
 * Busca un documento en los CSV de trazabilidad existentes.
 * Se usa para no reciclar DNI/RUC si se reinicia una secuencia manualmente.
 */
export function checkDuplicateDocument(documentType: string, documentNumber: string, csvFiles: string[]): DuplicateCheckResult {
  const normalizedType = String(documentType || '').trim().toUpperCase();
  const normalizedNumber = normalize(documentNumber);
  const key = `${normalizedType}:${normalizedNumber}`;
  const foundInFiles: string[] = [];

  for (const csvFile of csvFiles.filter(Boolean)) {
    const documents = readDocumentsFromCsv(csvFile);
    if (documents.has(key)) foundInFiles.push(csvFile);
  }

  return {
    duplicated: foundInFiles.length > 0,
    documentType: normalizedType,
    documentNumber: normalizedNumber,
    foundInFiles
  };
}

/** Registra eventos de duplicidad para auditoría sin mezclarlo con los documentos OK. */
export function appendDuplicateEvent(event: DuplicateEvent, csvFile = 'reports/generated/duplicados-detectados.csv'): void {
  const resolved = path.resolve(process.cwd(), csvFile);
  fs.mkdirSync(path.dirname(resolved), { recursive: true });

  const header = ['timestamp', 'environment', 'operation', 'documentType', 'documentNumber', 'policy', 'result', 'foundInFiles', 'source'];
  if (!fs.existsSync(resolved) || fs.readFileSync(resolved, 'utf-8').trim().length === 0) {
    fs.writeFileSync(resolved, `${header.join(';')}\n`, 'utf-8');
  }

  const row = [
    event.timestamp,
    event.environment,
    event.operation,
    event.documentType,
    event.documentNumber,
    event.policy,
    event.result,
    event.foundInFiles.join(','),
    event.source
  ];
  fs.appendFileSync(resolved, `${row.map(csvEscape).join(';')}\n`, 'utf-8');
}
