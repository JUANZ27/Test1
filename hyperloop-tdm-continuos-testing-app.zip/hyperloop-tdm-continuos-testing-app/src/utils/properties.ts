import fs from 'fs';
import os from 'os';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

export type Properties = Record<string, string>;

function parseProperties(content: string): Properties {
  const result: Properties = {};
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const index = line.indexOf('=');
    if (index < 0) continue;
    const key = line.substring(0, index).trim();
    const value = line.substring(index + 1).trim();
    result[key] = value;
  }
  return result;
}

function resolvePlaceholders(value: string, props: Properties): string {
  let resolved = value;
  for (let i = 0; i < 8 && resolved.includes('${'); i++) {
    resolved = resolved.replace(/\$\{([^}]+)\}/g, (_, key: string) => {
      const envKey = key.toUpperCase().replace(/[.-]/g, '_');
      return props[key] ?? process.env[envKey] ?? process.env[key] ?? '';
    });
  }
  return resolved;
}

function isBlankOrPlaceholder(value: string | undefined): boolean {
  const normalized = String(value ?? '').trim();
  if (!normalized) return true;
  return /^(TU_|REEMPLAZAR|CHANGE_ME|PENDIENTE|<.*>|\$\{.*\})/i.test(normalized);
}

function requireKeys(props: Properties, keys: string[], missing: string[]): void {
  for (const key of keys) {
    if (isBlankOrPlaceholder(props[key])) missing.push(key);
  }
}

/**
 * Validación temprana de configuración.
 *
 * Objetivo QA Automation Senior:
 * - Fallar rápido si falta un valor sensible o endpoint obligatorio.
 * - Evitar errores confusos durante el consumo del API.
 * - Mantener los tokens/credenciales fuera del feature y del código.
 */
function validateProperties(environment: string, props: Properties): void {
  const env = environment.toLowerCase();
  const apiFlavor = (props['ifx.api-flavor'] || '').toLowerCase();
  const missing: string[] = [];

  requireKeys(props, ['ifx.base-url', 'ifx.api-flavor'], missing);

  if (env === 'uat' || apiFlavor.includes('uat')) {
    requireKeys(props, [
      'ifx.token-path',
      'ifx.grant-type',
      'ifx.username',
      'ifx.password',
      'ifx.client-id',
      'ifx.client-secret',
      'ifx.scope-transaccion',
      'ifx.scope-consulta',
      'ifx.subscription-key',
      'ifx.subscription-secret',
      'ifx.create-customer-path',
      'ifx.create-merchant-path',
      'ifx.retrieve-customer-path',
      'ifx.generated-documents-csv'
    ], missing);
  }

  if (env === 'stg' || apiFlavor.includes('stg')) {
    requireKeys(props, [
      'ifx.subscription-key',
      'ifx.create-customer-path',
      'ifx.create-merchant-path',
      'ifx.retrieve-customer-path',
      'ifx.stg.consumer-id',
      'ifx.generated-documents-csv'
    ], missing);

    if (String(props['ifx.stg.authorization.enabled'] ?? 'false').toLowerCase() === 'true') {
      requireKeys(props, ['ifx.transaccion.static-token', 'ifx.consulta.static-token'], missing);
    }
  }

  if (missing.length > 0) {
    const configFile = props.__configFile || `application-${env}.properties`;
    throw new Error([
      `Configuración incompleta para ambiente '${env}'.`,
      `Archivo: ${configFile}`,
      'Completa o corrige las siguientes propiedades:',
      ...Array.from(new Set(missing)).map(key => `- ${key}`)
    ].join('\n'));
  }

  console.log(`[CONFIG][${env}] OK - archivo cargado: ${props.__configFile}`);
}

export function loadProperties(environment: string): Properties {
  const env = environment || process.env.ENVIRONMENT || 'uat';
  const localPath = path.join(os.homedir(), `application-${env}.properties`);
  const configPath = path.resolve(process.cwd(), `config/application-${env}.properties`);
  const examplePath = path.resolve(process.cwd(), `config/application-${env}.properties.example`);

  let selected = '';
  if (fs.existsSync(localPath)) selected = localPath;
  else if (fs.existsSync(configPath)) selected = configPath;
  else if (fs.existsSync(examplePath)) selected = examplePath;

  if (!selected) {
    throw new Error(`No se encontró application-${env}.properties. Copia config/application-${env}.properties.example a ${localPath}`);
  }

  const props = parseProperties(fs.readFileSync(selected, 'utf-8'));
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) props[key] = value;
  }

  const resolved: Properties = {};
  for (const [key, value] of Object.entries(props)) {
    resolved[key] = resolvePlaceholders(value, props);
  }
  resolved.__configFile = selected;
  resolved.__environment = env;

  validateProperties(env, resolved);
  return resolved;
}

export function prop(props: Properties, key: string, defaultValue = ''): string {
  const envKey = key.toUpperCase().replace(/[.-]/g, '_');
  return process.env[envKey] || props[key] || defaultValue;
}
