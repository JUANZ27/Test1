import path from 'path';
import XLSX from 'xlsx';

export type ExcelRow = Record<string, string>;

function normalizeHeader(value: string): string {
  return String(value || '').trim().replace(/^\uFEFF/, '').toUpperCase();
}

export function readExcelRows(dataDir: string, fileName: string): ExcelRow[] {
  const baseDir = path.isAbsolute(dataDir)
    ? dataDir
    : path.resolve(process.cwd(), 'src/main/resources', dataDir);
  const filePath = path.join(baseDir, fileName);
  const workbook = XLSX.readFile(filePath, { cellDates: false, raw: false });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
  return rows.map(row => {
    const normalized: ExcelRow = {};
    for (const [key, value] of Object.entries(row)) {
      normalized[normalizeHeader(key)] = String(value ?? '').trim();
    }
    return normalized;
  });
}

export function rowValue(row: ExcelRow, ...keys: string[]): string {
  for (const key of keys) {
    const value = row[normalizeHeader(key)];
    if (value) return value;
  }
  return '';
}
