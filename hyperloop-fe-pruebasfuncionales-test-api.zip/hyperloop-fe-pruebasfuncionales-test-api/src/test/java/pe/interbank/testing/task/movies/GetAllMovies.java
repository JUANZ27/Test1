package pe.interbank.testing.task.movies;

import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.util.JavaUtil;


import java.util.Optional;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GetAllMovies implements Task {

    //private static final Logger LOGGER = LoggerFactory.getLogger(GetAllMovies.class);
    private static final String TEMPLATE_GENERIC = "/template/graphql/generic.json";

    private static final String PATH_QUERY = "/template/graphql/movie/query/getAllMovies.graphql";

    public GetAllMovies(){}

    public static GetAllMovies all(){
        return instrumented(GetAllMovies.class);
    }

    @Override
    @Step("{0} search all movies")
    public <T extends Actor> void performAs(T actor){

        String queryGetMovies = JavaUtil.getQuery(PATH_QUERY, Optional.empty());

        actor.attemptsTo(
                Post.to(Endpoint.GRAPHQL_EXPERIENCE.getEndpoint())
                        .with(query -> query
                                .contentType(ContentType.JSON)
                                .body(JavaUtil.getTemplate(TEMPLATE_GENERIC)
                                        .replace("{operationName}","allFilms")
                                        .replace("{query}",queryGetMovies)
                                )
                        )
        );
    }
}
