package pe.interbank.testing.stepdefinition.user;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.model.User;
import pe.interbank.testing.task.user.CreateUser;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.generic.CommonQuestion.matchSchema;
import static pe.interbank.testing.question.user.CreateUserQuestion.firstNameDB;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_BAD_REQUEST;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_CREATED;

public class CreateUserStepDefinition {


    @Steps
    BaseUrl base;

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }


    @Given("^(.*) tiene los permisos para registrar un nuevo usuario$")
    public void administradorUtilizarElServicio(String actorName) {
        theActorCalled(actorName).whoCan(CallAnApi.at(base.getUrlRegresIn()));
    }

    @When("^se registra un usuario nuevo con (.*) y (.*)$")
    public void ingresoUnUsuarioConNombreYCargo(String Nombre, String Cargo) {

        User newUser = new User(Nombre, Cargo);
        theActorInTheSpotlight().attemptsTo(
                CreateUser.byUserId(newUser)
        );

    }

    @Then("^el usuario debería registrarse correctamente$")
    public void elUsuarioSeIngresoCorrectamente() {
        String PATH_SCHEMA = "schema/user/createUser.json";
        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_CREATED))
        );
        theActorInTheSpotlight().should(
                seeThat("The response match", matchSchema(PATH_SCHEMA))
        );


    }


    @And("^el (.*) debería visualizar el usuario (.*) registrado$")
    public void validoElNombreNombreConLaBaseDeDatos(String actor, String name) {
        theActorInTheSpotlight().should(
                seeThat("The first name of the DB", firstNameDB(name), equalTo(name))
        );
    }


    @When("^se registra un usuario existente (.*)$")
    public void registrarUsuarioIinexistente(String name) {
        theActorInTheSpotlight().attemptsTo(
                CreateUser.byUserId(new User(name, "job"))
        );
    }
    @Then("^el usuario no debería ser creado$")
    public void noDeberíaCrearseExitosamente() {
        theActorInTheSpotlight().should(
                seeThat("The http status", httpStatusCode(), equalTo(STATUS_CODE_BAD_REQUEST))
        );
    }




}
