package pe.interbank.testing.question.cuentaNegocio;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;

public class PersonaJuridicaQuestion {
    public static Question<String> responseRuc(){
        return Question.about("Response RUC")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().body().prettyPrint()
                );
    }

    public static Question<String> responseDni(){
        return Question.about("Response DNI")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().body().prettyPrint()
                );
    }
}
