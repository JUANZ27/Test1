package pe.interbank.testing.endpoint;

/**
 * This class provides utility methods for common operations in Java.
 * It contains methods for loading properties, retrieving templates, queries, and variables,
 * generating random numbers and codes, converting lists to strings, and parsing data tables.
 * The methods in this class are static and can be accessed without creating an instance of the class.
 * @author Joham Romucho
 */
public enum Endpoint {

    API_GETALL_USER("/api/users"),
    API_GET_USER_BY_ID("/api/users/{userId}"),
    API_DELETE_USER("/api/users/{userId}"),
    API_CREATE_USER("/api/users"),
    API_UPDATE_USER("/api/users/{userId}"),
    API_TOKEN("/oauth/token"),
    GRAPHQL_EXPERIENCE("/query");
    private final String endpoint;

    Endpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getEndpoint() {
        return endpoint;
    }
}
