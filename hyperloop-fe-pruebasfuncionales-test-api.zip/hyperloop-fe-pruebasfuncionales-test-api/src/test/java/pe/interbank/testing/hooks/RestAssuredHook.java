package pe.interbank.testing.hooks;

import io.cucumber.java.Before;
import io.restassured.RestAssured;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

/**
 * Cucumber hook to configure RestAssured before scenarios run.
 * Enables relaxed HTTPS validation to avoid SSL handshake failures against
 * environments using internal/self-signed certificates (UAT).
 */
public class RestAssuredHook {

    @Before(order = 0)
    public void enableRelaxedHTTPS() {
        // Allow RestAssured to accept unknown/self-signed certificates during tests
        RestAssured.useRelaxedHTTPSValidation();

        // Also set a global all-trusting SSL context and hostname verifier for
        // code paths that may not honour RestAssured's relaxed setting.
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                        public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                        public void checkServerTrusted(X509Certificate[] certs, String authType) { }
                    }
            };

            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) { return true; }
            };
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            // If this fails, leave the default behaviour and allow RestAssured to try.
            System.err.println("Could not set relaxed SSL context: " + e.getMessage());
        }
    }

}


