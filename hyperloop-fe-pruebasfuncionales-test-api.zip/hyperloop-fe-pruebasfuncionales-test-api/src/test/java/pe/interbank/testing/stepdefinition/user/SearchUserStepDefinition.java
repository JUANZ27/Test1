package pe.interbank.testing.stepdefinition.user;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.task.user.FindAll;
import pe.interbank.testing.task.user.FindUser;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.generic.CommonQuestion.matchSchema;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_NOT_FOUND;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_OK;


public class SearchUserStepDefinition {

    @Steps
    BaseUrl base;

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }


    @Given("^(.*) tiene los permisos para buscar un usuario$")
    public void administradorUtilizarElServicio(String actorName) {
        theActorCalled(actorName).whoCan(CallAnApi.at(base.getUrlRegresIn()));
    }

    @When("Filtro todos los usuarios en la busqueda")
    public void filtroTodosLosUsuariosEnLaBusqueda() {
        theActorInTheSpotlight().attemptsTo(
                FindAll.AllUsers()
        );
    }


    @Then("se debería encontrar exitosamente al usuario")
    public void seEncontroElUsuarioBuscado() {
        String PATH_SCHEMA = "schema/user/searchUser.json";

        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_OK))
        );
        theActorInTheSpotlight().should(
                seeThat("The response match", matchSchema(PATH_SCHEMA))
        );
    }

    @Then("se listaron correctamente todos los usuarios")
    public void seListaronCorrectamenteLosUsuarios() {
        String PATH_SCHEMA = "schema/user/searchAllUser.json";

        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_OK))
        );

        theActorInTheSpotlight().should(
                seeThat("The response match", matchSchema(PATH_SCHEMA))
        );
    }

    @When("se busca al usuario {}")
    public void seBuscaAlUsuarioUsuario(String Usuario) {

        theActorInTheSpotlight().attemptsTo(

                FindUser.byId(Usuario)
        );

    }

    @Then("no se debería encontrar el usuario buscado")
    public void noSeEncontroElUsuarioBuscado() {

        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_NOT_FOUND))
        );
    }

}
