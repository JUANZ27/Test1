package pe.interbank.testing.question.Token;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;

public class TokenQuestion {

    public static Question<String> saveToken(){
        return Question.about("Token obtenido")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().jsonPath().getString("access_token")

                );

    }
}
