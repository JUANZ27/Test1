package pe.interbank.testing.stepdefinition.token;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.task.CnPersonaJuridica.BusinessValidationTask;
import pe.interbank.testing.task.CnPersonaJuridica.PersonValidationSearchTask;
import pe.interbank.testing.task.token.GetTokenTask;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.core.IsEqual.equalTo;
import static pe.interbank.testing.question.Token.TokenQuestion.saveToken;
import static pe.interbank.testing.question.cuentaNegocio.PersonaJuridicaQuestion.responseDni;
import static pe.interbank.testing.question.cuentaNegocio.PersonaJuridicaQuestion.responseRuc;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_OK;

public class CnPersonaJuridicaStepDefinition {
    private static final Logger LOGGER = LoggerFactory.getLogger(CnPersonaJuridicaStepDefinition.class);

    @Steps
    BaseUrl base;

    @Given("^que (.*) quiere verificar si el ruc esta constituido")
    public void queCesarQuiereVerificarSiElRucEstaConstituido(String actor) {

        String PATH_SCHEMA="schema/token/tokenSchema.json";
        theActorCalled(actor).whoCan(CallAnApi.at(base.getToken()));
        theActorInTheSpotlight().attemptsTo(GetTokenTask.token());
        String token = theActorInTheSpotlight().asksFor(saveToken());
        System.out.println("TOKEN_TEST: " + token);
        Serenity.setSessionVariable("accessToken").to("Bearer " + token);
        theActorCalled(actor).whoCan(CallAnApi.at(base.getGraphqlUrl()));

    }

    @When("consulta el servicio con ruc (.*)$")
    public void consultaElServicioConRuc(String ruc) {
        LOGGER.info("OBTENIENDO EL TOKEN");
        theActorInTheSpotlight().attemptsTo(BusinessValidationTask.validation(Serenity.sessionVariableCalled("accessToken"),ruc));
        System.out.println(theActorInTheSpotlight().asksFor(responseRuc()));
        theActorInTheSpotlight().should(
                seeThat("HPTT CODE",httpStatusCode(),equalTo(STATUS_CODE_OK))
        );
    }

    @And("consulta el dni (.*)$")
    public void consultaElDni(String dni) {
        theActorInTheSpotlight().attemptsTo(PersonValidationSearchTask.validationPerson(Serenity.sessionVariableCalled("accessToken"),dni));
        System.out.println(theActorInTheSpotlight().asksFor(responseDni()));
        theActorInTheSpotlight().should(
                seeThat("HPTT CODE",httpStatusCode(),equalTo(STATUS_CODE_OK))
        );
    }

    @Then("se debería crear las cuentas exitosamente")
    public void seDeberíaCrearLasCuentasExitosamente() {
        theActorInTheSpotlight().should(
                seeThat("HPTT CODE",httpStatusCode(),equalTo(STATUS_CODE_OK))
        );
    }
}
