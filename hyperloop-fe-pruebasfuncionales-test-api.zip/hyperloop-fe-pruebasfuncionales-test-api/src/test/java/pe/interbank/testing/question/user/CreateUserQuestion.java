package pe.interbank.testing.question.user;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;
import pe.interbank.testing.model.TbPerson;

import static pe.interbank.testing.dao.UserDao.findPersonbyFirstName;

public class CreateUserQuestion {

    public static  Question<String> firstNameDB(String name) {
        return Question.about("The first name of the DB")
                .answeredBy(
                        actor -> {
                            try {
                                TbPerson person = findPersonbyFirstName(name);
                                Serenity.recordReportData().withTitle("Database evidence").andContents(String.valueOf(person));
                                return person.getFirstName();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                ).asString();
    }

    public static Question<String> userId() {
        return Question.about("The id of the user")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().jsonPath().getString("id")
                );
    }


}
