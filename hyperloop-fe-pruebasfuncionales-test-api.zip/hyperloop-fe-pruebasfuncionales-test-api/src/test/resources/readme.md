## Regulatory Reporting Controls

This project illustrates Serenity's living documentation capabilities, through a set of requirements for an imaginary investment bank.
* The _Customer Due Diligence_ requirements, which are partially implemented (a mixture of pending and passing requirements), and
* The _Reporting controls_, which contain a variety of failing acceptance tests.

![Squad name](assets/interbank-benefit.png)