@TXDM-106
@ActualizarUsuario
Feature: Actualizar Usuario

  @TXDM-60 @regresion
  Scenario: Actualizar usuario
    Given que el administrador Jose tiene los permisos para actualizar un usuario
    And va a actualizar al usuario Guillermo con el cargo Developer
    When actualizo la información del usuario a Morpheus y Tester
    Then la informacion del usuario debería actualizarse correctamente
