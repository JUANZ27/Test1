# Hyperloop TDM - Playwright + TypeScript + BDD

Proyecto migrado a **Playwright API + TypeScript + Cucumber/Gherkin**.

El objetivo es ejecutar los flujos IFX desde features BDD y generar evidencias HTML con:

- Request headers
- Request body
- Response status
- Response headers
- Response body
- Screenshot HTML por escenario
- Video de evidencia por escenario
- Registro CSV de RUC generados
- Impresión en consola de response, busresponsemessage, srvresponsecode y srvresponsemessage

## Estructura principal

```text
src/test/features/ifx-tdm-operaciones.feature
src/test/steps/ifx.steps.ts
src/services/ifx-client.ts
src/support/hooks.ts
src/support/report-generator.ts
src/main/resources/Data/CargaClientePNPJ.xlsx
config/application-uat.properties.example
```

## Configuración

Copia el archivo:

```text
config/application-uat.properties.example
```

a:

```text
C:\Users\TU_USUARIO\application-uat.properties
```

Luego coloca tus credenciales reales:

```properties
ifx.password=...
ifx.client-id=...
ifx.client-secret=...
ifx.scope-transaccion=...
ifx.scope-consulta=...
```

## Instalación

```bash
npm install
npm run install:browsers
```

## Ejecución por tags solicitados

```bash
npx cucumber-js --tags @CrearPersonaNaturalIFX
npx cucumber-js --tags @ConsultaClienteIFX
npx cucumber-js --tags @ConsultaCustomerSpecialStatusCCE
npx cucumber-js --tags @CrearClientePJIFX
npx cucumber-js --tags @CrearCuentaIFX
npx cucumber-js --tags @GenerateDataFromExcel
```

También puedes usar scripts npm:

```bash
npm run test:crear-pn
npm run test:consulta-full
npm run test:cce-status
npm run test:crear-pj
npm run test:crear-cuenta
npm run test:excel
```

## Features creados

Todos los tags pedidos están creados en:

```text
src/test/features/ifx-tdm-operaciones.feature
```

Incluye:

| Tag | Operación | Token |
|---|---|---|
| `@CrearPersonaNaturalIFX` | Crear cliente PN | Transacción |
| `@ConsultaClienteIFX` | Consulta cliente full | Consulta |
| `@ConsultaCustomerSpecialStatusCCE` | Consulta CCE Customer Special Status | Consulta |
| `@CrearClientePJIFX` | Crear cliente PJ | Transacción |
| `@CrearCuentaIFX` | Crear cuenta | Transacción |
| `@GenerateDataFromExcel` | Ejecuta operaciones desde Excel | Transacción |

## Reportes y evidencias

Después de ejecutar pruebas se generan:

```text
reports/cucumber/cucumber-report.html
reports/html/index.html
reports/html/evidencias.html
reports/evidence/*.json
reports/screenshots/*.png
reports/videos/*.webm
reports/generated/ruc-generados.csv
```

El reporte `reports/html/evidencias.html` muestra por escenario:

- URL ejecutada
- Método HTTP
- Tipo de token usado
- Request headers
- Request body
- Response status
- Response headers
- Response body
- `response.header.busresponsemessage`
- `response.header.srvresponsecode`
- `response.header.srvresponsemessage`
- Documentos generados, cuando aplique
- Screenshot
- Video

## Impresión de response y headers clave

En cada ejecución, el cliente imprime en consola:

```text
[IFX][Operacion] RESPONSE STATUS
[IFX][Operacion] response.header.busresponsemessage
[IFX][Operacion] response.header.srvresponsecode
[IFX][Operacion] response.header.srvresponsemessage
[IFX][Operacion] RESPONSE HEADERS
[IFX][Operacion] RESPONSE BODY
```

Además, estos valores se guardan en:

```text
reports/evidence/*.json
reports/html/evidencias.html
reports/html/scenarios/*.html
```

## Registro de RUC generados

Cuando el escenario `@CrearClientePJIFX` genera un RUC dinámico, se guarda automáticamente en CSV:

```text
reports/generated/ruc-generados.csv
```

El CSV incluye:

```text
timestamp;environment;documentType;documentNumber;operation;source;sequenceFile
```

La ruta se puede cambiar desde properties:

```properties
ifx.generated-ruc-csv=reports/generated/ruc-generados.csv
```

## Excel de ejemplo

Se incluye:

```text
src/main/resources/Data/CargaClientePNPJ.xlsx
```

Columnas principales:

```text
OPERACION
TIPO DOCUMENTO
NUMERO DOC
CUSTOMER ID
SOCIETYTYPE
COUNTRYCODE
ECONOMICACTIVITYCODE
PRODUCT CODE
SUB PRODUCT CODE
CURRENCY CODE
```

Operaciones permitidas:

```text
CREAR_CLIENTE
CREAR_CUENTA
CREAR_CLIENTE_Y_CUENTA
```

## Tokens separados

El cliente usa tokens diferentes:

- Token **consulta**: para `@ConsultaClienteIFX` y `@ConsultaCustomerSpecialStatusCCE`
- Token **transacción**: para `@CrearPersonaNaturalIFX`, `@CrearClientePJIFX`, `@CrearCuentaIFX`, `@GenerateDataFromExcel`

Configuración:

```properties
ifx.scope-transaccion=TU_SCOPE_TRANSACCION
ifx.scope-consulta=TU_SCOPE_CONSULTA
ifx.transaccion.scope=${ifx.scope-transaccion}
ifx.consulta.scope=${ifx.scope-consulta}
```

## Limpieza

```bash
npm run clean
```

Luego ejecuta nuevamente las pruebas.
