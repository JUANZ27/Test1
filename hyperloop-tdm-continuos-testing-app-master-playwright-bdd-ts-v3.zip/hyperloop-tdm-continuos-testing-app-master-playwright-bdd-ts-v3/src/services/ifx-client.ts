import { request, APIResponse } from '@playwright/test';
import { Properties, prop } from '../utils/properties';
import { nextSequence, nextValidRuc20 } from '../utils/sequence';
import { appendGeneratedDocument, GeneratedDocumentRecord } from '../utils/generated-store';
import { readExcelRows, rowValue, ExcelRow } from '../utils/excel';

export interface ExecutionEvidence {
  operation: string;
  tokenType: 'consulta' | 'transaccion';
  method: string;
  url: string;
  requestHeaders: Record<string, string>;
  requestBody?: unknown;
  responseStatus: number;
  responseHeaders: Record<string, string>;
  responseBody: string;
  parsedResponse?: unknown;
  busResponseMessage: string;
  srvResponseCode: string;
  srvResponseMessage: string;
  generatedDocuments?: GeneratedDocumentRecord[];
  timestamp: string;
}

function cleanBaseUrl(value: string): string {
  return value.endsWith('/') ? value.slice(0, -1) : value;
}

function pathJoin(pathValue: string): string {
  return pathValue.startsWith('/') ? pathValue : `/${pathValue}`;
}

function firstNonBlank(...values: Array<string | undefined>): string {
  for (const value of values) {
    if (value && value.trim()) return value.trim();
  }
  return '';
}

function normalizeOptionalValue(value: string | undefined): string {
  const normalized = (value || '').trim();
  if (!normalized) return '';
  const lower = normalized.toLowerCase();
  if (lower === 'string' || lower === 'null' || lower === 'undefined' || lower === 'n/a' || lower === 'na' || lower === '-') return '';
  return normalized;
}

function valueOrDefault(value: string | undefined, defaultValue: string): string {
  return normalizeOptionalValue(value) || defaultValue;
}

function toLimaIsoTimestamp(date: Date): string {
  const limaDate = new Date(date.getTime() - 5 * 60 * 60 * 1000);
  return `${limaDate.toISOString().slice(0, 23)}-05:00`;
}

function normalizeDocumentType(type: string): string {
  return (type || 'DNI').trim().toUpperCase();
}

function documentTypeId(type: string): string {
  const t = normalizeDocumentType(type);
  if (t === 'DNI') return '1';
  if (t === 'RUC') return '2';
  if (t === 'CE') return '3';
  if (t === 'PASAPORTE') return '5';
  return t;
}

export class IfxClient {
  constructor(private props: Properties) {}

  async createNaturalPerson(typeDocument = 'DNI'): Promise<ExecutionEvidence> {
    const docType = normalizeDocumentType(typeDocument);
    const docNumber = nextSequence(
      prop(this.props, 'ifx.dni-base', '54072013'),
      prop(this.props, 'ifx.dni-sequence-file', 'reports/sequences/dni-sequence.txt'),
      8
    );

    const body = this.buildNaturalPersonBody(documentTypeId(docType), docNumber, {});
    return this.postJson('CrearPersonaNaturalIFX', 'transaccion', prop(this.props, 'ifx.create-customer-path'), this.naturalPersonHeaders(), body);
  }

  async retrieveCustomer(typeDocument = 'DNI', documentNumber = ''): Promise<ExecutionEvidence> {
    const docType = normalizeDocumentType(typeDocument);
    const docNumber = firstNonBlank(documentNumber, docType === 'RUC' ? prop(this.props, 'ifx.query-ruc') : prop(this.props, 'ifx.query-dni', '40903462'));
    const body = {
      searchCriteria: prop(this.props, 'ifx.consulta.search-criteria', '5'),
      identificationDocumentType: documentTypeId(docType),
      identificationDocumentNumber: docNumber,
      cardId: '',
      customerAccount: {
        organisationId: '',
        currencyCode: '',
        categoryCode: '',
        account: { branchCode: '', accountNumber: '' }
      }
    };
    return this.postJson('ConsultaClienteIFX', 'consulta', prop(this.props, 'ifx.retrieve-customer-path'), this.consultationHeaders(), body);
  }

  async retrieveCustomerSpecialStatus(documentTypeIdValue = '1', documentNumber = '40975592'): Promise<ExecutionEvidence> {
    const query = new URLSearchParams({ documentTypeId: documentTypeIdValue, documentNumber }).toString();
    const path = `${prop(this.props, 'ifx.customer-special-status-path') || '/customer-profile/v1/customer-special-status'}?${query}`;
    return this.getJson('ConsultaCustomerSpecialStatusCCE', 'consulta', path, this.specialStatusHeaders());
  }

  async createLegalPerson(row: ExcelRow = {}): Promise<ExecutionEvidence> {
    const providedRuc = rowValue(row, 'NUMERO DOC', 'NUMERO_DOCUMENTO', 'DOCUMENT_NUMBER', 'DOCUMENT NUMBER');
    const generatedDocuments: GeneratedDocumentRecord[] = [];
    const ruc = providedRuc || this.generateAndPersistRuc('CrearClientePJIFX', 'createLegalPerson', generatedDocuments);
    const body = this.buildLegalPersonBody('2', ruc, row);
    const evidence = await this.postJson('CrearClientePJIFX', 'transaccion', prop(this.props, 'ifx.create-merchant-path'), this.merchantHeaders(row), body);
    if (generatedDocuments.length > 0) {
      for (const generated of generatedDocuments) {
        generated.responseStatus = evidence.responseStatus;
        generated.busResponseMessage = evidence.busResponseMessage;
        generated.srvResponseCode = evidence.srvResponseCode;
        appendGeneratedDocument(generated);
        console.log(`[IFX][${generated.operation}] RUC generado guardado en CSV: ${generated.documentNumber} -> ${generated.csvFile}`);
      }
      evidence.generatedDocuments = generatedDocuments;
    }
    return evidence;
  }

  async createAccount(typeDocument = 'DNI', documentNumber = '', customerId = '', row: ExcelRow = {}): Promise<ExecutionEvidence> {
    const docType = normalizeDocumentType(typeDocument);
    const docNumber = firstNonBlank(documentNumber, rowValue(row, 'NUMERO DOC', 'DOCUMENT NUMBER'), docType === 'RUC' ? prop(this.props, 'ifx.ruc-base') : prop(this.props, 'ifx.dni-base'));
    const resolvedCustomerId = firstNonBlank(customerId, rowValue(row, 'CUSTOMER ID', 'CUSTOMER_ID'), prop(this.props, 'ifx.account.customer-id'), docNumber);
    const body = this.buildCreateAccountBody(documentTypeId(docType), docNumber, resolvedCustomerId, row);
    return this.postJson('CrearCuentaIFX', 'transaccion', prop(this.props, 'ifx.create-account-path'), this.accountHeaders(row), body);
  }

  async generateDataFromExcel(dataDir: string, fileName: string): Promise<ExecutionEvidence> {
    const rows = readExcelRows(dataDir, fileName);
    const executions: ExecutionEvidence[] = [];
    for (const row of rows) {
      const operation = rowValue(row, 'OPERACION', 'OPERATION') || 'CREAR_CLIENTE';
      const typeDocument = rowValue(row, 'TIPO DOCUMENTO', 'TYPE DOCUMENT') || 'DNI';
      const docNumber = rowValue(row, 'NUMERO DOC', 'DOCUMENT NUMBER');
      const customerId = rowValue(row, 'CUSTOMER ID', 'CUSTOMER_ID');

      if (operation.includes('CUENTA') && operation.includes('CLIENTE')) {
        const clientExecution = normalizeDocumentType(typeDocument) === 'RUC'
          ? await this.createLegalPerson(row)
          : await this.postJson('CrearPersonaNaturalIFX', 'transaccion', prop(this.props, 'ifx.create-customer-path'), this.naturalPersonHeaders(), this.buildNaturalPersonBody(documentTypeId(typeDocument), docNumber || nextSequence(prop(this.props, 'ifx.dni-base', '54072013'), prop(this.props, 'ifx.dni-sequence-file', 'reports/sequences/dni-sequence.txt'), 8), row));
        executions.push(clientExecution);
        const clientGeneratedDoc = clientExecution.generatedDocuments?.[0]?.documentNumber || '';
        const resolvedDocNumber = docNumber || clientGeneratedDoc;
        executions.push(await this.createAccount(typeDocument, resolvedDocNumber, customerId || resolvedDocNumber || '', row));
      } else if (operation.includes('CUENTA')) {
        executions.push(await this.createAccount(typeDocument, docNumber, customerId, row));
      } else {
        executions.push(normalizeDocumentType(typeDocument) === 'RUC'
          ? await this.createLegalPerson(row)
          : await this.postJson('CrearPersonaNaturalIFX', 'transaccion', prop(this.props, 'ifx.create-customer-path'), this.naturalPersonHeaders(), this.buildNaturalPersonBody(documentTypeId(typeDocument), docNumber || nextSequence(prop(this.props, 'ifx.dni-base', '54072013'), prop(this.props, 'ifx.dni-sequence-file', 'reports/sequences/dni-sequence.txt'), 8), row)));
      }
    }

    return {
      operation: 'GenerateDataFromExcel',
      tokenType: 'transaccion',
      method: 'BATCH',
      url: `${dataDir}/${fileName}`,
      requestHeaders: {},
      requestBody: { rows: rows.length },
      responseStatus: executions.every(e => e.responseStatus >= 200 && e.responseStatus < 500) ? 200 : 500,
      responseHeaders: {},
      responseBody: JSON.stringify(executions, null, 2),
      parsedResponse: executions,
      busResponseMessage: '',
      srvResponseCode: '',
      srvResponseMessage: '',
      generatedDocuments: executions.flatMap(e => e.generatedDocuments || []),
      timestamp: new Date().toISOString()
    };
  }

  private async token(type: 'consulta' | 'transaccion'): Promise<string> {
    const scope = type === 'consulta'
      ? prop(this.props, 'ifx.consulta.scope', prop(this.props, 'ifx.scope-consulta'))
      : prop(this.props, 'ifx.transaccion.scope', prop(this.props, 'ifx.scope-transaccion'));

    const context = await request.newContext({ ignoreHTTPSErrors: true });
    const response = await context.post(`${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(prop(this.props, 'ifx.token-path'))}`, {
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      form: {
        grant_type: prop(this.props, 'ifx.grant-type', 'password'),
        username: prop(this.props, 'ifx.username'),
        password: prop(this.props, 'ifx.password'),
        client_id: prop(this.props, 'ifx.client-id'),
        client_secret: prop(this.props, 'ifx.client-secret'),
        scope
      }
    });
    const json = await response.json().catch(async () => ({ raw: await response.text() }));
    await context.dispose();
    if (!response.ok()) throw new Error(`No se pudo generar token ${type}. Status ${response.status()}: ${JSON.stringify(json)}`);
    return json.access_token;
  }

  private authorization(token: string, type: 'consulta' | 'transaccion'): string {
    const prefix = prop(this.props, `ifx.${type}.authorization-prefix`, prop(this.props, 'ifx.authorization-prefix', 'Bearer'));
    return prefix ? `${prefix} ${token}` : token;
  }

  private async postJson(operation: string, tokenType: 'consulta' | 'transaccion', pathValue: string, headers: Record<string, string>, body: unknown): Promise<ExecutionEvidence> {
    const accessToken = await this.token(tokenType);
    const url = `${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(pathValue)}`;
    const requestHeaders = { ...headers, authorization: this.authorization(accessToken, tokenType) };
    const context = await request.newContext({ ignoreHTTPSErrors: true });
    const response = await context.post(url, { headers: requestHeaders, data: body });
    const responseBody = await response.text();
    const evidence = this.toEvidence(operation, tokenType, 'POST', url, requestHeaders, body, response, responseBody);
    await context.dispose();
    return evidence;
  }

  private async getJson(operation: string, tokenType: 'consulta' | 'transaccion', pathValue: string, headers: Record<string, string>): Promise<ExecutionEvidence> {
    const accessToken = await this.token(tokenType);
    const url = `${cleanBaseUrl(prop(this.props, 'ifx.base-url'))}${pathJoin(pathValue)}`;
    const requestHeaders = { ...headers, authorization: this.authorization(accessToken, tokenType) };
    const context = await request.newContext({ ignoreHTTPSErrors: true });
    const response = await context.get(url, { headers: requestHeaders });
    const responseBody = await response.text();
    const evidence = this.toEvidence(operation, tokenType, 'GET', url, requestHeaders, undefined, response, responseBody);
    await context.dispose();
    return evidence;
  }

  private toEvidence(operation: string, tokenType: 'consulta' | 'transaccion', method: string, url: string, requestHeaders: Record<string, string>, requestBody: unknown, response: APIResponse, responseBody: string): ExecutionEvidence {
    let parsedResponse: unknown;
    try { parsedResponse = JSON.parse(responseBody); } catch { parsedResponse = responseBody; }

    const responseHeaders = response.headers();
    const busResponseMessage = this.headerValue(responseHeaders, 'busresponsemessage');
    const srvResponseCode = this.headerValue(responseHeaders, 'srvresponsecode');
    const srvResponseMessage = this.headerValue(responseHeaders, 'srvresponsemessage');

    this.printExecutionResponse(operation, response.status(), responseHeaders, responseBody);

    return {
      operation,
      tokenType,
      method,
      url,
      requestHeaders: this.maskSensitiveHeaders(requestHeaders),
      requestBody,
      responseStatus: response.status(),
      responseHeaders,
      responseBody,
      parsedResponse,
      busResponseMessage,
      srvResponseCode,
      srvResponseMessage,
      timestamp: new Date().toISOString()
    };
  }

  private headerValue(headers: Record<string, string>, headerName: string): string {
    const foundKey = Object.keys(headers).find(key => key.toLowerCase() === headerName.toLowerCase());
    return foundKey ? String(headers[foundKey] || '') : '';
  }

  private printExecutionResponse(operation: string, status: number, responseHeaders: Record<string, string>, responseBody: string): void {
    console.log('\n============================================================');
    console.log(`[IFX][${operation}] RESPONSE STATUS: ${status}`);
    console.log(`[IFX][${operation}] response.header.busresponsemessage: ${this.headerValue(responseHeaders, 'busresponsemessage')}`);
    console.log(`[IFX][${operation}] response.header.srvresponsecode: ${this.headerValue(responseHeaders, 'srvresponsecode')}`);
    console.log(`[IFX][${operation}] response.header.srvresponsemessage: ${this.headerValue(responseHeaders, 'srvresponsemessage')}`);
    console.log(`[IFX][${operation}] RESPONSE HEADERS:`);
    console.log(JSON.stringify(responseHeaders, null, 2));
    console.log(`[IFX][${operation}] RESPONSE BODY:`);
    console.log(responseBody || '<empty body>');
    console.log('============================================================\n');
  }

  private generateAndPersistRuc(operation: string, source: string, generatedDocuments: GeneratedDocumentRecord[]): string {
    const sequenceFile = prop(this.props, 'ifx.ruc-sequence-file', 'reports/sequences/ruc-sequence.txt');
    const csvFile = prop(this.props, 'ifx.generated-ruc-csv', 'reports/generated/ruc-generados.csv');
    const ruc = nextValidRuc20(prop(this.props, 'ifx.ruc-base', '20276135769'), sequenceFile);
    const record: GeneratedDocumentRecord = {
      timestamp: toLimaIsoTimestamp(new Date()),
      environment: prop(this.props, '__environment', prop(this.props, 'environment', 'uat')),
      documentType: 'RUC',
      documentNumber: ruc,
      operation,
      source,
      sequenceFile,
      csvFile
    };
    generatedDocuments.push(record);
    return ruc;
  }

  private maskSensitiveHeaders(headers: Record<string, string>): Record<string, string> {
    const masked = { ...headers };
    for (const key of Object.keys(masked)) {
      if (['authorization', 'ocp-apim-subscription-key', 'ocp-apim-subscription-secret'].includes(key.toLowerCase())) {
        masked[key] = masked[key] ? `${masked[key].slice(0, 12)}***` : '';
      }
    }
    return masked;
  }

  private naturalPersonHeaders(): Record<string, string> {
    return {
      accept: 'application/json',
      branchid: prop(this.props, 'ifx.branch-id', '100'),
      chanelid: prop(this.props, 'ifx.chanel-id', '16'),
      consumerid: prop(this.props, 'ifx.consumer-id', 'BPE'),
      'content-type': 'application/json',
      deviceid: prop(this.props, 'ifx.device-id', '192.135.183.250'),
      funcionalidadid: prop(this.props, 'ifx.funcionalidad-id', 'Funcionalidad IFX'),
      iporigen: prop(this.props, 'ifx.ip-origen', '192.135.183.200'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.parent-id', '11a7f97345'),
      timestamp: prop(this.props, 'ifx.timestamp', '2016-05-24T11:57:48.000Z'),
      traceid: prop(this.props, 'ifx.trace-id', '34338b0e6d2271c2345'),
      userid: prop(this.props, 'ifx.user-id', 'S7301'),
      'x-global-transaction-id': prop(this.props, 'ifx.global-transaction-id', '20160623152105')
    };
  }

  private consultationHeaders(): Record<string, string> {
    return {
      accept: 'application/json',
      consumerid: prop(this.props, 'ifx.consulta.consumer-id', 'BCV'),
      'content-type': 'application/json',
      funcionalidadid: prop(this.props, 'ifx.consulta.funcionalidad-id', 'funcionalidad01'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.consulta.parent-id', '53ce929d0e0e4736'),
      traceid: prop(this.props, 'ifx.consulta.trace-id', '53ce929d0e0e4736'),
      usertype: prop(this.props, 'ifx.consulta.user-type', 'F')
    };
  }

  private specialStatusHeaders(): Record<string, string> {
    return {
      accept: 'application/json',
      consumerid: prop(this.props, 'ifx.special-status.consumer-id', '7824164593336320'),
      'content-type': 'application/json',
      funcionalidadid: prop(this.props, 'ifx.special-status.funcionalidad-id', '2516899420176384'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: prop(this.props, 'ifx.special-status.parent-id', '3686228603961344'),
      traceid: prop(this.props, 'ifx.special-status.trace-id', '2359211902107648')
    };
  }

  private merchantHeaders(row: ExcelRow): Record<string, string> {
    return {
      accept: 'application/json',
      application: 'ASSI',
      branchid: '898',
      cardidtype: '1',
      channelid: '15',
      consumerid: '01',
      'content-type': 'application/json',
      countrycode: 'PE',
      deviceid: '130.30.20.80',
      funcionalidadid: 'funcionalidad01',
      groupmember: 'G0001',
      iporigen: '130.30.20.80',
      messageid: '20160623152105',
      moduloid: 'modcontacto',
      netid: 'BI',
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: '53ce929d0e0e4736',
      referencenumber: 'REF01092',
      serverid: 'server12',
      serviceid: 'BIP',
      supervisorid: 'S2058',
      timestamp: '2016-05-24T11:57:48.000Z',
      traceid: '53ce929d0e0e4736',
      userid: 'S23052',
      usertype: 'F'
    };
  }

  private accountHeaders(row: ExcelRow): Record<string, string> {
    return {
      accept: 'application/json',
      branchid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'BRANCHID')), valueOrDefault(prop(this.props, 'ifx.account.branch-id'), '100')),
      cardidtype: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CARDIDTYPE')), valueOrDefault(prop(this.props, 'ifx.account.card-id-type'), '1')),
      channelid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CHANNELID')), valueOrDefault(prop(this.props, 'ifx.account.channel-id'), '16')),
      consumerid: firstNonBlank(normalizeOptionalValue(rowValue(row, 'CONSUMERID')), valueOrDefault(prop(this.props, 'ifx.account.consumer-id'), 'BPE')),
      'content-type': 'application/json',
      countrycode: firstNonBlank(normalizeOptionalValue(rowValue(row, 'COUNTRYCODE')), valueOrDefault(prop(this.props, 'ifx.account.country-code'), 'PE')),
      deviceid: valueOrDefault(prop(this.props, 'ifx.account.device-id'), '192.135.183.250'),
      funcionalidadid: valueOrDefault(prop(this.props, 'ifx.account.funcionalidad-id'), 'Funcionalidad IFX'),
      iporigen: valueOrDefault(prop(this.props, 'ifx.account.ip-origen'), '192.135.183.200'),
      'ocp-apim-subscription-key': prop(this.props, 'ifx.subscription-key'),
      'ocp-apim-subscription-secret': prop(this.props, 'ifx.subscription-secret'),
      parentid: valueOrDefault(prop(this.props, 'ifx.account.parent-id'), '11a7f97345'),
      traceid: valueOrDefault(prop(this.props, 'ifx.account.trace-id'), '34338b0e6d2271c2345'),
      userid: valueOrDefault(prop(this.props, 'ifx.account.user-id'), 'S7301')
    };
  }

  private buildNaturalPersonBody(docTypeId: string, docNumber: string, row: ExcelRow): unknown {
    return {
      documentTypeId: docTypeId,
      documentNumber: docNumber,
      passportNumber: '42800711313',
      birthDate: '1980-12-12T00:00:00.000Z',
      firstLastName: rowValue(row, 'FIRST LAST NAME', 'APELLIDO PATERNO') || 'Zaciga',
      secondLastName: rowValue(row, 'SECOND LAST NAME', 'APELLIDO MATERNO') || 'Puen',
      firstName: rowValue(row, 'FIRST NAME', 'NOMBRE') || 'Wils',
      secondName: rowValue(row, 'SECOND NAME', 'SEGUNDO NOMBRE') || 'Giovan',
      genderType: 'M', maritalStatus: 'S', nationalityCode: '1', birthCountryCode: '4029', residentCountryCode: '4029', nationalityCountryCode: '4029',
      streetType: 'AV', streetName: 'SAN FRANCISCO', streetNumber: '7', blockIdentification: '1', lotId: '1', insideId: '1', urbanizationName: 'URUBAMBA',
      locationReference: 'AL FRENTE DE RESTAURANT', department: 'LIMA', province: 'LIMA', district: 'LINCE',
      phoneAddress: [
        { phoneType: 'C', phonePrefix: '051', phoneNumber: rowValue(row, 'PHONE') || '921602513', extension: '123' },
        { phoneType: 'C', phonePrefix: '051', phoneNumber: rowValue(row, 'PHONE') || '921602513', extension: '123' }
      ],
      emailType: 'P', email: rowValue(row, 'EMAIL') || `wils${docNumber}@gmail.com`, ciiuCode: '', employmentDate: '', companyName: 'SYNOPSYS', ocupationCode: 'PRF'
    };
  }

  private buildLegalPersonBody(docTypeId: string, docNumber: string, row: ExcelRow): unknown {
    return {
      documentTypeId: docTypeId,
      documentNumber: docNumber,
      codFuente: firstNonBlank(
        normalizeOptionalValue(rowValue(row, 'COD FUENTE', 'CODFUENTE', 'SOURCE_CODE')),
        prop(this.props, 'ifx.merchant.source-code', 'VCL')
      ),
      accountsExecutiveId: '11126',
      countryCode: rowValue(row, 'COUNTRYCODE', 'COUNTRY CODE') || prop(this.props, 'ifx.merchant.body-country-code', '2023'),
      company: {
        companyName: rowValue(row, 'COMPANY NAME', 'RAZON SOCIAL') || 'ARICA',
        constitutionDate: '20101204',
        economicActivityCode: rowValue(row, 'ECONOMICACTIVITYCODE', 'ECONOMIC ACTIVITY CODE') || prop(this.props, 'ifx.merchant.economic-activity-code', '1520'),
        economicGroupCode: '0001', mainActivity: 'Prestampos', tradeName: 'Caja Arequipa', companyNameAcronym: 'Arequipa',
        societyType: rowValue(row, 'SOCIETYTYPE', 'SOCIETY TYPE') || prop(this.props, 'ifx.merchant.society-type', 'EIRL'),
        profitFlag: 'Y', businessMagnitude: '1'
      },
      standardizedAddress: {
        streetType: 'JR', streetName: 'Catalino Miranda', streetNumber: '154', blockIdentification: '1', lotNumber: '154', insideNumber: '1',
        urbanization: 'Barranco', landmark: 'Altura Javier Prado', department: 'Lima', province: 'Lima', district: 'Barranco'
      },
      contact: {
        phoneAddress: { useCode: 'C', prefix: '051', phoneNumber: '909298641', extension: '12345' },
        electronicAddress: { useCode: 'T', emailAddress: rowValue(row, 'EMAIL') || 'JDEVELOPER@NET.COM.PE' }
      }
    };
  }

  private buildCreateAccountBody(docTypeId: string, docNumber: string, customerId: string, row: ExcelRow): unknown {
    return {
      accountOpeningType: rowValue(row, 'ACCOUNT OPENING TYPE') || '01',
      appCode: rowValue(row, 'APP CODE') || 'ST', bankId: '03', productCode: rowValue(row, 'PRODUCT CODE') || '002', subProductCode: rowValue(row, 'SUB PRODUCT CODE') || '223',
      currencyCode: rowValue(row, 'CURRENCY CODE') || '002', termType: 'M', termTime: 2, blockedAccountFlag: 'S', investmentFoundType: 20, netCode: 'BI', annualRate: 2.01,
      functionaryId: '', sellerId: '', agency: '200', conector: 'IND', debitCard: { locateCard: 'S', validateFlag: 'N' }, accountNumber: '',
      customer: [{ order: 2, customerId, newCardFlag: 'S', cardId: '411074******3333' }],
      person: { documentTypeId: docTypeId, documentNumber: docNumber, personType: '', emailAddress: rowValue(row, 'EMAIL') || 'davde@hotmail.com' }
    };
  }
}
