import fs from 'fs';
import os from 'os';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

export type Properties = Record<string, string>;

function parseProperties(content: string): Properties {
  const result: Properties = {};
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const index = line.indexOf('=');
    if (index < 0) continue;
    const key = line.substring(0, index).trim();
    const value = line.substring(index + 1).trim();
    result[key] = value;
  }
  return result;
}

function resolvePlaceholders(value: string, props: Properties): string {
  let resolved = value;
  for (let i = 0; i < 8 && resolved.includes('${'); i++) {
    resolved = resolved.replace(/\$\{([^}]+)\}/g, (_, key: string) => {
      const envKey = key.toUpperCase().replace(/[.-]/g, '_');
      return props[key] ?? process.env[envKey] ?? process.env[key] ?? '';
    });
  }
  return resolved;
}

export function loadProperties(environment: string): Properties {
  const env = environment || process.env.ENVIRONMENT || 'uat';
  const localPath = path.join(os.homedir(), `application-${env}.properties`);
  const configPath = path.resolve(process.cwd(), `config/application-${env}.properties`);
  const examplePath = path.resolve(process.cwd(), `config/application-${env}.properties.example`);

  let selected = '';
  if (fs.existsSync(localPath)) selected = localPath;
  else if (fs.existsSync(configPath)) selected = configPath;
  else if (fs.existsSync(examplePath)) selected = examplePath;

  if (!selected) {
    throw new Error(`No se encontró application-${env}.properties. Copia config/application-${env}.properties.example a ${localPath}`);
  }

  const props = parseProperties(fs.readFileSync(selected, 'utf-8'));
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) props[key] = value;
  }

  const resolved: Properties = {};
  for (const [key, value] of Object.entries(props)) {
    resolved[key] = resolvePlaceholders(value, props);
  }
  resolved.__configFile = selected;
  resolved.__environment = env;
  return resolved;
}

export function prop(props: Properties, key: string, defaultValue = ''): string {
  const envKey = key.toUpperCase().replace(/[.-]/g, '_');
  return process.env[envKey] || props[key] || defaultValue;
}
