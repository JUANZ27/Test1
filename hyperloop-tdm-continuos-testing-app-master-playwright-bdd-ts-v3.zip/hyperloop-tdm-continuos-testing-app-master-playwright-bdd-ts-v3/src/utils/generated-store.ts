import fs from 'fs';
import path from 'path';

export interface GeneratedDocumentRecord {
  timestamp: string;
  environment: string;
  documentType: 'RUC' | 'DNI' | string;
  documentNumber: string;
  operation: string;
  source: string;
  sequenceFile: string;
  csvFile: string;
  responseStatus?: number;
  busResponseMessage?: string;
  srvResponseCode?: string;
}

function csvEscape(value: unknown): string {
  const raw = String(value ?? '');
  if (/[",\n\r;]/.test(raw)) return `"${raw.replace(/"/g, '""')}"`;
  return raw;
}

export function appendGeneratedDocument(record: GeneratedDocumentRecord): void {
  const filePath = path.resolve(process.cwd(), record.csvFile);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });

  const header = [
    'timestamp',
    'environment',
    'documentType',
    'documentNumber',
    'operation',
    'source',
    'sequenceFile',
    'responseStatus',
    'busResponseMessage',
    'srvResponseCode'
  ];
  const row = [
    record.timestamp,
    record.environment,
    record.documentType,
    record.documentNumber,
    record.operation,
    record.source,
    record.sequenceFile,
    record.responseStatus ?? '',
    record.busResponseMessage ?? '',
    record.srvResponseCode ?? ''
  ];

  if (!fs.existsSync(filePath) || fs.readFileSync(filePath, 'utf-8').trim().length === 0) {
    fs.writeFileSync(filePath, `${header.join(';')}\n`, 'utf-8');
  } else {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split(/\r?\n/);
    const existingHeader = (lines[0] || '').trim();
    const expectedHeader = header.join(';');

    if (existingHeader && existingHeader !== expectedHeader) {
      const existingColumns = existingHeader.split(';');
      const migratedRows = lines
        .slice(1)
        .filter(line => line.trim().length > 0)
        .map(line => {
          const values = line.split(';');
          const mapped: Record<string, string> = {};
          for (let i = 0; i < existingColumns.length; i++) {
            mapped[existingColumns[i]] = values[i] || '';
          }
          return header.map(column => mapped[column] || '').join(';');
        });

      fs.writeFileSync(filePath, `${expectedHeader}\n${migratedRows.join('\n')}${migratedRows.length ? '\n' : ''}`, 'utf-8');
    }
  }
  fs.appendFileSync(filePath, `${row.map(csvEscape).join(';')}\n`, 'utf-8');
}
