import fs from 'fs';
import path from 'path';

export function nextSequence(base: string, filePath: string, width: number): string {
  const resolvedPath = path.resolve(process.cwd(), filePath);
  fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });
  let last = Number(base) - 1;
  if (fs.existsSync(resolvedPath)) {
    const raw = fs.readFileSync(resolvedPath, 'utf-8').trim();
    if (raw) last = Number(raw);
  }
  const next = last + 1;
  fs.writeFileSync(resolvedPath, String(next), 'utf-8');
  return String(next).padStart(width, '0');
}

function onlyDigits(value: string): string {
  return (value || '').replace(/\D/g, '');
}

function rucCheckDigit(base10Digits: string): number {
  const factors = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += Number(base10Digits[i]) * factors[i];
  }
  const diff = 11 - (sum % 11);
  if (diff === 10) return 0;
  if (diff === 11) return 1;
  return diff;
}

export function nextValidRuc20(baseRuc: string, filePath: string): string {
  const resolvedPath = path.resolve(process.cwd(), filePath);
  fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

  const baseDigits = onlyDigits(baseRuc);
  const baseBody = (baseDigits.length >= 10 ? baseDigits.slice(2, 10) : baseDigits).padStart(8, '0').slice(-8);

  let lastBody = Number(baseBody) - 1;
  if (fs.existsSync(resolvedPath)) {
    const raw = onlyDigits(fs.readFileSync(resolvedPath, 'utf-8').trim());
    if (raw.length >= 10 && raw.startsWith('20')) {
      lastBody = Number(raw.slice(2, 10));
    } else if (raw.length >= 8) {
      lastBody = Number(raw.slice(-8));
    }
  }

  const nextBody = (lastBody + 1) % 100000000;
  const base10 = `20${String(nextBody).padStart(8, '0')}`;
  const check = rucCheckDigit(base10);
  const ruc = `${base10}${check}`;

  fs.writeFileSync(resolvedPath, ruc, 'utf-8');
  return ruc;
}

