import { Given, When, Then } from '@cucumber/cucumber';
import assert from 'assert';
import { CustomWorld } from '../../support/world';
import { loadProperties, prop } from '../../utils/properties';
import { IfxClient } from '../../services/ifx-client';

function client(world: CustomWorld): IfxClient {
  if (!world.props) world.props = loadProperties(world.environment);
  return new IfxClient(world.props);
}

Given('que uso el ambiente {string}', function (this: CustomWorld, environment: string) {
  this.environment = environment;
  this.props = loadProperties(environment);
});

When('ejecuto Crear Persona Natural IFX con tipo documento {string}', async function (this: CustomWorld, typeDocument: string) {
  this.addEvidence(await client(this).createNaturalPerson(typeDocument));
});

When('ejecuto Consulta Cliente IFX con tipo documento {string} y numero documento {string}', async function (this: CustomWorld, typeDocument: string, documentNumber: string) {
  this.addEvidence(await client(this).retrieveCustomer(typeDocument, documentNumber));
});

When('ejecuto Consulta Customer Special Status CCE con documentTypeId {string} y documentNumber {string}', async function (this: CustomWorld, documentTypeId: string, documentNumber: string) {
  this.addEvidence(await client(this).retrieveCustomerSpecialStatus(documentTypeId, documentNumber));
});

When('ejecuto Crear Cliente PJ IFX con RUC dinamico societyType {string} countryCode {string} economicActivityCode {string}', async function (this: CustomWorld, societyType: string, countryCode: string, economicActivityCode: string) {
  this.addEvidence(await client(this).createLegalPerson({
    SOCIETYTYPE: societyType,
    COUNTRYCODE: countryCode,
    ECONOMICACTIVITYCODE: economicActivityCode
  }));
});

When('ejecuto Crear Cuenta IFX con tipo documento {string} numero documento {string} y customerId {string}', async function (this: CustomWorld, typeDocument: string, documentNumber: string, customerId: string) {
  this.addEvidence(await client(this).createAccount(typeDocument, documentNumber, customerId));
});

When('ejecuto GenerateDataFromExcel con data {string} y file {string}', async function (this: CustomWorld, dataDir: string, fileName: string) {
  this.addEvidence(await client(this).generateDataFromExcel(dataDir, fileName));
});

Then('la respuesta HTTP debe ser exitosa o aceptada por el ambiente', function (this: CustomWorld) {
  assert.ok(this.evidences.length > 0, 'No existen evidencias de ejecución');

  const allowed5xxByOperation = prop(this.props || {}, 'ifx.allowed-5xx-operations', '')
    .split(',')
    .map(v => v.trim())
    .filter(Boolean);

  const invalid = this.evidences.filter(e => {
    if (e.responseStatus < 200) return true;
    if (e.responseStatus < 500) return false;
    return !allowed5xxByOperation.includes(e.operation);
  });

  assert.deepStrictEqual(invalid.map(e => ({ operation: e.operation, status: e.responseStatus, body: e.responseBody })), []);
});

Then('se adjunta el request, response y headers al reporte', function (this: CustomWorld) {
  assert.ok(this.evidences.length > 0, 'No existen evidencias para adjuntar');
  for (const evidence of this.evidences) {
    assert.ok(evidence.responseHeaders, `No hay response headers para ${evidence.operation}`);
    assert.ok(typeof evidence.responseBody === 'string', `No hay response body para ${evidence.operation}`);
  }
});
