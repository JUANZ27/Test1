# language: es
Característica: Operaciones IFX TDM con Playwright API
  Como automatizador QA
  Quiero ejecutar operaciones IFX usando Playwright, TypeScript y Cucumber
  Para obtener evidencias HTML con request, response y headers

  Antecedentes:
    Dado que uso el ambiente "uat"

  @CrearPersonaNaturalIFX @transaccion @pn
  Escenario: Crear persona natural IFX con token transaccional
    Cuando ejecuto Crear Persona Natural IFX con tipo documento "DNI"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

  @ConsultaClienteIFX @consulta @full
  Escenario: Consultar cliente full information IFX con token de consulta
    Cuando ejecuto Consulta Cliente IFX con tipo documento "DNI" y numero documento "40903462"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

  @ConsultaCustomerSpecialStatusCCE @consulta @cce
  Escenario: Consultar CCE Customer Special Status con token de consulta
    Cuando ejecuto Consulta Customer Special Status CCE con documentTypeId "1" y documentNumber "40975592"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

  @CrearClientePJIFX @transaccion @pj
  Escenario: Crear cliente persona juridica IFX con token transaccional
    Cuando ejecuto Crear Cliente PJ IFX con RUC dinamico societyType "EIRL" countryCode "2023" economicActivityCode "1520"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

  @CrearCuentaIFX @transaccion @cuenta
  Escenario: Crear cuenta IFX con token transaccional
    Cuando ejecuto Crear Cuenta IFX con tipo documento "DNI" numero documento "40903462" y customerId "00000062331644"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte

  @GenerateDataFromExcel @transaccion @excel
  Escenario: Generar datos desde archivo Excel PN PJ y cuentas
    Cuando ejecuto GenerateDataFromExcel con data "Data" y file "CargaClientePNPJ.xlsx"
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request, response y headers al reporte
