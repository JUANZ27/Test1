import fs from 'fs';
import path from 'path';

function escapeHtml(value: string): string {
  return String(value || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function rel(p: string): string {
  return path.relative('reports/html', p).replace(/\\/g, '/');
}

const indexPath = 'reports/evidence/evidence-index.json';
fs.mkdirSync('reports/html', { recursive: true });

const items = fs.existsSync(indexPath) ? JSON.parse(fs.readFileSync(indexPath, 'utf-8')) : [];
const rows = items.map((item: any) => `
  <tr>
    <td>${escapeHtml(item.status)}</td>
    <td>${escapeHtml(item.scenario)}</td>
    <td>${item.evidences.map((e: any) => `
      <div class="op">
        <strong>${escapeHtml(e.operation)}</strong> ${escapeHtml(e.method)} status ${e.status}<br>
        <small>${escapeHtml(e.url)}</small><br>
        <small><b>busresponsemessage:</b> ${escapeHtml(e.busResponseMessage || '')}</small><br>
        <small><b>srvresponsecode:</b> ${escapeHtml(e.srvResponseCode || '')}</small><br>
        <small><b>srvresponsemessage:</b> ${escapeHtml(e.srvResponseMessage || '')}</small>
        ${e.generatedDocuments?.length ? `<br><small><b>Generados:</b> ${escapeHtml(e.generatedDocuments.map((d: any) => `${d.documentType} ${d.documentNumber}`).join(', '))}</small>` : ''}
      </div>`).join('')}</td>
    <td><a href="${rel(item.htmlFile)}">Ver request/response/headers</a></td>
    <td>${item.screenshotFile ? `<a href="${rel(item.screenshotFile)}">Screenshot</a>` : ''}</td>
    <td>${item.videoFile ? `<a href="${rel(item.videoFile)}">Video</a>` : ''}</td>
  </tr>`).join('\n');

const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Reporte IFX Playwright BDD</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f8fafc; padding: 24px; color: #0f172a; }
    h1 { margin-bottom: 4px; }
    table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 1px 8px #0001; }
    th { background: #123c69; color: white; text-align: left; padding: 10px; }
    td { border-bottom: 1px solid #e2e8f0; padding: 10px; vertical-align: top; }
    a { color: #005bbb; font-weight: 600; }
    small { color: #475569; }
    .op { margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px dashed #cbd5e1; }
  </style>
</head>
<body>
  <h1>Reporte IFX Playwright + Cucumber BDD</h1>
  <p>Incluye request, request headers, request body, response headers, response body, busresponsemessage, srvresponsecode, srvresponsemessage, screenshots y videos.</p>
  <p><strong>RUC generados:</strong> se almacenan en <code>reports/generated/ruc-generados.csv</code>.</p>
  <table>
    <thead>
      <tr><th>Estado</th><th>Escenario</th><th>Operaciones</th><th>Detalle</th><th>Imagen</th><th>Video</th></tr>
    </thead>
    <tbody>${rows || '<tr><td colspan="6">No hay evidencias. Ejecuta npm test primero.</td></tr>'}</tbody>
  </table>
</body>
</html>`;

fs.writeFileSync('reports/html/index.html', html, 'utf-8');
fs.writeFileSync('reports/html/evidencias.html', html, 'utf-8');
console.log('Reporte generado en reports/html/index.html y reports/html/evidencias.html');
