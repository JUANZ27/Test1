import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import { Properties } from '../utils/properties';
import { ExecutionEvidence } from '../services/ifx-client';

export class CustomWorld extends World {
  environment = 'uat';
  props?: Properties;
  evidences: ExecutionEvidence[] = [];

  constructor(options: IWorldOptions) {
    super(options);
  }

  addEvidence(evidence: ExecutionEvidence): void {
    this.evidences.push(evidence);
  }
}

setWorldConstructor(CustomWorld);
