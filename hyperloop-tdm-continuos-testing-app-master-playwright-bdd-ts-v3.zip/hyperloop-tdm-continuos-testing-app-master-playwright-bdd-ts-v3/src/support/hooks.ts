import { After, Before, Status } from '@cucumber/cucumber';
import fs from 'fs';
import path from 'path';
import { chromium } from '@playwright/test';
import { CustomWorld } from './world';
import { loadProperties } from '../utils/properties';

function safeName(name: string): string {
  return name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 120);
}

function escapeHtml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function evidenceHtml(scenarioName: string, status: string, evidences: any[]): string {
  const cards = evidences.map((evidence, index) => `
    <section class="card">
      <h2>${index + 1}. ${escapeHtml(evidence.operation)} <span>${escapeHtml(evidence.method)}</span></h2>
      <p><strong>Token:</strong> ${escapeHtml(evidence.tokenType)} | <strong>Status:</strong> ${evidence.responseStatus}</p>
      <p><strong>URL:</strong> ${escapeHtml(evidence.url)}</p>
      <div class="headers-resumen">
        <p><strong>response.header.busresponsemessage:</strong> ${escapeHtml(evidence.busResponseMessage || '')}</p>
        <p><strong>response.header.srvresponsecode:</strong> ${escapeHtml(evidence.srvResponseCode || '')}</p>
        <p><strong>response.header.srvresponsemessage:</strong> ${escapeHtml(evidence.srvResponseMessage || '')}</p>
      </div>
      ${evidence.generatedDocuments?.length ? `<h3>Documentos generados</h3><pre>${escapeHtml(JSON.stringify(evidence.generatedDocuments, null, 2))}</pre>` : ''}
      <h3>Request headers</h3><pre>${escapeHtml(JSON.stringify(evidence.requestHeaders, null, 2))}</pre>
      <h3>Request body</h3><pre>${escapeHtml(JSON.stringify(evidence.requestBody ?? {}, null, 2))}</pre>
      <h3>Response headers</h3><pre>${escapeHtml(JSON.stringify(evidence.responseHeaders, null, 2))}</pre>
      <h3>Response body</h3><pre>${escapeHtml(evidence.responseBody || '')}</pre>
    </section>`).join('\n');

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>${escapeHtml(scenarioName)}</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; color: #1f2937; padding: 24px; }
    h1 { color: #0f172a; }
    .card { background: white; border-radius: 12px; padding: 18px; margin: 18px 0; box-shadow: 0 2px 10px #0001; }
    h2 { color: #123c69; margin-top: 0; }
    h2 span { font-size: 12px; background: #e0f2fe; padding: 4px 8px; border-radius: 999px; }
    pre { white-space: pre-wrap; overflow-wrap: anywhere; background: #0b1220; color: #d7e3f4; padding: 14px; border-radius: 8px; font-size: 12px; }
    .headers-resumen { background: #ecfeff; border-left: 4px solid #0891b2; padding: 8px 12px; border-radius: 8px; margin: 10px 0; }
    .headers-resumen p { margin: 4px 0; }
    .status { display: inline-block; padding: 6px 10px; border-radius: 999px; background: ${status === 'PASSED' ? '#dcfce7' : '#fee2e2'}; }
  </style>
</head>
<body>
  <h1>${escapeHtml(scenarioName)}</h1>
  <p class="status">${escapeHtml(status)}</p>
  ${cards || '<p>No se registraron evidencias.</p>'}
</body>
</html>`;
}

Before(function (this: CustomWorld) {
  this.environment = process.env.ENVIRONMENT || process.env.env || 'uat';
  this.props = loadProperties(this.environment);
});

After(async function (this: CustomWorld, scenario) {
  fs.mkdirSync('reports/evidence', { recursive: true });
  fs.mkdirSync('reports/screenshots', { recursive: true });
  fs.mkdirSync('reports/videos', { recursive: true });
  fs.mkdirSync('reports/html/scenarios', { recursive: true });

  const name = safeName(scenario.pickle.name);
  const status = scenario.result?.status === Status.PASSED ? 'PASSED' : 'FAILED';
  const evidenceFile = path.resolve('reports/evidence', `${name}.json`);
  const htmlFile = path.resolve('reports/html/scenarios', `${name}.html`);
  const screenshotFile = path.resolve('reports/screenshots', `${name}.png`);

  fs.writeFileSync(evidenceFile, JSON.stringify({ scenario: scenario.pickle.name, status, evidences: this.evidences }, null, 2), 'utf-8');
  fs.writeFileSync(htmlFile, evidenceHtml(scenario.pickle.name, status, this.evidences), 'utf-8');

  this.attach(JSON.stringify(this.evidences, null, 2), 'application/json');

  let finalVideo = '';
  try {
    const browser = await chromium.launch();
    const context = await browser.newContext({ recordVideo: { dir: 'reports/videos', size: { width: 1280, height: 720 } } });
    const page = await context.newPage();
    await page.setContent(fs.readFileSync(htmlFile, 'utf-8'), { waitUntil: 'domcontentloaded' });
    await page.screenshot({ path: screenshotFile, fullPage: true });
    await page.close();
    await context.close();
    await browser.close();

    const videoFiles = fs.readdirSync('reports/videos').filter(f => f.endsWith('.webm')).map(f => path.join('reports/videos', f));
    const lastVideo = videoFiles.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0];
    finalVideo = lastVideo ? path.join('reports/videos', `${name}.webm`) : '';
    if (lastVideo && lastVideo !== finalVideo) fs.renameSync(lastVideo, finalVideo);
  } catch (error) {
    // No bloquear el escenario si faltan binarios o hay problemas TLS al instalar browser.
    console.warn(`[WARN][After] No se pudo generar screenshot/video: ${error instanceof Error ? error.message : String(error)}`);
  }

  const indexFile = 'reports/evidence/evidence-index.json';
  const index = fs.existsSync(indexFile) ? JSON.parse(fs.readFileSync(indexFile, 'utf-8')) : [];
  index.push({
    scenario: scenario.pickle.name,
    status,
    evidenceFile: path.relative(process.cwd(), evidenceFile),
    htmlFile: path.relative(process.cwd(), htmlFile),
    screenshotFile: path.relative(process.cwd(), screenshotFile),
    videoFile: finalVideo ? path.relative(process.cwd(), finalVideo) : '',
    evidences: this.evidences.map(e => ({
      operation: e.operation,
      method: e.method,
      url: e.url,
      status: e.responseStatus,
      tokenType: e.tokenType,
      busResponseMessage: e.busResponseMessage,
      srvResponseCode: e.srvResponseCode,
      srvResponseMessage: e.srvResponseMessage,
      generatedDocuments: e.generatedDocuments || []
    }))
  });
  fs.writeFileSync(indexFile, JSON.stringify(index, null, 2), 'utf-8');
});
