@FlujoCnPj
Feature: Creacion de CN para PJ

  @VerificacionDeRuc
  Scenario Outline: Creacion de CN para empresa constituida y dni cliente
    Given que Cesar quiere verificar si el ruc esta constituido
    When consulta el servicio con ruc <RUC>
    And consulta el dni <DNI>
    Then se debería crear las cuentas exitosamente

    Examples:
      | RUC         | DNI      |
      | 20563938201 | 74822033 |
      | 20521312603 | 99800001 |
