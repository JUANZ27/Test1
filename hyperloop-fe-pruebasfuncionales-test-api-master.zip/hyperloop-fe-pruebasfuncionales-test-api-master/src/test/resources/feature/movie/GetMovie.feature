@BuscarPeliculas
 Feature: Listar Peliculas

   @test1
   Scenario: Listar todas las peliculas
     Given que Cesar quiere saber las peliculas en cartelera
     When busca las peliculas
     Then deberia encontrar todas las peliculas exitosamente