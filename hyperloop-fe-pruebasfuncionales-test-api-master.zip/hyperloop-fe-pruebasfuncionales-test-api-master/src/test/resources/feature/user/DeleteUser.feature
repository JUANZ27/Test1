@regresion
@TXDM-106
@EliminarUsuario
Feature: Borrar Usuario

  @TXDM-72
  Scenario: Eliminar un usuario por Id
    Given que el administrador Carlos tiene los permisos para borrar un usuario
    And va a eliminar el registro del usuario Guillermo con el cargo Developer
    When elimina al usuario
    Then la informacion del usuario debería eliminarse correctamente
