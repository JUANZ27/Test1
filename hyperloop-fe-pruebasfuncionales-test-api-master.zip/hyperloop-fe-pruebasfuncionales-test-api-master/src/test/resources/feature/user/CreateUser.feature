@TXDM-106
@RegistrarUsuario
Feature: Registrar usuario

  @TXDM-53 @regresion
  Scenario Outline: Registrar nuevo usuario
    Given Administrador tiene los permisos para registrar un nuevo usuario
    When se registra un usuario nuevo con <Nombre> y <Cargo>
    Then el usuario debería registrarse correctamente
    # And el Administrador debería visualizar el usuario <Nombre> registrado
    Examples:
      | Nombre | Cargo |
      | Mariza | Leader |

  Scenario: Registrar usuario existente
    Given Joham tiene los permisos para registrar un nuevo usuario
    When se registra un usuario existente 111
    Then el usuario no debería ser creado