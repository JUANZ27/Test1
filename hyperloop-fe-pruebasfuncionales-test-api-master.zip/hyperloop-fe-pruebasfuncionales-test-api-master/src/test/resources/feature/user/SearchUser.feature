@TXDM-106
@BuscarUsuario
Feature: Buscar Usuario

  @TXDM-69 @regresion
  Scenario: Búsqueda de todos los usuarios
    Given Carlos tiene los permisos para buscar un usuario
    When Filtro todos los usuarios en la busqueda
    Then se listaron correctamente todos los usuarios

  @TXDM-70 @regresion
  Scenario Outline: Búsqueda de un usuario por Id
    Given Administrador tiene los permisos para buscar un usuario
    When se busca al usuario <Usuario>
    Then se debería encontrar exitosamente al usuario
    Examples:
      | Usuario |
      | 2       |

  @TXDM-71 @regresion
  Scenario Outline: Búsqueda de un usuario inexistente
    Given Administrador tiene los permisos para buscar un usuario
    When se busca al usuario <Usuario>
    Then no se debería encontrar el usuario buscado
    Examples:
      | Usuario |
      | 23      |