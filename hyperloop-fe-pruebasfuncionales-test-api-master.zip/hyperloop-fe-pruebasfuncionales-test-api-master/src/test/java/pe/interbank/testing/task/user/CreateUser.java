package pe.interbank.testing.task.user;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.model.User;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class CreateUser implements Task{

    private final User newUser;
    private static final Logger LOGGER = LoggerFactory.getLogger(CreateUser.class);

    public CreateUser(User newUser) {
        this.newUser = newUser;
    }

    public static CreateUser byUserId(User newUser) {
        return instrumented(CreateUser.class,newUser);
    }

    @Override
    @Step("{0} create a user")
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                      Post.to(Endpoint.API_CREATE_USER.getEndpoint())
                        .with(requestSpecification -> requestSpecification.body(newUser))
        );

        LOGGER.info("RESPONSE\n" + SerenityRest.lastResponse().body().prettyPrint());

    }



}
