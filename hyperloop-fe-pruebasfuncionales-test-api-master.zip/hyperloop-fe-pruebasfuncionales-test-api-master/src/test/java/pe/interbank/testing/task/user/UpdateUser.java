package pe.interbank.testing.task.user;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Put;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.model.User;
import pe.interbank.testing.util.JavaUtil;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class UpdateUser implements Task{

    private static final String TEMPLATE_UPDATE_USER = "/template/api/user/updateUser.json";
    private final User updateUser;
    private final String userId;


    public UpdateUser(String userId,User updateUser) {
        this.userId=userId;
        this.updateUser = updateUser;
    }


    public static UpdateUser byUserId(String userId,User updateUser) {
        return instrumented(UpdateUser.class,userId,updateUser);
    }


    @Override
    @Step("{0} update a user")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Put.to(Endpoint.API_UPDATE_USER.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .pathParam("userId", userId)
                                .body(JavaUtil.getTemplate(TEMPLATE_UPDATE_USER)
                                        .replace("{name}", updateUser.getName())
                                        .replace("{job}", updateUser.getJob())
                                )
                        )
        );

    }


}
