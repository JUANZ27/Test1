package pe.interbank.testing.task.user;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class FindAll implements Task {


    public FindAll() {

    }


    public static FindAll AllUsers() {
        return instrumented(FindAll.class);
    }


    @Override
    @Step("{0} search all users")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Get.resource(Endpoint.API_GETALL_USER.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .queryParam("page", 2)
                        )
        );

    }

}
