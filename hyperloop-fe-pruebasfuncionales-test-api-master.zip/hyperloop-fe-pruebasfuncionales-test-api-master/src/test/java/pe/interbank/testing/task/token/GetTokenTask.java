package pe.interbank.testing.task.token;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GetTokenTask implements Task {
    public GetTokenTask(){}

    public static GetTokenTask token(){
        return instrumented(GetTokenTask.class);
    }

    @Override
    @Step("{0} get token")
    public < T extends Actor> void performAs (T actor){

        actor.attemptsTo(
                Post.to(Endpoint.API_TOKEN.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .contentType("application/x-www-form-urlencoded")
                                .header("Ocp-Apim-Subscription-Key","db7ceb620d3f492c9a88157a9a6cd8cb")
                                .header("Authorization","Basic QkNXOnBHR3djY3lkeDJmc3g0Tm0=")
                                .formParam("grant_type", "client_credentials")
                                .formParam("scope", "all")

                        )
        );

    }
}
