package pe.interbank.testing.stepdefinition.user;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.model.User;
import pe.interbank.testing.task.user.CreateUser;
import pe.interbank.testing.task.user.DeleteUser;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.user.CreateUserQuestion.userId;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_NO_CONTENT;
import static pe.interbank.testing.util.JavaUtil.generateRandomCode;

public class DeleteUserStepDefinition {

    @Steps
    BaseUrl base;

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }


    @Given("^que el administrador (.*) tiene los permisos para borrar un usuario$")
    public void administradorUtilizarElServicio(String actorName) {
        theActorCalled(actorName).whoCan(CallAnApi.at(base.getUrlRegresIn()));
    }

    @And("^va a eliminar el registro del usuario (.*) con el cargo (.*)$")
    public void adminCreateAUserForUpdate(String name, String job) {

        String genericName = generateRandomCode(name, 4);
        String genericJob = generateRandomCode(job, 4);

        theActorInTheSpotlight().attemptsTo(
                CreateUser.byUserId(new User(genericName, genericJob))
        );

        Serenity.setSessionVariable("userId").to(
                theActorInTheSpotlight().asksFor(userId())
        );
    }

    @When("^elimina al usuario$")
    public void eliminoUnUsuarioUsuario() {
        String userId = Serenity.sessionVariableCalled("userId");

        theActorInTheSpotlight().attemptsTo(
                DeleteUser.byUserId(userId)
        );
    }

    @Then("^la informacion del usuario debería eliminarse correctamente$")
    public void elUsuarioSeEliminoCorrectamente() {
        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_NO_CONTENT))
        );
    }
}
