package pe.interbank.testing.stepdefinition.movie;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import org.junit.Before;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.task.movies.GetAllMovies;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.core.IsEqual.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.*;

public class GetMovieStepDefinition {

    @Steps
    BaseUrl base;

    @Before
    public void setTheStage(){ OnStage.setTheStage(new OnlineCast()); }

    @Given("^que (.*) quiere saber las peliculas en cartelera$")
    public void givenActorWantsToKnowWhatMoviesAre(String actor){
        theActorCalled(actor).whoCan(CallAnApi.at(base.getGraphqlUrl()));
    }

    @When("busca las peliculas")
    public void buscaLasPeliculas() {
        theActorInTheSpotlight().attemptsTo(GetAllMovies.all());
        
    }

    @Then("deberia encontrar todas las peliculas exitosamente")
    public void deberiaEncontrarTodasLasPeliculasExitosamente() {
        String PATH_SCHEMA = "schema/movies/searchAllMovies.json";
        theActorInTheSpotlight().should(
                seeThat("HPTT CODE",httpStatusCode(),equalTo(404))
        );
//        theActorInTheSpotlight().should(
//                seeThat("the response",matchSchema(PATH_SCHEMA))
//        );
    }


}
