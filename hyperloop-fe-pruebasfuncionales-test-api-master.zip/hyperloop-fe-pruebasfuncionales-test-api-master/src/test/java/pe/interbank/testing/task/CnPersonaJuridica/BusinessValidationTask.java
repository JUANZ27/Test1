package pe.interbank.testing.task.CnPersonaJuridica;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.util.JavaUtil;

import java.util.Optional;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class BusinessValidationTask implements Task {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessValidationTask.class);

    private static final String TEMPLATE_GENERIC = "/template/graphql/genericWithVariables.json";
    private static final String PATH_QUERY = "/template/graphql/cnPersonaJuridica/query/businessValidationStep.graphql";
    private static final String PATH_VARIABLES = "/template/graphql/cnPersonaJuridica/variable/businessValidationStepVar.json";

    private final String Token;
    private final String Ruc;

    public BusinessValidationTask(String accessToken, String ruc){

        this.Token = accessToken;
        this.Ruc = ruc;
    }

    public static BusinessValidationTask validation(String accessToken,String ruc){
        return instrumented(BusinessValidationTask.class,accessToken, ruc);
    }

    @Override
    @Step("{0} validar ruc constitudo #RUC")
    public < T extends Actor> void performAs (T actor){
        String queryBusinessValidation = JavaUtil.getQuery(PATH_QUERY, Optional.empty());
        String variablesBusinessValidation = JavaUtil.getVariables(PATH_VARIABLES).replace("{ruc}",Ruc);
        actor.attemptsTo(
                Post.to(Endpoint.GRAPHQL_EXPERIENCE.getEndpoint())
                        .with(query -> query
                                .contentType(ContentType.JSON)
                                .header("Ocp-Apim-Subscription-Key","db7ceb620d3f492c9a88157a9a6cd8cb")
                                .header("Authorization",Token)
                                .body(JavaUtil.getTemplate(TEMPLATE_GENERIC)
                                        .replace("{operationName}","businessValidationStep")
                                        .replace("{query}",queryBusinessValidation)
                                        .replace("{variables}",variablesBusinessValidation)
                                )
                        )
        );
        //LOGGER.info("RESPONSE\n" + SerenityRest.lastResponse().body().prettyPrint());
    }
}
