package pe.interbank.testing.stepdefinition.user;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.model.User;
import pe.interbank.testing.task.user.CreateUser;
import pe.interbank.testing.task.user.UpdateUser;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.generic.CommonQuestion.matchSchema;
import static pe.interbank.testing.question.user.CreateUserQuestion.userId;
import static pe.interbank.testing.util.ApiCommon.STATUS_CODE_OK;
import static pe.interbank.testing.util.JavaUtil.generateRandomCode;

public class UpdateUserStepDefinition {

    @Steps
    BaseUrl base;

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }


    @Given("^que el administrador (.*) tiene los permisos para actualizar un usuario$")
    public void administradorUtilizarElServicio(String actorName) {
        theActorCalled(actorName).whoCan(CallAnApi.at(base.getUrlRegresIn()));
    }

    @And("^va a actualizar al usuario (.*) con el cargo (.*)$")
    public void adminCreateAUserForUpdate(String name, String job) {

        String genericName = generateRandomCode(name, 4);
        String genericJob = generateRandomCode(job, 4);

        theActorInTheSpotlight().attemptsTo(
                CreateUser.byUserId(new User(genericName, genericJob))
        );

        Serenity.setSessionVariable("userId").to(
                theActorInTheSpotlight().asksFor(userId())
        );
    }

    @When("^actualizo la información del usuario a (.*) y (.*)$")
    public void actualizoUnUsuarioConNombreYCargo(String newName, String newJob) {
        String userId = Serenity.sessionVariableCalled("userId");
        User updateUser = new User(newName, newJob);

        theActorInTheSpotlight().attemptsTo(
                UpdateUser.byUserId(userId, updateUser)
        );

    }

    @Then("^la informacion del usuario debería actualizarse correctamente$")
    public void elUsuarioSeActualizoCorrectamente() {
        String PATH_SCHEMA = "schema/user/updateUser.json";
        theActorInTheSpotlight().should(
                seeThat(httpStatusCode(), equalTo(STATUS_CODE_OK))
        );
        theActorInTheSpotlight().should(
                seeThat("The response match", matchSchema(PATH_SCHEMA))
        );
    }

}
