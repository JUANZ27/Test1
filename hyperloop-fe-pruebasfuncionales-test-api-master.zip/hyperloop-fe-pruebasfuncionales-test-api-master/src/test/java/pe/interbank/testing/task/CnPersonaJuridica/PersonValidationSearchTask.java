package pe.interbank.testing.task.CnPersonaJuridica;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.util.JavaUtil;

import java.util.Optional;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PersonValidationSearchTask implements Task {

    private static final Logger LOGGER = LoggerFactory.getLogger(PersonValidationSearchTask.class);

    private static final String TEMPLATE_GENERIC = "/template/graphql/genericWithVariables.json";
    private static final String PATH_QUERY = "/template/graphql/cnPersonaJuridica/query/personValidationSearchStep.graphql";
    private static final String PATH_VARIABLES = "/template/graphql/cnPersonaJuridica/variable/personValidationSearchStepVar.json";
    private final String Token;
    private final String Dni;

    public PersonValidationSearchTask(String accessToken,String dni){
        this.Token = accessToken;
        this.Dni = dni;
    }

    public static PersonValidationSearchTask validationPerson(String accessToken,String dni){
        return instrumented(PersonValidationSearchTask.class,accessToken,dni);
    }

    @Override
    @Step("{0} validar dni #DNI")
    public < T extends Actor> void performAs (T actor){
        String queryPersonValidation = JavaUtil.getQuery(PATH_QUERY, Optional.empty());
        String variablesPersonValidation = JavaUtil.getVariables(PATH_VARIABLES).replace("{dni}",Dni);
        actor.attemptsTo(
                Post.to(Endpoint.GRAPHQL_EXPERIENCE.getEndpoint())
                        .with(query -> query
                                .contentType(ContentType.JSON)
                                .header("Ocp-Apim-Subscription-Key","db7ceb620d3f492c9a88157a9a6cd8cb")
                                .header("Authorization",Token)
                                .body(JavaUtil.getTemplate(TEMPLATE_GENERIC)
                                        .replace("{operationName}","personValidationSearchStep")
                                        .replace("{query}",queryPersonValidation)
                                        .replace("{variables}",variablesPersonValidation)
                                )
                        )
        );
        //LOGGER.info("RESPONSE\n" + SerenityRest.lastResponse().body().prettyPrint());
    }

}
