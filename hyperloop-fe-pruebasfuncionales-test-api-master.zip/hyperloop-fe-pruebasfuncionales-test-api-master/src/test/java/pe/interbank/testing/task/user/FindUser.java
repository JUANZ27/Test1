package pe.interbank.testing.task.user;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class FindUser implements Task{

    private final String userId;

    public FindUser(String userId) {
        this.userId = userId;
    }


    public static FindUser byId(String userId) {
        return instrumented(FindUser.class, userId);
    }


    @Override
    @Step("{0} search a user by id #userId")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Get.resource(Endpoint.API_GET_USER_BY_ID.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .pathParam("userId",userId)
                        )
        );

    }


}
