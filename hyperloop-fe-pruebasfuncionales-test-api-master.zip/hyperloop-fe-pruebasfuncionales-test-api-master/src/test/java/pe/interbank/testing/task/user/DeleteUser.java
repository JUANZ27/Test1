package pe.interbank.testing.task.user;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Delete;
import net.thucydides.core.annotations.Step;
import pe.interbank.testing.endpoint.Endpoint;

import static net.serenitybdd.screenplay.Tasks.instrumented;
public class DeleteUser implements Task{

    private final String userId;


    public DeleteUser(String userId) {
        this.userId = userId;
    }


    public static DeleteUser byUserId(String userId) {
        return instrumented(DeleteUser.class,userId);
    }


    @Override
    @Step("{0} delete a user")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Delete.from(Endpoint.API_DELETE_USER.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .pathParam("userId",userId)
                        )
        );

    }

}
