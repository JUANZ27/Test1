Param(
	[Parameter(Mandatory = $false)]
  $num_iterations,$environment,$backend,$collection,
  [string[]]$collections
)

Write-Output $Env:BUILD_BUILDID
Write-Output $Env:BUILD_REASON

if ($collections.Count -eq 0)
{
  $collection = If ($collection.Trim() -eq '') {$backend} Else {$collection.Trim()};
  $collections = Get-ChildItem -Path "./collections/$backend" -Recurse -Exclude "$backend" -Include "*$collection*" -Attributes Directory -Name

  if(-not $collections) {
    Write-Output "##vso[task.setvariable variable=RUN_COLLECTIONS_STATUS]Failed"
    Write-Output "##vso[task.logissue type=error]Colección no encontrada"
    Write-Output "##vso[task.complete result=Failed;]La colección no existe."
    Exit
  }
}

Write-Output "collections to run: $collections"
foreach ($collectionName in $collections)
{
  $collectionPath = "./collections/$backend/$collectionName"
  $PathExist = Test-Path -Path  $collectionPath

  if($PathExist)
  {
    $collectionFiles = Get-ChildItem -Path $collectionPath -Recurse | Resolve-Path -Relative

    $collection = $collectionFiles | Where-Object {$_-Like "*collection.json"} | Select-Object -First 1
    $collectionEnvironment = Get-ChildItem -Path "./env" -Recurse | Resolve-Path -Relative | Where-Object {$_ -Like "*$environment"+".environment.json"} | Select-Object -First 1
    $collectionData = $collectionFiles | Where-Object {$_ -Like "*$environment"+".data.json"} | Select-Object -First 1

    $outputXmlFile = "./Results/" + $collectionName +"_testResults.xml"
    $outputHtmlFile = "./Html-Results/" + $collectionName +"_testResults.html"

    if($null -eq $collectionData){
      Write-Output "Starting newman run Command with collection $collectionName"
      "newman run $collection -e $collectionEnvironment -n $num_iterations --reporters cli,htmlextra,junit --reporter-junit-export $outputXmlFile --reporter-htmlextra-export $outputHtmlFile"

      newman run $collection -e $collectionEnvironment -n $num_iterations --reporters cli,htmlextra,junit --reporter-junit-export $outputXmlFile --reporter-htmlextra-export $outputHtmlFile
    } else {
      Write-Output "Starting newman run Command with collection $collectionName"
      "newman run $collection -e $collectionEnvironment -d $collectionData -n $num_iterations --reporters cli,htmlextra,junit --reporter-junit-export $outputXmlFile --reporter-htmlextra-export $outputHtmlFile"

      newman run $collection -e $collectionEnvironment -d $collectionData -n $num_iterations --reporters cli,htmlextra,junit --reporter-junit-export $outputXmlFile --reporter-htmlextra-export $outputHtmlFile
    }
    Write-Output "newman run Command finished"
  }
}
Write-Output "##vso[task.setvariable variable=RUN_COLLECTIONS_STATUS]Succeeded"

exit 0