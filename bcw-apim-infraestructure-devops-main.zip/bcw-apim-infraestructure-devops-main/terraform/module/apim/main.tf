resource "azurerm_api_management_api_version_set" "api_set" {
  name                = var.api.api_name
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  display_name        = var.api.display_name
  description         = var.api.description
  versioning_scheme   = var.versioning_scheme
}

resource "azurerm_api_management_api" "resource_api_management" {
  display_name        = var.api.display_name
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  revision            = var.api.revision
  version             = var.api.version_n
  name                = var.api.api_name
  path                = var.api.path
  protocols           = var.protocols
  service_url         = var.api.service_url
  version_set_id      = azurerm_api_management_api_version_set.api_set.id

  import {
    content_format = var.content_format
    content_value  = file(var.api.content_value)
  }
}

resource "azurerm_api_management_product_api" "product_api" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  for_each = toset( var.api.product )
  api_name            = var.api.api_name
  product_id          = each.value
  api_management_name = var.apimanagement_name
  resource_group_name = var.resourcegroup_name
}

resource "azurerm_api_management_api_policy" "api_policy" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  api_name            = var.api.api_name
  api_management_name = var.apimanagement_name
  resource_group_name = var.resourcegroup_name
  xml_content         = var.apimanagement_policy_xml_content
}

resource "azurerm_api_management_api_operation_policy" "operation_policy" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  for_each = {for i in try(var.api.operations_policy,{}) : i.operation_name => i}
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  api_name            = var.api.api_name
  operation_id        = each.value.operation_name
  xml_content         = each.value.policy_xml_content   
}
