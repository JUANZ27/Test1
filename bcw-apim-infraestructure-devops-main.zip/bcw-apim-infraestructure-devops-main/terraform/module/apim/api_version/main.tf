resource "azurerm_api_management_api" "resource_api_management" {
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  display_name        = var.api_version.display_name  
  revision            = var.api_version.revision
  version             = var.api_version.version
  name                = var.api_version.api_name
  description         = var.api_version.description
  path                = var.api_version.path
  protocols           = var.protocols
  service_url         = var.api_version.service_url
  version_set_id      = var.api_version.version_set_id
  
  import {
    content_format = var.content_format
    content_value  = file(var.api_version.swagger_content)
  }
}

resource "azurerm_api_management_api_policy" "api_policy" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  api_name            = var.api_version.api_name
  xml_content         = var.api_version.policy_xml_content
}

resource "azurerm_api_management_product_api" "product_api" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  for_each = toset( var.api_version.product )
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  api_name            = var.api_version.api_name
  product_id          = each.value
}

resource "azurerm_api_management_api_operation_policy" "operation_policy" {
  depends_on = [
    azurerm_api_management_api.resource_api_management
  ]
  for_each = {for i in try(var.api_version.operations_policy,{}) : i.operation_name => i}
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  api_name            = var.api_version.api_name
  operation_id        = each.value.operation_name
  xml_content         = each.value.policy_xml_content   
}
