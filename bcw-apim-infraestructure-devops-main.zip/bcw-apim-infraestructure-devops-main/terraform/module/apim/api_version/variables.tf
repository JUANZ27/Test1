variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "api_version" {}
variable "protocols" {default = ["https", "http"]}
variable "content_format" {default ="openapi"}