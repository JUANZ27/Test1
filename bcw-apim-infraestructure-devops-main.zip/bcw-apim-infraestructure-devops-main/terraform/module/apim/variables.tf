variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "apimanagement_policy_xml_content" {}
variable "api" {}
variable "protocols" {default = ["https", "http"]}
variable "content_format" {default ="openapi"}
variable "versioning_scheme" {default="Segment"}