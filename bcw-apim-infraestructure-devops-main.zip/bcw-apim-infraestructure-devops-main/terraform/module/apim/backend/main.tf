resource "azurerm_api_management_backend" "backend_api" {
  name                = var.name
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  protocol            = var.protocols
  url                 = var.url
  credentials {
    header = var.backend_headers
  }
}