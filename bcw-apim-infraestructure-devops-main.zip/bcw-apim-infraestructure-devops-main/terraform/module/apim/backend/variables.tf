variable "name" {}
variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "protocols" {default = "http"}
variable "url" {}
variable "backend_headers" {}