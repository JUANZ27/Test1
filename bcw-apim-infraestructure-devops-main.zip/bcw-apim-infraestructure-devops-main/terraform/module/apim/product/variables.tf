variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "product_id" {}
variable "display_name" {}
variable "subscription_required" {}
variable "approval_required" {}
variable "published" {}
variable "subscriptions_limit" {}

variable "product" {}