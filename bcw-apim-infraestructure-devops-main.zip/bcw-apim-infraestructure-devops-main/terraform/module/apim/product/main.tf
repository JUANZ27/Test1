resource "azurerm_api_management_product" "product" {
  resource_group_name     = var.resourcegroup_name
  api_management_name     = var.apimanagement_name
  product_id              = var.product_id
  display_name            = var.display_name
  subscription_required   = var.subscription_required
  approval_required       = var.approval_required
  published               = var.published
  subscriptions_limit     = var.subscriptions_limit
}

resource "azurerm_api_management_product_policy" "product_policy" {
  product_id          = var.product_id
  api_management_name = var.apimanagement_name
  resource_group_name = var.resourcegroup_name
  xml_content = var.product.policy_xml_content
}