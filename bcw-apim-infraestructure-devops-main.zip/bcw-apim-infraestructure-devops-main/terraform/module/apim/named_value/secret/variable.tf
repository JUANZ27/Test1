variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "display_name" {}
variable "value" {}
variable "name" {}