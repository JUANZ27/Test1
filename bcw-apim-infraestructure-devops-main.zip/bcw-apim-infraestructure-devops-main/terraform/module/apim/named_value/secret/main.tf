resource "azurerm_api_management_named_value" "apim_named_value_secret" {
  name                = var.name
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  display_name        = var.display_name
  value               = var.value
  secret              = true
}
