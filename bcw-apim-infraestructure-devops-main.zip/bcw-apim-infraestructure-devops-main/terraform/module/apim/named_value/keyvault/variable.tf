variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "display_name" {}
variable "name" {}
variable "secret_id" {}