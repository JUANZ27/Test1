variable "resourcegroup_name" {}
variable "apimanagement_name" {}
variable "api" {}
variable "versioning_scheme" {default="Segment"}
variable "protocols" {default = ["https", "http"]}
variable "content_format" {default ="openapi"}

output "api_set_id" {
  value = azurerm_api_management_api_version_set.api_set.id
}