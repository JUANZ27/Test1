#crear api management
 resource "azurerm_api_management_api_version_set" "api_set" {
  resource_group_name = var.resourcegroup_name
  api_management_name = var.apimanagement_name
  display_name        = var.api.display_name
  name                = var.api.api_name
  description         = var.api.description
  versioning_scheme   = var.versioning_scheme
}