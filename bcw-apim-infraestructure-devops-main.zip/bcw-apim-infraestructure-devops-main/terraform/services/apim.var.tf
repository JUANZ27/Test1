############################################################################################################
####################################    API Management - Named Values ######################################
############################################################################################################

variable "apimanagement_namedvalue_display_bcw_hypl_storage_account"{default = "bcw-hypl-storage-account-name"}
variable "apimanagement_namedvalue_name_bcw_hypl_storage_account"{default = "bcw-hypl-storage-account-name"}
variable "apimanagement_namedvalue_value_bcw_hypl_storage_account"{default = "__TERRAFORM_STORAGE_ACCOUNT__"}

variable "apimanagement_namedvalue_display_bcw_hypl_storage_account_02"{default = "bcw-hypl-storage-account-name-02"}
variable "apimanagement_namedvalue_name_bcw_hypl_storage_account_02"{default = "bcw-hypl-storage-account-name-02"}
variable "apimanagement_namedvalue_value_bcw_hypl_storage_account_02"{default = "__TERRAFORM_STORAGE_ACCOUNT_02__"}

variable "apimanagement_namedvalue_display_bcw_security_redirect_scope"{default = "bcw-hypl-security-policies-scope"}
variable "apimanagement_namedvalue_name_bcw_security_redirect_scope"{default = "bcw-hypl-security-policies-scope"}
variable "apimanagement_namedvalue_value_bcw_security_redirect_scope"{default = "__API_SECURITY_REDIRECT_POLICY_SCOPE__"}

variable "apimanagement_namedvalue_display_bcw_security_redirect_client_id"{default = "bcw-hypl-security-policies-client-id"}
variable "apimanagement_namedvalue_name_bcw_security_redirect_client_id"{default = "bcw-hypl-security-policies-client-id"}
variable "apimanagement_namedvalue_value_id_bcw_security_client_id"{default="__API_NAMEDVALUE_BCW_SECURITY_CLIENT_ID__"}

variable "apimanagement_namedvalue_display_bcw_security_redirect_secret"{default = "bcw-hypl-security-policies-secret"}
variable "apimanagement_namedvalue_name_bcw_security_redirect_secret"{default = "bcw-hypl-security-policies-secret"}
variable "apimanagement_namedvalue_value_id_bcw_security_secret"{default="__API_NAMEDVALUE_BCW_SECURITY_SECRET__"}

variable "apimanagement_namedvalue_display_bcw_security_basic_introspect"{default="bcw-hypl-security-policies-basic-introspect"}
variable "apimanagement_namedvalue_name_bcw_security_basic_introspect"{default="bcw-hypl-security-policies-basic-introspect"}
variable "apimanagement_namedvalue_value_id_bcw_basic_introspect"{default="__API_NAMEDVALUE_BCW_SECURITY_BASIC_INTROSPECT__"}

variable "apimanagement_namedvalue_display_bcw_assi_security_basic_checktoken"{default="bcw-assi-security-policies-basic-checktoken"}
variable "apimanagement_namedvalue_name_bcw_assi_security_basic_checktoken"{default="bcw-assi-security-policies-basic-checktoken"}
variable "apimanagement_namedvalue_value_id_bcw_assi_basic_checktoken"{default="__API_NAMEDVALUE_BCW_ASSI_SECURITY_BASIC_CHECKTOKEN__"}
############################################################################################################
############################################################################################################
############################################################################################################

##############################
# PRODUCT PRUEBA      #
##############################
variable "product_prueba_id"{default="bcw-prueba"}
variable "display_product_prueba_name"{default="bcw-prueba"} 

##############################
# PRODUCT BCW-HYPERLOOP      #
##############################
variable "product_id"{default="bcw-hyperloop"}
variable "display_product_name"{default="bcw-hyperloop"} 

##############################
# PRODUCT BCW-COMERCIAL      #
##############################
variable "bcw_hyperloop_comercial_product_id"{default="bcw-comercial"}
variable "bcw_hyperloop_comercial_display_product_name"{default="bcw-comercial"}

##############################
# PRODUCT BCW-CROSS      #
##############################
variable "bcw_hyperloop_cross_product_id"{default="bcw-cross"}
variable "bcw_hyperloop_cross_display_product_name"{default="bcw-cross"}

####################################
# API BCW HYPERLOOP SECURITY - SET #
####################################
variable "apimanagement_display_name_security"{default = "BCW Hyperloop Security"}
variable "apimanagement_api_name_security"{default = "bcw-hyperloop-security"}
variable "apimanagement_api_description_security"{default = "BCW Hyperloop Servicios de Seguridad"}
variable "apimanagement_backend_ingress" {default = "__SERVICE_APIMANAGEMENT_BACKEND_INGRESS__"}

####################################
# BACKEND BCW-COMMON-FUNCTION  - V1#
####################################

variable "apim_backend_bcw_common_function_backend_id"{default = "bcw-common-function"}
variable "apim_backend_bcw_common_function_backend_id_old"{default = "func-hyperloop-common-services"}
variable "apim_backend_bcw_common_function_url"{default = "__APIM_BACKEND_BCW_FACTORING_COMMONS_URL__"}

####################################
# BACKEND BCW-BULKLOAD-FUNCTION  - V1#
####################################

variable "apim_backend_bcw_bulkload_function_backend_id"{default = "bcw-bulkload-function"}
variable "apim_backend_bcw_bulkload_function_backend_id_old"{default = "func-hyperloop-bulkload"}
variable "apim_backend_bcw_bulkload_function_url"{default = "__APIM_BACKEND_BCW_FACTORING_BULKLOAD_URL__"}

####################################
# API BCW HYPERLOOP SECURITY - V1 #
####################################
variable "apimanagement_display_name_security_v1"{default = "BCW Hyperloop Security"}
variable "apimanagement_api_name_security_v1"{default = "bcw-hyperloop-security"}
variable "apimanagement_api_description_security_v1"{default = "BCW Hyperloop Servicios de Seguridad V1"}
variable "apimanagement_revision_security_v1"{default = "1"}
variable "apimanagement_version_security_v1"{default = "v1"}
variable "apimanagement_path_security_v1"{default = "bcw-hyperloop-security"}
variable "apimanagement_backend_path_security_v1"{default = "security"}
variable "apimanagement_product_security_v1"{default = ["hyperloop","bcw-cross"]}
variable "apimanagement_path_swagger_security_v1"{default = "./resources/api-management/swagger/hyperloop-security/bcw-hyperloop-security-redirect-v1.json"}




##################
# API BCW HYPERLOOP EXPERIENCE V1 #
##################
variable "apimanagement_display_name_hyperloop_experience"{default = "BCW Hyperloop Experience"}
variable "apimanagement_api_name_hyperloop_experience"{default = "bcw-hyperloop-experience"}
variable "apimanagement_api_description_hyperloop_experience"{default = "BCW Servicios de la capa de experiencia de hyperloop V1"}
variable "apimanagement_revision_hyperloop_experience"{default = "1"}
variable "apimanagement_version_hyperloop_experience"{default = "v1"}
variable "apimanagement_backend_path_hyperloop_experience"{default = "hyperloop-experience/winterfell-hyperloop"}
variable "apimanagement_path_hyperloop_experience"{default = "bcw-hyperloop-experience"}
variable "apimanagement_product_hyperloop_experience"{default = ["bcw-hyperloop","hyperloop"]}
variable "apimanagement_path_swagger_hyperloop_experience"{default = "./resources/api-management/swagger/hyperloop-experience/hyperloop-experience-v1.json"}



##################
# API BCW COMERCIAL EXPERIENCE V1 #
##################
variable "apimanagement_display_name_comercial_experience"{default = "BCW Comercial Experience"}
variable "apimanagement_api_name_comercial_experience"{default = "bcw-comercial-experience"}
variable "apimanagement_api_description_comercial_experience"{default = "BCW Servicios de la capa de experiencia de comercial V1 (cn/cce/bpi)"}
variable "apimanagement_revision_comercial_experience"{default = "1"}
variable "apimanagement_version_comercial_experience"{default = "v1"}
variable "apimanagement_backend_service_comercial_experience"{default = "comercial-experience/winterfell-comercial"}
variable "apimanagement_path_comercial_experience"{default = "bcw-comercial-experience"}
variable "apimanagement_product_comercial_experience"{default = ["bcw-comercial","hyperloop"]}
variable "apimanagement_path_swagger_comercial_experience"{default = "./resources/api-management/swagger/comercial-experience/comercial-experience-v1.json"}


##################
# API BCW HYPERLOOP FACTORING V1 #
##################
variable "apimanagement_display_name_hyperloop_factoring"{default = "BCW Hyperloop Factoring"}
variable "apimanagement_api_name_hyperloop_factoring"{default = "bcw-hyperloop-factoring"}
variable "apimanagement_api_description_hyperloop_factoring"{default = "BCW Servicios de Hyperloop Factoring V1"}
variable "apimanagement_revision_hyperloop_factoring"{default = "1"}
variable "apimanagement_version_hyperloop_factoring"{default = "v1"}
variable "apimanagement_backend_service_hyperloop_factoring"{default = "hyperloop-factoring"}
variable "apimanagement_path_hyperloop_factoring"{default = "bcw-hyperloop-factoring"}
variable "apimanagement_product_hyperloop_factoring"{default = ["bcw-hyperloop","hyperloop"]}
variable "apimanagement_path_swagger_factoring"{default = "./resources/api-management/swagger/hyperloop-factoring/hyperloop-factoring-v1.json"}


##################
# API BCW Hyperloop Support V1 #
##################
variable "apimanagement_display_name_hyperloop_support"{default = "BCW Hyperloop Support"}
variable "apimanagement_api_name_hyperloop_support"{default = "bcw-hyperloop-support"}
variable "apimanagement_api_description_hyperloop_support"{default = "BCW Servicios de Hyperloop Support V1"}
variable "apimanagement_revision_hyperloop_support"{default = "1"}
variable "apimanagement_version_hyperloop_support"{default = "v1"}
variable "apimanagement_backend_service_hyperloop_support"{default = "hyperloop-support"}
variable "apimanagement_path_hyperloop_support"{default = "bcw-hyperloop-support"}
variable "apimanagement_product_hyperloop_support"{default = ["bcw-cross","hyperloop"]}
variable "apimanagement_path_swagger_support"{default = "./resources/api-management/swagger/hyperloop-support/hyperloop-support-v1.json"}


##################
# API BCW Hyperloop Report V1 #
##################
variable "apimanagement_display_name_hyperloop_report"{default = "BCW Hyperloop Report"}
variable "apimanagement_api_name_hyperloop_report"{default = "bcw-hyperloop-report"}
variable "apimanagement_api_description_hyperloop_report"{default = "BCW Servicios de Hyperloop Reporte V1"}
variable "apimanagement_revision_hyperloop_report"{default = "1"}
variable "apimanagement_version_hyperloop_report"{default = "v1"}
variable "apimanagement_backend_service_hyperloop_report"{default = "hyperloop-report"}
variable "apimanagement_path_hyperloop_report"{default = "bcw-hyperloop-report"}
variable "apimanagement_product_hyperloop_report"{default = ["bcw-cross","hyperloop"]}
variable "apimanagement_path_swagger_report"{default = "./resources/api-management/swagger/hyperloop-report/hyperloop-report-v1.json"}

##################
# API BCW Hyperloop Factoring Tray Backend V1 #
##################
variable "apimanagement_display_name_hyperloop_factoring_tray_backend"{default = "BCW Hyperloop Factoring Tray Backend"}
variable "apimanagement_api_name_hyperloop_factoring_tray_backend"{default = "bcw-hyperloop-factoring-tray-backend"}
variable "apimanagement_api_description_hyperloop_factoring_tray_backend"{default = "BCW Servicios de microservicio de factoring tray"}
variable "apimanagement_revision_hyperloop_factoring_tray_backend"{default = "1"}
variable "apimanagement_version_hyperloop_factoring_tray_backend"{default = "v1"}
variable "apimanagement_backend_service_hyperloop_factoring_tray_backend"{default = "hyperloop-factoring-tray-backend"}
variable "apimanagement_path_hyperloop_factoring_tray_backend"{default = "bcw-hyperloop-factoring-tray-backend"}
variable "apimanagement_product_hyperloop_factoring_tray_backend"{default = ["bcw-hyperloop","bcw-cross","hyperloop"]}
variable "apimanagement_path_swagger_hyperloop_factoring_tray_backend"{default = "./resources/api-management/swagger/hyperloop-factoring-tray-backend/hyperloop-factoring-tray-backend-v1.json"}

##################
# API BCW Hyperloop Tray Business Account  V1 #
##################
variable "apimanagement_display_name_hyperloop_tray_business_account"{default = "BCW Hyperloop Tray Business Account"}
variable "apimanagement_api_name_hyperloop_tray_business_account"{default = "bcw-hyperloop-tray-business-account"}
variable "apimanagement_api_description_hyperloop_tray_business_account"{default = "BCW Servicios de Bandejas de Cuenta Negocios"}
variable "apimanagement_revision_hyperloop_tray_business_account"{default = "1"}
variable "apimanagement_version_hyperloop_tray_business_account"{default = "v1"}
variable "apimanagement_backend_service_hyperloop_tray_business_account"{default = "hyperloop-tray-business-account"}
variable "apimanagement_path_hyperloop_tray_business_account"{default = "bcw-hyperloop-tray-business-account"}
variable "apimanagement_product_hyperloop_tray_business_account"{default = ["bcw-comercial","hyperloop"]}
variable "apimanagement_path_swagger_hyperloop_tray_business_account"{default = "./resources/api-management/swagger/hyperloop-tray-business-account/hyperloop-tray-business-account-v1.json"}


#############################
# Hyperloop Storage Files #
#############################
variable "api_management_display_name_hyperloop_azure_storage_files"{default = "BCW Hyperloop Azure Storage Files"}
variable "api_management_api_name_hyperloop_azure_storage_files"{default = "bcw-hyperloop-azure-storage-files"}
variable "apimanagement_api_description_hyperloop_azure_storage_files"{default = "BCW Servicios de Azure Storage de hyperloop"}


#############################
# Hyperloop Storage Files v1 #
#############################
variable "api_management_display_name_hyperloop_azure_storage_files_v1"{default = "BCW Hyperloop Azure Storage Files v1"}
variable "api_management_api_name_hyperloop_azure_storage_files_v1"{default = "bcw-hyperloop-azure-storage-files-v1"}
variable "apimanagement_api_description_hyperloop_azure_storage_files_v1"{default = "BCW Servicios de Azure Storage de hyperloop v1"}
variable "api_management_revision_hyperloop_azure_storage_files_v1"{default = "1"}
variable "api_management_version_hyperloop_azure_storage_files_v1"{default = "v1"}
variable "api_management_path_hyperloop_azure_storage_files_v1"{default = "bcw-hyperloop-azure-storage-files"}
variable "api_management_backend_service_hyperloop_azure_storage_files_v1" {default = ""}
variable "api_management_product_hyperloop_azure_storage_files_v1"{default = ["bcw-cross","hyperloop"]}
variable "api_management_path_swagger_hyperloop_azure_storage_files_v1"{default = "./resources/api-management/swagger/hyperloop-azure-storage-files/hyperloop-Azure-Storage-Files-v1.json"}

#############################
# Hyperloop Storage Files v2 #
#############################
variable "api_management_display_name_hyperloop_azure_storage_files_v2"{default = "BCW Hyperloop Azure Storage Files v2"}
variable "api_management_api_name_hyperloop_azure_storage_files_v2"{default = "bcw-hyperloop-azure-storage-files-v2"}
variable "apimanagement_api_description_hyperloop_azure_storage_files_v2"{default = "BCW Servicios de Azure Storage de hyperloop v2"}
variable "api_management_revision_hyperloop_azure_storage_files_v2"{default = "1"}
variable "api_management_version_hyperloop_azure_storage_files_v2"{default = "v2"}
variable "api_management_path_hyperloop_azure_storage_files_v2"{default = "bcw-hyperloop-azure-storage-files"}
variable "api_management_backend_service_hyperloop_azure_storage_files_v2" {default = ""}
variable "api_management_product_hyperloop_azure_storage_files_v2"{default = ["bcw-cross","hyperloop"]}
variable "api_management_path_swagger_hyperloop_azure_storage_files_v2"{default = "./resources/api-management/swagger/hyperloop-azure-storage-files/hyperloop-Azure-Storage-Files-v2.json"}


#############################
# Hyperloop Storage Files v3 #
#############################
variable "api_management_display_name_hyperloop_azure_storage_files_v3"{default = "BCW Hyperloop Azure Storage Files v3"}
variable "api_management_api_name_hyperloop_azure_storage_files_v3"{default = "bcw-hyperloop-azure-storage-files-v3"}
variable "apimanagement_api_description_hyperloop_azure_storage_files_v3"{default = "BCW Servicios de Azure Storage de hyperloop v3"}
variable "api_management_revision_hyperloop_azure_storage_files_v3"{default = "1"}
variable "api_management_version_hyperloop_azure_storage_files_v3"{default = "v3"}
variable "api_management_path_hyperloop_azure_storage_files_v3"{default = "bcw-hyperloop-azure-storage-files"}
variable "api_management_backend_service_hyperloop_azure_storage_files_v3" {default = ""}
variable "api_management_product_hyperloop_azure_storage_files_v3"{default = ["bcw-cross","hyperloop"]}
variable "api_management_path_swagger_hyperloop_azure_storage_files_v3"{default = "./resources/api-management/swagger/hyperloop-azure-storage-files/hyperloop-Azure-Storage-Files-v3.json"}



#############################
# Hyperloop Common Services #
#############################
variable "api_management_display_name_hyperloop_common_services"{default = "BCW Hyperloop Common Services"}
variable "api_management_api_name_hyperloop_common_services"{default = "bcw-hyperloop-common-services"}
variable "apimanagement_api_description_hyperloop_common_services"{default = "BCW Servicios utilitarios de hyperloop"}

#############################
# Hyperloop Common Services v1 #
#############################
variable "api_management_display_name_hyperloop_common_services_v1"{default = "BCW Hyperloop Common Services v1"}
variable "api_management_api_name_hyperloop_common_services_v1"{default = "bcw-hyperloop-common-services-v1"}
variable "apimanagement_api_description_hyperloop_common_services_v1"{default = "BCW Servicios utilitarios de hyperloop v1"}
variable "api_management_revision_hyperloop_common_services_v1"{default = "1"}
variable "api_management_version_hyperloop_common_services_v1"{default = "v1"}
variable "api_management_path_hyperloop_common_services_v1"{default = "bcw-hyperloop-common"}
variable "api_management_backend_service_hyperloop_common_services_v1" {default = ""}
variable "api_management_product_hyperloop_common_services_v1"{default = ["bcw-cross","hyperloop"]}
variable "api_management_path_swagger_hyperloop_common_services_v1"{default = "./resources/api-management/swagger/hyperloop-common/hyperloop-common-v1.json"}
variable "apim_operation_policy_var_fun_app_name_hypl_common_v1"{default = "func-hyperloop-common-services"}

#############################
# Hyperloop Bulkload Services #
#############################
variable "api_management_display_name_hyperloop_bulkload_services"{default = "BCW Hyperloop Bulkload Services"}
variable "api_management_api_name_hyperloop_bulkload_services"{default = "bcw-hyperloop-bulkload-services"}
variable "apimanagement_api_description_hyperloop_bulkload_services"{default = "BCW Servicios utilitarios de hyperloop"}

#############################
# Hyperloop Bulkload Services v1 #
#############################
variable "api_management_display_name_hyperloop_bulkload_services_v1"{default = "BCW Hyperloop Bulkload Services v1"}
variable "api_management_api_name_hyperloop_bulkload_services_v1"{default = "bcw-hyperloop-bulkload-services-v1"}
variable "apimanagement_api_description_hyperloop_bulkload_services_v1"{default = "BCW Servicios carga giradores y aceptantes hyperloop v1"}
variable "api_management_revision_hyperloop_bulkload_services_v1"{default = "1"}
variable "api_management_version_hyperloop_bulkload_services_v1"{default = "v1"}
variable "api_management_path_hyperloop_bulkload_services_v1"{default = "bcw-hyperloop-bulkload"}
variable "api_management_backend_service_hyperloop_bulkload_services_v1" {default = ""}
variable "api_management_product_hyperloop_bulkload_services_v1"{default = ["bcw-cross","hyperloop"]}
variable "api_management_path_swagger_hyperloop_bulkload_services_v1"{default = "./resources/api-management/swagger/hyperloop-bulkload/hyperloop-bulkload-v1.json"}
variable "apim_operation_policy_var_fun_app_name_hypl_bulkload_v1"{default = "func-hyperloop-bulkload-services"}

#############################
# API BCW-CURRENT-ACCOUNT V1#
#############################
variable "api_management_display_name_bcw_current_account"{default = "BCW Current Account"}
variable "api_management_api_name_bcw_current_account"{default = "bcw-current-account-backend"}
variable "api_management_api_description_bcw_current_account"{default = "BCW Servicios de cuenta corriente"}
variable "api_management_revision_bcw_current_account_v1"{default = "1"}
variable "api_management_version_bcw_current_account_v1"{default = "v1"}
variable "api_management_backend_service_bcw_current_account_v1"{default = "bcw-current-account-backend"}
variable "api_management_path_bcw_current_account_v1"{default = "bcw-current-account"}
variable "api_management_product_bcw_current_account_v1"{default = ["bcw-comercial","hyperloop"]}
variable "api_management_path_swagger_bcw_current_account_v1"{default = "./resources/api-management/swagger/current-account-backend/current-account-backend-v1.json"}

##############################
# API BCW-BUSINESS-ACCOUNT V1#
##############################
variable "api_management_display_name_bcw_business_account"{default = "BCW Business Account"}
variable "api_management_api_name_bcw_business_account"{default = "bcw-business-account-backend"}
variable "api_management_api_description_bcw_business_account"{default = "BCW Servicios de cuenta negocio"}
variable "api_management_revision_bcw_business_account_v1"{default = "1"}
variable "api_management_version_bcw_business_account_v1"{default = "v1"}
variable "api_management_backend_service_bcw_business_account_v1"{default = "bcw-business-account-backend"}
variable "api_management_path_bcw_business_account_v1"{default = "bcw-business-account"}
variable "api_management_product_bcw_business_account_v1"{default = ["bcw-comercial","hyperloop"]}
variable "api_management_path_swagger_bcw_business_account_v1"{default = "./resources/api-management/swagger/business-account-backend/business-account-backend-v1.json"}

##############################
# API BCW-ADMIN            V1#
##############################
variable "api_management_display_name_bcw_hyperloop_admin"{default = "BCW Hyperloop Admin"}
variable "api_management_api_name_bcw_hyperloop_admin"{default = "bcw-admin-service"}
variable "api_management_api_description_bcw_hyperloop_admin"{default = "BCW Servicios de parametria admin"}
variable "api_management_revision_bcw_hyperloop_admin_v1"{default = "1"}
variable "api_management_version_bcw_hyperloop_admin_v1"{default = "v1"}
variable "api_management_backend_service_bcw_hyperloop_admin_v1"{default = "bcw-admin-service"}
variable "api_management_path_bcw_hyperloop_admin_v1"{default = "bcw-admin"}
variable "api_management_product_bcw_hyperloop_admin_v1"{default = ["bcw-hyperloop","hyperloop"]}
variable "api_management_path_swagger_bcw_hyperloop_admin_v1"{default = "./resources/api-management/swagger/hyperloop-admin/hyperloop-admin-v1.json"}