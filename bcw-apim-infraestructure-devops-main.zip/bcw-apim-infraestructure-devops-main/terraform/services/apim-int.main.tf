############################################################################################################
####################################    API Management - Named Values ######################################
############################################################################################################

module "apim-named-value-interno-storage-account-name-hypl" {
  count                               =  contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_hypl_storage_account
  name                                = var.apimanagement_namedvalue_name_bcw_hypl_storage_account
  value                               = var.apimanagement_namedvalue_value_bcw_hypl_storage_account
}

module "apim-named-value-interno-security-redirect-scope-hypl" {
  count                               =  contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_security_redirect_scope
  name                                = var.apimanagement_namedvalue_name_bcw_security_redirect_scope
  value                               = var.apimanagement_namedvalue_value_bcw_security_redirect_scope
}

module "apim-named-value-interno-security-redirect-client-id-hypl" {
  count                               =  contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_security_redirect_client_id
  name                                = var.apimanagement_namedvalue_name_bcw_security_redirect_client_id
  value                               = var.apimanagement_namedvalue_value_id_bcw_security_client_id
}

module "apim-named-value-interno-security-redirect-secret-hypl" {
  count                               =  contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_security_redirect_secret
  name                                = var.apimanagement_namedvalue_name_bcw_security_redirect_secret
  value                               = var.apimanagement_namedvalue_value_id_bcw_security_secret
}

module "apim-named-value-interno-security-basic-introspect-secret-hypl" {
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_security_basic_introspect
  name                                = var.apimanagement_namedvalue_name_bcw_security_basic_introspect
  value                               = var.apimanagement_namedvalue_value_id_bcw_basic_introspect
}

module "apim-named-value-interno-security-basic-introspect-secret-assi" {
  count                               = !contains(["PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_assi_security_basic_checktoken
  name                                = var.apimanagement_namedvalue_name_bcw_assi_security_basic_checktoken
  value                               = var.apimanagement_namedvalue_value_id_bcw_assi_basic_checktoken
}


module "apim-named-value-interno-storage-account-name-hypl-02" {
  count                               =  contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/named_value/secret"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  display_name                        = var.apimanagement_namedvalue_display_bcw_hypl_storage_account_02
  name                                = var.apimanagement_namedvalue_name_bcw_hypl_storage_account_02
  value                               = var.apimanagement_namedvalue_value_bcw_hypl_storage_account_02
}

############################################################################################################
############################################################################################################
############################################################################################################


/********************************************************************************
* @name  BCW HYPERLOOP PRUEBA
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/
module  "product-int-bcw-prueba" {
  count                 = contains(["DEV"], var.environment) ? 1 : 0
  source                = "./../module/apim/product"
  providers             = { azurerm = azurerm.api_int }
  resourcegroup_name    = var.groupname_api_interno
  apimanagement_name    = var.apimanagement_name_interno
  product_id            = var.product_prueba_id
  display_name          = var.display_product_prueba_name
  subscription_required = true
  approval_required     = true
  published             = true
  subscriptions_limit   = 10
  product = {
    policy_xml_content = templatefile("./resources/api-management/policies/product_prueba_v1.xml", {})
  }
}

/********************************************************************************
* @name  BCW HYPERLOOP PRODUCT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/
module  "product-int-bcw-hyperloop" {
  count                 = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                = "./../module/apim/product"
  providers             = { azurerm = azurerm.api_int }
  resourcegroup_name    = var.groupname_api_interno
  apimanagement_name    = var.apimanagement_name_interno
  product_id            = var.product_id
  display_name          = var.display_product_name
  subscription_required = true
  approval_required     = true
  published             = true
  subscriptions_limit   = 10
  product = {
    policy_xml_content = templatefile("./resources/api-management/policies/product_basic_v1.xml", {})
  }
}

/********************************************************************************
* @name  BCW HYPERLOOP COMERCIAL PRODUCT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/
module  "product-int-bcw-hyperloop-comercial" {
  count                 = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                = "./../module/apim/product"
  providers             = { azurerm = azurerm.api_int }
  resourcegroup_name    = var.groupname_api_interno
  apimanagement_name    = var.apimanagement_name_interno
  product_id            = var.bcw_hyperloop_comercial_product_id
  display_name          = var.bcw_hyperloop_comercial_display_product_name
  subscription_required = true
  approval_required     = true
  published             = true
  subscriptions_limit   = 10
  product = {
    policy_xml_content = templatefile("./resources/api-management/policies/product_basic_v1.xml", {})
  }
}
/********************************************************************************
* @name  BCW HYPERLOOP CROSS PRODUCT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/
module  "product-int-bcw-hyperloop-cross" {
  count                 = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                = "./../module/apim/product"
  providers             = { azurerm = azurerm.api_int }
  resourcegroup_name    = var.groupname_api_interno
  apimanagement_name    = var.apimanagement_name_interno
  product_id            = var.bcw_hyperloop_cross_product_id
  display_name          = var.bcw_hyperloop_cross_display_product_name
  subscription_required = true
  approval_required     = true
  published             = true
  subscriptions_limit   = 10
  product = {
    policy_xml_content = templatefile("./resources/api-management/policies/product_basic_v1.xml", {})
  }
}

############################################################################################################
####################################    API Management - BACKEND   #########################################
############################################################################################################

/********************************************************************************
* @name  BCW COMMON FUNCTION
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-backend-interno-bcw-common-function" {
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/backend"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  name                                = var.apim_backend_bcw_common_function_backend_id
  url                                 = var.apim_backend_bcw_common_function_url
  backend_headers = {
      "x-functions-key" = "{{bcw-keyvault-commons-master-function-key}}"//referencia a namedvalue previamente creado en apim
    }
  }

/********************************************************************************
* @name  BCW BULKLOAD FUNCTION
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-backend-interno-bcw-bulkload-function" {
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/backend"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  name                                = var.apim_backend_bcw_bulkload_function_backend_id
  url                                 = var.apim_backend_bcw_bulkload_function_url
  backend_headers = {
      "x-functions-key" = "{{bcw-keyvault-bulkload-master-function-key}}"//referencia a namedvalue previamente creado en apim
    }
  }

############################################################################################################
####################################    API Management - APIS ##############################################
############################################################################################################

/********************************************************************************
* @name BCW HYPERLOOP SECURITY
* @author HYPERLOOP
* @api   interno
* @description
********************************************************************************/
module "apim-service-interno_bcw_hyperloop_security" {
  depends_on = [module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop
  ]
  count                     = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                    = "./../module/apim/api_set"
  providers                 = { azurerm = azurerm.api_int }
  resourcegroup_name        = var.groupname_api_interno
  apimanagement_name        = var.apimanagement_name_interno  
  api = {
    display_name  = var.apimanagement_display_name_security
    api_name      = var.apimanagement_api_name_security
    description   = var.apimanagement_api_description_security
  }
}


module "apim-service-interno_bcw_hyperloop_security-v1" {
  depends_on                          = [module.apim-service-interno_bcw_hyperloop_security,
    module.apim-named-value-interno-security-redirect-scope-hypl,
    module.apim-named-value-interno-security-redirect-client-id-hypl,
    module.apim-named-value-interno-security-redirect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim/api_version"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  api_version = {
      version_set_id                  = module.apim-service-interno_bcw_hyperloop_security[0].api_set_id
      display_name                    = var.apimanagement_display_name_security_v1
      api_name                        = var.apimanagement_api_name_security_v1
      description                     = var.apimanagement_api_description_security_v1
      revision                        = var.apimanagement_revision_security_v1
      version                         = var.apimanagement_version_security_v1
      path                            = var.apimanagement_path_security_v1
      service_url                     = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_path_security_v1}"
      product                         = var.apimanagement_product_security_v1
      swagger_content                 = var.apimanagement_path_swagger_security_v1
      policy_xml_content              = templatefile("./resources/api-management/policies/hypl-security-policies-v1.xml", {})
      operations_policy = [      
        {
          operation_name        = "generarTokenRedirecOauth2"
          policy_xml_content    = templatefile("./resources/api-management/policies/hypl-security-operation-policies-v1.xml", {})
        }
      ]
  }
}
 


/********************************************************************************
* @name BCW HYPERLOOP EXPERIENCE
* @author HYPERLOOP
* @api   interno
* @description
********************************************************************************/
module "apim-service-interno-bcw-hyperloop-experience" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile(
    /*politica auxiliar para habilitar orgenes pruebas dev-uat 'CORS policy'*/
    contains(["UAT","DEV"], var.environment) ? 
    "./resources/api-management/policies/hypl-experience-apis-policies-v1-UAT.xml" :
    "./resources/api-management/policies/hypl-experience-apis-policies-v1.xml", {
    hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
  })
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_experience
      api_name          = var.apimanagement_api_name_hyperloop_experience
      description       = var.apimanagement_api_description_hyperloop_experience
      revision          = var.apimanagement_revision_hyperloop_experience
      version_n         = var.apimanagement_version_hyperloop_experience
      path              = var.apimanagement_path_hyperloop_experience
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_path_hyperloop_experience}"
      product           = var.apimanagement_product_hyperloop_experience
      content_value     = var.apimanagement_path_swagger_hyperloop_experience
  }
}


/********************************************************************************
* @name  BCW COMERCIAL EXPERIENCE
* @author HYPERLOOP
* @api  interno
* @description
********************************************************************************/
module "apim-service-interno-bcw-comercial-experience" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile(
    /*politica auxiliar para habilitar orgenes pruebas dev-uat 'CORS policy'*/
    contains(["UAT","DEV"], var.environment) ? 
    "./resources/api-management/policies/hypl-experience-apis-policies-v1-UAT.xml" :
    "./resources/api-management/policies/hypl-experience-apis-policies-v1.xml", {
    hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
  })
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_comercial_experience
      api_name          = var.apimanagement_api_name_comercial_experience
      description       = var.apimanagement_api_description_comercial_experience
      revision          = var.apimanagement_revision_comercial_experience
      version_n         = var.apimanagement_version_comercial_experience
      path              = var.apimanagement_path_comercial_experience
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_comercial_experience}"
      product           = var.apimanagement_product_comercial_experience
      content_value     = var.apimanagement_path_swagger_comercial_experience
  }
}


/********************************************************************************
* @name  BCW HYPERLOOP FACTORING
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-service-interno-bcw-hyperloop-factoring" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
    hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
  })
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_factoring
      api_name          = var.apimanagement_api_name_hyperloop_factoring
      description       = var.apimanagement_api_description_hyperloop_factoring
      revision          = var.apimanagement_revision_hyperloop_factoring
      version_n         = var.apimanagement_version_hyperloop_factoring
      path              = var.apimanagement_path_hyperloop_factoring
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_hyperloop_factoring}"
      product           = var.apimanagement_product_hyperloop_factoring
      content_value     = var.apimanagement_path_swagger_factoring
  }
}


/********************************************************************************
* @name  BCW HYPERLOOP SUPPORT
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-services-interno-bcw-hyperloop-support" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
    hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
  })
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_support
      api_name          = var.apimanagement_api_name_hyperloop_support
      description       = var.apimanagement_api_description_hyperloop_support
      revision          = var.apimanagement_revision_hyperloop_support
      version_n         = var.apimanagement_version_hyperloop_support
      path              = var.apimanagement_path_hyperloop_support
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_hyperloop_support}"
      product           = var.apimanagement_product_hyperloop_support
      content_value     = var.apimanagement_path_swagger_support
  }
}


/********************************************************************************
* @name  BCW HYPERLOOP REPORT
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-service-interno-bcw-hyperloop-report" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-assi,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-base.xml", {
    hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
  })
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_report
      api_name          = var.apimanagement_api_name_hyperloop_report
      description       = var.apimanagement_api_description_hyperloop_report
      revision          = var.apimanagement_revision_hyperloop_report
      version_n         = var.apimanagement_version_hyperloop_report
      path              = var.apimanagement_path_hyperloop_report
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_hyperloop_report}"
      product           = var.apimanagement_product_hyperloop_report
      content_value     = var.apimanagement_path_swagger_report
  }
}




  /********************************************************************************
  * @name  BCW HYPERLOOP FACTORING TRAY BACKEND
  * @author HYPERLOOP
  * @api interno
  * @description
  ********************************************************************************/

  module "apim-service-interno-bcw-hyperloop-factoring-tray-backend" {
    depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
      module.product-int-bcw-hyperloop-cross,
      module.product-int-bcw-hyperloop-comercial,
      module.product-int-bcw-hyperloop]
    count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
    source                              = "./../module/apim"
    providers                           = { azurerm = azurerm.api_int}
    resourcegroup_name                  = var.groupname_api_interno
    apimanagement_name                  = var.apimanagement_name_interno
    apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_factoring_tray_backend
      api_name          = var.apimanagement_api_name_hyperloop_factoring_tray_backend
      description       = var.apimanagement_api_description_hyperloop_factoring_tray_backend
      revision          = var.apimanagement_revision_hyperloop_factoring_tray_backend
      version_n         = var.apimanagement_version_hyperloop_factoring_tray_backend
      path              = var.apimanagement_path_hyperloop_factoring_tray_backend
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_hyperloop_factoring_tray_backend}"
      product           = var.apimanagement_product_hyperloop_factoring_tray_backend
      content_value     = var.apimanagement_path_swagger_hyperloop_factoring_tray_backend
    }
}



/********************************************************************************
* @name  BCW HYPERLOOP TRAY BUSINESS ACCOUNT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/

module "apim-service-interno-hyperloop-tray-business-account" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-base.xml", {})
  api = {
      index             = 0
      display_name      = var.apimanagement_display_name_hyperloop_tray_business_account
      api_name          = var.apimanagement_api_name_hyperloop_tray_business_account
      description       = var.apimanagement_api_description_hyperloop_tray_business_account
      revision          = var.apimanagement_revision_hyperloop_tray_business_account
      version_n         = var.apimanagement_version_hyperloop_tray_business_account
      path              = var.apimanagement_path_hyperloop_tray_business_account
      service_url       = "${var.apimanagement_backend_ingress}${var.apimanagement_backend_service_hyperloop_tray_business_account}"
      product           = var.apimanagement_product_hyperloop_tray_business_account
      content_value     = var.apimanagement_path_swagger_hyperloop_tray_business_account
  }
}


/********************************************************************************
* @name  BCW HYPERLOOP COMMON SERVICES
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-service-interno-hyperloop-common-services" {
  count                     = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                    = "./../module/apim/api_set"
  providers                 = { azurerm = azurerm.api_int }
  resourcegroup_name        = var.groupname_api_interno
  apimanagement_name        = var.apimanagement_name_interno
  api = {
    display_name  = var.api_management_display_name_hyperloop_common_services
    api_name      = var.api_management_api_name_hyperloop_common_services
    description   = var.apimanagement_api_description_hyperloop_common_services
  }
}
/*******************************************************************************************************************************************
* NOTA: retirar logica -> 
* contains(["PRD"], var.environment) ? var.apim_backend_bcw_common_function_backend_id_old : var.apim_backend_bcw_common_function_backend_id
* despues de implementadas las functions commons y bulkload en prd
********************************************************************************************************************************************/
module "apim-service-interno-hyperloop-common-services-v1" {
  depends_on                = [module.apim-service-interno-hyperloop-common-services,module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop,
    module.apim-backend-interno-bcw-common-function]
  count                     = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                    = "./../module/apim/api_version"
  providers                 = { azurerm = azurerm.api_int }
  resourcegroup_name        = var.groupname_api_interno
  apimanagement_name        = var.apimanagement_name_interno  
  api_version = {
    version_set_id          = module.apim-service-interno-hyperloop-common-services[0].api_set_id
    display_name            = var.api_management_display_name_hyperloop_common_services_v1
    api_name                = var.api_management_api_name_hyperloop_common_services_v1
    description             = var.apimanagement_api_description_hyperloop_common_services_v1
    revision                = var.api_management_revision_hyperloop_common_services_v1
    version                 = var.api_management_version_hyperloop_common_services_v1
    path                    = var.api_management_path_hyperloop_common_services_v1
    service_url             = var.api_management_backend_service_hyperloop_common_services_v1
    product                 = var.api_management_product_hyperloop_common_services_v1
    swagger_content         = var.api_management_path_swagger_hyperloop_common_services_v1
    policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    operations_policy = [      
      {
        operation_name        = "1-send-message-service-bus-queue"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies.xml",  {
          backendId           = var.apim_backend_bcw_common_function_backend_id
        })
      },
      {
        operation_name        = "2-ejecutar-pipeline-adf"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies.xml",  {
          backendId           = var.apim_backend_bcw_common_function_backend_id
        })
      }
    ]
  }
}


/********************************************************************************
* @name  BCW HYPERLOOP BULKLOAD SERVICES
* @author HYPERLOOP
* @api  interno
* @description  
********************************************************************************/
module "apim-service-interno-hyperloop-bulkload-services" {
  count                     = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                    = "./../module/apim/api_set"
  providers                 = { azurerm = azurerm.api_int }
  resourcegroup_name        = var.groupname_api_interno
  apimanagement_name        = var.apimanagement_name_interno
  api = {
    display_name  = var.api_management_display_name_hyperloop_bulkload_services
    api_name      = var.api_management_api_name_hyperloop_bulkload_services
    description   = var.apimanagement_api_description_hyperloop_bulkload_services
  }
}

module "apim-service-interno-hyperloop-bulkload-services-v1" {
  depends_on                = [module.apim-service-interno-hyperloop-bulkload-services,module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop,
    module.apim-backend-interno-bcw-bulkload-function]
  count                     = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                    = "./../module/apim/api_version"
  providers                 = { azurerm = azurerm.api_int }
  resourcegroup_name        = var.groupname_api_interno
  apimanagement_name        = var.apimanagement_name_interno  
  api_version = {
    version_set_id          = module.apim-service-interno-hyperloop-bulkload-services[0].api_set_id
    display_name            = var.api_management_display_name_hyperloop_bulkload_services_v1
    api_name                = var.api_management_api_name_hyperloop_bulkload_services_v1
    description             = var.apimanagement_api_description_hyperloop_bulkload_services_v1
    revision                = var.api_management_revision_hyperloop_bulkload_services_v1
    version                 = var.api_management_version_hyperloop_bulkload_services_v1
    path                    = var.api_management_path_hyperloop_bulkload_services_v1
    service_url             = var.api_management_backend_service_hyperloop_bulkload_services_v1
    product                 = var.api_management_product_hyperloop_bulkload_services_v1
    swagger_content         = var.api_management_path_swagger_hyperloop_bulkload_services_v1
    policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    operations_policy = [      
      {
        operation_name        = "1-get-bulkloads-http-trigger"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies.xml",  {
          backendId           = var.apim_backend_bcw_bulkload_function_backend_id
        })
      }
    ]
  }
}



/********************************************************************************
* @name  BCW HYPERLOOP AZURE STORAGE FILES
* @author HYPERLOOP
* @api  interno
* @description
********************************************************************************/

module "apim-service-interno-bcw-hyperloop-azure-storage-files" {
  depends_on = [module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count              = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source             = "./../module/apim/api_set"
  providers          = { azurerm = azurerm.api_int }
  resourcegroup_name = var.groupname_api_interno
  apimanagement_name = var.apimanagement_name_interno
  api = {
    display_name  = var.api_management_display_name_hyperloop_azure_storage_files
    api_name      = var.api_management_api_name_hyperloop_azure_storage_files
    description   = var.apimanagement_api_description_hyperloop_azure_storage_files
  }
}



module "apim-service-interno-bcw-hyperloop-azure-storage-files-v1" {
  depends_on = [module.apim-service-interno-bcw-hyperloop-azure-storage-files,module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                   = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                  = "./../module/apim/api_version"
  providers               = { azurerm = azurerm.api_int }
  resourcegroup_name      = var.groupname_api_interno
  apimanagement_name      = var.apimanagement_name_interno
  api_version = {
    version_set_id        = module.apim-service-interno-bcw-hyperloop-azure-storage-files[0].api_set_id
    display_name          = var.api_management_display_name_hyperloop_azure_storage_files_v1
    api_name              = var.api_management_api_name_hyperloop_azure_storage_files_v1
    description           = var.apimanagement_api_description_hyperloop_azure_storage_files_v1
    revision              = var.api_management_revision_hyperloop_azure_storage_files_v1
    version               = var.api_management_version_hyperloop_azure_storage_files_v1
    path                  = var.api_management_path_hyperloop_azure_storage_files_v1
    service_url           = var.api_management_backend_service_hyperloop_azure_storage_files_v1
    product               = var.api_management_product_hyperloop_azure_storage_files_v1
    swagger_content       = var.api_management_path_swagger_hyperloop_azure_storage_files_v1
    policy_xml_content    = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    operations_policy = [
      {
        operation_name        = "1-put-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v1.xml")
      },
      {
        operation_name        = "2-generate-sas-token"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies.xml", {
          backendId     = var.apimanagement_operation_policy_var_function_app_name_hyperloop_azure_storage_files_v1
        })
      }
    ]
  }
}


module "apim-service-interno-bcw-hyperloop-azure-storage-files-v2" {
  depends_on = [module.apim-service-interno-bcw-hyperloop-azure-storage-files,module.apim-named-value-interno-storage-account-name-hypl,
                module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                       = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                      = "./../module/apim/api_version"
  providers                   = { azurerm = azurerm.api_int }
  resourcegroup_name          = var.groupname_api_interno
  apimanagement_name          = var.apimanagement_name_interno 
  api_version = {
    version_set_id            = module.apim-service-interno-bcw-hyperloop-azure-storage-files[0].api_set_id
    display_name              = var.api_management_display_name_hyperloop_azure_storage_files_v2
    api_name                  = var.api_management_api_name_hyperloop_azure_storage_files_v2
    description               = var.apimanagement_api_description_hyperloop_azure_storage_files_v2
    revision                  = var.api_management_revision_hyperloop_azure_storage_files_v2
    version                   = var.api_management_version_hyperloop_azure_storage_files_v2
    path                      = var.api_management_path_hyperloop_azure_storage_files_v2
    service_url               = var.api_management_backend_service_hyperloop_azure_storage_files_v2
    product                   = var.api_management_product_hyperloop_azure_storage_files_v2
    swagger_content           = var.api_management_path_swagger_hyperloop_azure_storage_files_v2
    policy_xml_content        = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    operations_policy = [      
      {
        operation_name        = "1-generate-sas-token"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies.xml", {
          backendId           = var.apimanagement_operation_policy_var_function_app_name_hyperloop_azure_storage_files_v2
        })
      },
      {
        operation_name        = "2-put-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v2.xml")
      },
      {
        operation_name        = "3-delete-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v2.xml")
      },
      {
        operation_name        = "4-get-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v2.xml")
      }
    ]
  }
}


module "apim-service-interno-bcw-hyperloop-azure-storage-files-v3" {
  depends_on = [module.apim-service-interno-bcw-hyperloop-azure-storage-files,module.apim-named-value-interno-storage-account-name-hypl-02,
                module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                       = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                      = "./../module/apim/api_version"
  providers                   = { azurerm = azurerm.api_int }
  resourcegroup_name          = var.groupname_api_interno
  apimanagement_name          = var.apimanagement_name_interno 
  api_version = {
    version_set_id            = module.apim-service-interno-bcw-hyperloop-azure-storage-files[0].api_set_id
    display_name              = var.api_management_display_name_hyperloop_azure_storage_files_v3
    api_name                  = var.api_management_api_name_hyperloop_azure_storage_files_v3
    description               = var.apimanagement_api_description_hyperloop_azure_storage_files_v3
    revision                  = var.api_management_revision_hyperloop_azure_storage_files_v3
    version                   = var.api_management_version_hyperloop_azure_storage_files_v3
    path                      = var.api_management_path_hyperloop_azure_storage_files_v3
    service_url               = var.api_management_backend_service_hyperloop_azure_storage_files_v3
    product                   = var.api_management_product_hyperloop_azure_storage_files_v3
    swagger_content           = var.api_management_path_swagger_hyperloop_azure_storage_files_v3
    policy_xml_content        = templatefile("./resources/api-management/policies/hypl-validation-token-policies-v1.xml", {
      hyplCheckTokenSecurityUrl  = var.apimanagement_hypl_security_checktoken_service_url
    })
    operations_policy = [      
      {
        operation_name        = "1-generate-sas-token"
        policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-v3.xml", {
          backendId           = var.apimanagement_operation_policy_var_function_app_name_hyperloop_azure_storage_files_v2
        })
      },
      {
        operation_name        = "2-put-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v3.xml")
      },
      {
        operation_name        = "3-delete-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v3.xml")
      },
      {
        operation_name        = "4-get-operations"
        policy_xml_content    = file("./resources/api-management/policies/hypl-operations-azure-storage-policies-v3.xml")
      }
    ]
  }
}

/********************************************************************************
* @name  BCW CURRENT ACCOUNT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/

module "apim-service-interno-bcw-current-account-backend" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-base.xml", {})
  api = {
      index             = 0
      display_name      = var.api_management_display_name_bcw_current_account
      api_name          = var.api_management_api_name_bcw_current_account
      description       = var.api_management_api_description_bcw_current_account
      revision          = var.api_management_revision_bcw_current_account_v1
      version_n         = var.api_management_version_bcw_current_account_v1
      path              = var.api_management_path_bcw_current_account_v1
      service_url       = "${var.apimanagement_backend_ingress}${var.api_management_backend_service_bcw_current_account_v1}"
      product           = var.api_management_product_bcw_current_account_v1
      content_value     = var.api_management_path_swagger_bcw_current_account_v1
  }
}

/********************************************************************************
* @name  BCW HYPERLOOP TRAY BUSINESS ACCOUNT
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/

module "apim-service-interno-bcw-business-account-backend" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-base.xml", {})
  api = {
      index             = 0
      display_name      = var.api_management_display_name_bcw_business_account
      api_name          = var.api_management_api_name_bcw_business_account
      description       = var.api_management_api_description_bcw_business_account
      revision          = var.api_management_revision_bcw_business_account_v1
      version_n         = var.api_management_version_bcw_business_account_v1
      path              = var.api_management_path_bcw_business_account_v1
      service_url       = "${var.apimanagement_backend_ingress}${var.api_management_backend_service_bcw_business_account_v1}"
      product           = var.api_management_product_bcw_business_account_v1
      content_value     = var.api_management_path_swagger_bcw_business_account_v1
  }
}

/********************************************************************************
* @name  BCW HYPERLOOP ADMIN
* @author HYPERLOOP
* @api interno
* @description
********************************************************************************/

module "apim-service-interno-bcw-hyperloop-admin-backend" {
  depends_on                          = [module.apim-named-value-interno-security-basic-introspect-secret-hypl,
    module.product-int-bcw-hyperloop-cross,
    module.product-int-bcw-hyperloop-comercial,
    module.product-int-bcw-hyperloop]
  count                               = contains(["UAT","STG","PRD"], var.environment) ? 1 : 0
  source                              = "./../module/apim"
  providers                           = { azurerm = azurerm.api_int}
  resourcegroup_name                  = var.groupname_api_interno
  apimanagement_name                  = var.apimanagement_name_interno
  apimanagement_policy_xml_content    = templatefile("./resources/api-management/policies/hypl-set-backend-policies-base.xml", {})
  api = {
      index             = 0
      display_name      = var.api_management_display_name_bcw_hyperloop_admin
      api_name          = var.api_management_api_name_bcw_hyperloop_admin
      description       = var.api_management_api_description_bcw_hyperloop_admin
      revision          = var.api_management_revision_bcw_hyperloop_admin_v1
      version_n         = var.api_management_version_bcw_hyperloop_admin_v1
      path              = var.api_management_path_bcw_hyperloop_admin_v1
      service_url       = "${var.apimanagement_backend_ingress}${var.api_management_backend_service_bcw_hyperloop_admin_v1}"
      product           = var.api_management_product_bcw_hyperloop_admin_v1
      content_value     = var.api_management_path_swagger_bcw_hyperloop_admin_v1
  }
}