variable "project" {default = "hyperloop"}
variable "environment" {default = "__TERRAFORM_ENVIRONMENT__"}

variable "client_id" {default = "__TERRAFORM_CLIENT_ID__"}
variable "client_secret" {default = "__TERRAFORM_CLIENT_SECRET__"}
variable "tenant_id" {default = "__TERRAFORM_TENANT_ID__"}
variable "subscription_ext_id" {default = "__TERRAFORM_EXT_SUBSCRIPTION_ID__"}
variable "subscription_int_id" {default = "__TERRAFORM_INT_SUBSCRIPTION_ID__"} 
    
variable "apimanagement_name_externo"{default = "__SERVICE_APIMANAGEMENT_NAME_EXTERNO__"}
variable "groupname_api_externo" {default = "__SERVICE_APIMANAGEMENT_EXTERNO_RG_NAME__"}
variable "apimanagement_name_interno"{default = "__SERVICE_APIMANAGEMENT_NAME_INTERNO__"}
variable "groupname_api_interno" {default = "__SERVICE_APIMANAGEMENT_INTERNO_RG_NAME__"}


#POLICIES
variable "apimanagement_assi_security_checktoken_service_url" {default = "__SERVICE_APIMANAGEMENT_ASSI_SECURITY_CHECKTOKEN_URL__"}
variable "apimanagement_hypl_security_checktoken_service_url" {default = "__SERVICE_APIMANAGEMENT_HYPL_SECURITY_CHECKTOKEN_URL__"}
variable "apimanagement_operation_policy_redirect_oauth_security_client_id"{default = "__SERVICE_APIMANAGEMENT_HYPL_SECURITY_REDIRECT_CLIENT_ID_V1__"}
variable "apimanagement_operation_policy_redirect_oauth_security_client_secret"{default = "__SERVICE_APIMANAGEMENT_HYPL_SECURITY_REDIRECT_CLIENT_SECRET_V1__"}
variable "apimanagement_operation_policy_redirect_oauth_security_client_scope"{default = "__SERVICE_APIMANAGEMENT_HYPL_SECURITY_REDIRECT_SCOPE_V1__"}
variable "apimanagement_operation_policy_var_function_app_name_hyperloop_azure_storage_files_v1"{default = "__SERVICE_APIMANAGEMENT_HYPL_FUNCTION_STORAGE_FILE_V1__"}
variable "apimanagement_operation_policy_var_function_app_name_hyperloop_azure_storage_files_v2"{default = "__SERVICE_APIMANAGEMENT_HYPL_FUNCTION_STORAGE_FILE_V2__"}