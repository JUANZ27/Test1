const fs = require('fs');
const path = require('path');
const reporter = require('multiple-cucumber-html-reporter');

const jsonDir = path.resolve('reports/cucumber');
const jsonFile = path.join(jsonDir, 'cucumber-report.json');

if (!fs.existsSync(jsonFile)) {
  console.error('No existe reports/cucumber/cucumber-report.json. Ejecuta primero npm test.');
  process.exit(1);
}

reporter.generate({
  jsonDir,
  reportPath: path.resolve('reports/html'),
  openReportInBrowser: false,
  pageTitle: 'IBK11 Playwright BDD Report',
  reportName: 'IBK11 Cuenta Negocios - Playwright BDD',
  displayDuration: true,
  metadata: {
    browser: {
      name: process.env.BROWSER || 'chromium',
      version: 'Playwright managed'
    },
    device: 'Local machine',
    platform: {
      name: process.platform,
      version: process.version
    }
  },
  customData: {
    title: 'Ejecución',
    data: [
      { label: 'Proyecto', value: 'IBK11 Cuenta Negocios' },
      { label: 'Framework', value: 'Playwright + Cucumber BDD' },
      { label: 'Evidencias', value: 'Videos en reports/videos y screenshots en reports/screenshots' }
    ]
  }
});

console.log('Reporte generado en reports/html/index.html');
