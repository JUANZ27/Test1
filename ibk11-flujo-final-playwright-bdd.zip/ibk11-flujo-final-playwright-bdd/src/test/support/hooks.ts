import { After, AfterAll, Before, BeforeAll, Status, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium, firefox, webkit, Browser } from 'playwright';
import fs from 'fs';
import path from 'path';
import { CustomWorld } from './world';
import { testConfig } from './config';

// Establece el timeout de cada step de Cucumber (ms). El valor de cucumber.js
// no siempre se propaga a los workers paralelos, así que lo forzamos aquí.
setDefaultTimeout(
  Math.max(
    testConfig.timeout,
    testConfig.captchaWaitSeconds * 1000 + 180_000
  )
);

const chromeLaunchArgs = [
  '--disable-blink-features=AutomationControlled',
  '--disable-infobars',
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-dev-shm-usage'
];

let sharedBrowser: Browser;

function ensureDir(dir: string) {
  fs.mkdirSync(dir, { recursive: true });
}

function sanitize(name: string) {
  return name.replace(/[^a-z0-9-_]+/gi, '_').slice(0, 100);
}

BeforeAll(async function () {
  ensureDir('reports/cucumber');
  ensureDir('reports/html');
  ensureDir('reports/videos');
  ensureDir('reports/screenshots');

  const launcher = testConfig.browser === 'firefox'
    ? firefox
    : testConfig.browser === 'webkit'
      ? webkit
      : chromium;

  const launchOptions: any = {
    headless: testConfig.headless,
    slowMo: testConfig.slowMo
  };

  if (testConfig.browser === 'chromium') {
    launchOptions.args = chromeLaunchArgs;
    launchOptions.ignoreDefaultArgs = ['--enable-automation'];
  }

  if (testConfig.browser === 'chromium' && testConfig.chromeExecutablePath) {
    launchOptions.executablePath = testConfig.chromeExecutablePath;
  }

  try {
    sharedBrowser = await launcher.launch(launchOptions);
  } catch (error: any) {
    const missingChromium =
      testConfig.browser === 'chromium' &&
      `${error?.message || ''}`.includes("Executable doesn't exist");

    if (missingChromium && testConfig.preferSystemChrome) {
      console.warn(
        `[playwright] No se encontró el binario de Chromium descargado. ` +
        `Se intentará usar Chrome del sistema con channel='${testConfig.chromeChannel}'.`
      );

      sharedBrowser = await chromium.launch({
        channel: testConfig.chromeChannel,
        headless: testConfig.headless,
        slowMo: testConfig.slowMo,
        args: chromeLaunchArgs,
        ignoreDefaultArgs: ['--enable-automation']
      });
      return;
    }

    throw error;
  }
});

Before(async function (this: CustomWorld, scenario) {
  this.scenarioName = scenario.pickle.name;

  this.browser = sharedBrowser;

  const baseContextOptions = {
    viewport: { width: 1440, height: 900 },
    ignoreHTTPSErrors: true,
    locale: 'es-PE',
    timezoneId: 'America/Lima'
  };

  this.context = await this.browser.newContext({
    ...baseContextOptions,
    recordVideo: testConfig.video
      ? {
          dir: 'reports/videos',
          size: { width: 1440, height: 900 }
        }
      : undefined
  });

  this.context.setDefaultTimeout(testConfig.timeout);
  this.context.setDefaultNavigationTimeout(testConfig.timeout);
  await this.context.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  try {
    this.page = await this.context.newPage();
  } catch (error: any) {
    const missingFfmpeg = `${error?.message || ''}`.includes('ffmpeg');

    if (missingFfmpeg && testConfig.video) {
      console.warn('[playwright] ffmpeg no disponible; se desactiva video para continuar la ejecución.');
      await this.context.close();
      this.context = await this.browser.newContext(baseContextOptions);
      this.context.setDefaultTimeout(testConfig.timeout);
      this.context.setDefaultNavigationTimeout(testConfig.timeout);
      await this.context.addInitScript(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      });
      this.page = await this.context.newPage();
      return;
    }

    throw error;
  }
});

After(async function (this: CustomWorld, scenario) {
  if (!this.page || !this.context) {
    return;
  }

  const failed = scenario.result?.status === Status.FAILED;
  const safeName = sanitize(this.scenarioName);
  const pageOpen = !this.page.isClosed();

  if (failed && testConfig.screenshotOnFailure && pageOpen) {
    try {
      const screenshotPath = path.join('reports', 'screenshots', `${safeName}.png`);
      await this.page.screenshot({ path: screenshotPath, fullPage: true });
      (this as any).attach(fs.readFileSync(screenshotPath), 'image/png');
    } catch (error: any) {
      console.warn(`[after] No se pudo tomar screenshot: ${error?.message || error}`);
    }
  }

  const video = pageOpen ? this.page.video() : null;
  await this.context.close().catch(() => undefined);

  if (video) {
    const originalPath = await video.path().catch(() => '');
    const targetPath = path.join('reports', 'videos', `${safeName}.webm`);
    if (originalPath && fs.existsSync(originalPath)) {
      fs.renameSync(originalPath, targetPath);
      this.videoPath = targetPath;
      (this as any).attach(`Video de ejecución: ${targetPath}`, 'text/plain');
    }
  }
});

AfterAll(async function () {
  if (sharedBrowser) {
    await sharedBrowser.close();
  }
});
