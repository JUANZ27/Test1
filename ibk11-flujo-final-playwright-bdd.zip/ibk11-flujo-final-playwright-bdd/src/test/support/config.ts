declare const process: any;
import dotenv from 'dotenv';

dotenv.config();

function bool(value: string | undefined, defaultValue: boolean): boolean {
  if (value === undefined || value === '') return defaultValue;
  return ['true', '1', 'yes', 'y', 'si', 'sí'].includes(value.toLowerCase());
}

function num(value: string | undefined, defaultValue: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : defaultValue;
}

export const testConfig = {
  baseUrl: process.env.BASE_URL || 'https://coloca-aqui-tu-url',
  browser: (process.env.BROWSER || 'chromium').toLowerCase(),
  chromeChannel: (process.env.CHROMIUM_CHANNEL || 'chrome').toLowerCase(),
  chromeExecutablePath: process.env.CHROME_EXECUTABLE_PATH,
  preferSystemChrome: bool(process.env.PREFER_SYSTEM_CHROME, true),
  headless: bool(process.env.HEADLESS, false),
  slowMo: num(process.env.SLOW_MO, 150),
  timeout: num(process.env.TIMEOUT, 45000),
  video: bool(process.env.VIDEO, true),
  screenshotOnFailure: bool(process.env.SCREENSHOT_ON_FAILURE, true),
  // auto = marca el checkbox de reCAPTCHA; manual = espera humana; disabled = no espera
  captchaMode: (process.env.CAPTCHA_MODE || 'auto').toLowerCase(),
  captchaWaitSeconds: num(process.env.CAPTCHA_WAIT_SECONDS, 30),
  data: {
    ruc: process.env.RUC,
    dni: process.env.DNI,
    partida: process.env.PARTIDA,
    rubro: process.env.RUBRO,
    subrubro: process.env.SUBRUBRO
  }
};
