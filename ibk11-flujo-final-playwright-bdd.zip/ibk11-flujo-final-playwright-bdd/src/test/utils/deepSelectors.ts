import { ElementHandle, Page } from 'playwright';

const DEEP_QUERY_TIMEOUT_MS = 5000;

export async function deepQuery(page: Page, selector: string): Promise<ElementHandle<HTMLElement> | null> {
  try {
    const handle = await Promise.race<any>([
      page.evaluateHandle((cssSelector) => {
        function isVisible(el: Element): boolean {
          const html = el as HTMLElement;
          const style = window.getComputedStyle(html);
          const rect = html.getBoundingClientRect();
          return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
        }

        function find(root: Document | ShadowRoot | Element): Element | null {
          const direct = (root as Document | ShadowRoot | Element).querySelector?.(cssSelector);
          if (direct && isVisible(direct)) return direct;
          const nodes = Array.from((root as Document | ShadowRoot | Element).querySelectorAll?.('*') || []);
          for (const node of nodes) {
            const shadow = (node as HTMLElement).shadowRoot;
            if (shadow) {
              const found = find(shadow);
              if (found) return found;
            }
          }
          return null;
        }

        return find(document);
      }, selector),
      new Promise<null>((resolve) => setTimeout(() => resolve(null), DEEP_QUERY_TIMEOUT_MS))
    ]);

    if (!handle || handle === null) return null;
    // Si el race devolvió null (timeout) el handle no existe
    if (typeof handle.asElement !== 'function') return null;
    const element = handle.asElement() as ElementHandle<HTMLElement> | null;
    return element;
  } catch {
    return null;
  }
}


export async function deepQueryAllText(page: Page): Promise<string> {
  return page.evaluate(() => document.body?.innerText || '');
}

export async function clickDeepText(page: Page, text: string): Promise<boolean> {
  return page.evaluate((expected) => {
    const normalize = (s: string) => (s || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();

    const wanted = normalize(expected);

    function roots(root: Document | ShadowRoot | Element, acc: Array<Document | ShadowRoot | Element>) {
      acc.push(root);
      const nodes = Array.from((root as Document | ShadowRoot | Element).querySelectorAll?.('*') || []);
      for (const node of nodes) {
        const shadow = (node as HTMLElement).shadowRoot;
        if (shadow) roots(shadow, acc);
      }
      return acc;
    }

    for (const root of roots(document, [])) {
      const elements = Array.from((root as Document | ShadowRoot | Element).querySelectorAll?.('button, label, a, li, div, span') || []);
      const target = elements.find((el) => {
        const html = el as HTMLElement;
        const style = window.getComputedStyle(html);
        const visible = style.display !== 'none' && style.visibility !== 'hidden' && html.getClientRects().length > 0;
        if (!visible) return false;
        const value = normalize(html.innerText || html.textContent || '');
        return value === wanted || value.includes(wanted);
      }) as HTMLElement | undefined;
      if (target) {
        target.scrollIntoView({ block: 'center', inline: 'center' });
        target.click();
        return true;
      }
    }
    return false;
  }, text);
}
