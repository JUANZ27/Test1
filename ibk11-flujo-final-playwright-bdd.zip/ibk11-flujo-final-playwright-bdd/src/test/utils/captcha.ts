import { Page } from 'playwright';
import { testConfig } from '../support/config';

export async function isCaptchaChallengeVisible(page: Page): Promise<boolean> {
  return page.evaluate(() => {
    const frames = Array.from(document.querySelectorAll('iframe'));
    return frames.some((frame) => {
      const src = frame.src || frame.getAttribute('src') || '';
      const title = (frame.title || frame.getAttribute('title') || '').toLowerCase();
      const isRecaptcha = src.includes('recaptcha') || title.includes('recaptcha');
      const isChallenge = isRecaptcha && (src.includes('bframe') || title.includes('challenge'));
      if (!isChallenge) return false;
      const rect = frame.getBoundingClientRect();
      const style = window.getComputedStyle(frame);
      return rect.width > 220 && rect.height > 140 && style.display !== 'none' && style.visibility !== 'hidden';
    });
  });
}

export async function waitManualCaptchaIfPresent(page: Page): Promise<void> {
  if (!(await isCaptchaChallengeVisible(page))) return;

  console.warn('======================================================');
  console.warn('CAPTCHA detectado. Resolver manualmente en el navegador.');
  console.warn(`El test esperará hasta ${testConfig.captchaWaitSeconds} segundos.`);
  console.warn('======================================================');

  const timeout = Date.now() + testConfig.captchaWaitSeconds * 1000;
  while (Date.now() < timeout) {
    if (!(await isCaptchaChallengeVisible(page))) {
      console.warn('CAPTCHA resuelto. Continuando flujo.');
      return;
    }
    await page.waitForTimeout(2000);
  }

  console.warn('Timeout esperando resolución manual de CAPTCHA. Se continúa para dejar evidencia del estado.');
}
