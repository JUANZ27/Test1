import { Frame, Page } from 'playwright';
import { testConfig } from '../support/config';

function pageIsOpen(page: Page): boolean {
  return !page.isClosed();
}

async function safeWait(page: Page, ms: number): Promise<void> {
  if (!pageIsOpen(page)) return;
  await page.waitForTimeout(ms).catch(() => undefined);
}

export async function isCaptchaChallengeVisible(page: Page): Promise<boolean> {
  if (!pageIsOpen(page)) return false;
  try {
    const challenge = page.locator('iframe[src*="recaptcha"][src*="bframe"]').first();
    if (!(await challenge.isVisible().catch(() => false))) return false;
    const box = await challenge.boundingBox().catch(() => null);
    return !!box && box.width > 220 && box.height > 140;
  } catch {
    return false;
  }
}

function findCheckboxFrame(page: Page): Frame | undefined {
  return page.frames().find((frame) => {
    const url = frame.url() || '';
    return url.includes('recaptcha') && url.includes('anchor') && !url.includes('bframe');
  });
}

async function isCheckboxWidgetVisible(page: Page): Promise<boolean> {
  if (!pageIsOpen(page)) return false;
  try {
    const widget = page.locator('#recaptcha iframe, .g-recaptcha iframe').first();
    if (await widget.isVisible().catch(() => false)) {
      const box = await widget.boundingBox().catch(() => null);
      if (box && box.width > 250 && box.height > 70) return true;
    }

    const anchors = page.locator('iframe[src*="recaptcha"][src*="anchor"]');
    const count = await anchors.count().catch(() => 0);
    for (let i = 0; i < count; i++) {
      const iframe = anchors.nth(i);
      const inBadge = await iframe.evaluate((el) => !!el.closest('.grecaptcha-badge')).catch(() => false);
      if (inBadge) continue;
      if (!(await iframe.isVisible().catch(() => false))) continue;
      const box = await iframe.boundingBox().catch(() => null);
      if (box && box.width > 250 && box.height > 70) return true;
    }
    return false;
  } catch {
    return false;
  }
}

async function isCheckboxChecked(page: Page): Promise<boolean> {
  if (!pageIsOpen(page)) return false;
  try {
    const frame = findCheckboxFrame(page);
    if (!frame) return false;
    const checked = await frame.locator('#recaptcha-anchor').getAttribute('aria-checked');
    return checked === 'true';
  } catch {
    return false;
  }
}

/**
 * Marca el checkbox "No soy un robot" solo si el widget está visible.
 * Ignora el badge de reCAPTCHA del pie de página.
 */
export async function clickRecaptchaCheckboxIfPresent(page: Page): Promise<boolean> {
  if (!pageIsOpen(page)) return false;

  try {
    if (!(await isCheckboxWidgetVisible(page)) && !(await isCaptchaChallengeVisible(page))) {
      return false;
    }
    if (await isCheckboxChecked(page)) return true;

    const frame = findCheckboxFrame(page);
    if (!frame) return false;

    const checkbox = frame.locator('#recaptcha-anchor');
    const visible = await checkbox.isVisible({ timeout: 2500 }).catch(() => false);
    if (!visible) return false;

    await checkbox.click({ timeout: 5000 });
    await safeWait(page, 1500);
    return true;
  } catch {
    return false;
  }
}

async function waitUntilCaptchaCleared(page: Page, timeoutMs: number): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!pageIsOpen(page)) return false;
    if (!(await isCaptchaChallengeVisible(page))) {
      if (await isCheckboxChecked(page) || !(await isCheckboxWidgetVisible(page))) return true;
    }
    await safeWait(page, 1000);
  }
  return pageIsOpen(page) && !(await isCaptchaChallengeVisible(page));
}

export async function waitManualCaptchaIfPresent(page: Page): Promise<void> {
  await handleCaptchaIfPresent(page);
}

export async function handleCaptchaIfPresent(page: Page): Promise<void> {
  if (!pageIsOpen(page)) return;
  if (testConfig.captchaMode === 'disabled') return;

  const challengeVisible = await isCaptchaChallengeVisible(page);
  const widgetVisible = await isCheckboxWidgetVisible(page);
  if (!challengeVisible && !widgetVisible) return;

  const clicked = await clickRecaptchaCheckboxIfPresent(page);

  if (testConfig.captchaMode !== 'manual') {
    if (clicked) {
      console.warn('reCAPTCHA: se marcó el checkbox automáticamente.');
    }

    const waitMs = clicked && !challengeVisible
      ? 8000
      : Math.min(Math.max(testConfig.captchaWaitSeconds, 10), 45) * 1000;
    const cleared = await waitUntilCaptchaCleared(page, waitMs);
    if (cleared) {
      console.warn('reCAPTCHA superado. Continuando flujo.');
      return;
    }

    if (await isCaptchaChallengeVisible(page)) {
      console.warn('El reto visual de reCAPTCHA sigue visible. Se continúa para no bloquear el test.');
    }
    return;
  }

  if (!challengeVisible) return;

  console.warn('======================================================');
  console.warn('CAPTCHA detectado. Resolver manualmente en el navegador.');
  console.warn(`El test esperará hasta ${testConfig.captchaWaitSeconds} segundos.`);
  console.warn('======================================================');

  const timeout = Date.now() + testConfig.captchaWaitSeconds * 1000;
  while (Date.now() < timeout) {
    if (!pageIsOpen(page)) return;
    if (!(await isCaptchaChallengeVisible(page))) {
      console.warn('CAPTCHA resuelto. Continuando flujo.');
      return;
    }
    await safeWait(page, 2000);
  }

  console.warn('Timeout esperando resolución manual de CAPTCHA. Se continúa para dejar evidencia del estado.');
}
