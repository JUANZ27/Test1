# language: es

@IBK11 @CuentaNegocios @PersonaJuridica
Característica: Apertura de Cuenta Negocios para Persona Jurídica
  Como representante legal de una empresa
  Quiero completar el flujo web de Cuenta Negocios
  Para solicitar la apertura de una cuenta de negocios en Interbank

  @smoke @staging @serenity
  Escenario: Completar flujo final de Cuenta Negocios hasta abrir cuenta
    Dado que el usuario ingresa al portal de Cuenta Negocios
    Y acepta las recomendaciones iniciales si aparecen
    Cuando selecciona el tipo de cuenta "Persona Jurídica"
    Y presiona el botón Continuar
    E ingresa el RUC "20653561378"
    Y el DNI del representante legal "47396815"
    E acepta la política de privacidad
    Y acepta la validación biométrica
    Y presiona el botón Comencemos
    Y resuelve manualmente el captcha si aparece
    Cuando completa los datos del negocio con partida "11045263", rubro "Alquileres" y subrubro "Alquiler de autos"
    Y completa los datos de los accionistas con participacion total del 100 por ciento
    Y completa los datos del representante legal
    Y continua la validacion de identidad si aparece
    Y selecciona la moneda "Soles"
    Entonces presiona el botón Abrir cuenta
