# language: es

@IBK11 @CuentaNegocios @NegocioConstitucion
Característica: Apertura de Cuenta Negocios para negocio en proceso de constitución
  Como representante legal de una empresa en proceso de constitución
  Quiero completar el flujo web de Cuenta Negocios
  Para iniciar la solicitud de apertura de cuenta antes de tener RUC definitivo

  @smoke @constitucion @FlujoEnProcesoDeConstitucion
  Escenario: Completar flujo de negocio en proceso de constitución
    Dado que el usuario ingresa al portal de Cuenta Negocios
    Y acepta las recomendaciones iniciales si aparecen
    Cuando selecciona el tipo de cuenta "Negocio en proceso de constitución"
    Y presiona el botón Continuar
    E ingresa los datos iniciales del representante legal para negocio en constitución
    Y presiona el botón Comencemos
    Y resuelve manualmente el captcha si aparece
    Cuando completa los datos del representante legal para negocio en constitución
    Y continua la validacion de identidad si aparece
    Y completa los datos del negocio en proceso de constitución
    Y inicia la validación biométrica si aparece
    Y configura la cuenta y solicita la apertura para negocio en constitución
    Entonces se genera la evidencia del flujo "Negocio en proceso de constitución"
