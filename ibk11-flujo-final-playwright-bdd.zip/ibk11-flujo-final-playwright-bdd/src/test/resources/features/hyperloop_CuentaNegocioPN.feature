# language: es

@IBK11 @CuentaNegocios @PersonaNatural
Característica: Apertura de Cuenta Negocios para Persona Natural
  Como persona natural con negocio
  Quiero completar el flujo web de Cuenta Negocios
  Para solicitar la apertura de una cuenta de negocios digital

  @smoke @personaNatural @FlujoCrearPersonaNatural @word
  Escenario: Completar flujo de creación de Persona Natural
    Dado que el usuario ingresa al portal de Cuenta Negocios
    Y acepta las recomendaciones iniciales si aparecen
    Cuando selecciona el tipo de cuenta "Persona Natural"
    Y presiona el botón Continuar
    E ingresa los datos iniciales de Persona Natural
    Y presiona el botón Comencemos
    Y resuelve manualmente el captcha si aparece
    Cuando completa los datos personales de Persona Natural
    Y continua la validacion de identidad si aparece
    Y completa los datos del negocio para Persona Natural
    Y inicia la validación biométrica si aparece
    Y configura la cuenta y solicita la apertura para Persona Natural
    Entonces se genera la evidencia del flujo "Persona Natural"

  @smoke @personaNatural @CP22 @FlujoPnCp22
  Escenario: Completar flujo Persona Natural con DNI y RUC CP22
    Dado que el usuario ingresa al portal de Cuenta Negocios
    Y acepta las recomendaciones iniciales si aparecen
    Cuando selecciona el tipo de cuenta "Persona Natural"
    Y presiona el botón Continuar
    E ingresa DNI y RUC del flujo CP22 de Persona Natural
    Y presiona el botón Comencemos
    Y resuelve manualmente el captcha si aparece
    Cuando responde PEP y residencia fiscal de Persona Natural ya registrada
    Y continua la validacion OTP de identidad si aparece
    Y completa los datos del negocio del flujo CP22 de Persona Natural
    Y inicia la validación biométrica si aparece
    Y configura la cuenta y solicita la apertura del flujo CP22 de Persona Natural
    Entonces se genera la evidencia del flujo "Persona Natural CP22 DNI y RUC"
