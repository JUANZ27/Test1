import { When, Then } from '@cucumber/cucumber';
import { CuentaNegociosPage } from '../pages/CuentaNegociosPage';
import { CustomWorld } from '../support/world';
import testData from '../resources/data/cuenta-negocios.json';

function pagina(world: CustomWorld): CuentaNegociosPage {
  return new CuentaNegociosPage(world.page);
}

When('ingresa los datos iniciales de Persona Natural', async function (this: CustomWorld) {
  const data = testData.personaNatural;
  await pagina(this).enterInitialNaturalPersonData(data.dni, data.rucOpcional);
});

When('completa los datos personales de Persona Natural', async function (this: CustomWorld) {
  await pagina(this).completeNaturalPersonPersonalData(testData.personaNatural.datosPersonales);
});

When('completa los datos del negocio para Persona Natural', async function (this: CustomWorld) {
  await pagina(this).completeNaturalPersonBusinessData(testData.personaNatural.datosNegocio);
});

When('configura la cuenta y solicita la apertura para Persona Natural', async function (this: CustomWorld) {
  await pagina(this).completeAccountConfiguration(testData.personaNatural.configuracionCuenta);
});

When('ingresa DNI y RUC del flujo CP22 de Persona Natural', async function (this: CustomWorld) {
  const data = testData.personaNaturalCp22;
  await pagina(this).enterInitialNaturalPersonData(data.dni, data.ruc);
});

When('responde PEP y residencia fiscal de Persona Natural ya registrada', async function (this: CustomWorld) {
  const data = testData.personaNaturalCp22;
  await pagina(this).completeNaturalPersonExistingClientDeclarations(data);
});

When('continua la validacion OTP de identidad si aparece', async function (this: CustomWorld) {
  await pagina(this).completeOtpIdentityValidationIfPresent(testData.personaNaturalCp22.otp);
});

When('completa los datos del negocio del flujo CP22 de Persona Natural', async function (this: CustomWorld) {
  await pagina(this).completeNaturalPersonBusinessData(testData.personaNaturalCp22.datosNegocio);
});

When('configura la cuenta y solicita la apertura del flujo CP22 de Persona Natural', async function (this: CustomWorld) {
  await pagina(this).completeAccountConfiguration(testData.personaNaturalCp22.configuracionCuenta);
});

When('ingresa los datos iniciales del representante legal para negocio en constitución', async function (this: CustomWorld) {
  const data = testData.negocioConstitucion;
  await pagina(this).enterInitialConstitutionData(data.dniRepresentante);
});

When('completa los datos del representante legal para negocio en constitución', async function (this: CustomWorld) {
  await pagina(this).completeConstitutionRepresentativeData(testData.negocioConstitucion.representanteLegal);
});

When('completa los datos del negocio en proceso de constitución', async function (this: CustomWorld) {
  await pagina(this).completeConstitutionBusinessData(testData.negocioConstitucion.datosNegocio);
});

When('configura la cuenta y solicita la apertura para negocio en constitución', async function (this: CustomWorld) {
  await pagina(this).completeAccountConfiguration(testData.negocioConstitucion.configuracionCuenta);
});

When('inicia la validación biométrica si aparece', async function (this: CustomWorld) {
  await pagina(this).startBiometricValidationIfPresent();
});

Then('se genera la evidencia del flujo {string}', async function (this: CustomWorld, flujo: string) {
  await this.attach(`Flujo ejecutado: ${flujo}`, 'text/plain');
});
