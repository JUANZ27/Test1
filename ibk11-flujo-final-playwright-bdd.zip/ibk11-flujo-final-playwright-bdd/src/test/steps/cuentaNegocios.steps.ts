import { Given, When, Then } from '@cucumber/cucumber';
import { CuentaNegociosPage } from '../pages/CuentaNegociosPage';
import { CustomWorld } from '../support/world';
import { testConfig } from '../support/config';

function pagina(world: CustomWorld): CuentaNegociosPage {
  return new CuentaNegociosPage(world.page);
}

Given('que el usuario ingresa al portal de Cuenta Negocios', async function (this: CustomWorld) {
  await pagina(this).openPortal();
});

Given('acepta las recomendaciones iniciales si aparecen', async function (this: CustomWorld) {
  await pagina(this).acceptInitialRecommendationsIfPresent();
});

When('selecciona el tipo de cuenta {string}', async function (this: CustomWorld, tipoCuenta: string) {
  await pagina(this).selectAccountType(tipoCuenta);
});

When('presiona el botón Continuar', async function (this: CustomWorld) {
  await pagina(this).clickContinue();
});

When('ingresa el RUC {string}', async function (this: CustomWorld, ruc: string) {
  await pagina(this).enterRuc(testConfig.data.ruc || ruc);
});

When('el DNI del representante legal {string}', async function (this: CustomWorld, dni: string) {
  await pagina(this).enterDni(testConfig.data.dni || dni);
});

When('acepta la política de privacidad', async function (this: CustomWorld) {
  await pagina(this).acceptPrivacy();
});

When('acepta la validación biométrica', async function (this: CustomWorld) {
  await pagina(this).acceptBiometrics();
});

When('presiona el botón Comencemos', async function (this: CustomWorld) {
  await pagina(this).clickStart();
});

When('resuelve manualmente el captcha si aparece', async function (this: CustomWorld) {
  await pagina(this).handleCaptchaIfPresent();
});

When('completa los datos del negocio con partida {string}, rubro {string} y subrubro {string}', async function (this: CustomWorld, partida: string, rubro: string, subrubro: string) {
  await pagina(this).completeBusinessData(
    testConfig.data.partida || partida,
    testConfig.data.rubro || rubro,
    testConfig.data.subrubro || subrubro
  );
});

When('completa los datos de los accionistas con participacion total del 100 por ciento', async function (this: CustomWorld) {
  await pagina(this).completeShareholdersData();
});

When('completa los datos del representante legal', async function (this: CustomWorld) {
  await pagina(this).completeLegalRepresentativeData();
});

When('continua la validacion de identidad si aparece', async function (this: CustomWorld) {
  await pagina(this).continueIdentityValidationIfPresent();
});

When('selecciona la moneda {string}', async function (this: CustomWorld, moneda: string) {
  await pagina(this).selectAccountCurrency(moneda);
});

Then('presiona el botón Abrir cuenta', async function (this: CustomWorld) {
  await pagina(this).clickOpenAccount();
});
