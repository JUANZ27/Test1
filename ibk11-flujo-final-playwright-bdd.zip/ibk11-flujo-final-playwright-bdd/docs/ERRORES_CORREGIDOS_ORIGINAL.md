# Errores corregidos

## 1. Mezcla de versiones de Serenity

El proyecto anterior utilizaba clases de Serenity 5, mientras el ZIP de referencia usa Serenity 3.6.21. Eso puede producir errores de imports, inyección y ejecución.

Esta versión usa solamente:

```java
net.thucydides.core.annotations.Managed
net.thucydides.core.annotations.Steps
net.thucydides.core.annotations.Step
```

## 2. Runner y ciclo Maven

El proyecto de referencia ejecuta los runners mediante Maven Failsafe en la fase `verify`. Por ello, el comando correcto es:

```bash
mvn clean verify
```

## 3. ChromeDriver

Se configura antes de inicializar Serenity con una ruta absoluta:

```text
<proyecto>/src/test/resources/webdriver/windows/chromedriver.exe
```

No se utiliza Selenium Manager.

## 4. Shadow DOM

Los inputs, select y checkboxes de Hyperloop poseen raíces Shadow DOM abiertas. El Page Object implementa una búsqueda recursiva y selectores alternativos para soportar cambios menores en la estructura.

## 5. CAPTCHA

El flujo termina después del clic en **Comencemos**. No intenta localizar, resolver, omitir ni validar CAPTCHA.
