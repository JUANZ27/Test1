# Cambios aplicados al flujo final

## Se continuó la automatización después del CAPTCHA

El proyecto ahora automatiza las pantallas posteriores a la validación CAPTCHA/manual:

1. Datos del negocio.
2. Datos de accionistas.
3. Datos del representante legal.
4. Validación de identidad si aparece.
5. Configuración de moneda.
6. Botón Abrir cuenta.

## Serenity BDD

El proyecto queda configurado con Serenity BDD mediante:

- `serenity-core`
- `serenity-junit`
- `serenity-cucumber`
- `CucumberWithSerenity`
- reporte en `target/site/serenity/index.html`

## Seguridad

No se agregó lógica para evadir CAPTCHA ni OTP. Si aparece un reto de seguridad, el test espera intervención manual y luego continúa.

## Archivo funcional

Se agregó el Word de flujo final en:

`documentos/Flujo ibk final.docx`
