# Flujos Word implementados

Este documento resume los flujos agregados al proyecto Playwright + TypeScript + Cucumber.

## 1. Flujo crear Persona Natural

Fuente: `docs/word-flows/Flujo_crear_persona_Natural.docx`

Feature:

```text
src/test/resources/features/ibk11_persona_natural.feature
```

Tag principal:

```text
@FlujoCrearPersonaNatural
```

Secuencia automatizada:

1. Ingresar al portal Cuenta Negocios.
2. Aceptar recomendaciones iniciales si aparecen.
3. Seleccionar tipo de cuenta `Persona Natural`.
4. Continuar.
5. Ingresar DNI de Persona Natural y RUC opcional.
6. Aceptar privacidad, biometría y uso de datos si aplica.
7. Presionar `Comencemos`.
8. Resolver CAPTCHA manualmente si aparece.
9. Completar datos personales.
10. Completar domicilio.
11. Responder PEP y residencia fiscal.
12. Completar datos del negocio.
13. Iniciar validación biométrica si aparece.
14. Configurar cuenta y solicitar apertura.

## 2. Flujo negocio en proceso de constitución

Fuente: `docs/word-flows/Flujo_en_proceso_de_constitucion.docx`

Feature:

```text
src/test/resources/features/ibk11_negocio_constitucion.feature
```

Tag principal:

```text
@FlujoEnProcesoDeConstitucion
```

Secuencia automatizada:

1. Ingresar al portal Cuenta Negocios.
2. Aceptar recomendaciones iniciales si aparecen.
3. Seleccionar tipo de cuenta `Negocio en proceso de constitución`.
4. Continuar.
5. Ingresar DNI del representante legal.
6. Aceptar privacidad, biometría y uso de datos si aplica.
7. Presionar `Comencemos`.
8. Resolver CAPTCHA manualmente si aparece.
9. Completar datos del representante legal.
10. Completar domicilio.
11. Responder PEP y residencia fiscal.
12. Completar datos del negocio en constitución.
13. Iniciar validación biométrica si aparece.
14. Configurar cuenta y solicitar apertura.

## 3. Flujo Persona Natural CP22 (DNI y RUC)

Fuente: `docs/word-flows/Flujo_PN_CP22.docx`

Feature:

```text
src/test/resources/features/hyperloop_CuentaNegocioPN.feature
```

Tag principal:

```text
@FlujoPnCp22
```

Secuencia automatizada:

1. Ingresar al portal Cuenta Negocios.
2. Aceptar recomendaciones iniciales si aparecen.
3. Seleccionar tipo de cuenta `Persona Natural`.
4. Continuar.
5. Ingresar DNI `47396870` y RUC `20276136632`.
6. Aceptar privacidad, biometría/OTP y uso de datos si aplica.
7. Presionar `Comencemos`.
8. Resolver CAPTCHA manualmente si aparece.
9. En datos de Persona Natural ya registrada, responder PEP = No y residencia fiscal en Perú = Sí.
10. Continuar validación OTP por correo si aparece.
11. Completar datos del negocio: nombre comercial `JUGERIA CARMEN`, rubro `Servicios comerciales` y subrubro `Bazar y/o juguetería`.
12. Iniciar validación biométrica si aparece.
13. Configurar cuenta en Soles y dólares, ubicación Ancash / Huaraz y solicitar apertura.

## Buenas prácticas aplicadas

- Separación Feature / Steps / Page Object / Data.
- Data-driven testing usando `cuenta-negocios.json`.
- Steps legibles en español.
- Métodos reutilizables para campos comunes.
- Selectores tolerantes para Shadow DOM y componentes Hyperloop.
- Evidencias Cucumber, screenshots y video según configuración.
