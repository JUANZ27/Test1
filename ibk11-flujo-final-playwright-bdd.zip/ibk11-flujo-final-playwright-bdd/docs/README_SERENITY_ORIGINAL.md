# IBK11 - Cuenta Negocios - Selenium + Serenity BDD

Proyecto actualizado con el flujo final del documento **Flujo ibk final.docx**.

## Stack

- Java 11
- Maven
- Selenium WebDriver
- Serenity BDD 3.6.21
- Cucumber + Gherkin en español
- JUnit 4
- ChromeDriver local dentro del proyecto

## Flujo automatizado

1. Abrir `https://bancacomercial-stg.interbank.pe/cuenta-negocios`.
2. Click en **Entendido**.
3. Seleccionar **Persona Jurídica**.
4. Click en **Continuar**.
5. Ingresar RUC `20653561378`.
6. Ingresar DNI `47396815`.
7. Marcar política de privacidad y validación biométrica.
8. Click en **Comencemos**.
9. Si aparece CAPTCHA, el test espera resolución manual. No se evade ni se salta el CAPTCHA.
10. Completar datos del negocio:
   - Rango de ingresos: `Desde S/ 0 hasta S/ 742,500`
   - Partida registral: `11045263`
   - Rubro: `Alquileres`
   - Subrubro: `Alquiler de autos`
   - Residencia fiscal: `Sí`
11. Completar accionistas:
   - Accionista 1: DNI `47396815`, participación `50`, PEP `No`
   - Accionista 2: DNI `47396816`, participación `50`, PEP `No`
12. Completar representante legal:
   - Email: `zcarlos927@gmail.com`
   - Operador: `Claro`
   - Celular: `954841305`
   - Nombre: `Juan Salazar Quispe`
   - Fecha nacimiento: `27/09/1992`
   - Sexo: `Hombre`
   - Estado civil: `Soltero`
   - Dirección: `Amazonas / Bagua / Aramango / Avenida / alameda / 1`
13. Continuar validación de identidad si aparece.
14. Seleccionar moneda **Soles**.
15. Click en **Abrir cuenta**.

## Ejecutar

```bat
ejecutar-flujo.bat
```

O por consola:

```bat
mvn clean verify -Denvironment=staging -Dcucumber.filter.tags="@IBK11"
```

## Reporte Serenity

Al finalizar se genera:

```text
target/site/serenity/index.html
```

Puedes abrirlo con:

```bat
abrir-reporte.bat
```

## Nota importante sobre CAPTCHA y OTP

El flujo no evade CAPTCHA ni códigos OTP. Si aparece un reto de seguridad, el navegador queda abierto y el test espera intervención manual para continuar.

## Evidencia funcional

El Word recibido se incluye en:

```text
documentos/Flujo ibk final.docx
```
