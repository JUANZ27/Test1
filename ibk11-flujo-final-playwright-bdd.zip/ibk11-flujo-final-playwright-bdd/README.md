# IBK11 Cuenta Negocios - Playwright + BDD

Proyecto migrado desde Selenium/Serenity BDD a **Playwright + Cucumber BDD**.

## Qué incluye

- BDD con Cucumber en español.
- Playwright para automatización web.
- Videos de ejecución por escenario en `reports/videos`.
- Screenshots automáticos en fallos en `reports/screenshots`.
- Reporte Cucumber JSON/HTML en `reports/cucumber`.
- Reporte HTML consolidado en `reports/html/index.html`.
- Page Object convertido desde `CuentaNegociosPage.java` a `CuentaNegociosPage.ts`.
- Soporte para Shadow DOM abierto mediante helpers deep-query.

## Importante sobre CAPTCHA

No se implementa evasión ni salto de CAPTCHA con stealth. Para QA se recomienda usar una de estas opciones válidas:

1. Ambiente de pruebas con CAPTCHA desactivado por feature flag.
2. Test keys oficiales del proveedor de CAPTCHA.
3. Mock/stub del endpoint de verificación en un ambiente controlado.
4. Resolución manual durante la ejecución, que es lo que queda implementado en este proyecto.

El step existente se mantiene así:

```gherkin
Y resuelve manualmente el captcha si aparece
```

## Requisitos

- Node.js 18 o superior.
- NPM.

## Instalación

```bash
npm install
npm run install:browsers
```

Copia `.env.example` a `.env` y coloca tu URL real:

```properties
BASE_URL=https://tu-url-real
HEADLESS=false
VIDEO=true
SCREENSHOT_ON_FAILURE=true
CAPTCHA_WAIT_SECONDS=180
```

## Ejecución

```bash
npm test
```

Con navegador visible:

```bash
npm run test:headed
```

Por tag smoke:

```bash
npm run test:smoke
```

Generar reporte consolidado:

```bash
npm run report
```

Abrir reporte:

```text
reports/html/index.html
```

## Estructura

```text
src/test/resources/features/ibk11_cuenta_negocios.feature
src/test/steps/cuentaNegocios.steps.ts
src/test/pages/CuentaNegociosPage.ts
src/test/support/hooks.ts
src/test/support/world.ts
src/test/support/config.ts
src/test/utils/deepSelectors.ts
src/test/utils/captcha.ts
```

## Evidencias

- Videos: `reports/videos/*.webm`
- Screenshots de fallos: `reports/screenshots/*.png`
- JSON Cucumber: `reports/cucumber/cucumber-report.json`
- HTML Cucumber básico: `reports/cucumber/cucumber-report.html`
- HTML consolidado: `reports/html/index.html`

## Comandos rápidos en Windows

También puedes usar:

```bat
ejecutar-flujo-playwright.bat
abrir-reporte-playwright.bat
```

## Notas de migración

El proyecto original usaba Selenium, Serenity y WebDriver local. Esta versión elimina `chromedriver.exe` y usa los browsers gestionados por Playwright.

Se mantuvieron los pasos BDD originales y se migró la lógica del Page Object a TypeScript. Es posible que algunos selectores necesiten ajuste fino al probar contra el ambiente real, especialmente si los Shadow DOM son cerrados o si hay cambios en los componentes Hyperloop.

## Flujos agregados desde Word

Se agregaron dos flujos nuevos tomando como base los documentos enviados:

- `docs/word-flows/Flujo_crear_persona_Natural.docx`
- `docs/word-flows/Flujo_en_proceso_de_constitucion.docx`
- `docs/word-flows/Flujo_PN_CP22.docx`

### Features nuevos

```text
src/test/resources/features/ibk11_persona_natural.feature
src/test/resources/features/ibk11_negocio_constitucion.feature
```

### Steps nuevos

```text
src/test/steps/flujosWord.steps.ts
```

### Datos de prueba

Los datos quedaron centralizados en:

```text
src/test/resources/data/cuenta-negocios.json
```

Se añadieron estos nodos:

```json
personaNatural
personaNaturalCp22
negocioConstitucion
```

## Ejecución por flujo

### Flujo original Persona Jurídica

```bash
npm run test:pj
```

### Flujo Crear Persona Natural

```bash
npm run test:persona-natural
```

Equivalente por tag:

```bash
npx cucumber-js --config cucumber.js --tags @FlujoCrearPersonaNatural
```

### Flujo Persona Natural CP22 (DNI y RUC)

```bash
npm run test:pn-cp22
```

Equivalente por tag:

```bash
npx cucumber-js --config cucumber.js --tags @FlujoPnCp22
```

### Flujo Negocio en Proceso de Constitución

```bash
npm run test:constitucion
```

Equivalente por tag:

```bash
npx cucumber-js --config cucumber.js --tags @FlujoEnProcesoDeConstitucion
```

### Ejecutar ambos flujos del Word

```bash
npm run test:word-flows
```

### Ejecutar todos los flujos principales

```bash
npm run test:all-flows
```

## Notas técnicas de los nuevos flujos

- Se mantuvo el patrón Page Object en `CuentaNegociosPage.ts`.
- Se agregaron métodos públicos reutilizables para Persona Natural y Negocio en Proceso de Constitución.
- Se reforzó la selección del tipo de cuenta para que funcione por texto visible y no solo por `id` interno del componente.
- El CAPTCHA no se evade. El flujo mantiene espera manual o uso de bypass oficial de ambiente QA.
- La validación biométrica puede requerir intervención manual si el ambiente no tiene mock o bypass configurado.
- Las evidencias se siguen generando en `reports/videos`, `reports/screenshots`, `reports/cucumber` y `reports/html`.
