# IBK11 Cuenta Negocios - Playwright + BDD

Proyecto migrado desde Selenium/Serenity BDD a **Playwright + Cucumber BDD**.

## Qué incluye

- BDD con Cucumber en español.
- Playwright para automatización web.
- Videos de ejecución por escenario en `reports/videos`.
- Screenshots automáticos en fallos en `reports/screenshots`.
- Reporte Cucumber JSON/HTML en `reports/cucumber`.
- Reporte HTML consolidado en `reports/html/index.html`.
- Page Object convertido desde `CuentaNegociosPage.java` a `CuentaNegociosPage.ts`.
- Soporte para Shadow DOM abierto mediante helpers deep-query.

## Importante sobre CAPTCHA

No se implementa evasión ni salto de CAPTCHA con stealth. Para QA se recomienda usar una de estas opciones válidas:

1. Ambiente de pruebas con CAPTCHA desactivado por feature flag.
2. Test keys oficiales del proveedor de CAPTCHA.
3. Mock/stub del endpoint de verificación en un ambiente controlado.
4. Resolución manual durante la ejecución, que es lo que queda implementado en este proyecto.

El step existente se mantiene así:

```gherkin
Y resuelve manualmente el captcha si aparece
```

## Requisitos

- Node.js 18 o superior.
- NPM.

## Instalación

```bash
npm install
npm run install:browsers
```

Copia `.env.example` a `.env` y coloca tu URL real:

```properties
BASE_URL=https://tu-url-real
HEADLESS=false
VIDEO=true
SCREENSHOT_ON_FAILURE=true
CAPTCHA_WAIT_SECONDS=180
```

## Ejecución

```bash
npm test
```

Con navegador visible:

```bash
npm run test:headed
```

Por tag smoke:

```bash
npm run test:smoke
```

Generar reporte consolidado:

```bash
npm run report
```

Abrir reporte:

```text
reports/html/index.html
```

## Estructura

```text
src/test/resources/features/ibk11_cuenta_negocios.feature
src/test/steps/cuentaNegocios.steps.ts
src/test/pages/CuentaNegociosPage.ts
src/test/support/hooks.ts
src/test/support/world.ts
src/test/support/config.ts
src/test/utils/deepSelectors.ts
src/test/utils/captcha.ts
```

## Evidencias

- Videos: `reports/videos/*.webm`
- Screenshots de fallos: `reports/screenshots/*.png`
- JSON Cucumber: `reports/cucumber/cucumber-report.json`
- HTML Cucumber básico: `reports/cucumber/cucumber-report.html`
- HTML consolidado: `reports/html/index.html`

## Comandos rápidos en Windows

También puedes usar:

```bat
ejecutar-flujo-playwright.bat
abrir-reporte-playwright.bat
```

## Notas de migración

El proyecto original usaba Selenium, Serenity y WebDriver local. Esta versión elimina `chromedriver.exe` y usa los browsers gestionados por Playwright.

Se mantuvieron los pasos BDD originales y se migró la lógica del Page Object a TypeScript. Es posible que algunos selectores necesiten ajuste fino al probar contra el ambiente real, especialmente si los Shadow DOM son cerrados o si hay cambios en los componentes Hyperloop.
