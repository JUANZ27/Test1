@echo off
if exist reports\html\index.html (
  start reports\html\index.html
) else if exist reports\cucumber\cucumber-report.html (
  start reports\cucumber\cucumber-report.html
) else (
  echo No existe reporte. Ejecuta primero ejecutar-flujo-playwright.bat
  pause
)
