module.exports = {
  default: {
    requireModule: ['ts-node/register'],
    require: [
      'src/test/support/**/*.ts',
      'src/test/steps/**/*.ts'
    ],
    paths: ['src/test/resources/features/**/*.feature'],
    format: [
      'progress-bar',
      'json:reports/cucumber/cucumber-report.json',
      'html:reports/cucumber/cucumber-report.html'
    ],
    parallel: 1,
    retry: 0,
    timeout: 360000
  }
};
