@echo off
setlocal

echo =====================================
echo Ejecutando IBK11 Playwright BDD
echo =====================================

if not exist node_modules (
  echo Instalando dependencias...
  call npm install
)

call npm run install:browsers
call npm test
call npm run report

echo.
echo Reporte generado en reports\html\index.html
pause
