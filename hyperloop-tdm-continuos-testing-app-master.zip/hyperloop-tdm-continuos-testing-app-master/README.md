## Requisitos
- Tener instalado **JDK 18**
- Tener instalado **última versión** de **Maven**
## Proyecto TDM

Tiene como fin de mejorar la respuesta de pruebas, y con la implementación de pruebas automatizadas, 
es necesario proporcionar datos disponibles y seguros para ejecutar las pruebas, para este fin 
se esta implementando TDM, para mantener actualizados los datos que serán consumidos por los 
sistemas de automatización. Para mayor información ver [Test Data Management (TDM)](https://interbank.atlassian.net/wiki/spaces/TC/pages/3635642385/Test+Data+Management+TDM+-+Hyperloop)
## Usar Librería TDM
En esta primera fase se encuentra disponible com librería local
la cual se debe crear y registrar en el archivo pom.xml de cada proyecto E2E.

- Para crear la librería local ejecutar:
~~~~
C:\assi-tdm-continuous-testing> mvn clean install
~~~~
- Registrar en el archivo pom.xml del proyecto E2E
``` 
  <dependency>
     <groupId>com.nttdata.tdm</groupId>
     <artifactId>assi-tdm-continuous-testing</artifactId>
     <version>1.0</version>
  </dependency>
``` 
- Colocar los archivos [application-stg.properties](src/Documents/application-stg.properties) y [application-uat.properties](src/Documents/application-uat.properties), dentro del usuario local de la 
PC **C:\Users\Mi usuario**, este archivo contiene url de los servicios base y credenciales de acceso necesarios para 
ejecutar las validaciónes.

## Funciones disponibles
Dentro de de la clase [CD.java](src/test/java/com/nttdata/tdm/CD.java), se encuentran las funciones
disponibles para su usolas cuales se iran modificando de acuerdo a la necesidad.
La principales funciones disponibles son las siguieintes:

| Tag | Descripción                                                                                                                                                                                                                                                                                                                                                       |
| ------------- |-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `GenerateDataFromExcel` | Agrega clientes desde un archivo excel con valores TIPO DOCUMENTO, NUMERO DOC, ubicado en el directorio  [/src/main/resources/Data](src/main/resources/Data/) esta fucnión tiene como parametros <br/> - data: Directorio del donde se ubica el archivo<br/> - file: Nombre del archivo <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg** |
| `GenerateDataNoClient` | Genera datos n no clientes aleatorios, esta fucnión tiene como parametros <br/> - typeDocument: Tipo de documento a generar DNI, RUC<br/> - numberRecord: Numero de clientes a generar >0 <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                               |
| `GetDataNoClient` | Obtiene datos clientes o no clientes. <br/> - typeDocument, <br/> - typeClient: Tipo CLIENTE, NO CLIENTE  <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                                                                                               |
| `GetDataClient` | Obtiene datos clientes o no clientes que tienen socios. <br/> - typeDocument, <br/> - typeClient: Tipo CLIENTE, NO CLIENTE  <br/>- partners: Tipo CLIENTE, NO CLIENTE  <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                                  |
| `GetDataClientNatural` | Obtiene datos clientes o no clientes principalmente DNI que tengan menos de 4 cuentas creadas <br/> - typeDocument, <br/> - typeClient: Tipo CLIENTE, NO CLIENTE  <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                                       |
| `SetUpadateNoClient` | Actualiza los datos de un no cliente, actualiza estado, partners, usa los parametros <br/> - documentClient: Numero de documento dni  o ruc<br/> - partners: Identifica si tiene socios o no (true, false) <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**   <br/> - typeClient: Indica si es un Cliente o no Cliente opcional          |
| `SetUpadateClient` | Actualiza estado de no cliente a cliente y el numero de cuentas creadas<br/> - documentClient: Numero de documento dni  o ruc<br/> - countrecord: Numero de cuentas creadas <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                             |
| `SetOperation` | Almacena datos en la tabla de resultados luego de crear la cuenta <br/> - operation: Modelo de operación con todos los datos<br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                                                                             |
| `EmptyDataBase` | Elimina todos los datos de la base en el ambiente elegido <br/> - environment: Ambiente donde se ejecuta la carga, **uat**, **stg**                                                                                                               |

## Conexión Base de datos
En el archivo [application.properties](src/main/resources/application.properties), se encuentra la conexión a la base de datos deTDM.







