## Requisitos
- Tener instalado **JDK 18** o compatible
- Tener instalado **Maven**

## Proyecto TDM
Proyecto para mantener datos disponibles y seguros que serán consumidos por automatizaciones.

## Configuración local requerida
Por seguridad, las URLs y credenciales no deben quedar quemadas en `src/main/resources/application.properties`.

Copiar los archivos:

- [`application-uat.properties`](src/Documents/application-uat.properties)
- [`application-stg.properties`](src/Documents/application-stg.properties)

a la carpeta del usuario local de Windows:

```text
C:\Users\<tu_usuario>\application-uat.properties
C:\Users\<tu_usuario>\application-stg.properties
```

Ejemplo:

```text
C:\Users\user\application-uat.properties
```

El proyecto lee ese archivo automáticamente usando:

```text
file:${user.home}/application-${environment}.properties
```

## Endpoints IFX implementados

### 1. Crear cliente persona natural

```http
POST /tdm/ifx/customer/create?typeDocument=DNI
```

Consume internamente:

```text
/party-reference-data-directory-customer/v1/customer/create
```

El DNI es incremental desde `ifx.dni-base` y se guarda en:

```text
target/dni-sequence.txt
```

### 2. Consulta cliente

```http
POST /tdm/ifx/customer/retrieve?typeDocument=DNI&documentNumber=40903462
```

Consume internamente con token de consulta:

```text
/en-party-reference-data-directory-customer/v2/full-information/retrieve
```

Usa:

```properties
ifx.scope-consulta=...
```

Si no se envía `documentNumber`, usa:

```properties
ifx.query-dni=40903462
ifx.query-ruc=20276135769
```

### 3. Crear cliente PJ

```http
POST /tdm/ifx/merchant/create?typeDocument=RUC
```

Consume internamente con token transaccional:

```text
/party-reference-data-directory-merchant/v1/create-customer/execute
```

El RUC es incremental desde `ifx.ruc-base` y se guarda en:

```text
target/ruc-sequence.txt
```

### 4. Crear cuenta

```http
POST /tdm/ifx/account/create?typeDocument=DNI&documentNumber=12345456&customerId=12312312
```

Consume internamente con token transaccional:

```text
/customer-products-and-services/v1/accounts/create
```

## Funciones disponibles en `CD.java`

Dentro de la clase:

```text
src/test/java/com/nttdata/tdm/CD.java
```

se agregaron estas funciones principales:

| Tag | Descripción |
| --- | --- |
| `CrearPersonaNaturalIFX` | Crea persona natural con DNI incremental. |
| `ConsultaClienteIFX` | Consulta información completa de cliente con token de consulta. |
| `CrearClientePJIFX` | Crea cliente persona jurídica con RUC incremental. |
| `CrearCuentaIFX` | Crea cuenta usando documento y customerId. |
| `GenerateDataFromExcel` | Agrega clientes desde archivo Excel/CSV con columnas `TIPO DOCUMENTO`, `NUMERO DOC`, ubicado en `src/main/resources/Data`. |
| `GenerateDataNoClient` | Genera N no clientes aleatorios. `DNI` crea persona natural y `RUC` crea cliente PJ. |
| `GetDataNoClient` | Obtiene datos de cliente/no cliente usando token de consulta. |
| `GetDataClient` | Obtiene datos de cliente/no cliente con parámetro de socios. |
| `GetDataClientNatural` | Consulta cliente natural DNI y agrega metadata para validar regla de menos de 4 cuentas. |

## Ejecución desde `CD.java`

```powershell
mvn -Dtest=CD#CrearPersonaNaturalIFX -Denvironment=uat test
mvn -Dtest=CD#ConsultaClienteIFX -Denvironment=uat test
mvn -Dtest=CD#CrearClientePJIFX -Denvironment=uat test
mvn -Dtest=CD#CrearCuentaIFX -Denvironment=uat test
mvn -Dtest=CD#GenerateDataNoClient -Denvironment=uat test
mvn -Dtest=CD#GenerateDataFromExcel -Denvironment=uat test
mvn -Dtest=CD#GetDataNoClient -Denvironment=uat test
mvn -Dtest=CD#GetDataClient -Denvironment=uat test
mvn -Dtest=CD#GetDataClientNatural -Denvironment=uat test
```

## Ejecución como API Spring Boot

```powershell
mvn spring-boot:run -Denvironment=uat
```

Luego consumir:

```powershell
curl --request POST "http://localhost:8080/tdm/ifx/customer/create?typeDocument=DNI"
curl --request POST "http://localhost:8080/tdm/ifx/customer/retrieve?typeDocument=DNI&documentNumber=40903462"
curl --request POST "http://localhost:8080/tdm/ifx/merchant/create?typeDocument=RUC"
curl --request POST "http://localhost:8080/tdm/ifx/account/create?typeDocument=DNI&documentNumber=12345456&customerId=12312312"
```

Funciones expuestas como endpoint:

```powershell
curl --request POST "http://localhost:8080/tdm/ifx/GenerateDataNoClient?typeDocument=DNI&numberRecord=1"
curl --request POST "http://localhost:8080/tdm/ifx/GenerateDataFromExcel?data=Data&file=CargaCliente.xlsx"
curl --request GET  "http://localhost:8080/tdm/ifx/GetDataNoClient?typeDocument=DNI&typeClient=NO_CLIENTE"
curl --request GET  "http://localhost:8080/tdm/ifx/GetDataClient?typeDocument=DNI&typeClient=CLIENTE&partners=CLIENTE"
curl --request GET  "http://localhost:8080/tdm/ifx/GetDataClientNatural?typeDocument=DNI&typeClient=CLIENTE"
```

## Uso desde otro proyecto Java

```java
Do.crearPersonaNaturalIFX("DNI", "uat");
Do.consultarClienteIFX("DNI", "40903462", "uat");
Do.crearClientePJIFX("RUC", null, "uat");
Do.crearCuentaIFX("DNI", "12345456", "12312312", "uat");
Do.GenerateDataNoClient("DNI", 1, "uat");
Do.GenerateDataFromExcel("Data", "CargaCliente.xlsx", "uat");
Do.GetDataNoClient("DNI", "NO_CLIENTE", "uat");
Do.GetDataClient("DNI", "CLIENTE", "CLIENTE", "uat");
Do.GetDataClientNatural("DNI", "CLIENTE", "uat");
```

## Nota importante del token
El `grant_type` correcto es:

```text
password
```

No usar `passwrod`.

## Corrección v5: token específico para consulta full

La consulta full usa un token independiente de consulta. En `application-uat.properties` debe quedar así:

```properties
ifx.token-path=/oauthproviderh1/oauth2/token
ifx.scope-consulta=scopeTransaccionH1_o_scope_consulta_real

ifx.consulta.token-path=/oauthproviderh1/oauth2/token
ifx.consulta.grant-type=password
ifx.consulta.username=${ifx.username}
ifx.consulta.password=${ifx.password}
ifx.consulta.client-id=${ifx.client-id}
ifx.consulta.client-secret=${ifx.client-secret}
ifx.consulta.scope=${ifx.scope-consulta}
```

Equivale al curl de token de consulta:

```bash
curl --request POST \
  --url https://apic-gw-com.apps.ocpsbx.integracion.grupoib.local/ibk-uat/int-com-uat/oauthproviderh1/oauth2/token \
  --header 'content-type: application/x-www-form-urlencoded' \
  --data grant_type=password \
  --data username=uBseGenPrd \
  --data 'password=Ibk$2018' \
  --data 'client_id={{ifx_client_id}}' \
  --data 'client_secret={{ifx_client_secret}}' \
  --data 'scope={{ifx_scope_consulta}}'
```

Por defecto el header `authorization` se envía con el token tal como lo devuelve OAuth. Si el gateway exige `Bearer`, configurar:

```properties
ifx.consulta.authorization-prefix=Bearer
```


## IFX v6 - tokens separados

Se separaron los tokens por tipo de operación:

- **Consulta full** usa `ifx.consulta.scope` / `ifx.scope-consulta` y se genera con `generateConsultationToken()`.
- **Crear cliente PN**, **crear cliente PJ** y **crear cuenta** usan `ifx.transaccion.scope` / `ifx.scope-transaccion` y se generan con `generateTransactionToken()`.

Ejecutar pruebas:

```powershell
mvn -Dtest=CD#ConsultaClienteIFX -Denvironment=uat test
mvn -Dtest=CD#CrearPersonaNaturalIFX -Denvironment=uat test
mvn -Dtest=CD#CrearClientePJIFX -Denvironment=uat test
mvn -Dtest=CD#CrearCuentaIFX -Denvironment=uat test
```

En `C:\Users\<usuario>\application-uat.properties` debe existir:

```properties
ifx.scope-transaccion=TU_SCOPE_TRANSACCION
ifx.scope-consulta=TU_SCOPE_CONSULTA
ifx.transaccion.scope=${ifx.scope-transaccion}
ifx.consulta.scope=${ifx.scope-consulta}
ifx.transaccion.authorization-prefix=Bearer
ifx.consulta.authorization-prefix=Bearer
```

Si el API espera el token crudo sin `Bearer`, deja vacío `ifx.transaccion.authorization-prefix` o `ifx.consulta.authorization-prefix`.
