# Implementación IFX - Hyperloop TDM

## Archivos modificados/agregados

```text
src/main/java/com/nttdata/tdm/Do.java
src/main/java/com/nttdata/tdm/ifx/client/IfxStandaloneClient.java
src/main/java/com/nttdata/tdm/ifx/controller/IfxController.java
src/main/java/com/nttdata/tdm/ifx/dto/IfxApiResponse.java
src/main/java/com/nttdata/tdm/ifx/dto/IfxBatchResponse.java
src/test/java/com/nttdata/tdm/CD.java
src/Documents/application-uat.properties
src/Documents/application-stg.properties
src/main/resources/Data/CargaCliente.xlsx
src/main/resources/Data/CargaCliente.csv
pom.xml
README.md
```

## Endpoints internos IFX agregados

1. Consulta cliente:

```text
/en-party-reference-data-directory-customer/v2/full-information/retrieve
```

Usa token de consulta: `ifx.scope-consulta`.

2. Crear cliente PJ:

```text
/party-reference-data-directory-merchant/v1/create-customer/execute
```

Usa token transaccional: `ifx.scope-transaccion`.

3. Crear cuenta:

```text
/customer-products-and-services/v1/accounts/create
```

Usa token transaccional: `ifx.scope-transaccion`.

## Endpoints REST expuestos por el TDM

```text
POST /tdm/ifx/customer/create
POST /tdm/ifx/customer/retrieve
POST /tdm/ifx/merchant/create
POST /tdm/ifx/account/create
POST /tdm/ifx/GenerateDataFromExcel
POST /tdm/ifx/GenerateDataNoClient
GET  /tdm/ifx/GetDataNoClient
GET  /tdm/ifx/GetDataClient
GET  /tdm/ifx/GetDataClientNatural
```

## Seguridad

Las credenciales reales deben colocarse en:

```text
C:\Users\<usuario>\application-uat.properties
C:\Users\<usuario>\application-stg.properties
```

Los archivos del repositorio quedan como plantillas.

## v5 - Ajuste consulta full

Se separó explícitamente el token de consulta para `full-information/retrieve`:

```properties
ifx.consulta.token-path=/oauthproviderh1/oauth2/token
ifx.consulta.grant-type=password
ifx.consulta.username=${ifx.username}
ifx.consulta.password=${ifx.password}
ifx.consulta.client-id=${ifx.client-id}
ifx.consulta.client-secret=${ifx.client-secret}
ifx.consulta.scope=${ifx.scope-consulta}
```

La consulta cliente ahora usa `generateConsultationToken()` y ya no reutiliza el token transaccional.

## v6 - Separación estricta de tokens

Se corrige la ejecución para que cada operación solicite el token correcto:

- Consulta full: `generateConsultationToken()` con `ifx.consulta.scope` / `ifx.scope-consulta`.
- Crear cliente PN: `generateTransactionToken()` con `ifx.transaccion.scope` / `ifx.scope-transaccion`.
- Crear cliente PJ: `generateTransactionToken()` con `ifx.transaccion.scope` / `ifx.scope-transaccion`.
- Crear cuenta: `generateTransactionToken()` con `ifx.transaccion.scope` / `ifx.scope-transaccion`.

También se dejó `ifx.transaccion.authorization-prefix=Bearer` y `ifx.consulta.authorization-prefix=Bearer` por defecto. Si el gateway espera el token sin Bearer, dejar el valor vacío en el archivo local.


## v8 - Consulta CCE Customer Special Status

Se agregó el endpoint IFX:

```text
GET /customer-profile/v1/customer-special-status?documentTypeId=1&documentNumber=40975592
```

Características:

- Usa exclusivamente `generateConsultationToken()`.
- Envía `documentTypeId` y `documentNumber` como query params.
- Usa headers propios configurables bajo `ifx.special-status.*`.
- Se expone en Spring como `GET /tdm/ifx/customer-special-status`.
- Se agregó el método `ConsultaCustomerSpecialStatusCCE()` en `CD.java`.
