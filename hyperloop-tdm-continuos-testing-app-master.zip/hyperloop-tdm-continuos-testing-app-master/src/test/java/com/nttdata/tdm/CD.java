package com.nttdata.tdm;

import org.junit.jupiter.api.Test;

public class CD {
    /* ************ Ingresos automatizados ************ */
    // Cambiar a "stg" si necesitas ejecutar con application-stg.properties.
    String environment = System.getProperty("environment", "uat");

    @Test
    public void CrearPersonaNaturalIFX() {
        Do.crearPersonaNaturalIFX("DNI", environment);
    }

    @Test
    public void ConsultaClienteIFX() {
        Do.consultarClienteIFX("DNI", "40903462", environment);
    }

    @Test
    public void ConsultaCustomerSpecialStatusCCE() {
        Do.consultarCustomerSpecialStatusCCE("1", "40975592", environment);
    }

    @Test
    public void CrearClientePJIFX() {
        Do.crearClientePJIFX("RUC", null, environment);
    }

    @Test
    public void CrearCuentaIFX() {
        Do.crearCuentaIFX("DNI", "12345456", "12312312", environment);
    }

    /**
     * Agrega clientes desde un archivo Excel/CSV con columnas:
     * TIPO DOCUMENTO, NUMERO DOC.
     * Ubicacion sugerida: src/main/resources/Data/CargaCliente.xlsx
     */
    @Test
    public void GenerateDataFromExcel() {
        Do.GenerateDataFromExcel("Data", "CargaCliente.xlsx", environment);
    }

    /**
     * Genera N no clientes aleatorios.
     * typeDocument: DNI o RUC.
     * numberRecord: cantidad de registros a generar.
     */
    @Test
    public void GenerateDataNoClient() {
        Do.GenerateDataNoClient("DNI", 1, environment);
    }

    /**
     * Obtiene datos de cliente o no cliente usando token de consulta.
     */
    @Test
    public void GetDataNoClient() {
        Do.GetDataNoClient("DNI", "NO_CLIENTE", environment);
    }

    /**
     * Obtiene datos de cliente o no cliente que tienen socios.
     */
    @Test
    public void GetDataClient() {
        Do.GetDataClient("DNI", "CLIENTE", "CLIENTE", environment);
    }

    /**
     * Obtiene datos de cliente natural DNI, regla: menos de 4 cuentas creadas.
     */
    @Test
    public void GetDataClientNatural() {
        Do.GetDataClientNatural("DNI", "CLIENTE", environment);
    }
}
