package com.nttdata.tdm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static junit.framework.Assert.assertEquals;

@SpringBootTest
class HyperloopTdmApiTestingApplicationTests {

	@Test
	void contextLoads() {
		//assertEquals(0, HyperloopTdmApiTestingApplication.);
	}

}
