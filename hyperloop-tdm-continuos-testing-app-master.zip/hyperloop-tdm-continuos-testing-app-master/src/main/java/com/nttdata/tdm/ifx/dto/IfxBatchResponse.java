package com.nttdata.tdm.ifx.dto;

import java.util.ArrayList;
import java.util.List;

public class IfxBatchResponse {
    private String operation;
    private String environment;
    private int requested;
    private int executed;
    private List<IfxApiResponse> responses = new ArrayList<>();

    public String getOperation() { return operation; }
    public void setOperation(String operation) { this.operation = operation; }

    public String getEnvironment() { return environment; }
    public void setEnvironment(String environment) { this.environment = environment; }

    public int getRequested() { return requested; }
    public void setRequested(int requested) { this.requested = requested; }

    public int getExecuted() { return executed; }
    public void setExecuted(int executed) { this.executed = executed; }

    public List<IfxApiResponse> getResponses() { return responses; }
    public void setResponses(List<IfxApiResponse> responses) { this.responses = responses; }
}
