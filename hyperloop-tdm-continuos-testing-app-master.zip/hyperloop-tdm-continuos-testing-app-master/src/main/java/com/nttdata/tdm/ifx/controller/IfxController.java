package com.nttdata.tdm.ifx.controller;

import com.nttdata.tdm.Do;
import com.nttdata.tdm.ifx.dto.IfxApiResponse;
import com.nttdata.tdm.ifx.dto.IfxBatchResponse;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tdm/ifx")
public class IfxController {

    private String env(String environment) {
        return environment == null || environment.trim().isEmpty()
                ? System.getProperty("environment", "uat")
                : environment.trim().toLowerCase();
    }

    @PostMapping("/customer/create")
    @ResponseStatus(HttpStatus.OK)
    public IfxCreateCustomerResponse createCustomer(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                                    @RequestParam(value = "documentNumber", required = false) String documentNumber,
                                                    @RequestParam(value = "environment", required = false) String environment) {
        return Do.crearPersonaNaturalIFX(typeDocument, documentNumber, env(environment));
    }

    @PostMapping("/customer/retrieve")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse retrieveCustomer(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                           @RequestParam(value = "documentNumber", required = false) String documentNumber,
                                           @RequestParam(value = "environment", required = false) String environment) {
        return Do.consultarClienteIFX(typeDocument, documentNumber, env(environment));
    }

    @GetMapping("/customer-special-status")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse retrieveCustomerSpecialStatus(
            @RequestParam(value = "documentTypeId", defaultValue = "1") String documentTypeId,
            @RequestParam(value = "documentNumber", defaultValue = "40975592") String documentNumber,
            @RequestParam(value = "environment", required = false) String environment) {
        return Do.consultarCustomerSpecialStatusCCE(documentTypeId, documentNumber, env(environment));
    }

    @PostMapping("/merchant/create")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse createMerchant(@RequestParam(value = "typeDocument", defaultValue = "RUC") String typeDocument,
                                         @RequestParam(value = "documentNumber", required = false) String documentNumber,
                                         @RequestParam(value = "environment", required = false) String environment) {
        return Do.crearClientePJIFX(typeDocument, documentNumber, env(environment));
    }

    @PostMapping("/account/create")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse createAccount(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                        @RequestParam(value = "documentNumber", required = false) String documentNumber,
                                        @RequestParam(value = "customerId", required = false) String customerId,
                                        @RequestParam(value = "environment", required = false) String environment) {
        return Do.crearCuentaIFX(typeDocument, documentNumber, customerId, env(environment));
    }

    @PostMapping("/GenerateDataFromExcel")
    @ResponseStatus(HttpStatus.OK)
    public IfxBatchResponse generateDataFromExcel(@RequestParam(value = "data", defaultValue = "Data") String data,
                                                  @RequestParam(value = "file") String file,
                                                  @RequestParam(value = "environment", required = false) String environment) {
        return Do.GenerateDataFromExcel(data, file, env(environment));
    }

    @PostMapping("/GenerateDataNoClient")
    @ResponseStatus(HttpStatus.OK)
    public IfxBatchResponse generateDataNoClient(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                                 @RequestParam(value = "numberRecord", defaultValue = "1") int numberRecord,
                                                 @RequestParam(value = "environment", required = false) String environment) {
        return Do.GenerateDataNoClient(typeDocument, numberRecord, env(environment));
    }

    @GetMapping("/GetDataNoClient")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse getDataNoClient(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                          @RequestParam(value = "typeClient", defaultValue = "NO_CLIENTE") String typeClient,
                                          @RequestParam(value = "environment", required = false) String environment) {
        return Do.GetDataNoClient(typeDocument, typeClient, env(environment));
    }

    @GetMapping("/GetDataClient")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse getDataClient(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                        @RequestParam(value = "typeClient", defaultValue = "CLIENTE") String typeClient,
                                        @RequestParam(value = "partners", defaultValue = "CLIENTE") String partners,
                                        @RequestParam(value = "environment", required = false) String environment) {
        return Do.GetDataClient(typeDocument, typeClient, partners, env(environment));
    }

    @GetMapping("/GetDataClientNatural")
    @ResponseStatus(HttpStatus.OK)
    public IfxApiResponse getDataClientNatural(@RequestParam(value = "typeDocument", defaultValue = "DNI") String typeDocument,
                                               @RequestParam(value = "typeClient", defaultValue = "CLIENTE") String typeClient,
                                               @RequestParam(value = "environment", required = false) String environment) {
        return Do.GetDataClientNatural(typeDocument, typeClient, env(environment));
    }
}
