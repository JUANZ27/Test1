package com.nttdata.tdm.service;

import com.nttdata.tdm.model.entity.ClientEnt;

import java.util.List;

public interface IClientService {
    ClientEnt save(ClientEnt client);
    ClientEnt findById(String id);
    void delete(ClientEnt client);
    List <ClientEnt> findByTypeClient(String typeClient);

    List <ClientEnt> findByTypeDocument(String typeDocument);

    List <ClientEnt> findAllSunat(String typeClient,String typeDocument,Integer sunat);
    List <ClientEnt> findAllReniec(String typeClient,String typeDocument,Integer reniec);
}
