package com.nttdata.tdm.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="clientdatauat")
public class ClientEnt implements Serializable {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(name="documentclient")
    private String documentClient;
    @Column(name="typeclient")
    private String typeClient;
    @Column(name="typedocument")
    private String typeDocument;
    @Column(name="firstfirstname")
    private String firstFirstName;
    @Column(name="secondfirstname")
    private String secondFirstName;
    @Column(name="firstlastname")
    private String firstLastName;
    @Column(name="secondlastname")
    private String secondLastName;
    @Column(name="datebirth")
    private String dateBirth;
    @Column(name="operator")
    private String operator;
    @Column(name="phonenumber")
    private String phoneNumber;
    @Column(name="emailpersonal")
    private String emailPersonal;
    @Column(name="companyname")
    private String companyName;
    @Column(name="creationdate")
    private String creationDate;
    @Column(name="emailcompany")
    private String emailCompany;
    @Column(name="withpartners")
    private String withPartners;
    @Column(name="countrecord")
    private Integer countRecord;
    @Column(name="sunat")
    private String sunat;
    @Column(name="reniec")
    private String reniec;
    //@Column(name="address")
    //private List<ClientAddress> address;
}
