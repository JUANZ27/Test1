package com.nttdata.tdm.ifx.dto;

public class IfxCreateCustomerResponse {
    private String documentType;
    private String documentTypeId;
    private String documentNumber;
    private String firstName;
    private String secondName;
    private String firstLastName;
    private String secondLastName;
    private String email;
    private String phoneNumber;
    private int statusCode;
    private boolean tokenGenerated;
    private String busResponseMessage;
    private String srvResponseCode;
    private String srvResponseMessage;
    private String responseBody;

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentTypeId() {
        return documentTypeId;
    }

    public void setDocumentTypeId(String documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getFirstLastName() {
        return firstLastName;
    }

    public void setFirstLastName(String firstLastName) {
        this.firstLastName = firstLastName;
    }

    public String getSecondLastName() {
        return secondLastName;
    }

    public void setSecondLastName(String secondLastName) {
        this.secondLastName = secondLastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public boolean isTokenGenerated() {
        return tokenGenerated;
    }

    public void setTokenGenerated(boolean tokenGenerated) {
        this.tokenGenerated = tokenGenerated;
    }

    public String getBusResponseMessage() {
        return busResponseMessage;
    }

    public void setBusResponseMessage(String busResponseMessage) {
        this.busResponseMessage = busResponseMessage;
    }

    public String getSrvResponseCode() {
        return srvResponseCode;
    }

    public void setSrvResponseCode(String srvResponseCode) {
        this.srvResponseCode = srvResponseCode;
    }

    public String getSrvResponseMessage() {
        return srvResponseMessage;
    }

    public void setSrvResponseMessage(String srvResponseMessage) {
        this.srvResponseMessage = srvResponseMessage;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}
