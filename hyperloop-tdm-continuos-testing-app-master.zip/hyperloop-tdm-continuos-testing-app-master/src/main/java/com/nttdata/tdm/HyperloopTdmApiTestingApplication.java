package com.nttdata.tdm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.nttdata.tdm.controllers"})
public class HyperloopTdmApiTestingApplication {
	public static void main(String[] args) {
		SpringApplication.run(HyperloopTdmApiTestingApplication.class, args);
	}

}
