package com.nttdata.tdm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HyperloopTdmApiTestingApplication {
    public static void main(String[] args) {
        SpringApplication.run(HyperloopTdmApiTestingApplication.class, args);
    }
}
