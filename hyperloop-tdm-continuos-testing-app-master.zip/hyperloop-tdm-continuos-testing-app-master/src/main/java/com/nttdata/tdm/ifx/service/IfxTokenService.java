package com.nttdata.tdm.ifx.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.tdm.ifx.dto.IfxTokenResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class IfxTokenService {

    private final ObjectMapper objectMapper;
    private final IfxHttpClientFactory httpClientFactory;

    @Value("${ifx.base-url}")
    private String baseUrl;

    @Value("${ifx.token-path:/oauthproviderh1/oauth2/token}")
    private String tokenPath;

    @Value("${ifx.grant-type:password}")
    private String grantType;

    @Value("${ifx.username:}")
    private String username;

    @Value("${ifx.password:}")
    private String password;

    @Value("${ifx.client-id:}")
    private String clientId;

    @Value("${ifx.client-secret:}")
    private String clientSecret;

    @Value("${ifx.scope-transaccion:}")
    private String scopeTransaccion;

    @Value("${ifx.scope-consulta:}")
    private String scopeConsulta;

    @Value("${ifx.transaccion.token-path:${ifx.token-path:/oauthproviderh1/oauth2/token}}")
    private String transaccionTokenPath;

    @Value("${ifx.transaccion.grant-type:${ifx.grant-type:password}}")
    private String transaccionGrantType;

    @Value("${ifx.transaccion.username:${ifx.username:}}")
    private String transaccionUsername;

    @Value("${ifx.transaccion.password:${ifx.password:}}")
    private String transaccionPassword;

    @Value("${ifx.transaccion.client-id:${ifx.client-id:}}")
    private String transaccionClientId;

    @Value("${ifx.transaccion.client-secret:${ifx.client-secret:}}")
    private String transaccionClientSecret;

    @Value("${ifx.transaccion.scope:${ifx.scope-transaccion:}}")
    private String transaccionScope;

    @Value("${ifx.consulta.token-path:${ifx.token-path:/oauthproviderh1/oauth2/token}}")
    private String consultaTokenPath;

    @Value("${ifx.consulta.scope:${ifx.scope-consulta:}}")
    private String consultaScope;

    @Value("${ifx.consulta.grant-type:${ifx.grant-type:password}}")
    private String consultaGrantType;

    @Value("${ifx.consulta.username:${ifx.username:}}")
    private String consultaUsername;

    @Value("${ifx.consulta.password:${ifx.password:}}")
    private String consultaPassword;

    @Value("${ifx.consulta.client-id:${ifx.client-id:}}")
    private String consultaClientId;

    @Value("${ifx.consulta.client-secret:${ifx.client-secret:}}")
    private String consultaClientSecret;

    public IfxTokenService(ObjectMapper objectMapper, IfxHttpClientFactory httpClientFactory) {
        this.objectMapper = objectMapper;
        this.httpClientFactory = httpClientFactory;
    }

    public IfxTokenResponse generateTransactionToken() {
        String scope = transaccionScope == null || transaccionScope.isBlank() ? scopeTransaccion : transaccionScope;
        return generateToken(
                transaccionTokenPath,
                transaccionGrantType,
                transaccionUsername,
                transaccionPassword,
                transaccionClientId,
                transaccionClientSecret,
                scope,
                "transaccion");
    }

    public IfxTokenResponse generateConsultationToken() {
        String scope = consultaScope == null || consultaScope.isBlank() ? scopeConsulta : consultaScope;
        return generateToken(
                consultaTokenPath,
                consultaGrantType,
                consultaUsername,
                consultaPassword,
                consultaClientId,
                consultaClientSecret,
                scope,
                "consulta");
    }

    private IfxTokenResponse generateToken(String path,
                                           String grantTypeValue,
                                           String usernameValue,
                                           String passwordValue,
                                           String clientIdValue,
                                           String clientSecretValue,
                                           String scope,
                                           String tokenType) {
        try {
            if (scope == null || scope.isBlank()) {
                throw new IllegalStateException("No se configuro scope para token IFX " + tokenType);
            }
            Map<String, String> form = new LinkedHashMap<>();
            form.put("grant_type", grantTypeValue);
            form.put("username", usernameValue);
            form.put("password", passwordValue);
            form.put("client_id", clientIdValue);
            form.put("client_secret", clientSecretValue);
            form.put("scope", scope);

            String body = form.entrySet().stream()
                    .map(e -> encode(e.getKey()) + "=" + encode(e.getValue()))
                    .collect(Collectors.joining("&"));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(normalizeBaseUrl(baseUrl) + normalizePath(path)))
                    .timeout(Duration.ofSeconds(60))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpClient httpClient = httpClientFactory.create();
            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            IfxTokenResponse response = new IfxTokenResponse();
            response.setStatusCode(httpResponse.statusCode());
            response.setResponseBody(httpResponse.body());

            if (httpResponse.body() != null && !httpResponse.body().isBlank()) {
                JsonNode json = objectMapper.readTree(httpResponse.body());
                if (json.hasNonNull("access_token")) {
                    response.setAccessToken(json.get("access_token").asText());
                }
            }

            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error generando token IFX " + tokenType + ": " + e.getMessage(), e);
        }
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private String normalizeBaseUrl(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalStateException("Configure ifx.base-url o IFX_BASE_URL");
        }
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private String normalizePath(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        return value.startsWith("/") ? value : "/" + value;
    }
}
