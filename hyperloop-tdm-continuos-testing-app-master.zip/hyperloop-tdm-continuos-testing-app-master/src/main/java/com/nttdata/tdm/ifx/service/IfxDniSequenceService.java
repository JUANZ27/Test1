package com.nttdata.tdm.ifx.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class IfxDniSequenceService {

    @Value("${ifx.dni-base:54072013}")
    private String dniBase;

    @Value("${ifx.dni-sequence-file:target/dni-sequence.txt}")
    private String sequenceFile;

    public synchronized String nextDni() {
        try {
            Path path = Paths.get(sequenceFile);
            Files.createDirectories(path.toAbsolutePath().getParent());

            long nextValue;
            if (Files.exists(path)) {
                String lastValue = Files.readString(path, StandardCharsets.UTF_8).trim();
                nextValue = Long.parseLong(lastValue) + 1;
            } else {
                nextValue = Long.parseLong(dniBase.trim());
            }

            Files.writeString(path, String.valueOf(nextValue), StandardCharsets.UTF_8);
            return String.valueOf(nextValue);
        } catch (IOException | NumberFormatException e) {
            throw new IllegalStateException("No se pudo generar DNI incremental. Revise ifx.dni-base y ifx.dni-sequence-file", e);
        }
    }
}
