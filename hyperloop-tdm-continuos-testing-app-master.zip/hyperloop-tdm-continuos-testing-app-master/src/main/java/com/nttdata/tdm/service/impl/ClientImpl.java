package com.nttdata.tdm.service.impl;

import com.nttdata.tdm.model.dao.ClientDao;
import com.nttdata.tdm.model.entity.ClientEnt;
import com.nttdata.tdm.service.IClientService;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.provider.HibernateUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ClientImpl implements IClientService {
    @Autowired
    private ClientDao clientDao;
    @Transactional
    @Override
    public ClientEnt save(ClientEnt client) {
        return clientDao.save(client);
    }
    @Transactional(readOnly=true)
    @Override
    public ClientEnt findById(String id) {

        return clientDao.findById(id).orElse(null);
    }
    @Transactional
    @Override
    public void delete(ClientEnt client) {
        clientDao.delete(client);
    }
    @Transactional(readOnly=true)
    @Override
    public List<ClientEnt> findByTypeClient(String typeClient) {
        return (List<ClientEnt>) clientDao.findByTypeClient(typeClient);
    }
    @Transactional(readOnly=true)
    @Override
    public List<ClientEnt> findByTypeDocument(String typeDocument) {
        return (List<ClientEnt>) clientDao.findByTypeDocument(typeDocument);
    }
    @Transactional(readOnly=true)
    @Override
    public List<ClientEnt> findAllSunat(String typeClient,String typeDocument,Integer sunat) {
        return (List<ClientEnt>) clientDao.findAllSunat(typeClient,typeDocument,sunat);
    }
    @Transactional(readOnly=true)
    @Override
    public List<ClientEnt> findAllReniec(String typeClient,String typeDocument,Integer reniec) {
        return (List<ClientEnt>) clientDao.findAllReniec(typeClient,typeDocument,reniec);
    }
}
