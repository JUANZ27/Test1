package com.nttdata.tdm.model.dao;


import com.nttdata.tdm.model.entity.ClientEnt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ClientDao extends CrudRepository<ClientEnt,String> {
    List<ClientEnt> findByTypeClient(String typeClient);
    List<ClientEnt> findByTypeDocument(String typeDocument);

    @Query (value = "select * FROM ClientDataUat where typeClient =:typeClient " +
            "and typeDocument  =:typeDocument and sunat =:sunat",nativeQuery = true)
    List<ClientEnt> findAllSunat(String typeClient,String typeDocument,Integer sunat);
    @Query (value = "select * FROM ClientDataUat where typeClient =:typeClient " +
            "and typeDocument  =:typeDocument and reniec =:reniec",nativeQuery = true)
    List<ClientEnt> findAllReniec(String typeClient,String typeDocument,Integer reniec);


}
