package com.nttdata.tdm.config;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

@ComponentScan("com.nttdata.assitdmapitesting")
@Configuration
@PropertySource(value = "application.properties", ignoreResourceNotFound = true)
public class AppConfig {

    @Autowired
    public Environment env;

    @Getter
    private static String key;

    @Value("${secret.key}")
    public void setKey(String key) {
        AppConfig.key = key;
    }

    String dbURL = "db.url";
    String dbUserName = "db.username";
    String dbPassword = "db.password";
    String dbdatabase= "db.database";
    @Bean
    public DataSource dataSource() {
        SQLServerDataSource dataSource = new SQLServerDataSource();
        dataSource.setServerName(env.getProperty(dbURL));
        dataSource.setUser(env.getProperty(dbUserName));
        dataSource.setPassword(env.getProperty(dbPassword));
        //BASE DE DATOS DE PRUEBAS
        dataSource.setDatabaseName(env.getProperty(dbdatabase));
        //BASE DE DASO DE AZURE
        return dataSource;
    }
}