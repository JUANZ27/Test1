package com.nttdata.tdm.config;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

@Configuration
@PropertySources({
        @PropertySource(value = "classpath:application.properties", ignoreResourceNotFound = true),
        @PropertySource(value = "file:${user.home}/application-${environment:uat}.properties", ignoreResourceNotFound = true)
})
public class AppConfig {

    @Autowired
    public Environment env;

    @Getter
    private static String key;

    @Value("${secret.key:}")
    public void setKey(String key) {
        AppConfig.key = key;
    }

    String dbURL = "db.url";
    String dbUserName = "db.username";
    String dbPassword = "db.password";
    String dbdatabase = "db.database";

    @Bean
    public DataSource dataSource() {
        SQLServerDataSource dataSource = new SQLServerDataSource();
        dataSource.setServerName(env.getProperty(dbURL));
        dataSource.setUser(env.getProperty(dbUserName));
        dataSource.setPassword(env.getProperty(dbPassword));
        dataSource.setDatabaseName(env.getProperty(dbdatabase));
        return dataSource;
    }
}
