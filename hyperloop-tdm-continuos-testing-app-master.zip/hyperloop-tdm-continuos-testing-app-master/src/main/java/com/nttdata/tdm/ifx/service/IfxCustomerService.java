package com.nttdata.tdm.ifx.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;
import com.nttdata.tdm.ifx.dto.IfxTokenResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class IfxCustomerService {

    private final ObjectMapper objectMapper;
    private final IfxTokenService tokenService;
    private final IfxDniSequenceService dniSequenceService;
    private final IfxHttpClientFactory httpClientFactory;

    @Value("${ifx.base-url}")
    private String baseUrl;

    @Value("${ifx.create-customer-path:/party-reference-data-directory-customer/v1/customer/create}")
    private String createCustomerPath;

    @Value("${ifx.subscription-key:}")
    private String subscriptionKey;

    @Value("${ifx.subscription-secret:}")
    private String subscriptionSecret;

    @Value("${ifx.branch-id:100}")
    private String branchId;

    @Value("${ifx.chanel-id:16}")
    private String chanelId;

    @Value("${ifx.consumer-id:BPE}")
    private String consumerId;

    @Value("${ifx.device-id:192.135.183.250}")
    private String deviceId;

    @Value("${ifx.funcionalidad-id:Funcionalidad IFX}")
    private String funcionalidadId;

    @Value("${ifx.ip-origen:192.135.183.200}")
    private String ipOrigen;

    @Value("${ifx.parent-id:11a7f97345}")
    private String parentId;

    @Value("${ifx.trace-id:34338b0e6d2271c2345}")
    private String traceId;

    @Value("${ifx.user-id:S7301}")
    private String userId;

    @Value("${ifx.global-transaction-id:20160623152105}")
    private String globalTransactionId;

    @Value("${ifx.timestamp:2016-05-24T11:57:48.000Z}")
    private String timestamp;

    public IfxCustomerService(ObjectMapper objectMapper,
                              IfxTokenService tokenService,
                              IfxDniSequenceService dniSequenceService,
                              IfxHttpClientFactory httpClientFactory) {
        this.objectMapper = objectMapper;
        this.tokenService = tokenService;
        this.dniSequenceService = dniSequenceService;
        this.httpClientFactory = httpClientFactory;
    }

    public IfxCreateCustomerResponse createNaturalPerson(String typeDocument) {
        try {
            String requestedDocumentType = normalizeTypeDocument(typeDocument);
            String documentTypeId = toIfxDocumentTypeId(requestedDocumentType);
            String documentNumber = dniSequenceService.nextDni();
            String firstName = "Wils";
            String secondName = "Giovan";
            String firstLastName = "Zaciga";
            String secondLastName = "Puen";
            String phoneNumber = "921602513";
            String email = "wils" + documentNumber + "@gmail.com";

            IfxTokenResponse tokenResponse = tokenService.generateTransactionToken();
            String accessToken = tokenResponse.getAccessToken();

            IfxCreateCustomerResponse output = new IfxCreateCustomerResponse();
            output.setDocumentType(requestedDocumentType);
            output.setDocumentTypeId(documentTypeId);
            output.setDocumentNumber(documentNumber);
            output.setFirstName(firstName);
            output.setSecondName(secondName);
            output.setFirstLastName(firstLastName);
            output.setSecondLastName(secondLastName);
            output.setPhoneNumber(phoneNumber);
            output.setEmail(email);
            output.setTokenGenerated(accessToken != null && !accessToken.isBlank());

            if (accessToken == null || accessToken.isBlank()) {
                output.setStatusCode(tokenResponse.getStatusCode());
                output.setResponseBody("No se genero access_token. Respuesta token: " + tokenResponse.getResponseBody());
                return output;
            }

            String requestBody = objectMapper.writeValueAsString(buildCreateCustomerRequest(
                    documentTypeId, documentNumber, firstLastName, secondLastName, firstName, secondName, phoneNumber, email));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(normalizeBaseUrl(baseUrl) + normalizePath(createCustomerPath)))
                    .header("accept", "application/json")
                    .header("authorization", normalizeBearer(accessToken))
                    .header("branchid", safe(branchId))
                    .header("chanelid", safe(chanelId))
                    .header("consumerid", safe(consumerId))
                    .header("content-type", "application/json")
                    .header("deviceid", safe(deviceId))
                    .header("funcionalidadid", safe(funcionalidadId))
                    .header("iporigen", safe(ipOrigen))
                    .header("ocp-apim-subscription-key", safe(subscriptionKey))
                    .header("ocp-apim-subscription-secret", safe(subscriptionSecret))
                    .header("parentid", valueOrRandom(parentId, 10))
                    .header("timestamp", valueOrCurrentTimestamp(timestamp))
                    .header("traceid", valueOrRandom(traceId, 20))
                    .header("userid", safe(userId))
                    .header("x-global-transaction-id", valueOrCurrentGlobalTransactionId(globalTransactionId))
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpClient httpClient = httpClientFactory.create();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            output.setStatusCode(response.statusCode());
            output.setBusResponseMessage(response.headers().firstValue("busresponsemessage").orElse(""));
            output.setSrvResponseCode(response.headers().firstValue("srvresponsecode").orElse(""));
            output.setResponseBody(response.body());

            System.out.println("[IFX] Status: " + response.statusCode());
            System.out.println("[IFX] busresponsemessage: " + output.getBusResponseMessage());
            System.out.println("[IFX] srvresponsecode: " + output.getSrvResponseCode());
            System.out.println("[IFX] srvresponsemessage: " + output.getSrvResponseMessage());
            System.out.println("[IFX] Response: " + response.body());
            return output;
        } catch (Exception e) {
            throw new IllegalStateException("Error creando persona natural IFX: " + e.getMessage(), e);
        }
    }

    private Map<String, Object> buildCreateCustomerRequest(String documentTypeId,
                                                           String documentNumber,
                                                           String firstLastName,
                                                           String secondLastName,
                                                           String firstName,
                                                           String secondName,
                                                           String phoneNumber,
                                                           String email) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("documentTypeId", documentTypeId);
        body.put("documentNumber", documentNumber);
        body.put("passportNumber", "");
        body.put("birthDate", "1980-12-12T00:00:00.000Z");
        body.put("firstLastName", firstLastName);
        body.put("secondLastName", secondLastName);
        body.put("firstName", firstName);
        body.put("secondName", secondName);
        body.put("genderType", "M");
        body.put("maritalStatus", "S");
        body.put("nationalityCode", "1");
        body.put("birthCountryCode", "4029");
        body.put("residentCountryCode", "4029");
        body.put("nationalityCountryCode", "4029");
        body.put("streetType", "AV");
        body.put("streetName", "SAN FRANCISCO");
        body.put("streetNumber", "7");
        body.put("blockIdentification", "1");
        body.put("lotId", "1");
        body.put("insideId", "1");
        body.put("urbanizationName", "URUBAMBA");
        body.put("locationReference", "AL FRENTE DE RESTAURANT");
        body.put("department", "LIMA");
        body.put("province", "LIMA");
        body.put("district", "LINCE");

        Map<String, String> phone = new LinkedHashMap<>();
        phone.put("phoneType", "C");
        phone.put("phonePrefix", "051");
        phone.put("phoneNumber", phoneNumber);
        phone.put("extension", "123");
        body.put("phoneAddress", List.of(phone, new LinkedHashMap<>(phone)));

        body.put("emailType", "P");
        body.put("email", email);
        body.put("ciiuCode", "");
        body.put("employmentDate", "");
        body.put("companyName", "SYNOPSYS");
        body.put("ocupationCode", "PRF");
        return body;
    }

    private String normalizeTypeDocument(String typeDocument) {
        if (typeDocument == null || typeDocument.trim().isEmpty()) return "DNI";
        return typeDocument.trim().toUpperCase();
    }

    private String toIfxDocumentTypeId(String typeDocument) {
        switch (typeDocument) {
            case "DNI":
                return "1";
            case "RUC":
                return "2";
            case "CE":
                return "3";
            case "PASAPORTE":
                return "5";
            default:
                return typeDocument;
        }
    }

    private String normalizeBearer(String token) {
        if (token == null || token.trim().isEmpty()) return "";
        String value = token.trim();
        return value.toLowerCase().startsWith("bearer ") ? value : "Bearer " + value;
    }

    private String valueOrRandom(String configured, int length) {
        if (configured != null && !configured.trim().isEmpty()) return configured.trim();
        String raw = UUID.randomUUID().toString().replace("-", "");
        return raw.substring(0, Math.min(length, raw.length()));
    }

    private String valueOrCurrentTimestamp(String configured) {
        if (configured != null && !configured.trim().isEmpty()) return configured.trim();
        return DateTimeFormatter.ISO_INSTANT.format(Instant.now());
    }

    private String valueOrCurrentGlobalTransactionId(String configured) {
        if (configured != null && !configured.trim().isEmpty()) return configured.trim();
        return DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
                .withZone(ZoneOffset.UTC)
                .format(Instant.now());
    }

    private String normalizeBaseUrl(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalStateException("Configure ifx.base-url o IFX_BASE_URL");
        }
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private String normalizePath(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        return value.startsWith("/") ? value : "/" + value;
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }


}
