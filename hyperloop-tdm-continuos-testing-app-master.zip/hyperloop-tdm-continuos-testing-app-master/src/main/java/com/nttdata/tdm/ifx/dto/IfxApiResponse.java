package com.nttdata.tdm.ifx.dto;

import java.util.LinkedHashMap;
import java.util.Map;

public class IfxApiResponse {
    private String operation;
    private String environment;
    private String documentType;
    private String documentTypeId;
    private String documentNumber;
    private String customerId;
    private String accountNumber;
    private int statusCode;
    private boolean tokenGenerated;
    private String tokenType;
    private String url;
    private String busResponseMessage;
    private String srvResponseCode;
    private String srvResponseMessage;
    private String responseBody;
    private Map<String, Object> metadata = new LinkedHashMap<>();

    public String getOperation() { return operation; }
    public void setOperation(String operation) { this.operation = operation; }

    public String getEnvironment() { return environment; }
    public void setEnvironment(String environment) { this.environment = environment; }

    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }

    public String getDocumentTypeId() { return documentTypeId; }
    public void setDocumentTypeId(String documentTypeId) { this.documentTypeId = documentTypeId; }

    public String getDocumentNumber() { return documentNumber; }
    public void setDocumentNumber(String documentNumber) { this.documentNumber = documentNumber; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public int getStatusCode() { return statusCode; }
    public void setStatusCode(int statusCode) { this.statusCode = statusCode; }

    public boolean isTokenGenerated() { return tokenGenerated; }
    public void setTokenGenerated(boolean tokenGenerated) { this.tokenGenerated = tokenGenerated; }

    public String getTokenType() { return tokenType; }
    public void setTokenType(String tokenType) { this.tokenType = tokenType; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getBusResponseMessage() { return busResponseMessage; }
    public void setBusResponseMessage(String busResponseMessage) { this.busResponseMessage = busResponseMessage; }

    public String getSrvResponseCode() { return srvResponseCode; }
    public void setSrvResponseCode(String srvResponseCode) { this.srvResponseCode = srvResponseCode; }

    public String getSrvResponseMessage() { return srvResponseMessage; }
    public void setSrvResponseMessage(String srvResponseMessage) { this.srvResponseMessage = srvResponseMessage; }

    public String getResponseBody() { return responseBody; }
    public void setResponseBody(String responseBody) { this.responseBody = responseBody; }

    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
}
