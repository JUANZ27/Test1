package com.nttdata.tdm.ifx.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.tdm.ifx.dto.IfxApiResponse;
import com.nttdata.tdm.ifx.dto.IfxBatchResponse;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Collectors;

public class IfxStandaloneClient {

    private final String environment;
    private final Properties props;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public IfxStandaloneClient(String environment) {
        this.environment = isBlank(environment) ? "uat" : environment.trim().toLowerCase();
        this.props = loadProperties(this.environment);
    }

    public IfxCreateCustomerResponse createNaturalPerson(String typeDocument) {
        return createNaturalPerson(typeDocument, null);
    }

    public IfxCreateCustomerResponse createNaturalPerson(String typeDocument, String documentNumber) {
        IfxApiResponse generic = createNaturalPersonAsGeneric(typeDocument, documentNumber, null, null, null);
        IfxCreateCustomerResponse output = new IfxCreateCustomerResponse();
        output.setDocumentType(generic.getDocumentType());
        output.setDocumentTypeId(generic.getDocumentTypeId());
        output.setDocumentNumber(generic.getDocumentNumber());
        output.setFirstName(String.valueOf(generic.getMetadata().getOrDefault("firstName", "Wils")));
        output.setSecondName(String.valueOf(generic.getMetadata().getOrDefault("secondName", "Giovan")));
        output.setFirstLastName(String.valueOf(generic.getMetadata().getOrDefault("firstLastName", "Zaciga")));
        output.setSecondLastName(String.valueOf(generic.getMetadata().getOrDefault("secondLastName", "Puen")));
        output.setPhoneNumber(String.valueOf(generic.getMetadata().getOrDefault("phoneNumber", "921602513")));
        output.setEmail(String.valueOf(generic.getMetadata().getOrDefault("email", "wils@gmail.com")));
        output.setTokenGenerated(generic.isTokenGenerated());
        output.setStatusCode(generic.getStatusCode());
        output.setBusResponseMessage(generic.getBusResponseMessage());
        output.setSrvResponseCode(generic.getSrvResponseCode());
        output.setSrvResponseMessage(generic.getSrvResponseMessage());
        output.setResponseBody(generic.getResponseBody());

        String resolvedDocumentNumber = firstNonBlank(output.getDocumentNumber(), documentNumber);
        printIfxResult(
                "PN",
                resolvedDocumentNumber,
                output.getStatusCode(),
                output.getBusResponseMessage(),
                output.getSrvResponseCode(),
                output.getSrvResponseMessage(),
                output.getResponseBody()
        );

        return output;
    }

    public IfxApiResponse createNaturalPersonAsGeneric(String typeDocument, String documentNumberOverride) {
        return createNaturalPersonAsGeneric(typeDocument, documentNumberOverride, null, null, null);
    }

    public IfxApiResponse createNaturalPersonAsGeneric(String typeDocument,
                                                       String documentNumberOverride,
                                                       String societyType,
                                                       String countryCode,
                                                       String economicActivityCode) {
        try {
            String requestedDocumentType = normalizeTypeDocument(typeDocument);
            String documentTypeId = toIfxDocumentTypeId(requestedDocumentType);
            String documentNumber = chooseDocumentNumber(requestedDocumentType, documentNumberOverride);
            String firstName = value("ifx.natural.first-name", value("ifx.first-name", "Wils"));
            String secondName = value("ifx.natural.second-name", value("ifx.second-name", "Giovan"));
            String firstLastName = value("ifx.natural.first-last-name", value("ifx.first-last-name", "Zaciga"));
            String secondLastName = value("ifx.natural.second-last-name", value("ifx.second-last-name", "Puen"));
            String phoneNumber = value("ifx.natural.phone-number", value("ifx.phone-number", "921602513"));
            String email = value("ifx.natural.email", value("ifx.email", "wils" + documentNumber + "@gmail.com"));

            Map<String, Object> body = buildCreateNaturalPersonRequest(
                    documentTypeId, documentNumber, firstLastName, secondLastName, firstName, secondName, phoneNumber, email);

            Map<String, String> headers = baseNaturalPersonHeaders(generateTransactionToken());
            IfxApiResponse response = executeJsonPost(
                    "crearClientePN",
                    value("ifx.create-customer-path", "/party-reference-data-directory-customer/v1/customer/create"),
                    headers,
                    body,
                    "transaccion"
            );
            response.setDocumentType(requestedDocumentType);
            response.setDocumentTypeId(documentTypeId);
            response.setDocumentNumber(documentNumber);
            response.getMetadata().put("firstName", firstName);
            response.getMetadata().put("secondName", secondName);
            response.getMetadata().put("firstLastName", firstLastName);
            response.getMetadata().put("secondLastName", secondLastName);
            response.getMetadata().put("phoneNumber", phoneNumber);
            response.getMetadata().put("email", email);
            response.getMetadata().put("societyType", safe(societyType));
            response.getMetadata().put("countryCode", safe(countryCode));
            response.getMetadata().put("economicActivityCode", safe(economicActivityCode));
            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error creando persona natural IFX: " + e.getMessage(), e);
        }
    }

    public IfxApiResponse retrieveCustomer(String typeDocument, String documentNumber) {
        try {
            String requestedDocumentType = normalizeTypeDocument(typeDocument);
            String documentTypeId = toIfxDocumentTypeId(requestedDocumentType);
            String resolvedDocumentNumber = !isBlank(documentNumber)
                    ? documentNumber.trim()
                    : value(isRuc(requestedDocumentType) ? "ifx.query-ruc" : "ifx.query-dni", isRuc(requestedDocumentType) ? "20276135769" : "40903462");

            Map<String, Object> body = buildRetrieveCustomerRequest(documentTypeId, resolvedDocumentNumber);
            Map<String, String> headers = baseConsultationHeaders(generateConsultationToken());

            IfxApiResponse response = executeJsonPost(
                    "consultaCliente",
                    value("ifx.retrieve-customer-path", "/en-party-reference-data-directory-customer/v2/full-information/retrieve"),
                    headers,
                    body,
                    "consulta"
            );
            response.setDocumentType(requestedDocumentType);
            response.setDocumentTypeId(documentTypeId);
            response.setDocumentNumber(resolvedDocumentNumber);
            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error consultando cliente IFX: " + e.getMessage(), e);
        }
    }

    /**
     * Consulta CCE Customer Special Status mediante GET y token de consulta.
     * Query params requeridos: documentTypeId y documentNumber.
     */
    public IfxApiResponse retrieveCustomerSpecialStatus(String documentTypeId, String documentNumber) {
        try {
            String resolvedDocumentTypeId = firstNonBlank(
                    documentTypeId,
                    value("ifx.special-status.document-type-id", "1")
            );
            String resolvedDocumentNumber = firstNonBlank(
                    documentNumber,
                    value("ifx.special-status.document-number", "40975592")
            );

            Map<String, String> queryParams = new LinkedHashMap<>();
            queryParams.put("documentTypeId", resolvedDocumentTypeId);
            queryParams.put("documentNumber", resolvedDocumentNumber);

            Map<String, String> headers = baseSpecialStatusHeaders(generateConsultationToken());
            IfxApiResponse response = executeJsonGet(
                    "consultaCustomerSpecialStatusCCE",
                    value("ifx.customer-special-status-path", "/customer-profile/v1/customer-special-status"),
                    headers,
                    queryParams,
                    "consulta"
            );
            response.setDocumentType("1".equals(resolvedDocumentTypeId)
                    ? "DNI"
                    : ("2".equals(resolvedDocumentTypeId) ? "RUC" : resolvedDocumentTypeId));
            response.setDocumentTypeId(resolvedDocumentTypeId);
            response.setDocumentNumber(resolvedDocumentNumber);
            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error consultando CCE Customer Special Status IFX: " + e.getMessage(), e);
        }
    }

    public IfxApiResponse createLegalPerson(String typeDocument) {
        return createLegalPerson(typeDocument, null);
    }

    public IfxApiResponse createLegalPerson(String typeDocument, String documentNumberOverride) {
        return createLegalPerson(typeDocument, documentNumberOverride, null, null, null);
    }

    public IfxApiResponse createLegalPerson(String typeDocument,
                                            String documentNumberOverride,
                                            String societyType,
                                            String countryCode,
                                            String economicActivityCode) {
        try {
            String requestedDocumentType = normalizeTypeDocument(isBlank(typeDocument) ? "RUC" : typeDocument);
            String documentTypeId = isRuc(requestedDocumentType) ? "2" : toIfxDocumentTypeId(requestedDocumentType);
            String documentNumber = chooseDocumentNumber("RUC", documentNumberOverride);

            // Datos de contacto para traza/metadata en crearClientePJIFX
            String firstName = value("ifx.pj.first-name", value("ifx.natural.first-name", value("ifx.first-name", "Wils")));
            String secondName = value("ifx.pj.second-name", value("ifx.natural.second-name", value("ifx.second-name", "Giovan")));
            String firstLastName = value("ifx.pj.first-last-name", value("ifx.natural.first-last-name", value("ifx.first-last-name", "Zaciga")));
            String secondLastName = value("ifx.pj.second-last-name", value("ifx.natural.second-last-name", value("ifx.second-last-name", "Puen")));
            String phoneNumber = value("ifx.pj.phone-number", value("ifx.merchant.phone-number", value("ifx.phone-number", "921602513")));
            String email = value("ifx.pj.email", value("ifx.merchant.email-address", value("ifx.email", "wils" + documentNumber + "@gmail.com")));

            Map<String, Object> body = buildCreateLegalPersonRequest(documentTypeId, documentNumber, societyType, countryCode, economicActivityCode);
            Map<String, String> headers = baseMerchantHeaders(generateTransactionToken());

            IfxApiResponse response = executeJsonPost(
                    "crearClientePJ",
                    value("ifx.create-merchant-path", "/party-reference-data-directory-merchant/v1//create-customer/execute"),
                    headers,
                    body,
                    "transaccion"
            );
            response.setDocumentType("RUC");
            response.setDocumentTypeId(documentTypeId);
            response.setDocumentNumber(documentNumber);

            response.getMetadata().put("firstName", firstName);
            response.getMetadata().put("secondName", secondName);
            response.getMetadata().put("firstLastName", firstLastName);
            response.getMetadata().put("secondLastName", secondLastName);
            response.getMetadata().put("phoneNumber", phoneNumber);
            response.getMetadata().put("email", email);
            response.getMetadata().put("societyType", firstNonBlank(societyType, value("ifx.merchant.society-type", "EIRL")));
            response.getMetadata().put("countryCode", firstNonBlank(countryCode, value("ifx.merchant.body-country-code", "2023")));
            response.getMetadata().put("economicActivityCode", firstNonBlank(economicActivityCode, value("ifx.merchant.economic-activity-code", "1520")));

            printIfxResult(
                    "PJ",
                    response.getDocumentNumber(),
                    response.getStatusCode(),
                    response.getBusResponseMessage(),
                    response.getSrvResponseCode(),
                    response.getSrvResponseMessage(),
                    response.getResponseBody()
            );
            System.out.println("[IFX PJ] firstName: " + firstName);
            System.out.println("[IFX PJ] secondName: " + secondName);
            System.out.println("[IFX PJ] firstLastName: " + firstLastName);
            System.out.println("[IFX PJ] secondLastName: " + secondLastName);
            System.out.println("[IFX PJ] phoneNumber: " + phoneNumber);
            System.out.println("[IFX PJ] email: " + email);

            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error creando cliente PJ IFX: " + e.getMessage(), e);
        }
    }

    public IfxApiResponse createAccount(String typeDocument, String documentNumber, String customerId) {
        try {
            String requestedDocumentType = normalizeTypeDocument(typeDocument);
            String documentTypeId = toIfxDocumentTypeId(requestedDocumentType);
            String resolvedDocumentNumber = !isBlank(documentNumber) ? documentNumber.trim() : chooseDocumentNumber(requestedDocumentType, null);
            String resolvedCustomerId = !isBlank(customerId) ? customerId.trim() : value("ifx.account.customer-id", resolvedDocumentNumber);

            Map<String, Object> body = buildCreateAccountRequest(documentTypeId, resolvedDocumentNumber, resolvedCustomerId);
            Map<String, String> headers = baseAccountHeaders(generateTransactionToken());

            IfxApiResponse response = executeJsonPost(
                    "crearCuenta",
                    value("ifx.create-account-path", "/customer-products-and-services/v1/accounts/create"),
                    headers,
                    body,
                    "transaccion"
            );
            response.setDocumentType(requestedDocumentType);
            response.setDocumentTypeId(documentTypeId);
            response.setDocumentNumber(resolvedDocumentNumber);
            response.setCustomerId(resolvedCustomerId);
            response.setAccountNumber(extractAccountNumber(response.getResponseBody()));
            return response;
        } catch (Exception e) {
            throw new IllegalStateException("Error creando cuenta IFX: " + e.getMessage(), e);
        }
    }

    public IfxBatchResponse generateDataNoClient(String typeDocument, int numberRecord) {
        int total = Math.max(numberRecord, 1);
        IfxBatchResponse batch = new IfxBatchResponse();
        batch.setOperation("GenerateDataNoClient");
        batch.setEnvironment(environment);
        batch.setRequested(total);

        for (int i = 0; i < total; i++) {
            IfxApiResponse response = isRuc(typeDocument)
                    ? createLegalPerson("RUC", null)
                    : createNaturalPersonAsGeneric(typeDocument, null);
            response.getMetadata().put("typeClient", "NO_CLIENTE");
            batch.getResponses().add(response);
        }
        batch.setExecuted(batch.getResponses().size());
        return batch;
    }

    public IfxBatchResponse generateDataFromExcel(String data, String file) {
        try {
            Path input = resolveDataFile(data, file);
            List<Map<String, String>> rows = readDataRows(input);
            IfxBatchResponse batch = new IfxBatchResponse();
            batch.setOperation("GenerateDataFromExcel");
            batch.setEnvironment(environment);
            batch.setRequested(rows.size());

            for (Map<String, String> row : rows) {
                String typeDocument = firstNonBlank(row.get("TIPO DOCUMENTO"), row.get("TIPO_DOCUMENTO"), row.get("typeDocument"), row.get("TYPE DOCUMENT"), "DNI");
                String documentNumber = firstNonBlank(row.get("NUMERO DOC"), row.get("NUMERO_DOC"), row.get("NUMERO DOCUMENTO"), row.get("documentNumber"), row.get("DOCUMENT NUMBER"), "");
                String societyType = firstNonBlank(row.get("SOCIETYTYPE"), row.get("SOCIETY TYPE"), row.get("societyType"), row.get("SOCIETY_TYPE"), value("ifx.merchant.society-type", "EIRL"));
                String countryCode = firstNonBlank(row.get("COUNTRYCODE"), row.get("COUNTRY CODE"), row.get("countryCode"), row.get("COUNTRY_CODE"), value("ifx.merchant.body-country-code", "2023"));
                String economicActivityCode = firstNonBlank(row.get("ECONOMICACTIVITYCODE"), row.get("ECONOMIC ACTIVITY CODE"), row.get("economicActivityCode"), row.get("ECONOMIC_ACTIVITY_CODE"), value("ifx.merchant.economic-activity-code", "1520"));
                IfxApiResponse response = isRuc(typeDocument)
                        ? createLegalPerson("RUC", documentNumber, societyType, countryCode, economicActivityCode)
                        : createNaturalPersonAsGeneric(typeDocument, documentNumber, societyType, countryCode, economicActivityCode);
                response.getMetadata().put("sourceFile", input.toString());
                batch.getResponses().add(response);
            }
            batch.setExecuted(batch.getResponses().size());
            return batch;
        } catch (Exception e) {
            throw new IllegalStateException("Error ejecutando GenerateDataFromExcel: " + e.getMessage(), e);
        }
    }

    public IfxApiResponse getDataNoClient(String typeDocument, String typeClient) {
        IfxApiResponse response = retrieveCustomer(typeDocument, null);
        response.setOperation("GetDataNoClient");
        response.getMetadata().put("typeClient", typeClient);
        return response;
    }

    public IfxApiResponse getDataClient(String typeDocument, String typeClient, String partners) {
        IfxApiResponse response = retrieveCustomer(typeDocument, null);
        response.setOperation("GetDataClient");
        response.getMetadata().put("typeClient", typeClient);
        response.getMetadata().put("partners", partners);
        return response;
    }

    public IfxApiResponse getDataClientNatural(String typeDocument, String typeClient) {
        IfxApiResponse response = retrieveCustomer(typeDocument, null);
        response.setOperation("GetDataClientNatural");
        response.getMetadata().put("typeClient", typeClient);
        response.getMetadata().put("rule", "DNI con menos de 4 cuentas creadas. Validar count en responseBody segun estructura IFX.");
        response.getMetadata().put("accountsDetected", detectAccountsCount(response.getResponseBody()));
        return response;
    }

    /**
     * Token exclusivo para operaciones de creacion/modificacion.
     * Lo usan crear cliente PN, crear cliente PJ, crear cuenta y GenerateDataNoClient/FromExcel.
     * Debe usar scope={{ifx_scope_transaccion}}.
     */
    private String generateTransactionToken() throws Exception {
        String scope = firstNonBlank(
                value("ifx.transaccion.scope", ""),
                value("ifx.scope-transaccion", "")
        );
        return generateToken(
                value("ifx.transaccion.token-url", ""),
                value("ifx.transaccion.base-url", value("ifx.base-url", "")),
                value("ifx.transaccion.token-path", value("ifx.token-path", "/oauthproviderh1/oauth2/token")),
                value("ifx.transaccion.grant-type", value("ifx.grant-type", "password")),
                value("ifx.transaccion.username", value("ifx.username", "")),
                value("ifx.transaccion.password", value("ifx.password", "")),
                value("ifx.transaccion.client-id", value("ifx.client-id", "")),
                value("ifx.transaccion.client-secret", value("ifx.client-secret", "")),
                scope,
                "transaccion"
        );
    }

    /**
     * Token exclusivo para consultas full-information/retrieve.
     * Implementado según curl:
     * grant_type=password, username, password, client_id, client_secret y scope={{ifx_scope_consulta}}.
     */
    private String generateConsultationToken() throws Exception {
        String scope = firstNonBlank(
                value("ifx.consulta.scope", ""),
                value("ifx.scope-consulta", ""),
                value("ifx.scope-consultation", "")
        );
        return generateToken(
                value("ifx.consulta.token-url", ""),
                value("ifx.consulta.base-url", value("ifx.base-url", "")),
                value("ifx.consulta.token-path", value("ifx.token-path", "/oauthproviderh1/oauth2/token")),
                value("ifx.consulta.grant-type", value("ifx.grant-type", "password")),
                value("ifx.consulta.username", value("ifx.username", "")),
                value("ifx.consulta.password", value("ifx.password", "")),
                value("ifx.consulta.client-id", value("ifx.client-id", "")),
                value("ifx.consulta.client-secret", value("ifx.client-secret", "")),
                scope,
                "consulta"
        );
    }

    private String generateToken(String tokenUrl,
                                 String baseUrl,
                                 String tokenPath,
                                 String grantType,
                                 String username,
                                 String password,
                                 String clientId,
                                 String clientSecret,
                                 String scope,
                                 String tokenType) throws Exception {
        if (isBlank(scope)) {
            throw new IllegalStateException("No se configuro scope para token " + tokenType + ". Revisar ifx.scope-" + tokenType + " / ifx." + tokenType + ".scope en application-" + environment + ".properties");
        }

        Map<String, String> form = new LinkedHashMap<>();
        form.put("grant_type", grantType);
        form.put("username", username);
        form.put("password", password);
        form.put("client_id", clientId);
        form.put("client_secret", clientSecret);
        form.put("scope", scope);

        String body = form.entrySet().stream()
                .map(e -> encode(e.getKey()) + "=" + encode(e.getValue()))
                .collect(Collectors.joining("&"));

        String url = isBlank(tokenUrl)
                ? normalizeBaseUrl(baseUrl) + normalizePath(tokenPath)
                : tokenUrl.trim();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(longValue("ifx.timeout-seconds", 60)))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        System.out.println("[IFX TOKEN " + tokenType + "] URL: " + url);
        System.out.println("[IFX TOKEN " + tokenType + "] Scope: " + scope);

        HttpResponse<String> response = createHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("[IFX TOKEN " + tokenType + "] Status: " + response.statusCode());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            System.out.println("[IFX TOKEN " + tokenType + "] Body: " + response.body());
            return null;
        }
        JsonNode json = objectMapper.readTree(response.body());
        JsonNode tokenNode = json.get("access_token");
        return tokenNode == null ? null : tokenNode.asText();
    }

    private IfxApiResponse executeJsonPost(String operation,
                                           String path,
                                           Map<String, String> headers,
                                           Map<String, Object> body,
                                           String tokenType) throws Exception {
        String accessToken = headers.remove("__accessToken");
        String url = normalizeBaseUrl(value("ifx.base-url", "")) + normalizePath(path);
        String requestBody = objectMapper.writeValueAsString(body);

        IfxApiResponse output = new IfxApiResponse();
        output.setOperation(operation);
        output.setEnvironment(environment);
        output.setTokenType(tokenType);
        output.setTokenGenerated(!isBlank(accessToken));
        output.setUrl(url);

        if (isBlank(accessToken)) {
            output.setStatusCode(0);
            output.setResponseBody("No se genero access_token " + tokenType + ". Revisar application-" + environment + ".properties en user.home");
            System.out.println("[IFX] " + output.getResponseBody());
            return output;
        }

        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(longValue("ifx.timeout-seconds", 60)))
                .POST(HttpRequest.BodyPublishers.ofString(requestBody));

        headers.forEach((key, value) -> builder.header(key, safe(value)));
        builder.header("authorization", buildAuthorizationHeader(accessToken, tokenType));

        System.out.println("[IFX] Operation: " + operation);
        System.out.println("[IFX] URL: " + url);
        System.out.println("[IFX] Request body:\n" + objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));

        HttpResponse<String> response = createHttpClient().send(builder.build(), HttpResponse.BodyHandlers.ofString());
        output.setStatusCode(response.statusCode());
        output.setBusResponseMessage(response.headers().firstValue("busresponsemessage").orElse(""));
        output.setSrvResponseCode(response.headers().firstValue("srvresponsecode").orElse(""));
        output.setSrvResponseMessage(response.headers().firstValue("srvresponsemessage").orElse(""));
        output.setResponseBody(response.body());

        System.out.println("[IFX] Status: " + response.statusCode());
        System.out.println("[IFX] Response: " + response.body());
        return output;
    }

    private IfxApiResponse executeJsonGet(String operation,
                                          String path,
                                          Map<String, String> headers,
                                          Map<String, String> queryParams,
                                          String tokenType) throws Exception {
        String accessToken = headers.remove("__accessToken");
        String query = queryParams == null
                ? ""
                : queryParams.entrySet().stream()
                .filter(entry -> !isBlank(entry.getKey()) && entry.getValue() != null)
                .map(entry -> encode(entry.getKey()) + "=" + encode(entry.getValue()))
                .collect(Collectors.joining("&"));
        String url = normalizeBaseUrl(value("ifx.base-url", ""))
                + normalizePath(path)
                + (query.isEmpty() ? "" : "?" + query);

        IfxApiResponse output = new IfxApiResponse();
        output.setOperation(operation);
        output.setEnvironment(environment);
        output.setTokenType(tokenType);
        output.setTokenGenerated(!isBlank(accessToken));
        output.setUrl(url);

        if (isBlank(accessToken)) {
            output.setStatusCode(0);
            output.setResponseBody("No se genero access_token " + tokenType
                    + ". Revisar application-" + environment + ".properties en user.home");
            System.out.println("[IFX] " + output.getResponseBody());
            return output;
        }

        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(longValue("ifx.timeout-seconds", 60)))
                .GET();

        headers.forEach((key, value) -> builder.header(key, safe(value)));
        builder.header("authorization", buildAuthorizationHeader(accessToken, tokenType));

        System.out.println("[IFX] Operation: " + operation);
        System.out.println("[IFX] URL: " + url);

        HttpResponse<String> response = createHttpClient().send(builder.build(), HttpResponse.BodyHandlers.ofString());
        output.setStatusCode(response.statusCode());
        output.setBusResponseMessage(response.headers().firstValue("busresponsemessage").orElse(""));
        output.setSrvResponseCode(response.headers().firstValue("srvresponsecode").orElse(""));
        output.setSrvResponseMessage(response.headers().firstValue("srvresponsemessage").orElse(""));
        output.setResponseBody(response.body());

        System.out.println("[IFX] Status: " + response.statusCode());
        System.out.println("[IFX] Response: " + response.body());
        return output;
    }

    private Map<String, String> baseNaturalPersonHeaders(String accessToken) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("__accessToken", accessToken);
        headers.put("accept", "application/json");
        headers.put("branchid", value("ifx.branch-id", "100"));
        headers.put("chanelid", value("ifx.chanel-id", "16"));
        headers.put("consumerid", value("ifx.consumer-id", "BPE"));
        headers.put("content-type", "application/json");
        headers.put("deviceid", value("ifx.device-id", "192.135.183.250"));
        headers.put("funcionalidadid", value("ifx.funcionalidad-id", "Funcionalidad IFX"));
        headers.put("iporigen", value("ifx.ip-origen", "192.135.183.200"));
        headers.put("ocp-apim-subscription-key", value("ifx.subscription-key", value("ifx.client-id", "")));
        headers.put("ocp-apim-subscription-secret", value("ifx.subscription-secret", value("ifx.client-secret", "")));
        headers.put("parentid", valueOrRandom(value("ifx.parent-id", "11a7f97345"), 10));
        headers.put("timestamp", valueOrCurrentTimestamp(value("ifx.timestamp", "2016-05-24T11:57:48.000Z")));
        headers.put("traceid", valueOrRandom(value("ifx.trace-id", "34338b0e6d2271c2345"), 20));
        headers.put("userid", value("ifx.user-id", "S7301"));
        headers.put("x-global-transaction-id", valueOrCurrentGlobalTransactionId(value("ifx.global-transaction-id", "20160623152105")));
        return headers;
    }

    private Map<String, String> baseConsultationHeaders(String accessToken) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("__accessToken", accessToken);
        headers.put("accept", "application/json");
        headers.put("consumerid", value("ifx.consulta.consumer-id", "BCV"));
        headers.put("content-type", "application/json");
        headers.put("funcionalidadid", value("ifx.consulta.funcionalidad-id", "funcionalidad01"));
        headers.put("ocp-apim-subscription-key", value("ifx.subscription-key", value("ifx.client-id", "")));
        headers.put("ocp-apim-subscription-secret", value("ifx.subscription-secret", value("ifx.client-secret", "")));
        headers.put("parentid", valueOrRandom(value("ifx.consulta.parent-id", "53ce929d0e0e4736"), 16));
        headers.put("traceid", valueOrRandom(value("ifx.consulta.trace-id", "53ce929d0e0e4736"), 16));
        headers.put("usertype", value("ifx.consulta.user-type", "F"));
        return headers;
    }

    private Map<String, String> baseSpecialStatusHeaders(String accessToken) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("__accessToken", accessToken);
        headers.put("accept", "application/json");
        headers.put("consumerid", value("ifx.special-status.consumer-id", "7824164593336320"));
        headers.put("content-type", "application/json");
        headers.put("funcionalidadid", value("ifx.special-status.funcionalidad-id", "2516899420176384"));
        headers.put("ocp-apim-subscription-key", value("ifx.subscription-key", value("ifx.client-id", "")));
        headers.put("ocp-apim-subscription-secret", value("ifx.subscription-secret", value("ifx.client-secret", "")));
        headers.put("parentid", value("ifx.special-status.parent-id", "3686228603961344"));
        headers.put("traceid", value("ifx.special-status.trace-id", "2359211902107648"));
        return headers;
    }

    private Map<String, String> baseMerchantHeaders(String accessToken) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("__accessToken", accessToken);
        headers.put("accept", "application/json");
        headers.put("branchid", value("ifx.merchant.branch-id", "898"));
        headers.put("cardidtype", value("ifx.merchant.card-id-type", "1"));
        headers.put("channelid", value("ifx.merchant.channel-id", "15"));
        headers.put("consumerid", value("ifx.merchant.consumer-id", "01"));
        headers.put("content-type", "application/json");
        headers.put("countrycode", value("ifx.merchant.country-code", "PE"));
        headers.put("deviceid", value("ifx.merchant.device-id", "130.30.20.80"));
        headers.put("funcionalidadid", value("ifx.merchant.funcionalidad-id", "funcionalidad01"));
        headers.put("groupmember", value("ifx.merchant.group-member", "G0001"));
        headers.put("iporigen", value("ifx.merchant.ip-origen", "130.30.20.80"));
        headers.put("messageid", value("ifx.merchant.message-id", "20160623152105"));
        headers.put("moduloid", value("ifx.merchant.modulo-id", "modcontacto"));
        headers.put("netid", value("ifx.merchant.net-id", "BI"));
        headers.put("ocp-apim-subscription-key", value("ifx.subscription-key", value("ifx.client-id", "")));
        headers.put("ocp-apim-subscription-secret", value("ifx.subscription-secret", value("ifx.client-secret", "")));
        headers.put("parentid", value("ifx.merchant.parent-id", "53ce929d0e0e4736"));
        headers.put("referencenumber", value("ifx.merchant.reference-number", "REF01092"));
        headers.put("serverid", value("ifx.merchant.server-id", "server12"));
        headers.put("serviceid", value("ifx.merchant.service-id", "BPI"));
        headers.put("supervisorid", value("ifx.merchant.supervisor-id", "S2058"));
        headers.put("timestamp", value("ifx.merchant.timestamp", "2016-05-24T11:57:48.000Z"));
        headers.put("traceid", value("ifx.merchant.trace-id", "53ce929d0e0e4736"));
        headers.put("userid", value("ifx.merchant.user-id", "S23052"));
        headers.put("usertype", value("ifx.merchant.user-type", "F"));
        return headers;
    }

    private Map<String, String> baseAccountHeaders(String accessToken) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("__accessToken", accessToken);
        headers.put("accept", "application/json");
        headers.put("branchid", value("ifx.account.branch-id", "string"));
        headers.put("cardidtype", value("ifx.account.card-id-type", "string"));
        headers.put("channelid", value("ifx.account.channel-id", "string"));
        headers.put("consumerid", value("ifx.account.consumer-id", "string"));
        headers.put("content-type", "application/json");
        headers.put("countrycode", value("ifx.account.country-code", "string"));
        headers.put("deviceid", value("ifx.account.device-id", "string"));
        headers.put("funcionalidadid", value("ifx.account.funcionalidad-id", "string"));
        headers.put("groupmember", value("ifx.account.group-member", "string"));
        headers.put("iporigen", value("ifx.account.ip-origen", "string"));
        headers.put("messageid", valueOrCurrentGlobalTransactionId(value("ifx.account.message-id", "string")));
        headers.put("moduloid", value("ifx.account.modulo-id", "string"));
        headers.put("netid", value("ifx.account.net-id", "string"));
        headers.put("ocp-apim-subscription-key", value("ifx.subscription-key", value("ifx.client-id", "")));
        headers.put("ocp-apim-subscription-secret", value("ifx.subscription-secret", value("ifx.client-secret", "")));
        headers.put("parentid", valueOrRandom(value("ifx.account.parent-id", "string"), 16));
        headers.put("referencenumber", value("ifx.account.reference-number", "string"));
        headers.put("serverid", value("ifx.account.server-id", "string"));
        headers.put("serviceid", value("ifx.account.service-id", "string"));
        headers.put("supervisorid", value("ifx.account.supervisor-id", "string"));
        headers.put("timestamp", valueOrCurrentTimestamp(value("ifx.account.timestamp", "string")));
        headers.put("traceid", valueOrRandom(value("ifx.account.trace-id", "string"), 16));
        headers.put("userid", value("ifx.account.user-id", "string"));
        return headers;
    }

    private Map<String, Object> buildCreateNaturalPersonRequest(String documentTypeId,
                                                                 String documentNumber,
                                                                 String firstLastName,
                                                                 String secondLastName,
                                                                 String firstName,
                                                                 String secondName,
                                                                 String phoneNumber,
                                                                 String email) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("documentTypeId", documentTypeId);
        body.put("documentNumber", documentNumber);
        body.put("passportNumber", value("ifx.natural.passport-number", ""));
        body.put("birthDate", value("ifx.natural.birth-date", "1980-12-12T00:00:00.000Z"));
        body.put("firstLastName", firstLastName);
        body.put("secondLastName", secondLastName);
        body.put("firstName", firstName);
        body.put("secondName", secondName);
        body.put("genderType", value("ifx.natural.gender-type", "M"));
        body.put("maritalStatus", value("ifx.natural.marital-status", "S"));
        body.put("nationalityCode", value("ifx.natural.nationality-code", "1"));
        body.put("birthCountryCode", value("ifx.natural.birth-country-code", "4029"));
        body.put("residentCountryCode", value("ifx.natural.resident-country-code", "4029"));
        body.put("nationalityCountryCode", value("ifx.natural.nationality-country-code", "4029"));
        body.put("streetType", value("ifx.natural.street-type", "AV"));
        body.put("streetName", value("ifx.natural.street-name", "SAN FRANCISCO"));
        body.put("streetNumber", value("ifx.natural.street-number", "7"));
        body.put("blockIdentification", value("ifx.natural.block-identification", "1"));
        body.put("lotId", value("ifx.natural.lot-id", "1"));
        body.put("insideId", value("ifx.natural.inside-id", "1"));
        body.put("urbanizationName", value("ifx.natural.urbanization-name", "URUBAMBA"));
        body.put("locationReference", value("ifx.natural.location-reference", "AL FRENTE DE RESTAURANT"));
        body.put("department", value("ifx.natural.department", "LIMA"));
        body.put("province", value("ifx.natural.province", "LIMA"));
        body.put("district", value("ifx.natural.district", "LINCE"));

        Map<String, String> phone = new LinkedHashMap<>();
        phone.put("phoneType", value("ifx.natural.phone-type", "C"));
        phone.put("phonePrefix", value("ifx.natural.phone-prefix", "051"));
        phone.put("phoneNumber", phoneNumber);
        phone.put("extension", value("ifx.natural.phone-extension", "123"));
        body.put("phoneAddress", List.of(phone, new LinkedHashMap<>(phone)));

        body.put("emailType", value("ifx.natural.email-type", "P"));
        body.put("email", email);
        body.put("ciiuCode", value("ifx.natural.ciiu-code", ""));
        body.put("employmentDate", value("ifx.natural.employment-date", ""));
        body.put("companyName", value("ifx.natural.company-name", "SYNOPSYS"));
        body.put("ocupationCode", value("ifx.natural.ocupation-code", "PRF"));
        return body;
    }

    private Map<String, Object> buildRetrieveCustomerRequest(String documentTypeId, String documentNumber) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("searchCriteria", value("ifx.consulta.search-criteria", "5"));
        body.put("identificationDocumentType", documentTypeId);
        body.put("identificationDocumentNumber", documentNumber);
        body.put("cardId", value("ifx.consulta.card-id", ""));

        Map<String, Object> account = new LinkedHashMap<>();
        account.put("branchCode", value("ifx.consulta.account.branch-code", ""));
        account.put("accountNumber", value("ifx.consulta.account.account-number", ""));

        Map<String, Object> customerAccount = new LinkedHashMap<>();
        customerAccount.put("organisationId", value("ifx.consulta.organisation-id", ""));
        customerAccount.put("currencyCode", value("ifx.consulta.currency-code", ""));
        customerAccount.put("categoryCode", value("ifx.consulta.category-code", ""));
        customerAccount.put("account", account);
        body.put("customerAccount", customerAccount);
        return body;
    }

    private Map<String, Object> buildCreateLegalPersonRequest(String documentTypeId,
                                                              String documentNumber,
                                                              String societyType,
                                                              String countryCode,
                                                              String economicActivityCode) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("documentTypeId", documentTypeId);
        body.put("documentNumber", documentNumber);
        body.put("accountsExecutiveId", value("ifx.merchant.accounts-executive-id", "11126"));
        body.put("countryCode", firstNonBlank(countryCode, value("ifx.merchant.body-country-code", "2023")));

        Map<String, Object> company = new LinkedHashMap<>();
        company.put("companyName", value("ifx.merchant.company-name", "ARICA"));
        company.put("constitutionDate", value("ifx.merchant.constitution-date", "20101204"));
        company.put("economicActivityCode", firstNonBlank(economicActivityCode, value("ifx.merchant.economic-activity-code", "1520")));
        company.put("economicGroupCode", value("ifx.merchant.economic-group-code", "0001"));
        company.put("mainActivity", value("ifx.merchant.main-activity", "Prestampos"));
        company.put("tradeName", value("ifx.merchant.trade-name", "Caja Arequipa"));
        company.put("companyNameAcronym", value("ifx.merchant.company-name-acronym", "Arequipa"));
        company.put("societyType", firstNonBlank(societyType, value("ifx.merchant.society-type", "EIRL")));
        company.put("profitFlag", value("ifx.merchant.profit-flag", "Y"));
        company.put("businessMagnitude", value("ifx.merchant.business-magnitude", "1"));
        body.put("company", company);

        Map<String, Object> address = new LinkedHashMap<>();
        address.put("streetType", value("ifx.merchant.street-type", "JR"));
        address.put("streetName", value("ifx.merchant.street-name", "Catalino Miranda"));
        address.put("streetNumber", value("ifx.merchant.street-number", "154"));
        address.put("blockIdentification", value("ifx.merchant.block-identification", "1"));
        address.put("lotNumber", value("ifx.merchant.lot-number", "154"));
        address.put("insideNumber", value("ifx.merchant.inside-number", "1"));
        address.put("urbanization", value("ifx.merchant.urbanization", "Barranco"));
        address.put("landmark", value("ifx.merchant.landmark", "Altura Javier Prado"));
        address.put("department", value("ifx.merchant.department", "Lima"));
        address.put("province", value("ifx.merchant.province", "Lima"));
        address.put("district", value("ifx.merchant.district", "Barranco"));
        body.put("standardizedAddress", address);

        Map<String, Object> phoneAddress = new LinkedHashMap<>();
        phoneAddress.put("useCode", value("ifx.merchant.phone-use-code", "C"));
        phoneAddress.put("prefix", value("ifx.merchant.phone-prefix", "051"));
        phoneAddress.put("phoneNumber", value("ifx.merchant.phone-number", "909298641"));
        phoneAddress.put("extension", value("ifx.merchant.phone-extension", "12345"));

        Map<String, Object> electronicAddress = new LinkedHashMap<>();
        electronicAddress.put("useCode", value("ifx.merchant.email-use-code", "T"));
        electronicAddress.put("emailAddress", value("ifx.merchant.email-address", "JDEVELOPER@NET.COM.PE"));

        Map<String, Object> contact = new LinkedHashMap<>();
        contact.put("phoneAddress", phoneAddress);
        contact.put("electronicAddress", electronicAddress);
        body.put("contact", contact);
        return body;
    }

    private Map<String, Object> buildCreateAccountRequest(String documentTypeId, String documentNumber, String customerId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("accountOpeningType", value("ifx.account.opening-type", "01"));
        body.put("appCode", value("ifx.account.app-code", "ST"));
        body.put("bankId", value("ifx.account.bank-id", "03"));
        body.put("productCode", value("ifx.account.product-code", "002"));
        body.put("subProductCode", value("ifx.account.sub-product-code", "223"));
        body.put("currencyCode", value("ifx.account.currency-code", "002"));
        body.put("termType", value("ifx.account.term-type", "M"));
        body.put("termTime", intValue("ifx.account.term-time", 2));
        body.put("blockedAccountFlag", value("ifx.account.blocked-account-flag", "S"));
        body.put("investmentFoundType", intValue("ifx.account.investment-found-type", 20));
        body.put("netCode", value("ifx.account.net-code", "BI"));
        body.put("annualRate", doubleValue("ifx.account.annual-rate", 2.01));
        body.put("functionaryId", value("ifx.account.functionary-id", ""));
        body.put("sellerId", value("ifx.account.seller-id", ""));
        body.put("agency", value("ifx.account.agency", "200"));
        body.put("conector", value("ifx.account.conector", "IND"));

        Map<String, Object> debitCard = new LinkedHashMap<>();
        debitCard.put("locateCard", value("ifx.account.debit-card.locate-card", "S"));
        debitCard.put("validateFlag", value("ifx.account.debit-card.validate-flag", "N"));
        body.put("debitCard", debitCard);
        body.put("accountNumber", value("ifx.account.account-number", ""));

        Map<String, Object> customer = new LinkedHashMap<>();
        customer.put("order", intValue("ifx.account.customer-order", 2));
        customer.put("customerId", customerId);
        customer.put("newCardFlag", value("ifx.account.new-card-flag", "S"));
        customer.put("cardId", value("ifx.account.card-id", "411074******3333"));
        body.put("customer", List.of(customer, new LinkedHashMap<>(customer)));

        Map<String, Object> person = new LinkedHashMap<>();
        person.put("documentTypeId", documentTypeId);
        person.put("documentNumber", documentNumber);
        person.put("personType", value("ifx.account.person-type", ""));
        person.put("emailAddress", value("ifx.account.email-address", "davde@hotmail.com"));
        body.put("person", person);
        return body;
    }

    private String chooseDocumentNumber(String typeDocument, String documentNumberOverride) throws IOException {
        if (!isBlank(documentNumberOverride)) return documentNumberOverride.trim();
        if (isRuc(typeDocument)) return nextRuc();
        String configuredDocumentNumber = value("ifx.document-number", "");
        return isBlank(configuredDocumentNumber) ? nextDni() : configuredDocumentNumber;
    }

    private String nextDni() throws IOException {
        return nextSequence("ifx.dni-base", "54072013", "ifx.dni-sequence-file", "target/dni-sequence.txt", 8);
    }

    private String nextRuc() throws IOException {
        return nextSequence("ifx.ruc-base", "20276135769", "ifx.ruc-sequence-file", "target/ruc-sequence.txt", 11);
    }

    private String nextSequence(String baseKey, String baseDefault, String fileKey, String fileDefault, int width) throws IOException {
        long base = Long.parseLong(value(baseKey, baseDefault));
        Path path = Path.of(value(fileKey, fileDefault));
        Path parent = path.getParent();
        if (parent != null) Files.createDirectories(parent);
        long last = base - 1;
        if (Files.exists(path)) {
            String content = Files.readString(path).trim();
            if (!content.isEmpty()) last = Long.parseLong(content);
        }
        long next = last + 1;
        Files.writeString(path, String.valueOf(next));
        return String.format("%0" + width + "d", next);
    }

    private Path resolveDataFile(String data, String file) {
        if (isBlank(file)) throw new IllegalArgumentException("Debe enviar el nombre del archivo Excel/CSV en el parametro file");
        Path base;
        if (isBlank(data)) {
            base = Path.of("src", "main", "resources", "Data");
        } else {
            Path dataPath = Path.of(data);
            base = dataPath.isAbsolute() ? dataPath : Path.of("src", "main", "resources").resolve(dataPath);
        }
        return base.resolve(file);
    }

    private List<Map<String, String>> readDataRows(Path input) throws Exception {
        if (!Files.exists(input)) throw new IllegalArgumentException("No existe el archivo: " + input.toAbsolutePath());
        String name = input.getFileName().toString().toLowerCase();
        if (name.endsWith(".xlsx") || name.endsWith(".xls")) return readExcelRows(input);
        return readDelimitedRows(input);
    }

    private List<Map<String, String>> readExcelRows(Path input) throws Exception {
        List<Map<String, String>> result = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(input.toFile()); Workbook workbook = WorkbookFactory.create(fis)) {
            DataFormatter formatter = new DataFormatter();
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null || sheet.getPhysicalNumberOfRows() == 0) return result;
            Row header = sheet.getRow(sheet.getFirstRowNum());
            Map<Integer, String> headers = new HashMap<>();
            for (Cell cell : header) headers.put(cell.getColumnIndex(), normalizeHeader(formatter.formatCellValue(cell)));
            for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                Map<String, String> map = new LinkedHashMap<>();
                boolean hasData = false;
                for (Map.Entry<Integer, String> entry : headers.entrySet()) {
                    Cell cell = row.getCell(entry.getKey());
                    String value = cell == null ? "" : formatter.formatCellValue(cell).trim();
                    if (!value.isEmpty()) hasData = true;
                    map.put(entry.getValue(), normalizeCellValue(value));
                }
                if (hasData) result.add(map);
            }
        }
        return result;
    }

    private List<Map<String, String>> readDelimitedRows(Path input) throws IOException {
        List<Map<String, String>> result = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(input, StandardCharsets.UTF_8)) {
            String headerLine = br.readLine();
            if (headerLine == null) return result;
            String delimiter = headerLine.contains(";") ? ";" : ",";
            String[] headers = headerLine.split(delimiter);
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(delimiter, -1);
                Map<String, String> map = new LinkedHashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    map.put(normalizeHeader(headers[i]), i < values.length ? values[i].trim() : "");
                }
                result.add(map);
            }
        }
        return result;
    }

    private String normalizeHeader(String header) {
        if (header == null) return "";
        return header.trim().replace("\uFEFF", "").toUpperCase();
    }

    private String normalizeCellValue(String value) {
        if (value == null) return "";
        String trimmed = value.trim();
        if (trimmed.endsWith(".0")) return trimmed.substring(0, trimmed.length() - 2);
        return trimmed;
    }

    private String extractAccountNumber(String responseBody) {
        try {
            if (isBlank(responseBody)) return "";
            JsonNode json = objectMapper.readTree(responseBody);
            return findFirstText(json, "accountNumber");
        } catch (Exception e) {
            return "";
        }
    }

    private int detectAccountsCount(String responseBody) {
        try {
            if (isBlank(responseBody)) return -1;
            JsonNode json = objectMapper.readTree(responseBody);
            JsonNode accounts = findFirstNode(json, "accounts", "accountList", "customerAccounts");
            return accounts != null && accounts.isArray() ? accounts.size() : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    private String findFirstText(JsonNode node, String fieldName) {
        if (node == null) return "";
        if (node.has(fieldName) && !node.get(fieldName).isNull()) return node.get(fieldName).asText();
        if (node.isObject()) {
            var fields = node.fields();
            while (fields.hasNext()) {
                String found = findFirstText(fields.next().getValue(), fieldName);
                if (!isBlank(found)) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                String found = findFirstText(child, fieldName);
                if (!isBlank(found)) return found;
            }
        }
        return "";
    }

    private JsonNode findFirstNode(JsonNode node, String... fieldNames) {
        if (node == null) return null;
        for (String fieldName : fieldNames) {
            if (node.has(fieldName)) return node.get(fieldName);
        }
        if (node.isObject()) {
            var fields = node.fields();
            while (fields.hasNext()) {
                JsonNode found = findFirstNode(fields.next().getValue(), fieldNames);
                if (found != null) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                JsonNode found = findFirstNode(child, fieldNames);
                if (found != null) return found;
            }
        }
        return null;
    }

    private Properties loadProperties(String env) {
        Properties properties = new Properties();
        String fileName = "application-" + env + ".properties";
        File localFile = new File(System.getProperty("user.home"), fileName);
        if (localFile.exists()) {
            try (FileInputStream fis = new FileInputStream(localFile)) {
                properties.load(fis);
                System.out.println("[TDM] Configuracion local cargada: " + localFile.getAbsolutePath());
            } catch (IOException e) {
                throw new IllegalStateException("No se pudo leer " + localFile.getAbsolutePath(), e);
            }
        } else {
            try (var stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties")) {
                if (stream != null) properties.load(stream);
                System.out.println("[TDM] No existe " + localFile.getAbsolutePath() + ". Se usara application.properties/variables de entorno.");
            } catch (IOException e) {
                throw new IllegalStateException("No se pudo leer application.properties", e);
            }
        }
        return properties;
    }

    private String value(String propertyKey, String defaultValue) {
        String sys = System.getProperty(propertyKey);
        if (!isBlank(sys)) return sys.trim();
        String envKey = propertyKey.toUpperCase().replace('.', '_').replace('-', '_');
        String env = System.getenv(envKey);
        if (!isBlank(env)) return env.trim();
        String prop = props.getProperty(propertyKey);
        if (!isBlank(prop)) return resolvePlaceholders(prop.trim());
        return defaultValue;
    }

    private String resolvePlaceholders(String raw) {
        if (isBlank(raw) || !raw.contains("${")) return raw;
        String resolved = raw;
        for (int i = 0; i < 5 && resolved.contains("${"); i++) {
            int start = resolved.indexOf("${");
            int end = resolved.indexOf("}", start);
            if (start < 0 || end < 0) break;
            String key = resolved.substring(start + 2, end);
            String replacement = props.getProperty(key, System.getenv(key.toUpperCase().replace('.', '_').replace('-', '_')));
            if (replacement == null) replacement = "";
            resolved = resolved.substring(0, start) + replacement + resolved.substring(end + 1);
        }
        return resolved;
    }

    private HttpClient createHttpClient() throws Exception {
        String relaxedSslValue = value("ifx.relaxed-ssl", "true");
        boolean useRelaxedSsl = Boolean.parseBoolean(relaxedSslValue);
        if (!useRelaxedSsl) return HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();

        System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
        X509ExtendedTrustManager trustAllCerts = new X509ExtendedTrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] certs, String authType) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType) { }
            public void checkClientTrusted(X509Certificate[] certs, String authType, java.net.Socket socket) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType, java.net.Socket socket) { }
            public void checkClientTrusted(X509Certificate[] certs, String authType, javax.net.ssl.SSLEngine engine) { }
            public void checkServerTrusted(X509Certificate[] certs, String authType, javax.net.ssl.SSLEngine engine) { }
        };
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustAllCerts}, new SecureRandom());
        return HttpClient.newBuilder().sslContext(sslContext).connectTimeout(Duration.ofSeconds(30)).build();
    }

    private String normalizeTypeDocument(String typeDocument) {
        if (isBlank(typeDocument)) return "DNI";
        return typeDocument.trim().toUpperCase();
    }

    private String toIfxDocumentTypeId(String typeDocument) {
        switch (normalizeTypeDocument(typeDocument)) {
            case "DNI": return "1";
            case "RUC": return "2";
            case "CE": return "3";
            case "PASAPORTE": return "5";
            default: return typeDocument;
        }
    }

    private boolean isRuc(String typeDocument) {
        String normalized = normalizeTypeDocument(typeDocument);
        return "RUC".equals(normalized) || "2".equals(normalized);
    }

    private String normalizeBearer(String token) {
        if (isBlank(token)) return "";
        String value = token.trim();
        return value.toLowerCase().startsWith("bearer ") ? value : "Bearer " + value;
    }

    private String buildAuthorizationHeader(String token, String tokenType) {
        if (isBlank(token)) return "";
        String defaultPrefix = "consulta".equalsIgnoreCase(tokenType) || "transaccion".equalsIgnoreCase(tokenType) ? "Bearer" : "";
        String prefix = firstNonBlank(
                value("ifx." + tokenType + ".authorization-prefix", defaultPrefix),
                value("ifx.authorization-prefix", defaultPrefix)
        );
        if (isBlank(prefix)) return token.trim();
        if ("Bearer".equalsIgnoreCase(prefix.trim())) return normalizeBearer(token);
        return prefix.trim() + " " + token.trim();
    }

    private String valueOrRandom(String configured, int length) {
        if (!isBlank(configured) && !"string".equalsIgnoreCase(configured)) return configured.trim();
        String raw = UUID.randomUUID().toString().replace("-", "");
        return raw.substring(0, Math.min(length, raw.length()));
    }

    private String valueOrCurrentTimestamp(String configured) {
        if (!isBlank(configured) && !"string".equalsIgnoreCase(configured)) return configured.trim();
        return DateTimeFormatter.ISO_INSTANT.format(Instant.now());
    }

    private String valueOrCurrentGlobalTransactionId(String configured) {
        if (!isBlank(configured) && !"string".equalsIgnoreCase(configured)) return configured.trim();
        return DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneOffset.UTC).format(Instant.now());
    }

    private String normalizeBaseUrl(String value) {
        if (isBlank(value)) throw new IllegalStateException("Configure ifx.base-url en C:\\Users\\<usuario>\\application-" + environment + ".properties");
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private String normalizePath(String value) {
        if (isBlank(value)) return "";
        return value.startsWith("/") ? value : "/" + value;
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private String firstNonBlank(String... values) {
        if (values == null) return "";
        for (String value : values) if (!isBlank(value)) return value.trim();
        return "";
    }

    private int intValue(String key, int defaultValue) {
        try { return Integer.parseInt(value(key, String.valueOf(defaultValue))); }
        catch (Exception e) { return defaultValue; }
    }

    private long longValue(String key, long defaultValue) {
        try { return Long.parseLong(value(key, String.valueOf(defaultValue))); }
        catch (Exception e) { return defaultValue; }
    }

    private double doubleValue(String key, double defaultValue) {
        try { return Double.parseDouble(value(key, String.valueOf(defaultValue))); }
        catch (Exception e) { return defaultValue; }
    }

    private void printIfxResult(String operationTag,
                                String documentNumber,
                                int statusCode,
                                String busResponseMessage,
                                String srvResponseCode,
                                String srvResponseMessage,
                                String responseBody) {
        String prefix = "[IFX " + safe(operationTag) + "] ";
        System.out.println(prefix + "Documento generado: " + safe(documentNumber));
        System.out.println(prefix + "Status: " + statusCode);
        System.out.println(prefix + "busresponsemessage: " + safe(busResponseMessage));
        System.out.println(prefix + "srvresponsecode: " + safe(srvResponseCode));
        System.out.println(prefix + "srvresponsemessage: " + safe(srvResponseMessage));
        System.out.println(prefix + "Response: " + safe(responseBody));
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

