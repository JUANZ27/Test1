package com.nttdata.tdm.ifx.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.http.HttpClient;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;

@Component
public class IfxHttpClientFactory {

    @Value("${ifx.relaxed-ssl:true}")
    private boolean relaxedSsl;

    public HttpClient create() {
        try {
            HttpClient.Builder builder = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(30));

            if (relaxedSsl) {
                System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
                TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        // Uso exclusivo para ambientes internos/UAT con certificados no públicos.
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        // Uso exclusivo para ambientes internos/UAT con certificados no públicos.
                    }
                }};
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustAllCerts, new SecureRandom());
                builder.sslContext(sslContext);
            }

            return builder.build();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo construir el HttpClient IFX", e);
        }
    }
}
