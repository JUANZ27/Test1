package com.nttdata.tdm.controllers;

import com.nttdata.tdm.model.entity.ClientEnt;
import com.nttdata.tdm.service.IClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@ComponentScan("com.nttdata.tdm.service")
@RequestMapping("/tdm")
public class ClientController {
    @Autowired
    private IClientService clientService;
    @PostMapping("client")
    public ClientEnt create(@RequestBody ClientEnt client){
         return clientService.save(client);
    }
    @PutMapping("client")
    public ClientEnt update(@RequestBody ClientEnt client){
         return clientService.save(client);
    }
    @DeleteMapping("client/{id}")
    public void delete(@PathVariable String id){
        ClientEnt clientDelete = clientService.findById(id);
        clientService.delete(clientDelete);
    }
    @GetMapping("client/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ClientEnt showById(@PathVariable String id){
        return clientService.findById(id);
    }

    @GetMapping("client/showBy")
    @ResponseStatus(HttpStatus.OK)
    public List <ClientEnt> showByTypeClient(@RequestParam(value="type") String type,@RequestParam(value="value") String value ){
        if(type.equals("typeClient"))
            return clientService.findByTypeClient(value);
        if(type.equals("typeDocument"))
            return clientService.findByTypeDocument(value);
        return null;

    }
    @GetMapping("client/showBySunat")
    @ResponseStatus(HttpStatus.OK)
    public List <ClientEnt> ShowBySunat(@RequestParam(value="typeClient") String typeClient,
                                         @RequestParam(value="typeDocument") String typeDocument,
                                         @RequestParam(value="sunat") Integer  sunat){
            return clientService.findAllSunat(typeClient,typeDocument,sunat);
    }
    @GetMapping("client/showByReniec")
    @ResponseStatus(HttpStatus.OK)
    public List <ClientEnt> ShowByReniec(@RequestParam(value="typeClient") String typeClient,
                                         @RequestParam(value="typeDocument") String typeDocument,
                                         @RequestParam(value="reniec") Integer  reniec){
        return clientService.findAllReniec(typeClient,typeDocument,reniec);
    }


}
