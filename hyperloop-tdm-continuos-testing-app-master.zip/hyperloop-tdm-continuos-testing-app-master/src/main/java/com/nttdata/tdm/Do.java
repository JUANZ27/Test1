package com.nttdata.tdm;

import com.nttdata.tdm.ifx.client.IfxStandaloneClient;
import com.nttdata.tdm.ifx.dto.IfxApiResponse;
import com.nttdata.tdm.ifx.dto.IfxBatchResponse;
import com.nttdata.tdm.ifx.dto.IfxCreateCustomerResponse;

public class Do {

    private Do() {
    }

    public static IfxCreateCustomerResponse crearPersonaNaturalIFX(String tipoDocumento) {
        return crearPersonaNaturalIFX(tipoDocumento, defaultEnvironment());
    }

    public static IfxCreateCustomerResponse crearPersonaNaturalIFX(String tipoDocumento, String environment) {
        return new IfxStandaloneClient(environment).createNaturalPerson(tipoDocumento);
    }

    public static IfxCreateCustomerResponse crearPersonaNaturalIFX(String tipoDocumento, String numeroDocumento, String environment) {
        return new IfxStandaloneClient(environment).createNaturalPerson(tipoDocumento, numeroDocumento);
    }

    public static IfxApiResponse consultarClienteIFX(String tipoDocumento, String numeroDocumento) {
        return consultarClienteIFX(tipoDocumento, numeroDocumento, defaultEnvironment());
    }

    public static IfxApiResponse consultarClienteIFX(String tipoDocumento, String numeroDocumento, String environment) {
        return new IfxStandaloneClient(environment).retrieveCustomer(tipoDocumento, numeroDocumento);
    }

    public static IfxApiResponse consultarCustomerSpecialStatusCCE(String documentTypeId, String documentNumber) {
        return consultarCustomerSpecialStatusCCE(documentTypeId, documentNumber, defaultEnvironment());
    }

    public static IfxApiResponse consultarCustomerSpecialStatusCCE(String documentTypeId,
                                                                   String documentNumber,
                                                                   String environment) {
        return new IfxStandaloneClient(environment).retrieveCustomerSpecialStatus(documentTypeId, documentNumber);
    }

    public static IfxApiResponse crearClientePJIFX(String tipoDocumento, String numeroDocumento, String environment) {
        return new IfxStandaloneClient(environment).createLegalPerson(tipoDocumento, numeroDocumento);
    }

    public static IfxApiResponse crearClientePJIFX(String environment) {
        return new IfxStandaloneClient(environment).createLegalPerson("RUC");
    }

    public static IfxApiResponse crearCuentaIFX(String tipoDocumento, String numeroDocumento, String customerId, String environment) {
        return new IfxStandaloneClient(environment).createAccount(tipoDocumento, numeroDocumento, customerId);
    }

    public static IfxBatchResponse GenerateDataFromExcel(String data, String file, String environment) {
        return new IfxStandaloneClient(environment).generateDataFromExcel(data, file);
    }

    public static IfxBatchResponse GenerateDataNoClient(String typeDocument, int numberRecord, String environment) {
        return new IfxStandaloneClient(environment).generateDataNoClient(typeDocument, numberRecord);
    }

    public static IfxApiResponse GetDataNoClient(String typeDocument, String typeClient, String environment) {
        return new IfxStandaloneClient(environment).getDataNoClient(typeDocument, typeClient);
    }

    public static IfxApiResponse GetDataClient(String typeDocument, String typeClient, String partners, String environment) {
        return new IfxStandaloneClient(environment).getDataClient(typeDocument, typeClient, partners);
    }

    public static IfxApiResponse GetDataClientNatural(String typeDocument, String typeClient, String environment) {
        return new IfxStandaloneClient(environment).getDataClientNatural(typeDocument, typeClient);
    }

    private static String defaultEnvironment() {
        return System.getProperty("environment", "uat");
    }
}
