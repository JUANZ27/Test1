module.exports = {
  default: {
    paths: ['src/test/features/**/*.feature'],
    requireModule: ['ts-node/register'],
    require: ['src/support/**/*.ts', 'src/test/steps/**/*.ts'],
    format: [
      'progress-bar',
      'summary',
      'json:reports/cucumber/cucumber-report.json',
      'html:reports/cucumber/cucumber-report.html'
    ],
    publishQuiet: true,
    failFast: false,
    parallel: 0
  }
};
