# Plantilla de informe de pruebas de performance

Esta plantilla se llena automáticamente al ejecutar:

```bash
npm run test:performance:carga
npm run report
```

Archivo generado:

```text
reports/performance/informe-performance.md
reports/html/informe-performance.html
```

## Secciones generadas

1. Resumen ejecutivo.
2. Objetivo de la prueba según tipo: carga, pico, estrés o resistencia.
3. Configuración de usuarios, duración, ramp up y ambiente.
4. Resultados: TPS, throughput, error rate, percentiles, promedio, desviación estándar y dispersión.
5. Criterios de aceptación.
6. Decisión: APTO, OBSERVADO o NO APTO.
7. Recomendaciones técnicas.
8. Archivos de evidencia.
