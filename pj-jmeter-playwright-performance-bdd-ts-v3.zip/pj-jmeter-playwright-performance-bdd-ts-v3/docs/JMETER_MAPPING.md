# Mapping JMeter a Playwright API

## PJ.jmx

| JMeter sampler | Implementación TypeScript | Endpoint |
|---|---|---|
| Token | `PjService.token()` | `POST /bcv-security/v1/oauth/token` |
| Compliance | `PjService.compliance()` | `POST /bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation` |
| Apertura | `PjService.apertura()` | `POST /bcv-bacc-party-lifecycle-management/v1/business-account` |
| Tracking | `PjService.tracking()` | `GET /bcv-bacc-party-lifecycle-management/v1/business-account/status-expedient` |

## NoConstituida.jmx

| JMeter sampler | Implementación TypeScript | Endpoint |
|---|---|---|
| TOKEN SECURITY | `PjService.token()` | `POST /bcv-security/v1/oauth/token` |
| CREACION DE EXPEDIENTE | `PjService.complianceNoConstituida()` | `POST /bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation` |
| APERTURA DE CUENTA | `PjService.aperturaNoConstituida()` | `POST /bcv-bacc-party-lifecycle-management/v1/business-account` |

## Consideración para evitar 500 después del token

Antes, si no se obtenía `access_token`, el flujo podía seguir y enviar `authorization: Bearer ` vacío a los endpoints de negocio. Eso podía producir errores HTTP 500 difíciles de diagnosticar.

Ahora se aplica la regla:

```text
Si TokenPJ no tiene HTTP 2xx o no retorna access_token, no se llama compliance/apertura/tracking.
```

Esto no oculta errores reales del backend. Solo evita ejecutar negocio con token inválido y deja el error claro en logs y reportes.

## Archivos fuente originales

```text
docs/original/PJ.jmx
docs/original/NoConstituida.jmx
```
