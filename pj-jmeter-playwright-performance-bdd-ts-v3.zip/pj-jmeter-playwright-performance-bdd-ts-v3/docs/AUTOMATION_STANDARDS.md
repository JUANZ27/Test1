# Estándares de automatización aplicados

## Objetivo

Mantener una suite de performance API liviana, trazable y útil para toma de decisiones.

## Buenas prácticas aplicadas

1. **Sin video ni screenshots en performance**
   - Evita consumo extra de CPU, memoria y disco.
   - Reduce ruido en los resultados.
   - La evidencia se basa en métricas y logs.

2. **Separación de responsabilidades**
   - `services`: consumo de API.
   - `utils`: generación de datos, CSV, logs y performance runner.
   - `report`: generación de informes.
   - `features`: escenarios BDD.
   - `steps`: glue code de Cucumber.

3. **Data trazable**
   - DNI/RUC generados se guardan en CSV.
   - Modo incremental recomendado para pipelines.

4. **Métricas de performance útiles**
   - TPS.
   - Throughput.
   - Error rate.
   - Percentiles p50, p75, p90, p95 y p99.
   - Promedio, mínimo, máximo y desviación estándar.
   - Coeficiente de variación y outliers.
   - Dispersión por iteración.

5. **Informe orientado a decisión**
   - APTO.
   - OBSERVADO.
   - NO APTO.

6. **Headers de negocio**
   - Se imprimen y almacenan `busresponsemessage`, `srvresponsecode` y `srvresponsemessage`.

## Tipos de prueba

- **Carga:** valida comportamiento con carga esperada.
- **Pico:** valida respuesta ante aumento brusco.
- **Estrés:** busca límite o punto de quiebre.
- **Resistencia:** valida estabilidad en el tiempo.

## Criterios sugeridos

```env
PERF_MAX_ERROR_RATE=0.01
PERF_P95_MAX_MS=3000
PERF_MIN_TPS=5
PERF_MAX_CV=0.75
```

Estos valores deben ajustarse según SLA, capacidad esperada y línea base del sistema.
