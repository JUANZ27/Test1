# Configuración del archivo .env

El archivo `.env` debe ubicarse en la raíz del proyecto, junto a `package.json`.

```text
pj-jmeter-playwright-performance-bdd-ts-v3/
├── .env
├── package.json
├── cucumber.js
└── src/
```

El proyecto incluye `.env`, `.env.example` y `ENV-PERFORMANCE.txt`.

## Variables obligatorias

```env
BASE_URL=https://eu2-ibk-apm-stg-ext-001.azure-api.net
TOKEN_PATH=/bcv-security/v1/oauth/token
TOKEN_GRANT_TYPE=client_credentials
TOKEN_AUTHORIZATION_BASIC=Basic_REEMPLAZAR_AQUI
TOKEN_SUBSCRIPTION_KEY=REEMPLAZAR_AQUI
API_SUBSCRIPTION_KEY=REEMPLAZAR_AQUI
```

## Variables para NoConstituida.jmx

El sampler `APERTURA DE CUENTA` del JMX usa headers adicionales:

```env
APERTURA_CHANNEL=DIGITAL
APERTURA_CONSUMER_ID=ELhZrjaJHLXCCoq8u6YTxFVtTnfh3l1C
NO_CONSTITUIDA_DOCUMENT_START=60000001
```

## Cambiar flujo de performance

Para PJ constituida:

```env
PERF_FLOW_TYPE=PJ_CONSTITUIDA
```

Para no constituida:

```env
PERF_FLOW_TYPE=NO_CONSTITUIDA
```

## Recomendación

No subas el `.env` con valores reales a Git. Usa `.env.example` como plantilla y configura secretos en variables del pipeline cuando ejecutes en CI/CD.
