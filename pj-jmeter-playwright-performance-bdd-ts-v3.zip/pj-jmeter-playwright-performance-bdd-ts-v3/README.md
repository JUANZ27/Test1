# PJ y NoConstituida JMX migrados a Playwright API + TypeScript + Cucumber/Gherkin

Proyecto para automatizar los flujos de **performance API** migrados desde:

- `PJ.jmx`
- `NoConstituida.jmx`

El enfoque no usa video, screenshots ni navegador porque una prueba de performance debe medir el comportamiento real del servicio con el menor overhead posible. La evidencia se basa en métricas, logs, request, response, headers, TPS, percentiles, tasa de error, dispersión e informe ejecutivo.

## Stack

- Playwright API Request
- TypeScript
- Cucumber / Gherkin
- Node.js
- Reporte HTML propio
- CSV de dispersión
- JSON de resumen técnico
- Logs de ejecución
- Data dinámica DNI/RUC/documento no constituida incremental

## Mejora para evitar 500 después del token

Se agregó una validación defensiva: si el servicio de token no responde HTTP 2xx o no devuelve `access_token`, el framework **no ejecuta los endpoints de negocio**. Esto evita llamadas con `Bearer` vacío o inválido, que normalmente terminan generando errores 500 difíciles de diagnosticar.

El token ahora se envía como el JMX de No Constituida:

```text
POST /bcv-security/v1/oauth/token
content-type: application/x-www-form-urlencoded
grant_type=client_credentials
```

Y los flujos de negocio usan el `Bearer access_token` obtenido.

## Instalación

```bash
npm install
```

No es necesario ejecutar `playwright install` porque esta suite usa **API testing**, no navegador.

## Configuración del `.env`

El archivo `.env` debe estar en la **raíz del proyecto**, al mismo nivel de:

```text
package.json
cucumber.js
README.md
.env
```

El ZIP incluye:

```text
.env
.env.example
ENV-PERFORMANCE.txt
```

Como `.env` puede mostrarse oculto en Windows porque empieza con punto, también se deja `ENV-PERFORMANCE.txt` visible. Puedes copiarlo y renombrarlo como `.env`.

Windows PowerShell:

```powershell
Copy-Item ENV-PERFORMANCE.txt .env
```

Linux/Mac:

```bash
cp ENV-PERFORMANCE.txt .env
```

Configura tus valores reales:

```env
BASE_URL=https://...
TOKEN_AUTHORIZATION_BASIC=Basic_xxx
TOKEN_SUBSCRIPTION_KEY=xxx
API_SUBSCRIPTION_KEY=xxx
TOKEN_GRANT_TYPE=client_credentials
APERTURA_CHANNEL=DIGITAL
APERTURA_CONSUMER_ID=ELhZrjaJHLXCCoq8u6YTxFVtTnfh3l1C
```

Más detalle en:

```text
docs/CONFIGURACION_ENV.md
```

## Flujos disponibles

### PJ constituida, desde `PJ.jmx`

```bash
npm run test:token
npm run test:compliance
npm run test:apertura
npm run test:tracking
npm run test:pj
npm run report
```

### PJ no constituida, desde `NoConstituida.jmx`

```bash
npm run test:no-constituida:expediente
npm run test:no-constituida:apertura
npm run test:no-constituida
npm run report
```

También puedes ejecutar por tags:

```bash
npx cucumber-js --tags @CreacionExpedienteNoConstituida
npx cucumber-js --tags @AperturaNoConstituida
npx cucumber-js --tags @FlujoCompletoNoConstituida
```

## Ejecución de performance

### PJ constituida

```bash
npm run clean
npm run test:performance:carga
npm run report
```

### PJ no constituida

```bash
npm run clean
npm run test:performance:no-constituida:carga
npm run report
```

### Otros tipos de prueba para no constituida

```bash
npm run test:performance:no-constituida:pico
npm run test:performance:no-constituida:estres
npm run test:performance:no-constituida:resistencia
```

### Simulación parecida al JMeter `NoConstituida.jmx`

El JMX indica 4 threads, duración 3600 segundos e iteraciones configuradas. Para simularlo:

```bash
npm run clean
npm run test:performance:no-constituida:jmeter
npm run report
```

## Personalizar usuarios, duración, flujo y umbrales

Linux/Mac:

```bash
PERF_FLOW_TYPE=NO_CONSTITUIDA PERF_TEST_TYPE=CARGA PERF_VUS=4 PERF_DURATION_SECONDS=3600 PERF_P95_MAX_MS=3000 PERF_MAX_ERROR_RATE=0.01 npm run test:performance:no-constituida
npm run report
```

Windows PowerShell:

```powershell
$env:PERF_FLOW_TYPE="NO_CONSTITUIDA"
$env:PERF_TEST_TYPE="CARGA"
$env:PERF_VUS="4"
$env:PERF_DURATION_SECONDS="3600"
$env:PERF_P95_MAX_MS="3000"
$env:PERF_MAX_ERROR_RATE="0.01"
npm run test:performance:no-constituida
npm run report
```

## Métricas generadas

El runner calcula:

- Iteraciones totales
- Iteraciones exitosas y fallidas
- TPS o transacciones por segundo
- Throughput por minuto
- Success rate
- Error rate
- Tiempo mínimo
- Tiempo promedio
- Tiempo máximo
- Desviación estándar
- Coeficiente de variación
- Percentiles p50, p75, p90, p95 y p99
- Outliers estimados
- Dispersión por iteración
- Headers de negocio muestreados:
  - `busresponsemessage`
  - `srvresponsecode`
  - `srvresponsemessage`

## Reportes generados

Después de ejecutar `npm run report`:

```text
reports/html/index.html
reports/html/evidencias.html
reports/html/informe-performance.html
reports/html/dispersion.html
reports/performance/performance-summary.json
reports/performance/dispersion.csv
reports/logs/pj-execution.log
reports/generated/documentos-generados.csv
```

## Cómo tomar decisión

El informe genera una decisión ejecutiva:

- **APTO:** cumple criterios de error rate, p95, TPS y dispersión.
- **OBSERVADO:** sirve para análisis, pero requiere revisión antes de aprobar.
- **NO APTO:** no se recomienda aprobar sin corrección y nueva ejecución.

Los criterios se configuran en `.env`:

```env
PERF_MAX_ERROR_RATE=0.01
PERF_P95_MAX_MS=3000
PERF_MIN_TPS=5
PERF_MAX_CV=0.75
```

## Recomendación QA Senior

Para performance formal, no uses video, screenshots ni navegador. Usa métricas objetivas, logs, percentiles, TPS, tasa de error, dispersión y monitoreo de infraestructura. Este proyecto deja la ejecución liviana para que los resultados no se contaminen por overhead visual.
