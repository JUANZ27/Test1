import { Given, Then, When } from '@cucumber/cucumber';
import assert from 'assert';
import { config } from '../../support/config';
import { CustomWorld } from '../../support/world';
import { PjService } from '../../services/pj-service';
import { generateDocuments } from '../../utils/document-generator';
import { log } from '../../utils/logger';
import { runPerformance } from '../../utils/performance-runner';
import { PerformanceFlowType, PerformanceTestType } from '../../types';

function service(world: CustomWorld): PjService {
  return new PjService({
    token: world.token,
    documents: world.documents,
    expNumber: world.expNumber,
    evidence: world.evidence,
    scenario: world.scenarioName
  });
}

function syncWorldFromLastResponse(world: CustomWorld): void {
  const last = world.evidence[world.evidence.length - 1];
  world.token = extractAccessToken(last?.response.bodyJson) ?? world.token;
  world.expNumber = extractValue(last?.response.bodyJson, 'expedientNumber') ?? world.expNumber;
}

Given('que uso la configuración del ambiente {string}', function (this: CustomWorld, environment: string) {
  this.environment = environment;
  log(`[CONFIG] Ambiente solicitado en feature: ${environment}. Ambiente efectivo .env: ${config.environment}`);
});

Given('que genero documentos dinámicos para PJ', function (this: CustomWorld) {
  this.documents = generateDocuments();
  log('[DATA] Documentos generados para PJ', this.documents);
});

Given('que genero documentos dinámicos para PJ no constituida', function (this: CustomWorld) {
  this.documents = generateDocuments();
  log('[DATA] Documentos generados para PJ no constituida', this.documents);
});

When('solicito el token de seguridad PJ', async function (this: CustomWorld) {
  const record = await service(this).token();
  this.token = extractAccessToken(record.response.bodyJson) ?? this.token;
});

When('ejecuto la validación inicial compliance PJ', async function (this: CustomWorld) {
  await service(this).compliance();
  syncWorldFromLastResponse(this);
});

When('ejecuto la apertura de cuenta PJ', async function (this: CustomWorld) {
  await service(this).apertura();
  syncWorldFromLastResponse(this);
});

When('consulto el tracking del expediente PJ', async function (this: CustomWorld) {
  await service(this).tracking();
  syncWorldFromLastResponse(this);
});

When('ejecuto el flujo completo PJ migrado desde JMeter', async function (this: CustomWorld) {
  if (!this.documents) this.documents = generateDocuments();
  await service(this).fullFlow();
  syncWorldFromLastResponse(this);
});

When('ejecuto la creación de expediente no constituida', async function (this: CustomWorld) {
  await service(this).complianceNoConstituida();
  syncWorldFromLastResponse(this);
});

When('ejecuto la apertura de cuenta no constituida', async function (this: CustomWorld) {
  await service(this).aperturaNoConstituida();
  syncWorldFromLastResponse(this);
});

When('ejecuto el flujo completo no constituida migrado desde JMeter', async function (this: CustomWorld) {
  if (!this.documents) this.documents = generateDocuments();
  await service(this).fullFlowNoConstituida();
  syncWorldFromLastResponse(this);
});

When('ejecuto performance tipo {string} del flujo PJ con {int} usuarios durante {int} segundos', async function (this: CustomWorld, testType: string, vus: number, durationSeconds: number) {
  const summary = await runPerformance({
    vus,
    durationSeconds,
    scenario: this.scenarioName,
    testType: normalizeTestType(testType),
    flowType: 'PJ_CONSTITUIDA'
  });
  this.evidence.push(summary);
});

When('ejecuto performance tipo {string} del flujo no constituida con {int} usuarios durante {int} segundos', async function (this: CustomWorld, testType: string, vus: number, durationSeconds: number) {
  const summary = await runPerformance({
    vus,
    durationSeconds,
    scenario: this.scenarioName,
    testType: normalizeTestType(testType),
    flowType: 'NO_CONSTITUIDA'
  });
  this.evidence.push(summary);
});

When('ejecuto performance del flujo PJ con {int} usuarios durante {int} segundos', async function (this: CustomWorld, vus: number, durationSeconds: number) {
  const summary = await runPerformance({ vus, durationSeconds, scenario: this.scenarioName, flowType: 'PJ_CONSTITUIDA' });
  this.evidence.push(summary);
});

When('ejecuto performance del flujo no constituida con {int} usuarios durante {int} segundos', async function (this: CustomWorld, vus: number, durationSeconds: number) {
  const summary = await runPerformance({ vus, durationSeconds, scenario: this.scenarioName, flowType: 'NO_CONSTITUIDA' });
  this.evidence.push(summary);
});

Then('la respuesta HTTP debe ser exitosa o aceptada por el ambiente', function (this: CustomWorld) {
  const last = this.evidence[this.evidence.length - 1];
  assert.ok(last, 'No existe evidencia de respuesta HTTP');
  assert.ok(last.response.status >= 200 && last.response.status < 300, `HTTP no exitoso. Status recibido: ${last.response.status}`);
});

Then('no se debe ejecutar ningún endpoint de negocio si el token no es válido', function (this: CustomWorld) {
  const tokenRecord = this.evidence.find(item => item.operation === 'TokenPJ');
  assert.ok(tokenRecord, 'No se encontró evidencia del token');
  if (!tokenRecord.success) {
    const businessOperations = this.evidence.filter(item => item.operation !== 'TokenPJ');
    assert.equal(businessOperations.length, 0, 'Se ejecutaron operaciones de negocio aun cuando el token fue inválido');
  }
});

Then('se debe obtener el número de expediente si el servicio lo retorna', function (this: CustomWorld) {
  const last = this.evidence[this.evidence.length - 1];
  const expNumber = extractValue(last?.response.bodyJson, 'expedientNumber');
  if (expNumber) {
    this.expNumber = expNumber;
    log(`[VALIDATION] expedientNumber obtenido: ${expNumber}`);
  } else {
    log('[VALIDATION] El servicio no retornó expedientNumber. Se continúa porque depende del ambiente/respuesta real.');
  }
});

Then('todas las operaciones críticas del flujo PJ deben quedar registradas', function (this: CustomWorld) {
  const operations = this.evidence.map(item => item.operation);
  for (const required of ['TokenPJ', 'CompliancePJ', 'AperturaPJ', 'TrackingPJ']) {
    assert.ok(operations.includes(required), `No se registró la operación requerida: ${required}`);
  }
});

Then('todas las operaciones críticas del flujo no constituida deben quedar registradas', function (this: CustomWorld) {
  const operations = this.evidence.map(item => item.operation);
  for (const required of ['TokenPJ', 'CreacionExpedienteNoConstituida', 'AperturaNoConstituida']) {
    assert.ok(operations.includes(required), `No se registró la operación requerida: ${required}`);
  }
});

Then('se genera el resumen de performance en el reporte', function (this: CustomWorld) {
  const last = this.evidence[this.evidence.length - 1];
  assert.equal(last?.operation, 'PerformancePJ');
  assert.ok(last.performanceSummary, 'No existe performanceSummary en la evidencia');
});

Then('el informe de performance debe contener tps percentiles dispersión y decisión', function (this: CustomWorld) {
  const summary = this.evidence[this.evidence.length - 1]?.performanceSummary;
  assert.ok(summary, 'No existe resumen de performance');
  assert.ok(summary.flowType as PerformanceFlowType, 'No existe flowType');
  assert.ok(typeof summary.tps === 'number', 'No existe TPS');
  assert.ok(typeof summary.p95Ms === 'number', 'No existe p95');
  assert.ok(typeof summary.p99Ms === 'number', 'No existe p99');
  assert.ok(typeof summary.stdDevMs === 'number', 'No existe desviación estándar');
  assert.ok(Array.isArray(summary.samples), 'No existe data de dispersión');
  assert.ok(summary.decision?.status, 'No existe decisión ejecutiva');
});

Then('se adjunta el request response headers y métricas al reporte', function (this: CustomWorld) {
  assert.ok(this.evidence.length > 0, 'No hay evidencias para adjuntar al reporte');
  for (const item of this.evidence) {
    assert.ok(item.request, `No hay request para ${item.operation}`);
    assert.ok(item.response, `No hay response para ${item.operation}`);
    assert.ok(item.response.headers, `No hay response headers para ${item.operation}`);
    assert.ok(typeof item.response.durationMs === 'number', `No hay métrica durationMs para ${item.operation}`);
  }
});

function normalizeTestType(value: string): PerformanceTestType {
  const normalized = value.trim().toUpperCase();
  if (normalized === 'LOAD') return 'CARGA';
  if (normalized === 'SPIKE') return 'PICO';
  if (normalized === 'STRESS' || normalized === 'ESTRÉS') return 'ESTRES';
  if (normalized === 'ENDURANCE' || normalized === 'SOAK') return 'RESISTENCIA';
  if (['CARGA', 'PICO', 'ESTRES', 'RESISTENCIA'].includes(normalized)) return normalized as PerformanceTestType;
  return 'CARGA';
}

function extractAccessToken(json: unknown): string | undefined {
  return extractValue(json, 'access_token');
}

function extractValue(json: unknown, key: string): string | undefined {
  if (!json || typeof json !== 'object') return undefined;
  if (key in json) return String((json as Record<string, unknown>)[key]);
  for (const value of Object.values(json as Record<string, unknown>)) {
    const found = extractValue(value, key);
    if (found) return found;
  }
  return undefined;
}
