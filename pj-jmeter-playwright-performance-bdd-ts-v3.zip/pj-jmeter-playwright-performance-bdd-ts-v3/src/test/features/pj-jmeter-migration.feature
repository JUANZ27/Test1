# language: es
@PJ @JMeterMigration @PlaywrightAPI
Característica: Flujos PJ migrados desde JMeter a Playwright API
  Como QA Automation Senior
  Quiero automatizar los archivos PJ.jmx y NoConstituida.jmx con Playwright, TypeScript, Cucumber y Gherkin
  Para ejecutar pruebas funcionales y de performance con métricas, reportes HTML, request, response y headers

  Antecedentes:
    Dado que uso la configuración del ambiente "stg"

  @TokenPJ @smoke
  Escenario: Obtener token de seguridad para flujos PJ
    Cuando solicito el token de seguridad PJ
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y no se debe ejecutar ningún endpoint de negocio si el token no es válido
    Y se adjunta el request response headers y métricas al reporte

  @CompliancePJ @CrearExpedientePJ @smoke
  Escenario: Ejecutar validación inicial compliance para persona jurídica constituida
    Dado que genero documentos dinámicos para PJ
    Cuando ejecuto la validación inicial compliance PJ
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se debe obtener el número de expediente si el servicio lo retorna
    Y se adjunta el request response headers y métricas al reporte

  @AperturaPJ @smoke
  Escenario: Ejecutar apertura de cuenta PJ constituida
    Dado que genero documentos dinámicos para PJ
    Y ejecuto la validación inicial compliance PJ
    Cuando ejecuto la apertura de cuenta PJ
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request response headers y métricas al reporte

  @TrackingPJ @smoke
  Escenario: Consultar tracking de expediente PJ por DNI
    Dado que genero documentos dinámicos para PJ
    Y ejecuto la validación inicial compliance PJ
    Y ejecuto la apertura de cuenta PJ
    Cuando consulto el tracking del expediente PJ
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request response headers y métricas al reporte

  @FlujoCompletoPJ @regression
  Escenario: Ejecutar flujo completo PJ constituida migrado desde PJ.jmx
    Dado que genero documentos dinámicos para PJ
    Cuando ejecuto el flujo completo PJ migrado desde JMeter
    Entonces todas las operaciones críticas del flujo PJ deben quedar registradas
    Y se adjunta el request response headers y métricas al reporte

  @NoConstituida @CreacionExpedienteNoConstituida @smoke
  Escenario: Ejecutar creación de expediente para PJ no constituida
    Dado que genero documentos dinámicos para PJ no constituida
    Cuando ejecuto la creación de expediente no constituida
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se debe obtener el número de expediente si el servicio lo retorna
    Y se adjunta el request response headers y métricas al reporte

  @NoConstituida @AperturaNoConstituida @smoke
  Escenario: Ejecutar apertura de cuenta para PJ no constituida
    Dado que genero documentos dinámicos para PJ no constituida
    Y ejecuto la creación de expediente no constituida
    Cuando ejecuto la apertura de cuenta no constituida
    Entonces la respuesta HTTP debe ser exitosa o aceptada por el ambiente
    Y se adjunta el request response headers y métricas al reporte

  @NoConstituida @FlujoCompletoNoConstituida @regression
  Escenario: Ejecutar flujo completo no constituida migrado desde NoConstituida.jmx
    Dado que genero documentos dinámicos para PJ no constituida
    Cuando ejecuto el flujo completo no constituida migrado desde JMeter
    Entonces todas las operaciones críticas del flujo no constituida deben quedar registradas
    Y se adjunta el request response headers y métricas al reporte

  @PerformancePJ @Carga @load
  Escenario: Ejecutar prueba de carga del flujo PJ constituida
    Cuando ejecuto performance tipo "CARGA" del flujo PJ con 1 usuarios durante 10 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformancePJ @Pico @spike
  Escenario: Ejecutar prueba de pico del flujo PJ constituida
    Cuando ejecuto performance tipo "PICO" del flujo PJ con 80 usuarios durante 120 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformancePJ @Estres @stress
  Escenario: Ejecutar prueba de estrés del flujo PJ constituida
    Cuando ejecuto performance tipo "ESTRES" del flujo PJ con 100 usuarios durante 180 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformancePJ @Resistencia @endurance
  Escenario: Ejecutar prueba de resistencia del flujo PJ constituida
    Cuando ejecuto performance tipo "RESISTENCIA" del flujo PJ con 30 usuarios durante 600 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformanceNoConstituida @CargaNoConstituida @load
  Escenario: Ejecutar prueba de carga del flujo PJ no constituida
    Cuando ejecuto performance tipo "CARGA" del flujo no constituida con 1 usuarios durante 10 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformanceNoConstituida @PicoNoConstituida @spike
  Escenario: Ejecutar prueba de pico del flujo PJ no constituida
    Cuando ejecuto performance tipo "PICO" del flujo no constituida con 80 usuarios durante 120 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformanceNoConstituida @EstresNoConstituida @stress
  Escenario: Ejecutar prueba de estrés del flujo PJ no constituida
    Cuando ejecuto performance tipo "ESTRES" del flujo no constituida con 100 usuarios durante 180 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión

  @PerformanceNoConstituida @ResistenciaNoConstituida @endurance
  Escenario: Ejecutar prueba de resistencia del flujo PJ no constituida
    Cuando ejecuto performance tipo "RESISTENCIA" del flujo no constituida con 30 usuarios durante 600 segundos
    Entonces se genera el resumen de performance en el reporte
    Y el informe de performance debe contener tps percentiles dispersión y decisión
