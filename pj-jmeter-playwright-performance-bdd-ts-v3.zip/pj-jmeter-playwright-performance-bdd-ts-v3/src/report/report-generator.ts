import path from 'path';
import { loadAllEvidence, escapeHtml } from '../utils/evidence';
import { writeText } from '../utils/fs';
import { EvidenceRecord, PerformanceSummary } from '../types';

const records = loadAllEvidence();
const performanceSummaries = records
  .map(record => record.performanceSummary ?? (record.response.bodyJson as PerformanceSummary | undefined))
  .filter((summary): summary is PerformanceSummary => Boolean(summary?.testType && summary?.decision));

writeText(path.resolve(process.cwd(), 'reports/html/index.html'), renderIndex(records, performanceSummaries));
writeText(path.resolve(process.cwd(), 'reports/html/evidencias.html'), renderEvidence(records));
writeText(path.resolve(process.cwd(), 'reports/html/informe-performance.html'), renderPerformanceReport(performanceSummaries));
writeText(path.resolve(process.cwd(), 'reports/html/dispersion.html'), renderDispersionReport(performanceSummaries));
writeText(path.resolve(process.cwd(), 'reports/performance/informe-performance.md'), renderPerformanceMarkdown(performanceSummaries));

console.log('Reportes generados:');
console.log('- reports/html/index.html');
console.log('- reports/html/evidencias.html');
console.log('- reports/html/informe-performance.html');
console.log('- reports/html/dispersion.html');
console.log('- reports/performance/informe-performance.md');


function renderPerformanceMarkdown(summaries: PerformanceSummary[]): string {
  const summary = summaries[summaries.length - 1];
  if (!summary) return '# Informe de Performance\n\nNo hay ejecución de performance registrada.\n';
  return `# Informe de Pruebas de Performance - ${summary.flowType}

## 1. Resumen ejecutivo

- **Flujo:** ${summary.flowType}
- **Tipo de prueba:** ${summary.testType}
- **Ambiente:** ${summary.environment}
- **Fecha inicio:** ${summary.startedAt}
- **Fecha fin:** ${summary.finishedAt}
- **Decisión:** ${summary.decision.status}
- **Conclusión ejecutiva:** ${summary.decision.summary}

## 2. Objetivo

${summary.testObjective}

## 3. Configuración

| Campo | Valor |
|---|---:|
| Usuarios virtuales | ${summary.vus} |
| Ramp up | ${summary.rampSeconds} s |
| Duración | ${summary.durationSeconds} s |
| Think time | ${summary.thinkTimeMs} ms |
| Base URL | ${summary.baseUrl} |

## 4. Resultados

| Métrica | Valor |
|---|---:|
| Total iteraciones | ${summary.totalIterations} |
| Iteraciones OK | ${summary.successfulIterations} |
| Iteraciones con error | ${summary.failedIterations} |
| TPS | ${summary.tps} |
| Throughput/min | ${summary.throughputPerMinute} |
| Success rate | ${(summary.successRate * 100).toFixed(2)}% |
| Error rate | ${(summary.errorRate * 100).toFixed(2)}% |
| Promedio | ${summary.avgMs} ms |
| Mínimo | ${summary.minMs} ms |
| Máximo | ${summary.maxMs} ms |
| Desviación estándar | ${summary.stdDevMs} ms |
| Coeficiente de variación | ${summary.coefficientOfVariation} |
| p50 | ${summary.p50Ms} ms |
| p75 | ${summary.p75Ms} ms |
| p90 | ${summary.p90Ms} ms |
| p95 | ${summary.p95Ms} ms |
| p99 | ${summary.p99Ms} ms |
| Outliers estimados | ${summary.outliers} |

## 5. Criterios de aceptación

| Criterio | Umbral | Resultado |
|---|---:|---|
| Error rate | <= ${(summary.thresholds.maxErrorRate * 100).toFixed(2)}% | ${summary.criteria.errorRatePassed ? 'Cumple' : 'No cumple'} |
| p95 | ${summary.thresholds.p95MaxMs <= 0 ? 'Sin umbral' : '<= ' + summary.thresholds.p95MaxMs + ' ms'} | ${summary.criteria.p95Passed ? 'Cumple' : 'No cumple'} |
| TPS mínimo | ${summary.thresholds.minTps <= 0 ? 'Sin umbral' : '>= ' + summary.thresholds.minTps} | ${summary.criteria.tpsPassed ? 'Cumple' : 'No cumple'} |
| Dispersión CV | <= ${summary.thresholds.maxCoefficientOfVariation} | ${summary.criteria.dispersionPassed ? 'Cumple' : 'No cumple'} |

## 6. Recomendaciones

${summary.decision.recommendations.map(item => `- ${item}`).join('\n')}

## 7. Archivos generados

- HTML ejecutivo: reports/html/informe-performance.html
- Dispersión HTML: reports/html/dispersion.html
- Dispersión CSV: ${summary.dispersionCsv}
- Resumen JSON: reports/performance/performance-summary.json
- Logs: reports/logs/pj-execution.log
`;
}

function renderIndex(items: EvidenceRecord[], summaries: PerformanceSummary[]): string {
  const ok = items.filter(r => r.success).length;
  const bad = items.length - ok;
  const latestSummary = summaries[summaries.length - 1];
  return page('Reporte PJ Performance API', `
<h1>Reporte HTML - PJ migrado desde JMeter</h1>
<p>Automatización API con Playwright + TypeScript + Cucumber/Gherkin. Sin videos ni screenshots para evitar overhead en performance.</p>
<div class="cards">
  <div class="metric"><strong>Evidencias</strong><span>${items.length}</span></div>
  <div class="metric"><strong>OK</strong><span class="ok">${ok}</span></div>
  <div class="metric"><strong>Error</strong><span class="bad">${bad}</span></div>
  <div class="metric"><strong>Escenarios</strong><span>${new Set(items.map(r => r.scenario)).size}</span></div>
</div>
${latestSummary ? renderExecutiveCard(latestSummary) : '<p>No existe resumen de performance todavía. Ejecuta npm run test:performance y luego npm run report.</p>'}
<h2>Detalle de evidencias</h2>
<table><thead><tr><th>Fecha</th><th>Escenario</th><th>Operación</th><th>Status</th><th>Duración</th><th>Documento</th><th>Headers negocio</th></tr></thead><tbody>
${items.map(r => `<tr><td>${escapeHtml(r.timestamp)}</td><td>${escapeHtml(r.scenario)}</td><td>${escapeHtml(r.operation)}</td><td class="${r.success ? 'ok' : 'bad'}">${r.response.status}</td><td>${r.response.durationMs} ms</td><td>${escapeHtml([r.documentType, r.documentNumber].filter(Boolean).join(' '))}</td><td class="small">busresponsemessage=${escapeHtml(r.response.busResponseMessage ?? '')}<br/>srvresponsecode=${escapeHtml(r.response.srvResponseCode ?? '')}<br/>srvresponsemessage=${escapeHtml(r.response.srvResponseMessage ?? '')}</td></tr>`).join('\n')}
</tbody></table>
<p class="small">Ver también: <a href="informe-performance.html">Informe de performance</a> | <a href="dispersion.html">Reporte de dispersión</a> | <a href="evidencias.html">Evidencias técnicas</a></p>`);
}

function renderEvidence(items: EvidenceRecord[]): string {
  return page('Evidencias PJ', `
<h1>Evidencias técnicas</h1>
<p>Incluye request, response, response headers y headers de negocio por operación. No incluye evidencia visual porque esta suite está orientada a performance API.</p>
${items.map(r => `<section class="card"><h2>${escapeHtml(r.operation)} - HTTP ${r.response.status}</h2><p><strong>Escenario:</strong> ${escapeHtml(r.scenario)}</p><h3>Request</h3><pre>${escapeHtml(JSON.stringify(r.request, null, 2))}</pre><h3>Response headers</h3><pre>${escapeHtml(JSON.stringify(r.response.headers, null, 2))}</pre><h3>Response body</h3><pre>${escapeHtml(pretty(r.response.bodyText))}</pre></section>`).join('\n')}`);
}

function renderPerformanceReport(summaries: PerformanceSummary[]): string {
  const summary = summaries[summaries.length - 1];
  if (!summary) return page('Informe de Performance', '<h1>Informe de Performance</h1><p>No hay ejecución de performance registrada.</p>');

  return page('Informe de Performance', `
<h1>Informe de Pruebas de Performance - ${summary.flowType}</h1>
<section class="card">
<h2>1. Resumen ejecutivo</h2>
${renderExecutiveCard(summary)}
<p><strong>Objetivo:</strong> ${escapeHtml(summary.testObjective)}</p>
<p><strong>Decisión:</strong> <span class="${decisionClass(summary.decision.status)}">${summary.decision.status}</span> - ${escapeHtml(summary.decision.summary)}</p>
</section>
<section class="card"><h2>2. Configuración de la prueba</h2>${renderConfigTable(summary)}</section>
<section class="card"><h2>3. Métricas principales</h2>${renderMetricsTable(summary)}</section>
<section class="card"><h2>4. Criterios de aceptación</h2>${renderCriteriaTable(summary)}</section>
<section class="card"><h2>5. Reporte de dispersión</h2><p>La dispersión muestra la variabilidad de tiempos por iteración. Una dispersión alta puede indicar colas, saturación, intermitencia de servicios dependientes o datos inestables.</p>${renderScatter(summary)}</section>
<section class="card"><h2>6. Headers de negocio muestreados</h2>${renderSampleResponses(summary)}</section>
<section class="card"><h2>7. Recomendaciones</h2><ul>${summary.decision.recommendations.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul></section>
<section class="card"><h2>8. Conclusión</h2><p>${conclusion(summary)}</p></section>
`);
}

function renderDispersionReport(summaries: PerformanceSummary[]): string {
  const summary = summaries[summaries.length - 1];
  if (!summary) return page('Reporte de Dispersión', '<h1>Reporte de Dispersión</h1><p>No hay data de dispersión.</p>');
  return page('Reporte de Dispersión', `
<h1>Reporte de Dispersión - ${summary.flowType} - ${summary.testType}</h1>
<p><strong>Archivo CSV:</strong> ${escapeHtml(summary.dispersionCsv)}</p>
${renderScatter(summary)}
<h2>Muestras</h2>
<table><thead><tr><th>VU</th><th>Iteración</th><th>Offset inicio</th><th>Duración</th><th>Status</th><th>Resultado</th></tr></thead><tbody>
${summary.samples.slice(0, 1000).map(sample => `<tr><td>${sample.vu}</td><td>${sample.iteration}</td><td>${sample.startOffsetMs} ms</td><td>${sample.durationMs} ms</td><td>${sample.status}</td><td class="${sample.success ? 'ok' : 'bad'}">${sample.success ? 'OK' : 'ERROR'}</td></tr>`).join('\n')}
</tbody></table>`);
}

function renderExecutiveCard(summary: PerformanceSummary): string {
  return `<div class="cards">
    <div class="metric"><strong>Flujo</strong><span>${summary.flowType}</span></div>
    <div class="metric"><strong>Tipo</strong><span>${summary.testType}</span></div>
    <div class="metric"><strong>Decisión</strong><span class="${decisionClass(summary.decision.status)}">${summary.decision.status}</span></div>
    <div class="metric"><strong>TPS</strong><span>${summary.tps}</span></div>
    <div class="metric"><strong>Error rate</strong><span>${(summary.errorRate * 100).toFixed(2)}%</span></div>
    <div class="metric"><strong>p95</strong><span>${summary.p95Ms} ms</span></div>
    <div class="metric"><strong>p99</strong><span>${summary.p99Ms} ms</span></div>
  </div>`;
}

function renderConfigTable(summary: PerformanceSummary): string {
  return table([
    ['Ambiente', summary.environment],
    ['Base URL', summary.baseUrl],
    ['Flujo', summary.flowType],
    ['Tipo de prueba', summary.testType],
    ['Inicio', summary.startedAt],
    ['Fin', summary.finishedAt],
    ['Usuarios virtuales', String(summary.vus)],
    ['Ramp up', `${summary.rampSeconds} s`],
    ['Duración', `${summary.durationSeconds} s`],
    ['Think time', `${summary.thinkTimeMs} ms`]
  ]);
}

function renderMetricsTable(summary: PerformanceSummary): string {
  return table([
    ['Total iteraciones', String(summary.totalIterations)],
    ['Iteraciones exitosas', String(summary.successfulIterations)],
    ['Iteraciones fallidas', String(summary.failedIterations)],
    ['TPS', String(summary.tps)],
    ['Throughput por minuto', String(summary.throughputPerMinute)],
    ['Success rate', `${(summary.successRate * 100).toFixed(2)}%`],
    ['Error rate', `${(summary.errorRate * 100).toFixed(2)}%`],
    ['Mínimo', `${summary.minMs} ms`],
    ['Promedio', `${summary.avgMs} ms`],
    ['Máximo', `${summary.maxMs} ms`],
    ['Desviación estándar', `${summary.stdDevMs} ms`],
    ['Coeficiente de variación', String(summary.coefficientOfVariation)],
    ['p50', `${summary.p50Ms} ms`],
    ['p75', `${summary.p75Ms} ms`],
    ['p90', `${summary.p90Ms} ms`],
    ['p95', `${summary.p95Ms} ms`],
    ['p99', `${summary.p99Ms} ms`],
    ['Outliers estimados', String(summary.outliers)]
  ]);
}

function renderCriteriaTable(summary: PerformanceSummary): string {
  return `<table><thead><tr><th>Criterio</th><th>Umbral</th><th>Resultado</th></tr></thead><tbody>
<tr><td>Error rate</td><td>&lt;= ${(summary.thresholds.maxErrorRate * 100).toFixed(2)}%</td><td class="${summary.criteria.errorRatePassed ? 'ok' : 'bad'}">${summary.criteria.errorRatePassed ? 'Cumple' : 'No cumple'}</td></tr>
<tr><td>p95</td><td>${summary.thresholds.p95MaxMs <= 0 ? 'Sin umbral' : '&lt;= ' + summary.thresholds.p95MaxMs + ' ms'}</td><td class="${summary.criteria.p95Passed ? 'ok' : 'bad'}">${summary.criteria.p95Passed ? 'Cumple' : 'No cumple'}</td></tr>
<tr><td>TPS mínimo</td><td>${summary.thresholds.minTps <= 0 ? 'Sin umbral' : '&gt;= ' + summary.thresholds.minTps}</td><td class="${summary.criteria.tpsPassed ? 'ok' : 'bad'}">${summary.criteria.tpsPassed ? 'Cumple' : 'No cumple'}</td></tr>
<tr><td>Dispersión CV</td><td>&lt;= ${summary.thresholds.maxCoefficientOfVariation}</td><td class="${summary.criteria.dispersionPassed ? 'ok' : 'bad'}">${summary.criteria.dispersionPassed ? 'Cumple' : 'No cumple'}</td></tr>
</tbody></table>`;
}

function renderSampleResponses(summary: PerformanceSummary): string {
  if (!summary.sampleResponses.length) return '<p>No se capturaron responses de muestra.</p>';
  return `<table><thead><tr><th>Operación</th><th>Status</th><th>Duración</th><th>busresponsemessage</th><th>srvresponsecode</th><th>srvresponsemessage</th></tr></thead><tbody>
${summary.sampleResponses.map(sample => `<tr><td>${escapeHtml(sample.operation)}</td><td>${sample.status}</td><td>${sample.durationMs} ms</td><td>${escapeHtml(sample.busResponseMessage ?? '')}</td><td>${escapeHtml(sample.srvResponseCode ?? '')}</td><td>${escapeHtml(sample.srvResponseMessage ?? '')}</td></tr>`).join('\n')}
</tbody></table>`;
}

function renderScatter(summary: PerformanceSummary): string {
  const width = 900;
  const height = 360;
  const padding = 45;
  const samples = summary.samples.slice(0, 1200);
  const maxX = Math.max(...samples.map(s => s.endOffsetMs), summary.durationSeconds * 1000, 1);
  const maxY = Math.max(...samples.map(s => s.durationMs), summary.p95Ms, 1);
  const points = samples.map(sample => {
    const x = padding + (sample.endOffsetMs / maxX) * (width - padding * 2);
    const y = height - padding - (sample.durationMs / maxY) * (height - padding * 2);
    const color = sample.success ? '#0369a1' : '#dc2626';
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3" fill="${color}"><title>VU ${sample.vu} iter ${sample.iteration}: ${sample.durationMs} ms</title></circle>`;
  }).join('\n');
  const p95Y = height - padding - (summary.p95Ms / maxY) * (height - padding * 2);
  return `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Dispersión de tiempos" style="width:100%;max-width:${width}px;background:#fff;border:1px solid #e5e7eb;border-radius:10px">
<line x1="${padding}" y1="${height - padding}" x2="${width - padding}" y2="${height - padding}" stroke="#334155" />
<line x1="${padding}" y1="${padding}" x2="${padding}" y2="${height - padding}" stroke="#334155" />
<line x1="${padding}" y1="${p95Y.toFixed(1)}" x2="${width - padding}" y2="${p95Y.toFixed(1)}" stroke="#f97316" stroke-dasharray="6 4" />
<text x="${width - padding - 80}" y="${p95Y - 6}" font-size="12" fill="#f97316">p95 ${summary.p95Ms} ms</text>
${points}
<text x="${width / 2 - 60}" y="${height - 8}" font-size="12">Tiempo de ejecución</text>
<text x="10" y="20" font-size="12">Duración ms</text>
</svg>
<p class="small">Puntos azules: iteraciones exitosas. Puntos rojos: iteraciones fallidas. Línea naranja: p95.</p>`;
}

function conclusion(summary: PerformanceSummary): string {
  if (summary.decision.status === 'APTO') return `De acuerdo con los resultados, el flujo ${summary.flowType} puede aprobarse bajo las condiciones y umbrales definidos para esta ejecución. Se recomienda conservar estos valores como línea base.`;
  if (summary.decision.status === 'OBSERVADO') return 'El resultado permite continuar con análisis técnico, pero no debería aprobarse sin revisar la causa de la degradación, dispersión o errores detectados.';
  return 'El resultado no cumple los criterios definidos. Se recomienda no aprobar el flujo hasta corregir las causas y repetir la prueba.';
}

function table(rows: Array<[string, string]>): string {
  return `<table><tbody>${rows.map(([k, v]) => `<tr><th>${escapeHtml(k)}</th><td>${escapeHtml(v)}</td></tr>`).join('\n')}</tbody></table>`;
}

function page(title: string, body: string): string {
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>
body{font-family:Arial,Helvetica,sans-serif;margin:24px;background:#f8fafc;color:#111827}table{border-collapse:collapse;width:100%;background:#fff;margin:12px 0}th,td{border:1px solid #e5e7eb;padding:8px;font-size:13px;text-align:left}th{background:#0f172a;color:#fff}.ok{color:#15803d;font-weight:bold}.bad{color:#b91c1c;font-weight:bold}.observed{color:#b45309;font-weight:bold}.card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;margin:16px 0}.cards{display:flex;flex-wrap:wrap;gap:10px}.metric{background:#e0f2fe;color:#075985;border-radius:8px;padding:10px 14px;min-width:120px}.metric strong{display:block;font-size:12px;color:#0f172a}.metric span{font-size:20px}pre{background:#111827;color:#f9fafb;padding:12px;border-radius:8px;overflow:auto}.small{font-size:12px;color:#475569}a{color:#0369a1}
</style></head><body>${body}</body></html>`;
}

function decisionClass(status: string): string {
  if (status === 'APTO') return 'ok';
  if (status === 'OBSERVADO') return 'observed';
  return 'bad';
}

function pretty(text: string): string {
  try { return JSON.stringify(JSON.parse(text), null, 2); } catch { return text; }
}
