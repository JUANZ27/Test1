import fs from 'fs';
import path from 'path';

for (const file of ['PJ.jmx', 'NoConstituida.jmx']) {
  const location = path.resolve(process.cwd(), 'docs/original', file);
  if (!fs.existsSync(location)) continue;
  const jmx = fs.readFileSync(location, 'utf-8');
  const samplers = Array.from(jmx.matchAll(/<HTTPSamplerProxy[^>]*testname="([^"]+)"[\s\S]*?<stringProp name="HTTPSampler.path">([^<]+)<\/stringProp>[\s\S]*?<stringProp name="HTTPSampler.method">([^<]+)<\/stringProp>/g));
  console.log(`\nResumen de samplers migrados desde ${file}`);
  for (const [, name, endpoint, method] of samplers) {
    console.log(`- ${name}: ${method} ${endpoint}`);
  }
}
