import path from 'path';
import { appendText, fileExists, writeText } from './fs';

const generatedFile = path.resolve(process.cwd(), 'reports/generated/documentos-generados.csv');
const header = [
  'timestamp',
  'environment',
  'documentType',
  'documentNumber',
  'operation',
  'source',
  'responseStatus',
  'busResponseMessage',
  'srvResponseCode',
  'srvResponseMessage'
].join(';') + '\n';

export function saveGeneratedDocument(row: {
  environment: string;
  documentType: string;
  documentNumber: string;
  operation: string;
  source: string;
  responseStatus?: number;
  busResponseMessage?: string;
  srvResponseCode?: string;
  srvResponseMessage?: string;
}): void {
  if (!fileExists(generatedFile)) writeText(generatedFile, header);
  appendText(generatedFile, [
    new Date().toISOString(),
    row.environment,
    row.documentType,
    row.documentNumber,
    row.operation,
    row.source,
    String(row.responseStatus ?? ''),
    row.busResponseMessage ?? '',
    row.srvResponseCode ?? '',
    row.srvResponseMessage ?? ''
  ].map(csvCell).join(';') + '\n');
}

function csvCell(value: string): string {
  const escaped = value.replace(/"/g, '""');
  return /[;"\n\r]/.test(escaped) ? `"${escaped}"` : escaped;
}
