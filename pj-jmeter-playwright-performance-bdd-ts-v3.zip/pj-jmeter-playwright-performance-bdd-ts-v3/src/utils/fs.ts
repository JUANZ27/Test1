import fs from 'fs';
import path from 'path';

export function ensureDir(dir: string): void {
  fs.mkdirSync(dir, { recursive: true });
}

export function writeText(file: string, content: string): void {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, content, 'utf-8');
}

export function appendText(file: string, content: string): void {
  ensureDir(path.dirname(file));
  fs.appendFileSync(file, content, 'utf-8');
}

export function readText(file: string, defaultValue = ''): string {
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf-8') : defaultValue;
}

export function fileExists(file: string): boolean {
  return fs.existsSync(file);
}
