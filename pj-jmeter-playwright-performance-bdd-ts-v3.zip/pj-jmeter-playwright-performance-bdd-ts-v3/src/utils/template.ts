export function renderTemplate(template: string, values: Record<string, string>): string {
  return template.replace(/\$\{([^}]+)}/g, (_, key: string) => values[key] ?? '');
}

export function renderJsonTemplate<T = unknown>(template: string, values: Record<string, string>): T {
  return JSON.parse(renderTemplate(template, values)) as T;
}
