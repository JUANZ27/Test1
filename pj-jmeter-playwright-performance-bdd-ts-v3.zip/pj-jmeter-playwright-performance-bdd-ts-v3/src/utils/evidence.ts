import path from 'path';
import { EvidenceRecord } from '../types';
import { readText, writeText } from './fs';

export function saveEvidence(record: EvidenceRecord): string {
  const file = path.resolve(process.cwd(), `reports/evidence/${safeName(record.scenario)}-${record.operation}-${Date.now()}.json`);
  writeText(file, JSON.stringify(record, null, 2));
  return file;
}

export function buildEvidenceHtml(records: EvidenceRecord[]): string {
  return `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8" />
<title>Evidencia ${escapeHtml(records[0]?.scenario ?? '')}</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:24px;background:#f5f7fb;color:#1f2937}.card{background:#fff;border:1px solid #ddd;border-radius:10px;padding:16px;margin:12px 0;box-shadow:0 2px 6px rgba(0,0,0,.08)}.ok{color:#15803d;font-weight:bold}.bad{color:#b91c1c;font-weight:bold}.observed{color:#b45309;font-weight:bold}pre{background:#0f172a;color:#e5e7eb;padding:12px;border-radius:8px;overflow:auto;font-size:11px;max-height:380px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.tag{display:inline-block;background:#e0f2fe;color:#075985;border-radius:999px;padding:4px 10px;margin-right:6px;font-size:12px}.metric{display:inline-block;background:#f1f5f9;border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:4px}
</style>
</head>
<body>
<h1>Evidencia de ejecución - PJ Performance API</h1>
<p><strong>Escenario:</strong> ${escapeHtml(records[0]?.scenario ?? '')}</p>
${records.map(toCard).join('\n')}
</body>
</html>`;
}

export function safeName(input: string): string {
  return input.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 120) || 'scenario';
}

function toCard(record: EvidenceRecord): string {
  const summary = record.performanceSummary;
  if (summary) {
    return `<section class="card"><h2>${escapeHtml(record.operation)} <span class="${record.success ? 'ok' : 'bad'}">${escapeHtml(summary.decision.status)}</span></h2>
<p><span class="tag">${escapeHtml(summary.testType)}</span><span class="tag">VUS ${summary.vus}</span><span class="tag">TPS ${summary.tps}</span><span class="tag">p95 ${summary.p95Ms} ms</span><span class="tag">error ${(summary.errorRate * 100).toFixed(2)}%</span></p>
<div><span class="metric">Total: ${summary.totalIterations}</span><span class="metric">OK: ${summary.successfulIterations}</span><span class="metric">Error: ${summary.failedIterations}</span><span class="metric">Avg: ${summary.avgMs} ms</span><span class="metric">p99: ${summary.p99Ms} ms</span><span class="metric">StdDev: ${summary.stdDevMs} ms</span></div>
<h3>Decisión</h3><p>${escapeHtml(summary.decision.summary)}</p>
<ul>${summary.decision.recommendations.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>
<h3>Resumen JSON</h3><pre>${escapeHtml(JSON.stringify(summary, null, 2))}</pre></section>`;
  }
  return `<section class="card">
<h2>${escapeHtml(record.operation)} <span class="${record.success ? 'ok' : 'bad'}">${record.success ? 'OK' : 'ERROR'}</span></h2>
<p><span class="tag">${escapeHtml(record.environment)}</span><span class="tag">HTTP ${record.response.status}</span><span class="tag">${record.response.durationMs} ms</span>${record.documentType ? `<span class="tag">${record.documentType}: ${escapeHtml(record.documentNumber ?? '')}</span>` : ''}</p>
<p><strong>busresponsemessage:</strong> ${escapeHtml(record.response.busResponseMessage ?? '')}</p>
<p><strong>srvresponsecode:</strong> ${escapeHtml(record.response.srvResponseCode ?? '')}</p>
<p><strong>srvresponsemessage:</strong> ${escapeHtml(record.response.srvResponseMessage ?? '')}</p>
<div class="grid"><div><h3>Request</h3><pre>${escapeHtml(JSON.stringify(record.request, null, 2))}</pre></div><div><h3>Response headers</h3><pre>${escapeHtml(JSON.stringify(record.response.headers, null, 2))}</pre></div></div>
<h3>Response body</h3><pre>${escapeHtml(pretty(record.response.bodyText))}</pre>
</section>`;
}

function pretty(text: string): string {
  try { return JSON.stringify(JSON.parse(text), null, 2); } catch { return text; }
}

export function escapeHtml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

export function loadAllEvidence(): EvidenceRecord[] {
  const fs = require('fs') as typeof import('fs');
  const dir = path.resolve(process.cwd(), 'reports/evidence');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(file => file.endsWith('.json'))
    .flatMap(file => {
      try { return [JSON.parse(readText(path.join(dir, file))) as EvidenceRecord]; } catch { return []; }
    })
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}
