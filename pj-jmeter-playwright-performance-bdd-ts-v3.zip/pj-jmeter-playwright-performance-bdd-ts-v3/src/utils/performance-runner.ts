import path from 'path';
import { config } from '../support/config';
import { EvidenceRecord, PerformanceFlowType, PerformanceSample, PerformanceSummary, PerformanceTestType } from '../types';
import { generateDocuments } from './document-generator';
import { log } from './logger';
import { PjService } from '../services/pj-service';
import { writeText } from './fs';

interface PerformanceOptions {
  vus: number;
  durationSeconds: number;
  scenario: string;
  testType?: PerformanceTestType;
  flowType?: PerformanceFlowType;
}

interface Metrics {
  startedAt: number;
  totalIterations: number;
  successfulIterations: number;
  failedIterations: number;
  durations: number[];
  errors: string[];
  samples: PerformanceSample[];
  operationSamples: EvidenceRecord[];
}

export async function runPerformance(options: PerformanceOptions): Promise<EvidenceRecord> {
  const testType = options.testType ?? config.performance.testType;
  const flowType = options.flowType ?? config.performance.flowType;
  const vus = options.vus || config.performance.vus;
  const durationSeconds = options.durationSeconds || config.performance.durationSeconds;
  const rampSeconds = config.performance.rampSeconds;
  const startedAt = Date.now();
  const endAt = startedAt + durationSeconds * 1000;
  const metrics: Metrics = {
    startedAt,
    totalIterations: 0,
    successfulIterations: 0,
    failedIterations: 0,
    durations: [],
    errors: [],
    samples: [],
    operationSamples: []
  };

  log(`[PerformancePJ] Inicio flujo=${flowType} tipo=${testType} VUS=${vus} ramp=${rampSeconds}s duración=${durationSeconds}s thinkTime=${config.performance.thinkTimeMs}ms`);

  await Promise.all(
    Array.from({ length: vus }, (_, index) =>
      virtualUser(index + 1, endAt, metrics, options.scenario, rampDelay(index, vus, rampSeconds), flowType)
    )
  );

  const finishedAt = Date.now();
  const summary = buildSummary(flowType, testType, vus, rampSeconds, durationSeconds, startedAt, finishedAt, metrics);
  persistPerformanceArtifacts(summary);

  log('[PerformancePJ] Resumen ejecutivo', {
    flowType: summary.flowType,
    testType: summary.testType,
    decision: summary.decision.status,
    tps: summary.tps,
    totalIterations: summary.totalIterations,
    errorRate: summary.errorRate,
    avgMs: summary.avgMs,
    p95Ms: summary.p95Ms,
    p99Ms: summary.p99Ms,
    stdDevMs: summary.stdDevMs
  });

  return {
    id: `${Date.now()}-PerformancePJ`,
    scenario: options.scenario,
    operation: 'PerformancePJ',
    timestamp: new Date().toISOString(),
    environment: config.environment,
    request: {
      method: testType,
      url: config.baseUrl,
      headers: {},
      body: {
        flowType,
        testType,
        vus,
        rampSeconds,
        durationSeconds,
        thinkTimeMs: config.performance.thinkTimeMs,
        migratedFrom: flowType === 'NO_CONSTITUIDA' ? 'NoConstituida.jmx' : 'PJ.jmx'
      }
    },
    response: {
      status: summary.decision.status === 'NO_APTO' ? 500 : 200,
      statusText: summary.decision.status,
      headers: {},
      bodyText: JSON.stringify(summary, null, 2),
      bodyJson: summary,
      durationMs: finishedAt - startedAt
    },
    performanceSummary: summary,
    success: summary.decision.status !== 'NO_APTO'
  };
}

async function virtualUser(
  vu: number,
  endAt: number,
  metrics: Metrics,
  scenario: string,
  delayMs: number,
  flowType: PerformanceFlowType
): Promise<void> {
  if (delayMs > 0) await sleep(delayMs);
  let iteration = 0;

  while (Date.now() < endAt) {
    iteration += 1;
    const start = Date.now();
    const ctx = { documents: generateDocuments(), evidence: [] as EvidenceRecord[], scenario };

    try {
      const service = new PjService(ctx);
      if (flowType === 'NO_CONSTITUIDA') await service.fullFlowNoConstituida();
      else await service.fullFlow();

      const durationMs = Date.now() - start;
      const flowSuccess = ctx.evidence.length > 0 && ctx.evidence.every(item => item.success);
      const flowStatus = flowSuccess ? 200 : lastStatus(ctx.evidence);
      if (flowSuccess) metrics.successfulIterations += 1;
      else metrics.failedIterations += 1;
      metrics.durations.push(durationMs);
      captureSamples(metrics, ctx.evidence);
      captureDispersion(metrics, {
        vu,
        iteration,
        timestamp: new Date().toISOString(),
        startOffsetMs: start - metrics.startedAt,
        endOffsetMs: Date.now() - metrics.startedAt,
        durationMs,
        status: flowStatus,
        success: flowSuccess,
        error: flowSuccess ? undefined : `Flujo con respuesta no exitosa. HTTP final: ${flowStatus}`
      });
    } catch (error) {
      const durationMs = Date.now() - start;
      const message = (error as Error).message;
      metrics.failedIterations += 1;
      metrics.durations.push(durationMs);
      metrics.errors.push(`VU ${vu} ITER ${iteration}: ${message}`);
      captureDispersion(metrics, {
        vu,
        iteration,
        timestamp: new Date().toISOString(),
        startOffsetMs: start - metrics.startedAt,
        endOffsetMs: Date.now() - metrics.startedAt,
        durationMs,
        status: 500,
        success: false,
        error: message
      });
    } finally {
      metrics.totalIterations += 1;
      if (config.performance.thinkTimeMs > 0) await sleep(config.performance.thinkTimeMs);
    }
  }
}

function lastStatus(evidence: EvidenceRecord[]): number {
  const last = evidence[evidence.length - 1];
  return last?.response.status ?? 500;
}

function captureSamples(metrics: Metrics, evidence: EvidenceRecord[]): void {
  if (metrics.operationSamples.length >= config.performance.sampleLimit) return;
  metrics.operationSamples.push(...evidence.slice(0, config.performance.sampleLimit - metrics.operationSamples.length));
}

function captureDispersion(metrics: Metrics, sample: PerformanceSample): void {
  if (metrics.samples.length < config.performance.maxDispersionSamples) metrics.samples.push(sample);
}

function buildSummary(
  flowType: PerformanceFlowType,
  testType: PerformanceTestType,
  vus: number,
  rampSeconds: number,
  durationSeconds: number,
  startedAt: number,
  finishedAt: number,
  metrics: Metrics
): PerformanceSummary {
  const sorted = [...metrics.durations].sort((a, b) => a - b);
  const avg = average(sorted);
  const stdDev = standardDeviation(sorted, avg);
  const coefficientOfVariation = avg > 0 ? round(stdDev / avg, 4) : 0;
  const elapsedSeconds = Math.max((finishedAt - startedAt) / 1000, 1);
  const tps = round(metrics.successfulIterations / elapsedSeconds, 2);
  const throughputPerMinute = round(tps * 60, 2);
  const errorRate = metrics.totalIterations ? round(metrics.failedIterations / metrics.totalIterations, 4) : 0;
  const successRate = metrics.totalIterations ? round(metrics.successfulIterations / metrics.totalIterations, 4) : 0;
  const p95 = percentile(sorted, 0.95);
  const decisionInput = {
    errorRate,
    p95,
    tps,
    coefficientOfVariation,
    totalIterations: metrics.totalIterations,
    failedIterations: metrics.failedIterations
  };
  const decision = evaluateDecision(testType, flowType, decisionInput);

  return {
    flowType,
    testType,
    testObjective: objectiveFor(testType, flowType),
    environment: config.environment,
    baseUrl: config.baseUrl,
    startedAt: new Date(startedAt).toISOString(),
    finishedAt: new Date(finishedAt).toISOString(),
    vus,
    rampSeconds,
    durationSeconds,
    thinkTimeMs: config.performance.thinkTimeMs,
    totalIterations: metrics.totalIterations,
    successfulIterations: metrics.successfulIterations,
    failedIterations: metrics.failedIterations,
    tps,
    throughputPerMinute,
    successRate,
    errorRate,
    minMs: sorted[0] ?? 0,
    avgMs: Math.round(avg),
    maxMs: sorted[sorted.length - 1] ?? 0,
    stdDevMs: Math.round(stdDev),
    coefficientOfVariation,
    p50Ms: percentile(sorted, 0.50),
    p75Ms: percentile(sorted, 0.75),
    p90Ms: percentile(sorted, 0.90),
    p95Ms: p95,
    p99Ms: percentile(sorted, 0.99),
    outliers: countOutliers(sorted, avg, stdDev),
    thresholds: {
      maxErrorRate: config.performance.maxErrorRate,
      p95MaxMs: config.performance.p95MaxMs,
      minTps: config.performance.minTps,
      maxCoefficientOfVariation: config.performance.maxCoefficientOfVariation
    },
    criteria: {
      errorRatePassed: errorRate <= config.performance.maxErrorRate,
      p95Passed: config.performance.p95MaxMs <= 0 || p95 <= config.performance.p95MaxMs,
      tpsPassed: config.performance.minTps <= 0 || tps >= config.performance.minTps,
      dispersionPassed: coefficientOfVariation <= config.performance.maxCoefficientOfVariation
    },
    decision,
    sampleLimit: config.performance.maxDispersionSamples,
    dispersionCsv: 'reports/performance/dispersion.csv',
    samples: metrics.samples,
    sampleResponses: metrics.operationSamples.map(sample => ({
      operation: sample.operation,
      status: sample.response.status,
      durationMs: sample.response.durationMs,
      busResponseMessage: sample.response.busResponseMessage,
      srvResponseCode: sample.response.srvResponseCode,
      srvResponseMessage: sample.response.srvResponseMessage
    })),
    errors: metrics.errors.slice(0, 50)
  };
}

function evaluateDecision(
  testType: PerformanceTestType,
  flowType: PerformanceFlowType,
  data: { errorRate: number; p95: number; tps: number; coefficientOfVariation: number; totalIterations: number; failedIterations: number }
) {
  const errorOk = data.errorRate <= config.performance.maxErrorRate;
  const p95Ok = config.performance.p95MaxMs <= 0 || data.p95 <= config.performance.p95MaxMs;
  const tpsOk = config.performance.minTps <= 0 || data.tps >= config.performance.minTps;
  const dispersionOk = data.coefficientOfVariation <= config.performance.maxCoefficientOfVariation;
  const commonOk = errorOk && p95Ok && tpsOk;
  const flowName = flowType === 'NO_CONSTITUIDA' ? 'No Constituida' : 'PJ Constituida';

  if (data.totalIterations === 0) {
    return {
      status: 'NO_APTO' as const,
      summary: `No se obtuvieron iteraciones válidas para ${flowName}. La prueba no permite tomar una decisión.`,
      recommendations: ['Revisar token, datos dinámicos, headers obligatorios del JMX, conectividad y endpoint base antes de repetir.']
    };
  }

  if (testType === 'ESTRES') {
    if (data.failedIterations > 0 || !commonOk) {
      return {
        status: 'OBSERVADO' as const,
        summary: `La prueba de estrés identificó degradación o errores en ${flowName}. Esto ayuda a ubicar el límite operativo.`,
        recommendations: ['Revisar punto de quiebre, capacidad de backend y saturación por endpoint.', 'Repetir con escalones de usuarios para determinar el máximo estable.', 'No usar esta carga como carga nominal hasta estabilizar error rate, p95 y TPS.']
      };
    }
    return {
      status: 'APTO' as const,
      summary: `El flujo ${flowName} soportó la carga de estrés configurada sin superar los umbrales definidos.`,
      recommendations: ['Incrementar gradualmente los VUS para encontrar el límite real.', 'Validar métricas de infraestructura durante la siguiente ejecución.']
    };
  }

  if (testType === 'PICO') {
    if (commonOk) {
      return {
        status: dispersionOk ? 'APTO' as const : 'OBSERVADO' as const,
        summary: dispersionOk ? `El sistema soportó el pico configurado para ${flowName}.` : `El sistema respondió al pico para ${flowName}, pero la dispersión de tiempos indica variabilidad alta.`,
        recommendations: dispersionOk ? ['Mantener el umbral como referencia para regresión de performance.'] : ['Revisar latencias atípicas y comportamiento de colas/caché durante picos.']
      };
    }
    return {
      status: 'NO_APTO' as const,
      summary: `El sistema no soportó adecuadamente el pico configurado para ${flowName}.`,
      recommendations: ['Reducir ráfaga o mejorar capacidad antes de aceptar escenarios de alta concurrencia.', 'Revisar p95, errores y endpoints con mayor latencia.']
    };
  }

  if (testType === 'RESISTENCIA') {
    if (commonOk && dispersionOk) {
      return {
        status: 'APTO' as const,
        summary: `La prueba de resistencia no evidenció degradación relevante para ${flowName}.`,
        recommendations: ['Para una certificación real, ejecutar por una ventana mayor y monitorear memoria, CPU, conexiones y errores acumulados.']
      };
    }
    return {
      status: 'OBSERVADO' as const,
      summary: `La prueba de resistencia evidencia degradación, errores o dispersión alta para ${flowName}. Requiere análisis antes de aprobación.`,
      recommendations: ['Revisar tendencia de latencia por tiempo y errores acumulados.', 'Ejecutar una prueba más larga con monitoreo de recursos y logs de backend.']
    };
  }

  if (commonOk && dispersionOk) {
    return {
      status: 'APTO' as const,
      summary: `El flujo ${flowName} cumple los criterios definidos para prueba de carga.`,
      recommendations: ['Conservar los umbrales como baseline para futuras regresiones.', 'Comparar próximos resultados contra TPS, p95, error rate y dispersión.']
    };
  }

  return {
    status: 'NO_APTO' as const,
    summary: `El flujo ${flowName} no cumple los criterios de carga definidos. No se recomienda aprobar sin análisis/corrección.`,
    recommendations: ['Revisar endpoints con mayor latencia, errores de negocio y respuesta de infraestructura.', 'Ajustar capacidad o datos de prueba y repetir ejecución.']
  };
}

function objectiveFor(testType: PerformanceTestType, flowType: PerformanceFlowType): string {
  const flowName = flowType === 'NO_CONSTITUIDA' ? 'No Constituida' : 'PJ Constituida';
  switch (testType) {
    case 'CARGA': return `Validar que el flujo ${flowName} soporta la carga esperada dentro de los umbrales de tiempo y error.`;
    case 'PICO': return `Validar comportamiento de ${flowName} ante una ráfaga corta de usuarios o incremento súbito de tráfico.`;
    case 'ESTRES': return `Identificar degradación, límite operativo o punto de quiebre del flujo ${flowName}.`;
    case 'RESISTENCIA': return `Validar estabilidad del flujo ${flowName} durante una ejecución prolongada.`;
  }
}

function persistPerformanceArtifacts(summary: PerformanceSummary): void {
  writeText(path.resolve(process.cwd(), 'reports/performance/performance-summary.json'), JSON.stringify(summary, null, 2));
  writeText(path.resolve(process.cwd(), 'reports/performance/dispersion.csv'), renderDispersionCsv(summary.samples));
}

function renderDispersionCsv(samples: PerformanceSample[]): string {
  const header = 'timestamp;vu;iteration;startOffsetMs;endOffsetMs;durationMs;status;success;error\n';
  return header + samples.map(sample => [
    sample.timestamp,
    sample.vu,
    sample.iteration,
    sample.startOffsetMs,
    sample.endOffsetMs,
    sample.durationMs,
    sample.status,
    sample.success,
    csvCell(sample.error ?? '')
  ].join(';')).join('\n') + '\n';
}

function csvCell(value: string): string {
  const escaped = value.replace(/"/g, '""');
  return /[;"\n\r]/.test(escaped) ? `"${escaped}"` : escaped;
}

function rampDelay(index: number, vus: number, rampSeconds: number): number {
  if (vus <= 1 || rampSeconds <= 0) return 0;
  return Math.floor((index * rampSeconds * 1000) / vus);
}

function percentile(sorted: number[], p: number): number {
  if (!sorted.length) return 0;
  const index = Math.ceil(p * sorted.length) - 1;
  return sorted[Math.max(0, Math.min(index, sorted.length - 1))];
}

function average(values: number[]): number {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

function standardDeviation(values: number[], avg: number): number {
  if (!values.length) return 0;
  const variance = values.reduce((acc, value) => acc + Math.pow(value - avg, 2), 0) / values.length;
  return Math.sqrt(variance);
}

function countOutliers(values: number[], avg: number, stdDev: number): number {
  if (!values.length || stdDev === 0) return 0;
  const upper = avg + stdDev * 3;
  return values.filter(value => value > upper).length;
}

function round(value: number, decimals: number): number {
  const factor = Math.pow(10, decimals);
  return Math.round(value * factor) / factor;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
