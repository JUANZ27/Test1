import path from 'path';
import { appendText } from './fs';

const logFile = path.resolve(process.cwd(), 'reports/logs/pj-execution.log');

export function log(message: string, data?: unknown): void {
  const line = `[${new Date().toISOString()}] ${message}`;
  console.log(line);
  appendText(logFile, line + '\n');
  if (data !== undefined) {
    const rendered = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    console.log(rendered);
    appendText(logFile, rendered + '\n');
  }
}

export function logResponseHeaderSummary(operation: string, status: number, headers: Record<string, string>, body: string): void {
  const lower = Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v]));
  log(`[${operation}] HTTP Status: ${status}`);
  log(`[${operation}] response.header.busresponsemessage: ${lower.busresponsemessage ?? ''}`);
  log(`[${operation}] response.header.srvresponsecode: ${lower.srvresponsecode ?? ''}`);
  log(`[${operation}] response.header.srvresponsemessage: ${lower.srvresponsemessage ?? ''}`);
  log(`[${operation}] response.headers`, headers);
  log(`[${operation}] response.body`, prettyBody(body));
}

function prettyBody(body: string): string {
  try {
    return JSON.stringify(JSON.parse(body), null, 2);
  } catch {
    return body;
  }
}
