import path from 'path';
import { config } from '../support/config';
import { GeneratedDocuments } from '../types';
import { fileExists, readText, writeText } from './fs';

const sequenceFile = path.resolve(process.cwd(), 'reports/generated/document-sequence.json');

interface SequenceState {
  dni: number;
  rucBase: number;
  noConstituidaDocumentNumber: number;
}

export function generateDocuments(): GeneratedDocuments {
  const dni = nextDni();
  const noConstituidaDocumentNumber = nextNoConstituidaDocumentNumber();

  if (config.documents.useFixedRuc) {
    return {
      dni,
      ruc: config.documents.fixedRuc,
      noConstituidaDocumentNumber,
      source: 'FIXED'
    };
  }

  if (config.documents.mode === 'RANDOM') {
    return {
      dni: randomDni(),
      ruc: randomRuc20(),
      noConstituidaDocumentNumber: randomEightDigits(),
      source: 'RANDOM'
    };
  }

  return {
    dni,
    ruc: nextRuc20(),
    noConstituidaDocumentNumber,
    source: 'INCREMENTAL'
  };
}

function loadState(): SequenceState {
  if (!fileExists(sequenceFile)) {
    const initial = {
      dni: config.documents.dniStart,
      rucBase: Number(config.documents.rucStart.slice(0, 10)),
      noConstituidaDocumentNumber: config.documents.noConstituidaDocumentStart
    };
    writeText(sequenceFile, JSON.stringify(initial, null, 2));
    return initial;
  }
  const state = JSON.parse(readText(sequenceFile)) as Partial<SequenceState>;
  return {
    dni: state.dni ?? config.documents.dniStart,
    rucBase: state.rucBase ?? Number(config.documents.rucStart.slice(0, 10)),
    noConstituidaDocumentNumber: state.noConstituidaDocumentNumber ?? config.documents.noConstituidaDocumentStart
  };
}

function saveState(state: SequenceState): void {
  writeText(sequenceFile, JSON.stringify(state, null, 2));
}

function nextDni(): string {
  const state = loadState();
  const dni = String(state.dni).padStart(8, '0');
  state.dni += 1;
  saveState(state);
  return dni;
}

function nextNoConstituidaDocumentNumber(): string {
  const state = loadState();
  const documentNumber = String(state.noConstituidaDocumentNumber).padStart(8, '0');
  state.noConstituidaDocumentNumber += 1;
  saveState(state);
  return documentNumber;
}

function nextRuc20(): string {
  const state = loadState();
  const base10 = String(state.rucBase).padStart(10, '0').slice(0, 10);
  const ruc = base10 + rucCheckDigit(base10);
  state.rucBase += 1;
  saveState(state);
  return ruc;
}

function randomDni(): string {
  return randomEightDigits();
}

function randomEightDigits(): string {
  return Array.from({ length: 8 }, () => Math.floor(Math.random() * 10)).join('');
}

function randomRuc20(): string {
  const body = '20' + Array.from({ length: 8 }, () => Math.floor(Math.random() * 10)).join('');
  return body + rucCheckDigit(body);
}

function rucCheckDigit(base10: string): string {
  const weights = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  const sum = base10.split('').reduce((acc, digit, index) => acc + Number(digit) * weights[index], 0);
  const remainder = sum % 11;
  let checkDigit = 11 - remainder;
  if (checkDigit === 10) checkDigit = 0;
  if (checkDigit === 11) checkDigit = 1;
  return String(checkDigit);
}
