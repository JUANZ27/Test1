import path from 'path';
import { config } from '../support/config';
import { GeneratedDocuments, EvidenceRecord } from '../types';
import { readText } from '../utils/fs';
import { renderJsonTemplate } from '../utils/template';
import { sendApi } from './api-client';
import { saveGeneratedDocument } from '../utils/csv-store';
import { log } from '../utils/logger';

interface FlowContext {
  token?: string;
  documents?: GeneratedDocuments;
  expNumber?: string;
  evidence: EvidenceRecord[];
  scenario: string;
}

export class PjService {
  constructor(private readonly ctx: FlowContext) {}

  async token(): Promise<EvidenceRecord> {
    const operation = 'TokenPJ';
    const exchange = await sendApi({
      method: 'POST',
      baseUrl: config.baseUrl,
      path: config.paths.token,
      operation,
      headers: {
        authorization: config.token.authorizationBasic,
        'content-type': 'application/x-www-form-urlencoded',
        'ocp-apim-subscription-key': config.token.subscriptionKey,
        grant_type: config.token.grantType
      },
      form: {
        grant_type: config.token.grantType
      }
    });

    const token = extractJsonPath(exchange.response.bodyJson, 'access_token');
    const validToken = Boolean(token && token !== 'TOKEN_NOT_FOUND');
    if (validToken) this.ctx.token = token;

    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status) && validToken);
    this.ctx.evidence.push(evidence);

    if (!validToken) {
      log('[TokenPJ] No se obtuvo access_token. Se bloquearán llamadas de negocio para evitar errores 500 posteriores.');
    }
    return evidence;
  }

  async compliance(): Promise<EvidenceRecord> {
    await this.ensureValidToken();
    const docs = this.requireDocuments();
    const operation = 'CompliancePJ';
    const body = this.renderTemplate('src/data/compliance-request.template.json', { dni: docs.dni, ruc: docs.ruc });
    const exchange = await sendApi({
      method: 'POST',
      baseUrl: config.baseUrl,
      path: config.paths.compliance,
      operation,
      headers: this.businessHeaders({ xTraceId: config.business.xTraceIdCompliance }),
      body
    });

    this.ctx.expNumber = extractJsonPath(exchange.response.bodyJson, 'expedientNumber') ?? this.ctx.expNumber;
    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status), 'RUC', docs.ruc);
    this.ctx.evidence.push(evidence);
    this.saveDocuments(operation, docs, exchange);
    return evidence;
  }

  async apertura(): Promise<EvidenceRecord> {
    await this.ensureValidToken();
    const docs = this.requireDocuments();
    const operation = 'AperturaPJ';
    const body = this.renderTemplate('src/data/apertura-pj-request.template.json', {
      dni: docs.dni,
      ruc: docs.ruc,
      expNumber: this.ctx.expNumber ?? ''
    });
    const exchange = await sendApi({
      method: 'POST',
      baseUrl: config.baseUrl,
      path: config.paths.aperturaPj,
      operation,
      headers: this.businessHeaders(),
      body
    });

    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status), 'RUC', docs.ruc);
    this.ctx.evidence.push(evidence);
    return evidence;
  }

  async tracking(): Promise<EvidenceRecord> {
    await this.ensureValidToken();
    const docs = this.requireDocuments();
    const operation = 'TrackingPJ';
    const exchange = await sendApi({
      method: 'GET',
      baseUrl: config.baseUrl,
      path: config.paths.tracking,
      operation,
      headers: this.businessHeaders({ xTraceId: config.business.xTraceIdTracking }),
      params: { dni: docs.dni }
    });

    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status), 'DNI', docs.dni);
    this.ctx.evidence.push(evidence);
    return evidence;
  }

  async fullFlow(): Promise<EvidenceRecord[]> {
    log('[FlujoCompletoPJ] Inicio de flujo constituida migrado desde PJ.jmx');
    await this.token();
    await this.compliance();
    await this.apertura();
    await this.tracking();
    return this.ctx.evidence;
  }

  async complianceNoConstituida(): Promise<EvidenceRecord> {
    await this.ensureValidToken();
    const docs = this.requireDocuments();
    const operation = 'CreacionExpedienteNoConstituida';
    const body = this.renderTemplate('src/data/no-constituida-compliance-request.template.json', { dni: docs.dni });
    const exchange = await sendApi({
      method: 'POST',
      baseUrl: config.baseUrl,
      path: config.paths.compliance,
      operation,
      headers: this.businessHeaders({ xTraceId: config.business.xTraceIdCompliance }),
      body
    });

    this.ctx.expNumber = extractJsonPath(exchange.response.bodyJson, 'expedientNumber') ?? this.ctx.expNumber;
    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status), 'DNI', docs.dni);
    this.ctx.evidence.push(evidence);
    saveGeneratedDocument({
      environment: config.environment,
      documentType: 'DNI',
      documentNumber: docs.dni,
      operation,
      source: docs.source,
      responseStatus: exchange.response.status,
      busResponseMessage: exchange.response.busResponseMessage,
      srvResponseCode: exchange.response.srvResponseCode,
      srvResponseMessage: exchange.response.srvResponseMessage
    });
    return evidence;
  }

  async aperturaNoConstituida(): Promise<EvidenceRecord> {
    await this.ensureValidToken();
    const docs = this.requireDocuments();
    const operation = 'AperturaNoConstituida';
    const body = this.renderTemplate('src/data/no-constituida-apertura-request.template.json', {
      dni: docs.dni,
      documentNumber: docs.noConstituidaDocumentNumber,
      expNumber: this.ctx.expNumber ?? ''
    });
    const exchange = await sendApi({
      method: 'POST',
      baseUrl: config.baseUrl,
      path: config.paths.aperturaPj,
      operation,
      headers: this.businessHeaders({
        extraHeaders: {
          Channel: config.business.channel,
          'Consumer-Id': config.business.consumerId
        }
      }),
      body
    });

    const evidence = this.toEvidence(operation, exchange, this.isOk(exchange.response.status), 'DOC_NO_CONSTITUIDA', docs.noConstituidaDocumentNumber);
    this.ctx.evidence.push(evidence);
    saveGeneratedDocument({
      environment: config.environment,
      documentType: 'DOC_NO_CONSTITUIDA',
      documentNumber: docs.noConstituidaDocumentNumber,
      operation,
      source: docs.source,
      responseStatus: exchange.response.status,
      busResponseMessage: exchange.response.busResponseMessage,
      srvResponseCode: exchange.response.srvResponseCode,
      srvResponseMessage: exchange.response.srvResponseMessage
    });
    return evidence;
  }

  async fullFlowNoConstituida(): Promise<EvidenceRecord[]> {
    log('[FlujoCompletoNoConstituida] Inicio de flujo no constituida migrado desde NoConstituida.jmx');
    await this.token();
    await this.complianceNoConstituida();
    await this.aperturaNoConstituida();
    return this.ctx.evidence;
  }

  private async ensureValidToken(): Promise<void> {
    if (!this.ctx.token) {
      const record = await this.token();
      const token = extractJsonPath(record.response.bodyJson, 'access_token');
      if (token && token !== 'TOKEN_NOT_FOUND') this.ctx.token = token;
    }

    if (!this.ctx.token || this.ctx.token === 'TOKEN_NOT_FOUND') {
      throw new Error('No se ejecuta endpoint de negocio porque no existe access_token válido. Esto evita errores 500 posteriores al token y facilita el diagnóstico.');
    }
  }

  private requireDocuments(): GeneratedDocuments {
    if (!this.ctx.documents) {
      throw new Error('No existen documentos generados. Ejecuta el step: que genero documentos dinámicos para PJ');
    }
    return this.ctx.documents;
  }

  private businessHeaders(options: { xTraceId?: string; extraHeaders?: Record<string, string> } = {}): Record<string, string> {
    const headers: Record<string, string> = {
      authorization: `Bearer ${this.ctx.token ?? ''}`,
      'content-type': 'application/json',
      'ocp-apim-subscription-key': config.business.subscriptionKey,
      ...(options.extraHeaders ?? {})
    };
    if (options.xTraceId) headers['x-trace-id'] = options.xTraceId;
    return headers;
  }

  private renderTemplate(file: string, values: Record<string, string>): unknown {
    const template = readText(path.resolve(process.cwd(), file));
    return renderJsonTemplate(template, values);
  }

  private saveDocuments(
    operation: string,
    docs: GeneratedDocuments,
    exchange: { response: EvidenceRecord['response'] }
  ): void {
    for (const [documentType, documentNumber] of [['DNI', docs.dni], ['RUC', docs.ruc]]) {
      saveGeneratedDocument({
        environment: config.environment,
        documentType,
        documentNumber,
        operation,
        source: docs.source,
        responseStatus: exchange.response.status,
        busResponseMessage: exchange.response.busResponseMessage,
        srvResponseCode: exchange.response.srvResponseCode,
        srvResponseMessage: exchange.response.srvResponseMessage
      });
    }
  }

  private toEvidence(
    operation: string,
    exchange: { request: EvidenceRecord['request']; response: EvidenceRecord['response'] },
    success: boolean,
    documentType?: string,
    documentNumber?: string
  ): EvidenceRecord {
    return {
      id: `${Date.now()}-${operation}-${Math.random().toString(16).slice(2)}`,
      scenario: this.ctx.scenario,
      operation,
      timestamp: new Date().toISOString(),
      environment: config.environment,
      documentType,
      documentNumber,
      request: exchange.request,
      response: exchange.response,
      success
    };
  }

  private isOk(status: number): boolean {
    return status >= 200 && status < 300;
  }
}

function extractJsonPath(json: unknown, key: string): string | undefined {
  if (!json || typeof json !== 'object') return undefined;
  if (key in json) return String((json as Record<string, unknown>)[key]);
  for (const value of Object.values(json as Record<string, unknown>)) {
    if (value && typeof value === 'object') {
      const found = extractJsonPath(value, key);
      if (found) return found;
    }
  }
  return undefined;
}
