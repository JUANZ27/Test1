import { request, APIRequestContext } from '@playwright/test';
import { RequestLog, ResponseLog } from '../types';
import { logResponseHeaderSummary } from '../utils/logger';

export interface SendOptions {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  baseUrl: string;
  path: string;
  headers?: Record<string, string>;
  body?: unknown;
  form?: Record<string, string>;
  params?: Record<string, string>;
  operation: string;
}

export interface ApiExchange {
  request: RequestLog;
  response: ResponseLog;
}

export async function sendApi(options: SendOptions): Promise<ApiExchange> {
  const context = await request.newContext({
    baseURL: options.baseUrl,
    ignoreHTTPSErrors: true,
    extraHTTPHeaders: options.headers ?? {}
  });

  const url = buildUrl(options.baseUrl, options.path, options.params);
  const started = Date.now();
  try {
    const response = await dispatch(context, options);
    const durationMs = Date.now() - started;
    const headers = response.headers();
    const bodyText = await response.text();
    const bodyJson = parseJson(bodyText);
    const responseLog: ResponseLog = {
      status: response.status(),
      statusText: response.statusText(),
      headers,
      bodyText,
      bodyJson,
      durationMs,
      busResponseMessage: getHeader(headers, 'busresponsemessage'),
      srvResponseCode: getHeader(headers, 'srvresponsecode'),
      srvResponseMessage: getHeader(headers, 'srvresponsemessage')
    };

    const requestLog: RequestLog = {
      method: options.method,
      url,
      headers: maskHeaders(options.headers ?? {}),
      body: options.body,
      form: options.form ? maskForm(options.form) : undefined,
      params: options.params
    };

    logResponseHeaderSummary(options.operation, responseLog.status, headers, bodyText);
    return { request: requestLog, response: responseLog };
  } finally {
    await context.dispose();
  }
}

async function dispatch(context: APIRequestContext, options: SendOptions) {
  switch (options.method) {
    case 'GET':
      return context.get(options.path, { params: options.params, headers: options.headers });
    case 'POST':
      return context.post(options.path, {
        data: options.form ? undefined : options.body,
        form: options.form,
        params: options.params,
        headers: options.headers
      });
    case 'PUT':
      return context.put(options.path, { data: options.body, params: options.params, headers: options.headers });
    case 'DELETE':
      return context.delete(options.path, { params: options.params, headers: options.headers });
  }
}

function buildUrl(baseUrl: string, endpointPath: string, params?: Record<string, string>): string {
  const url = new URL(endpointPath, baseUrl.endsWith('/') ? baseUrl : baseUrl + '/');
  Object.entries(params ?? {}).forEach(([key, value]) => url.searchParams.set(key, value));
  return url.toString();
}

function parseJson(text: string): unknown | undefined {
  try {
    return text ? JSON.parse(text) : undefined;
  } catch {
    return undefined;
  }
}

function getHeader(headers: Record<string, string>, name: string): string | undefined {
  const found = Object.entries(headers).find(([key]) => key.toLowerCase() === name.toLowerCase());
  return found?.[1];
}

function maskHeaders(headers: Record<string, string>): Record<string, string> {
  const sensitive = ['authorization', 'ocp-apim-subscription-key'];
  return Object.fromEntries(Object.entries(headers).map(([key, value]) => [
    key,
    sensitive.includes(key.toLowerCase()) ? mask(value) : value
  ]));
}

function maskForm(form: Record<string, string>): Record<string, string> {
  return Object.fromEntries(Object.entries(form).map(([key, value]) => [key, key.toLowerCase().includes('secret') ? mask(value) : value]));
}

function mask(value: string): string {
  if (!value) return value;
  if (value.length <= 10) return '***';
  return value.slice(0, 6) + '***' + value.slice(-4);
}
