import { IWorldOptions, setWorldConstructor, World } from '@cucumber/cucumber';
import { GeneratedDocuments, EvidenceRecord } from '../types';

export class CustomWorld extends World {
  environment = 'stg';
  token?: string;
  documents?: GeneratedDocuments;
  expNumber?: string;
  evidence: EvidenceRecord[] = [];
  scenarioName = 'scenario';

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(CustomWorld);
