import { After, Before, Status } from '@cucumber/cucumber';
import path from 'path';
import { config } from './config';
import { CustomWorld } from './world';
import { buildEvidenceHtml, safeName, saveEvidence } from '../utils/evidence';
import { writeText } from '../utils/fs';
import { log } from '../utils/logger';

Before(async function (this: CustomWorld, scenario) {
  this.scenarioName = scenario.pickle.name;
  this.environment = config.environment;
  this.evidence = [];
  log(`[${this.scenarioName}] Inicio de escenario en ambiente ${this.environment}`);
});

After(async function (this: CustomWorld, scenario) {
  const name = safeName(this.scenarioName);
  const htmlPath = path.resolve(process.cwd(), `reports/html/scenarios/${name}.html`);
  writeText(htmlPath, buildEvidenceHtml(this.evidence));

  for (const record of this.evidence) saveEvidence(record);

  log(`[${scenario.pickle.name}] Resultado Cucumber: ${scenario.result?.status ?? Status.UNKNOWN}`);
});
