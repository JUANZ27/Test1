import dotenv from 'dotenv';
import path from 'path';
import { PerformanceFlowType, PerformanceTestType } from '../types';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

function env(name: string, defaultValue = ''): string {
  const value = process.env[name];
  return value === undefined || value === null || value === '' ? defaultValue : value;
}

function boolEnv(name: string, defaultValue = false): boolean {
  return ['true', '1', 'yes', 'y', 'si', 'sí'].includes(env(name, String(defaultValue)).toLowerCase());
}

function intEnv(name: string, defaultValue: number): number {
  const raw = env(name, String(defaultValue));
  const parsed = Number.parseInt(raw, 10);
  return Number.isFinite(parsed) ? parsed : defaultValue;
}

function numberEnv(name: string, defaultValue: number): number {
  const raw = env(name, String(defaultValue));
  const parsed = Number.parseFloat(raw);
  return Number.isFinite(parsed) ? parsed : defaultValue;
}

function testTypeEnv(name: string, defaultValue: PerformanceTestType): PerformanceTestType {
  const value = env(name, defaultValue).trim().toUpperCase();
  if (['CARGA', 'LOAD'].includes(value)) return 'CARGA';
  if (['PICO', 'SPIKE'].includes(value)) return 'PICO';
  if (['ESTRES', 'STRESS', 'ESTRÉS'].includes(value)) return 'ESTRES';
  if (['RESISTENCIA', 'ENDURANCE', 'SOAK'].includes(value)) return 'RESISTENCIA';
  return defaultValue;
}

function flowTypeEnv(name: string, defaultValue: PerformanceFlowType): PerformanceFlowType {
  const value = env(name, defaultValue).trim().toUpperCase();
  if (['NO_CONSTITUIDA', 'NO-CONSTITUIDA', 'INCORPORATION_IN_PROGRESS', 'NO_CONSTITUIDA_JMX'].includes(value)) return 'NO_CONSTITUIDA';
  return 'PJ_CONSTITUIDA';
}

export const config = {
  environment: env('ENVIRONMENT', 'stg'),
  baseUrl: env('BASE_URL', 'https://eu2-ibk-apm-stg-ext-001.azure-api.net'),
  paths: {
    token: env('TOKEN_PATH', '/bcv-security/v1/oauth/token'),
    compliance: env('COMPLIANCE_PATH', '/bcv-bacc-party-lifecycle-management/v1/business-account/initial-validation'),
    aperturaPj: env('APERTURA_PJ_PATH', '/bcv-bacc-party-lifecycle-management/v1/business-account'),
    tracking: env('TRACKING_PATH', '/bcv-bacc-party-lifecycle-management/v1/business-account/status-expedient')
  },
  token: {
    authorizationBasic: env('TOKEN_AUTHORIZATION_BASIC', 'Basic_REEMPLAZAR_AQUI'),
    subscriptionKey: env('TOKEN_SUBSCRIPTION_KEY', 'REEMPLAZAR_AQUI'),
    grantType: env('TOKEN_GRANT_TYPE', 'client_credentials')
  },
  business: {
    subscriptionKey: env('API_SUBSCRIPTION_KEY', 'REEMPLAZAR_AQUI'),
    xTraceIdCompliance: env('X_TRACE_ID_COMPLIANCE', 'b6735999dc71f5c23a66a3fc6079ca9b'),
    xTraceIdTracking: env('X_TRACE_ID_TRACKING', '123123-21312312-6654654'),
    channel: env('APERTURA_CHANNEL', 'DIGITAL'),
    consumerId: env('APERTURA_CONSUMER_ID', 'ELhZrjaJHLXCCoq8u6YTxFVtTnfh3l1C')
  },
  documents: {
    mode: env('DOCUMENT_GENERATION_MODE', 'INCREMENTAL').toUpperCase(),
    dniStart: intEnv('DNI_START', 40975592),
    rucStart: env('RUC_START', '20573044054'),
    noConstituidaDocumentStart: intEnv('NO_CONSTITUIDA_DOCUMENT_START', 60000001),
    useFixedRuc: boolEnv('USE_FIXED_RUC', false),
    fixedRuc: env('FIXED_RUC', '20573044054')
  },
  performance: {
    flowType: flowTypeEnv('PERF_FLOW_TYPE', 'PJ_CONSTITUIDA'),
    testType: testTypeEnv('PERF_TEST_TYPE', 'CARGA'),
    vus: intEnv('PERF_VUS', 50),
    rampSeconds: intEnv('PERF_RAMP_SECONDS', 1),
    durationSeconds: intEnv('PERF_DURATION_SECONDS', 60),
    thinkTimeMs: intEnv('PERF_THINK_TIME_MS', 0),
    maxErrorRate: numberEnv('PERF_MAX_ERROR_RATE', 0.01),
    p95MaxMs: intEnv('PERF_P95_MAX_MS', 3000),
    minTps: numberEnv('PERF_MIN_TPS', 0),
    maxCoefficientOfVariation: numberEnv('PERF_MAX_CV', 0.75),
    sampleLimit: intEnv('PERF_SAMPLE_LIMIT', 20),
    maxDispersionSamples: intEnv('PERF_MAX_DISPERSION_SAMPLES', 5000)
  }
};
