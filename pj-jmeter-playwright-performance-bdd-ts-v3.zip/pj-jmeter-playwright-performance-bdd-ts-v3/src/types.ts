export interface GeneratedDocuments {
  dni: string;
  ruc: string;
  noConstituidaDocumentNumber: string;
  source: 'INCREMENTAL' | 'RANDOM' | 'FIXED';
}

export type PerformanceTestType = 'CARGA' | 'PICO' | 'ESTRES' | 'RESISTENCIA';
export type PerformanceDecisionStatus = 'APTO' | 'OBSERVADO' | 'NO_APTO';
export type PerformanceFlowType = 'PJ_CONSTITUIDA' | 'NO_CONSTITUIDA';

export interface RequestLog {
  method: string;
  url: string;
  headers: Record<string, string>;
  body?: unknown;
  params?: Record<string, string>;
  form?: Record<string, string>;
}

export interface ResponseLog {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  bodyText: string;
  bodyJson?: unknown;
  durationMs: number;
  busResponseMessage?: string;
  srvResponseCode?: string;
  srvResponseMessage?: string;
}

export interface PerformanceSample {
  vu: number;
  iteration: number;
  timestamp: string;
  startOffsetMs: number;
  endOffsetMs: number;
  durationMs: number;
  status: number;
  success: boolean;
  error?: string;
}

export interface PerformanceDecision {
  status: PerformanceDecisionStatus;
  summary: string;
  recommendations: string[];
}

export interface PerformanceSummary {
  flowType: PerformanceFlowType;
  testType: PerformanceTestType;
  testObjective: string;
  environment: string;
  baseUrl: string;
  startedAt: string;
  finishedAt: string;
  vus: number;
  rampSeconds: number;
  durationSeconds: number;
  thinkTimeMs: number;
  totalIterations: number;
  successfulIterations: number;
  failedIterations: number;
  tps: number;
  throughputPerMinute: number;
  successRate: number;
  errorRate: number;
  minMs: number;
  avgMs: number;
  maxMs: number;
  stdDevMs: number;
  coefficientOfVariation: number;
  p50Ms: number;
  p75Ms: number;
  p90Ms: number;
  p95Ms: number;
  p99Ms: number;
  outliers: number;
  thresholds: {
    maxErrorRate: number;
    p95MaxMs: number;
    minTps: number;
    maxCoefficientOfVariation: number;
  };
  criteria: {
    errorRatePassed: boolean;
    p95Passed: boolean;
    tpsPassed: boolean;
    dispersionPassed: boolean;
  };
  decision: PerformanceDecision;
  sampleLimit: number;
  dispersionCsv: string;
  samples: PerformanceSample[];
  sampleResponses: Array<{
    operation: string;
    status: number;
    durationMs: number;
    busResponseMessage?: string;
    srvResponseCode?: string;
    srvResponseMessage?: string;
  }>;
  errors: string[];
}

export interface EvidenceRecord {
  id: string;
  scenario: string;
  operation: string;
  timestamp: string;
  environment: string;
  documentType?: string;
  documentNumber?: string;
  request: RequestLog;
  response: ResponseLog;
  success: boolean;
  performanceSummary?: PerformanceSummary;
}
